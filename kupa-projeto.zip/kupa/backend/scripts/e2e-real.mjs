#!/usr/bin/env node
/**
 * Verificação PONTA A PONTA da conexão com IA REAL: app/cliente -> backend -> provedor de IA -> resposta.
 *
 * Roda contra um backend JÁ HOSPEDADO. As credenciais vêm SÓ de variáveis de ambiente (nunca por argumento, nunca impressas):
 *   KUPA_BACKEND_URL   endereço https do backend (o que a hospedagem mostrou)
 *   KUPA_APP_TOKEN     o mesmo KUPA_APP_TOKEN configurado no backend
 *   E2E_PROVIDER       (opcional) openai | anthropic | gemini — por padrão testa TODOS os provedores configurados
 *   E2E_ALLOW_HTTP=1   (só para teste local) aceita http://
 *
 * Como distingue uma IA real de um texto fixo: manda um CÓDIGO ALEATÓRIO novo a cada execução e, numa segunda mensagem que
 * depende da primeira (contexto), exige que o modelo devolva esse código. Um servidor com respostas prontas não consegue.
 * Código de saída 0 SÓ se tudo passar. Escreve e2e-result.json (sem segredos) com a evidência.
 */
import { writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';

const URL_BASE = (process.env.KUPA_BACKEND_URL || '').trim().replace(/\/+$/, '');
const TOKEN = (process.env.KUPA_APP_TOKEN || '').trim();
const ALLOW_HTTP = process.env.E2E_ALLOW_HTTP === '1';
const ONLY = (process.env.E2E_PROVIDER || '').trim().toLowerCase();
const TIMEOUT_MS = Number(process.env.E2E_TIMEOUT_MS || 60000);

const results = [];
let failed = false;
const redact = (s) => (TOKEN ? String(s).split(TOKEN).join('[TOKEN]') : String(s));
const log = (s = '') => console.log(redact(s));
function record(step, ok, detail) {
  results.push({ step, ok, detail: redact(detail) });
  if (!ok) failed = true;
  log(`${ok ? 'PASSOU ' : 'FALHOU '} ${step}${detail ? ' — ' + detail : ''}`);
}

async function http(method, path, { body, token = TOKEN } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const headers = {};
    if (token) headers.authorization = `Bearer ${token}`;
    if (body !== undefined) headers['content-type'] = 'application/json';
    const res = await fetch(URL_BASE + path, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: ctrl.signal });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch { json = null; }
    return { status: res.status, json, text };
  } catch (err) {
    const why = err?.name === 'AbortError' ? 'tempo esgotado' : (err?.cause?.code || err?.message || 'erro de rede');
    return { status: 0, json: null, text: '', error: String(why) };
  } finally {
    clearTimeout(timer);
  }
}

function fail(msg) {
  record('pré-requisitos', false, msg);
  finish();
}

function finish() {
  const summary = { ok: !failed, quando: new Date().toISOString(), backend: URL_BASE.replace(/^(https?:\/\/[^/]+).*/, '$1'), etapas: results };
  try { writeFileSync('e2e-result.json', JSON.stringify(summary, null, 2)); } catch { /* sem permissão de escrita: ignora */ }
  log();
  if (failed) {
    log('RESULTADO: FALHOU — a conexão real com a IA NÃO foi comprovada. Veja a primeira linha FALHOU acima.');
    process.exit(1);
  }
  log('RESULTADO: CONEXÃO REAL COMPROVADA — backend -> provedor de IA -> resposta com o código aleatório devolvido no contexto.');
  process.exit(0);
}

if (!URL_BASE) fail('KUPA_BACKEND_URL não definida.');
else if (!TOKEN) fail('KUPA_APP_TOKEN não definido.');
else if (!/^https:\/\//i.test(URL_BASE) && !(ALLOW_HTTP && /^http:\/\//i.test(URL_BASE))) fail('KUPA_BACKEND_URL precisa ser https:// (http só com E2E_ALLOW_HTTP=1, em teste local).');
else await main();

async function main() {
  log(`Backend: ${URL_BASE}`);

  // 1) o endereço é mesmo um backend do KUPA?
  const health = await http('GET', '/health', { token: '' });
  if (health.status === 200 && health.json?.service === 'kupa-backend') record('1. /health responde como kupa-backend', true, `versão ${health.json.version || '?'}`);
  else { record('1. /health responde como kupa-backend', false, health.error ? `sem conexão (${health.error})` : `HTTP ${health.status}`); return finish(); }

  // 2) a autenticação está ligada (sem token e com token errado NÃO entram)
  const noTok = await http('GET', '/v1/config', { token: '' });
  const badTok = await http('GET', '/v1/config', { token: 'token-errado-' + randomBytes(4).toString('hex') });
  record('2. rejeita requisição sem token e com token errado', noTok.status === 401 && (badTok.status === 401 || badTok.status === 403), `sem token: HTTP ${noTok.status}; token errado: HTTP ${badTok.status}`);

  // 3) o token certo é aceito e há provedor configurado
  const cfg = await http('GET', '/v1/config');
  if (cfg.status !== 200) { record('3. token válido e configuração do backend', false, `HTTP ${cfg.status} ${cfg.json?.error?.code || ''}`); return finish(); }
  const providers = Array.isArray(cfg.json?.providers) ? cfg.json.providers : [];
  const ready = providers.filter((p) => p.configured).map((p) => p.name);
  record('3. token válido e há provedor de IA configurado', ready.length > 0, ready.length ? `prontos: ${ready.join(', ')}` : 'NENHUM provedor com chave e modelo no backend');
  if (!ready.length) return finish();
  const targets = ONLY ? ready.filter((n) => n === ONLY) : ready;
  if (!targets.length) { record('3b. provedor pedido está configurado', false, `E2E_PROVIDER=${ONLY} não está entre ${ready.join(', ')}`); return finish(); }

  for (const name of targets) {
    // 4) chamada REAL ao provedor
    const t = await http('POST', '/v1/ai/test', { body: { provider: name } });
    if (t.status === 200 && t.json?.ok) record(`4. [${name}] chamada real ao provedor`, true, `modelo ${t.json.model}, ${t.json.latencyMs} ms`);
    else { record(`4. [${name}] chamada real ao provedor`, false, `HTTP ${t.status} ${t.json?.error?.code || t.error || ''} ${(t.json?.error?.message || '').slice(0, 160)}`); continue; }

    // 5) conversa com CONTEXTO usando um código aleatório inédito
    const code = 'KUPA-' + randomBytes(4).toString('hex').toUpperCase();
    const q1 = `Memorize este código de teste: ${code}. Responda apenas com a palavra OK.`;
    const r1 = await http('POST', '/v1/ai/respond', { body: { messages: [{ role: 'user', text: q1 }], options: { provider: name, casual: false } } });
    if (r1.status !== 200 || r1.json?.status !== 'final' || !r1.json?.text) { record(`5a. [${name}] primeira mensagem`, false, `HTTP ${r1.status} ${r1.json?.error?.code || r1.error || ''}`); continue; }
    record(`5a. [${name}] primeira mensagem respondida`, true, `resposta: "${String(r1.json.text).slice(0, 60).replace(/\s+/g, ' ')}" (modelo ${r1.json.model})`);
    const q2 = 'Qual era o código de teste que pedi para memorizar? Responda apenas com o código.';
    const r2 = await http('POST', '/v1/ai/respond', {
      body: { messages: [{ role: 'user', text: q1 }, { role: 'assistant', text: r1.json.text }, { role: 'user', text: q2 }], options: { provider: name, casual: false } },
    });
    const echoed = r2.status === 200 && typeof r2.json?.text === 'string' && r2.json.text.toUpperCase().includes(code);
    record(`5b. [${name}] a IA lembrou do código aleatório (contexto real)`, echoed, echoed ? `devolveu ${code}` : `HTTP ${r2.status}; resposta: "${String(r2.json?.text || r2.json?.error?.code || '').slice(0, 80)}"`);
  }
  finish();
}
