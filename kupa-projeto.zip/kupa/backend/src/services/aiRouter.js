/**
 * AIRouter: escolhe provedor e modelo conforme a tarefa. Regras simples e explícitas (nada de "mágica"):
 *  - imagem anexada      -> modelo de visão (OPENAI_MODEL_VISION)
 *  - modo escolhido      -> classe pedida pelo usuário no modo (fast | reasoning | default)
 *  - tarefas de análise  -> raciocínio (OPENAI_MODEL_REASONING)
 *  - modo gamer / curto  -> rápido (OPENAI_MODEL_FAST)
 *  - resto               -> OPENAI_MODEL
 * Classe sem modelo configurado cai no OPENAI_MODEL (e o motivo informa isso). Privacidade/segurança não mudam com a escolha.
 */
export const MODEL_CLASSES = ['default', 'fast', 'vision', 'reasoning'];
const ANALYSIS_TASKS = new Set(['niche_survey', 'script', 'analyze_text']);

export function route({ task = 'general', hasImage = false, mode = 'chat', brief = false, modelClass = '' }, models, providerName = 'openai') {
  let wanted = 'default';
  let reason = 'conversa comum';
  if (hasImage) {
    wanted = 'vision';
    reason = 'há imagem anexada';
  } else if (modelClass === 'fast' || modelClass === 'reasoning') {
    wanted = modelClass;
    reason = `o modo ativo pede o modelo "${modelClass}"`;
  } else if (ANALYSIS_TASKS.has(task)) {
    wanted = 'reasoning';
    reason = `tarefa de análise (${task})`;
  } else if (mode === 'gamer' || brief) {
    wanted = 'fast';
    reason = 'resposta curta e rápida';
  }
  let model = models[wanted];
  if (!model) {
    if (wanted !== 'default') reason += ` (sem modelo "${wanted}" configurado: usando o padrão)`;
    wanted = 'default';
    model = models.default;
  }
  return { provider: providerName, modelClass: wanted, model, reason };
}

/**
 * Planeja QUAIS provedores tentar e em que ordem, só com fatos verificáveis: configuração, capacidades declaradas,
 * tamanho do contexto (se o limite foi informado), preferência do usuário e a ordem configurada. Não usa preço nem "qualidade" inventados.
 * @returns {{candidates: {provider:string, model:string, modelClass:string, reason:string}[], skipped: {provider:string, why:string}[], error?: {code:string, message:string}}}
 */
export function planProviders({ task = 'general', hasImage = false, needsTools = false, contextChars = 0, mode = 'chat', brief = false, modelClass = '', preference = 'auto' }, providers, order) {
  const skipped = [];
  const eligible = [];
  for (const name of order) {
    const p = providers.find(name);
    if (!p) continue;
    const st = p.status();
    const caps = p.capabilities();
    if (!st.configured) { skipped.push({ provider: name, why: 'não configurado no backend' }); continue; }
    if (hasImage && !caps.vision) { skipped.push({ provider: name, why: 'não aceita imagem' }); continue; }
    if (needsTools && !caps.tools) { skipped.push({ provider: name, why: 'não aceita ferramentas' }); continue; }
    if (caps.maxContextChars > 0 && contextChars > caps.maxContextChars) { skipped.push({ provider: name, why: 'contexto maior que o limite configurado' }); continue; }
    eligible.push(name);
  }
  let ordered = eligible;
  let explicit = false;
  if (preference && preference !== 'auto') {
    explicit = true;
    if (!providers.find(preference)) {
      return { candidates: [], skipped, error: { code: 'provider_unknown', message: `Provedor desconhecido: ${String(preference).slice(0, 30)}.` } };
    }
    if (!eligible.includes(preference)) {
      const why = skipped.find((s) => s.provider === preference)?.why || 'indisponível para este pedido';
      return { candidates: [], skipped, error: { code: 'provider_not_available', message: `O provedor escolhido (${preference}) não pode atender este pedido: ${why}.` } };
    }
    ordered = [preference, ...eligible.filter((n) => n !== preference)];
  }
  if (ordered.length === 0) {
    return { candidates: [], skipped, error: { code: 'no_provider_available', message: 'Nenhum provedor de IA está configurado e disponível para este pedido.' } };
  }
  const candidates = ordered.map((name, i) => {
    const r = route({ task, hasImage, mode, brief, modelClass }, providers.find(name).models(), name);
    const why = i === 0 ? (explicit ? 'escolhido por você' : 'primeiro da ordem entre os disponíveis') : 'reserva (só se o fallback estiver autorizado)';
    return { provider: name, model: r.model, modelClass: r.modelClass, reason: `${why}; modelo: ${r.reason}` };
  });
  return { candidates, skipped };
}
