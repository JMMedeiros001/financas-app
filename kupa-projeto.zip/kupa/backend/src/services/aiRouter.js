/**
 * AIRouter: escolhe provedor e modelo conforme a tarefa. Regras simples e explícitas (nada de "mágica"):
 *  - imagem anexada      -> modelo de visão (OPENAI_MODEL_VISION)
 *  - modo escolhido      -> classe pedida pelo usuário no modo (fast | reasoning | default)
 *  - tarefas de análise  -> raciocínio (OPENAI_MODEL_REASONING)
 *  - modo gamer / curto  -> rápido (OPENAI_MODEL_FAST)
 *  - resto               -> OPENAI_MODEL
 * Classe sem modelo configurado cai no OPENAI_MODEL (e o motivo informa isso). Privacidade/segurança não mudam com a escolha.
 */
export const MODEL_CLASSES = ['default', 'fast', 'vision', 'reasoning'];
const ANALYSIS_TASKS = new Set(['niche_survey', 'script', 'analyze_text']);

export function route({ task = 'general', hasImage = false, mode = 'chat', brief = false, modelClass = '' }, models, providerName = 'openai') {
  let wanted = 'default';
  let reason = 'conversa comum';
  if (hasImage) {
    wanted = 'vision';
    reason = 'há imagem anexada';
  } else if (modelClass === 'fast' || modelClass === 'reasoning') {
    wanted = modelClass;
    reason = `o modo ativo pede o modelo "${modelClass}"`;
  } else if (ANALYSIS_TASKS.has(task)) {
    wanted = 'reasoning';
    reason = `tarefa de análise (${task})`;
  } else if (mode === 'gamer' || brief) {
    wanted = 'fast';
    reason = 'resposta curta e rápida';
  }
  let model = models[wanted];
  if (!model) {
    if (wanted !== 'default') reason += ` (sem modelo "${wanted}" configurado: usando o padrão)`;
    wanted = 'default';
    model = models.default;
  }
  return { provider: providerName, modelClass: wanted, model, reason };
}
