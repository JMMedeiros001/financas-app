import crypto from 'node:crypto';

/**
 * Guarda, por poucos minutos, o estado de uma conversa que está esperando o resultado de uma ferramenta
 * executada no aparelho (ex.: captura de tela). Uso único: take() consome a sessão.
 */
export class SessionStore {
  constructor({ ttlMs = 300_000, max = 200, now = () => Date.now() } = {}) {
    this.ttlMs = ttlMs;
    this.max = max;
    this.now = now;
    this.map = new Map();
  }

  create(data) {
    this.#sweep();
    while (this.map.size >= this.max) this.map.delete(this.map.keys().next().value);
    const id = crypto.randomUUID();
    this.map.set(id, { ...data, expiresAt: this.now() + this.ttlMs });
    return id;
  }

  peek(id) {
    this.#sweep();
    return this.map.get(id) || null;
  }

  take(id) {
    this.#sweep();
    const session = this.map.get(id);
    if (!session) return null;
    this.map.delete(id);
    return session;
  }

  get size() {
    this.#sweep();
    return this.map.size;
  }

  #sweep() {
    const t = this.now();
    for (const [id, s] of this.map) if (s.expiresAt <= t) this.map.delete(id);
  }
}
