import { HttpError } from '../http.js';
import { ProviderError } from '../providers/openaiProvider.js';
import { buildInstructions } from '../prompts/system.js';
import { CLIENT_TOOL_NAMES, buildTools } from '../tools/registry.js';

const MODES = new Set(['chat', 'search', 'screen', 'gamer']);
const IMAGE_PREFIX = /^data:image\/(png|jpe?g|webp);base64,/i;
const MAX_MESSAGES = 40;
const MAX_TEXT = 20_000;
const MAX_IMAGES = 3;
const MAX_IMAGE_CHARS = 6_000_000;

const bad = (message) => new HttpError(400, 'bad_request', message);
const normalize = (text) => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

function toFunctionCallOutput(result) {
  let output;
  if (result.error) {
    output = `ERRO: ${result.error}`;
  } else if (result.imageDataUrl) {
    output = [
      { type: 'input_text', text: result.text || 'Captura da tela do usuário.' },
      { type: 'input_image', image_url: result.imageDataUrl, detail: 'auto' },
    ];
  } else {
    output = result.text || 'OK';
  }
  return { type: 'function_call_output', call_id: result.callId, output };
}

function buildInputItems(messages, attachments) {
  return messages.map((m, i) => {
    if (m.role === 'assistant') return { role: 'assistant', content: m.text };
    if (i === messages.length - 1 && attachments.length > 0) {
      return {
        role: 'user',
        content: [
          { type: 'input_text', text: m.text },
          ...attachments.map((a) => ({ type: 'input_image', image_url: a.dataUrl, detail: 'auto' })),
        ],
      };
    }
    return { role: 'user', content: m.text };
  });
}

/** AIService: camada independente entre o app e o provedor de IA (hoje: OpenAI). */
export class AIService {
  constructor({ config, provider, sessions, logger, now = () => new Date() }) {
    this.config = config;
    this.provider = provider;
    this.sessions = sessions;
    this.logger = logger;
    this.now = now;
  }

  describe() {
    const st = this.provider.status();
    return {
      provider: this.provider.name,
      model: st.model,
      modelConfigured: st.modelConfigured,
      apiKeyConfigured: st.apiKeyConfigured,
      webSearchEnabled: st.webSearchEnabled,
      clientTools: CLIENT_TOOL_NAMES,
      maxToolRounds: this.config.maxToolRounds,
    };
  }

  /** Teste REAL: faz uma chamada de verdade à OpenAI. Só deve ser considerado "conectado" se isto retornar. */
  async test() {
    const started = Date.now();
    const result = await this.provider.generate({
      instructions: 'Você é o KUPA. Faça exatamente o que o usuário pedir, de forma curta.',
      items: [{ role: 'user', content: 'Kupa, responda apenas: conexão funcionando.' }],
      tools: [],
    });
    return {
      ok: true,
      provider: this.provider.name,
      model: result.model,
      latencyMs: Date.now() - started,
      reply: result.text,
      replyMatches: normalize(result.text).includes('conexao funcionando'),
    };
  }

  async ask(body) {
    const req = this.#validate(body);
    let items;
    let rounds = 0;
    let settings = req.settings;

    if (req.sessionId) {
      const session = this.sessions.peek(req.sessionId);
      if (!session) throw new HttpError(410, 'session_expired', 'A sessão expirou. Faça a pergunta de novo.');
      const pending = new Set(session.pendingCallIds);
      for (const r of req.toolResults) {
        if (!pending.has(r.callId)) throw bad(`Resultado para uma chamada desconhecida: ${r.callId}`);
        pending.delete(r.callId);
      }
      if (pending.size > 0) throw bad('Faltam resultados de ferramentas pedidas pela IA.');
      this.sessions.take(req.sessionId);
      items = [...session.items, ...req.toolResults.map(toFunctionCallOutput)];
      rounds = session.rounds;
      settings = session.settings;
    } else {
      items = buildInputItems(req.messages, req.attachments);
    }

    const { tools, clientTools } = buildTools({
      allowWebSearch: settings.allowWebSearch,
      webSearchConfig: this.config.openai,
      enabledClientTools: settings.enabledTools,
    });
    const instructions = buildInstructions({
      language: settings.language,
      mode: settings.mode,
      brief: settings.brief,
      gameContext: settings.gameContext,
      timeZone: settings.timeZone,
      webSearchEnabled: settings.allowWebSearch,
      clientTools,
      now: this.now(),
    });

    const result = await this.provider.generate({ instructions, items, tools });

    if (result.toolCalls.length > 0) {
      const allowed = new Set(clientTools);
      const forbidden = result.toolCalls.find((c) => !allowed.has(c.name));
      if (forbidden) {
        this.logger?.warn('tool_not_allowed', { tool: forbidden.name });
        throw new ProviderError('tool_not_allowed', 'A IA pediu uma ferramenta que não está autorizada.', { status: 502 });
      }
      if (rounds + 1 > this.config.maxToolRounds) {
        throw new HttpError(422, 'too_many_tool_rounds', 'A IA pediu ferramentas demais para uma única pergunta.');
      }
      const sessionId = this.sessions.create({
        items: [...items, ...result.items],
        pendingCallIds: result.toolCalls.map((c) => c.callId),
        rounds: rounds + 1,
        settings,
      });
      return { status: 'tool_calls', sessionId, calls: result.toolCalls, text: result.text || '', model: result.model };
    }

    return {
      status: 'final',
      text: result.text,
      sources: result.sources,
      webSearchUsed: result.webSearchUsed,
      model: result.model,
      sessionId: null,
    };
  }

  #validate(body) {
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw bad('Corpo inválido.');
    const options = body.options && typeof body.options === 'object' ? body.options : {};

    const mode = options.mode === undefined ? 'chat' : options.mode;
    if (!MODES.has(mode)) throw bad('options.mode inválido.');

    const enabledTools = options.enabledTools === undefined ? [] : options.enabledTools;
    if (!Array.isArray(enabledTools)) throw bad('options.enabledTools deve ser uma lista.');
    for (const t of enabledTools) {
      if (!CLIENT_TOOL_NAMES.includes(t)) throw bad(`Ferramenta desconhecida: ${String(t).slice(0, 40)}`);
    }

    const gameContext = typeof options.gameContext === 'string' ? options.gameContext.slice(0, 2000) : '';
    const language = typeof options.language === 'string' && options.language.length <= 20 ? options.language : 'pt-BR';
    const timeZone = typeof options.timeZone === 'string' && options.timeZone.length <= 64 ? options.timeZone : '';

    const settings = {
      mode,
      language,
      timeZone,
      gameContext,
      brief: Boolean(options.brief) || mode === 'gamer',
      allowWebSearch: Boolean(options.allowWebSearch) && this.config.openai.webSearch,
      enabledTools: [...new Set(enabledTools)],
    };

    const sessionId = typeof body.sessionId === 'string' && body.sessionId ? body.sessionId : null;
    if (sessionId) {
      const results = body.toolResults;
      if (!Array.isArray(results) || results.length === 0) throw bad('toolResults é obrigatório ao continuar uma sessão.');
      const toolResults = results.map((r) => {
        if (!r || typeof r.callId !== 'string') throw bad('toolResults[].callId inválido.');
        const out = { callId: r.callId };
        if (typeof r.text === 'string') out.text = r.text.slice(0, 8000);
        if (typeof r.error === 'string') out.error = r.error.slice(0, 1000);
        if (r.imageDataUrl !== undefined && r.imageDataUrl !== null) {
          if (typeof r.imageDataUrl !== 'string' || !IMAGE_PREFIX.test(r.imageDataUrl) || r.imageDataUrl.length > MAX_IMAGE_CHARS) {
            throw bad('toolResults[].imageDataUrl inválido ou grande demais.');
          }
          out.imageDataUrl = r.imageDataUrl;
        }
        return out;
      });
      return { sessionId, toolResults, settings, messages: [], attachments: [] };
    }

    const messages = body.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > MAX_MESSAGES) {
      throw bad(`messages deve ter de 1 a ${MAX_MESSAGES} itens.`);
    }
    const cleanMessages = messages.map((m) => {
      if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.text !== 'string') throw bad('messages[] inválido.');
      const text = m.text.trim();
      if (!text || text.length > MAX_TEXT) throw bad('messages[].text vazio ou grande demais.');
      return { role: m.role, text };
    });
    if (cleanMessages[cleanMessages.length - 1].role !== 'user') throw bad('A última mensagem deve ser do usuário.');

    const attachments = Array.isArray(body.attachments) ? body.attachments : [];
    if (attachments.length > MAX_IMAGES) throw bad(`No máximo ${MAX_IMAGES} imagens por pergunta.`);
    const cleanAttachments = attachments.map((a) => {
      if (!a || a.type !== 'image' || typeof a.dataUrl !== 'string' || !IMAGE_PREFIX.test(a.dataUrl) || a.dataUrl.length > MAX_IMAGE_CHARS) {
        throw bad('attachments[] inválido (use data URL de imagem png, jpeg ou webp).');
      }
      return { dataUrl: a.dataUrl };
    });

    return { sessionId: null, toolResults: [], settings, messages: cleanMessages, attachments: cleanAttachments };
  }
}
