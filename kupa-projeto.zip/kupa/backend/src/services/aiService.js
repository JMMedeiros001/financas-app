import { HttpError } from '../http.js';
import { ProviderError } from '../providers/errors.js';
import { buildInstructions } from '../prompts/system.js';
import { CLIENT_TOOLS, CLIENT_TOOL_NAMES, validateToolArgs } from '../tools/registry.js';
import { planProviders } from './aiRouter.js';
import { TASKS, buildTaskInstructions, sanitizeNiche } from '../prompts/contentTasks.js';

const MODES = new Set(['chat', 'search', 'screen', 'gamer']);
const PROACTIVITY = new Set(['OFF', 'LOW', 'MEDIUM', 'HIGH']);
const MODEL_CLASSES = new Set(['default', 'fast', 'reasoning']);
const IMAGE_PREFIX = /^data:image\/(png|jpe?g|webp);base64,/i;
const MAX_MESSAGES = 40;
const MAX_TEXT = 20_000;
const MAX_IMAGES = 3;
const MAX_IMAGE_CHARS = 6_000_000;

const bad = (message) => new HttpError(400, 'bad_request', message);
const normalize = (text) => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

/**
 * AIService (AI Orchestrator): camada independente entre o app e os provedores de IA.
 * Fluxo: valida -> planeja provedores (AIRouter) -> chama o provedor -> valida ferramentas pedidas -> devolve.
 * Nenhum provedor controla o aparelho: só pode PEDIR ferramentas autorizadas, e o app decide.
 */
export class AIService {
  constructor({ config, providers, sessions, logger, now = () => new Date() }) {
    this.config = config;
    this.providers = providers;
    this.sessions = sessions;
    this.logger = logger;
    this.now = now;
  }

  #defaultProvider() {
    const order = this.config.providerOrder;
    const configured = order.map((n) => this.providers.find(n)).filter((p) => p && p.status().configured);
    return configured[0] || this.providers.find(order[0]) || this.providers.all()[0];
  }

  describe() {
    const def = this.#defaultProvider();
    const st = def.status();
    return {
      // compatibilidade com o app antigo: dados do provedor padrão
      provider: def.name,
      model: st.model,
      modelConfigured: st.modelConfigured,
      apiKeyConfigured: st.apiKeyConfigured,
      webSearchEnabled: st.webSearchEnabled,
      // todos os provedores (a chave NUNCA aparece; só se está configurada)
      providers: this.providers.all().map((p) => {
        const s = p.status();
        return { name: p.name, label: p.label, configured: s.configured, apiKeyConfigured: s.apiKeyConfigured, modelConfigured: s.modelConfigured, model: s.model, models: p.models(), capabilities: p.capabilities() };
      }),
      providerOrder: this.config.providerOrder,
      tasks: TASKS,
      clientTools: CLIENT_TOOL_NAMES,
      maxToolRounds: this.config.maxToolRounds,
    };
  }

  /** Teste REAL: faz uma chamada de verdade ao provedor. Só deve ser considerado "conectado" se isto retornar. */
  async test(providerName) {
    const p = providerName ? this.providers.find(providerName) : this.#defaultProvider();
    if (!p) throw bad('Provedor desconhecido.');
    const started = Date.now();
    const result = await p.ping();
    return {
      ok: true,
      provider: p.name,
      model: result.model,
      latencyMs: Date.now() - started,
      reply: result.text,
      replyMatches: normalize(result.text).includes('conexao funcionando'),
    };
  }

  async ask(body) {
    const req = this.#validate(body);
    let settings = req.settings;

    // ---- continuação depois de uma ferramenta: SEMPRE o mesmo provedor (o estado é dele); sem fallback, para não duplicar operações
    if (req.sessionId) {
      const session = this.sessions.peek(req.sessionId);
      if (!session) throw new HttpError(410, 'session_expired', 'A sessão expirou. Faça a pergunta de novo.');
      const pending = new Set(session.pendingCallIds);
      for (const r of req.toolResults) {
        if (!pending.has(r.callId)) throw bad(`Resultado para uma chamada desconhecida: ${r.callId}`);
        pending.delete(r.callId);
      }
      if (pending.size > 0) throw bad('Faltam resultados de ferramentas pedidas pela IA.');
      this.sessions.take(req.sessionId);
      settings = session.settings;
      const provider = this.providers.find(session.provider);
      const clientDefs = this.#clientDefs(settings);
      const tools = this.#toolsFor(provider, settings, clientDefs);
      const instructions = this.#instructions(settings, tools, clientDefs);
      const result = await provider.resume({ instructions, state: session.state, toolResults: req.toolResults, tools, model: session.routing.model });
      return this.#finish({ provider, routing: session.routing, result, settings: { ...settings, hasImage: settings.hasImage || req.toolResults.some((r) => r.imageDataUrl) }, rounds: session.rounds, clientDefs, fallback: null });
    }

    // ---- primeira chamada: planeja provedores
    const clientDefs = this.#clientDefs(settings);
    const hasImage = req.attachments.length > 0;
    const contextChars = req.messages.reduce((n, m) => n + m.text.length, 0);
    const plan = planProviders(
      { task: settings.task, hasImage, needsTools: clientDefs.length > 0, contextChars, mode: settings.mode, brief: settings.brief, modelClass: settings.modelClass, preference: settings.provider },
      this.providers,
      this.config.providerOrder,
    );
    if (plan.error) {
      throw new ProviderError(plan.error.code, plan.error.message, { status: 503 });
    }
    settings = { ...settings, hasImage };

    // Fallback SÓ se o usuário autorizou e só para falhas do provedor (nunca para um pedido inválido); no máximo uma alternativa.
    const attempts = settings.fallbackAllowed ? plan.candidates.slice(0, 2) : plan.candidates.slice(0, 1);
    let lastError;
    for (let i = 0; i < attempts.length; i += 1) {
      const routing = attempts[i];
      const provider = this.providers.find(routing.provider);
      const tools = this.#toolsFor(provider, settings, clientDefs);
      const instructions = this.#instructions(settings, tools, clientDefs);
      this.logger?.info('route', { provider: routing.provider, modelClass: routing.modelClass, reason: routing.reason });
      try {
        const result = await provider.start({ instructions, messages: req.messages, attachments: req.attachments, tools, model: routing.model });
        const fallback = i > 0 ? { from: attempts[0].provider, to: routing.provider, reason: lastError?.code || 'falha' } : null;
        return this.#finish({ provider, routing, result, settings, rounds: 0, clientDefs, fallback });
      } catch (err) {
        lastError = err;
        const canFallback = err instanceof ProviderError && err.fallbackEligible && i + 1 < attempts.length;
        if (!canFallback) throw err;
        this.logger?.warn('fallback', { from: routing.provider, code: err.code });
      }
    }
    throw lastError;
  }

  #clientDefs(settings) {
    return settings.enabledTools.filter((n) => CLIENT_TOOLS[n]).map((name) => ({ name, description: CLIENT_TOOLS[name].description, parameters: CLIENT_TOOLS[name].parameters }));
  }

  /** Ferramentas neutras para ESTE provedor: a busca só entra se ele a suporta (e combina com as ferramentas do KUPA). */
  #toolsFor(provider, settings, clientDefs) {
    const caps = provider.capabilities();
    const webSearch = settings.allowWebSearch && caps.webSearch && (caps.webSearchWithTools || clientDefs.length === 0);
    return { client: caps.tools ? clientDefs : [], webSearch };
  }

  #instructions(settings, tools, clientDefs) {
    return buildInstructions({
      task: settings.task,
      taskInstructions: buildTaskInstructions(settings.task, settings.niche),
      assistantName: settings.assistantName,
      modeName: settings.modeName,
      modeInstructions: settings.modeInstructions,
      modeNotes: settings.modeNotes,
      proactivity: settings.proactivity,
      verbosity: settings.verbosity,
      language: settings.language,
      mode: settings.mode,
      brief: settings.brief,
      gameContext: settings.gameContext,
      timeZone: settings.timeZone,
      webSearchEnabled: tools.webSearch,
      clientTools: tools.client.map((t) => t.name),
      now: this.now(),
    });
  }

  #finish({ provider, routing, result, settings, rounds, clientDefs, fallback }) {
    const routeInfo = { provider: provider.name, modelClass: routing.modelClass, reason: routing.reason, ...(fallback ? { fallback } : {}) };
    if (result.toolCalls.length > 0) {
      const allowed = new Set(clientDefs.map((d) => d.name));
      const forbidden = result.toolCalls.find((c) => !allowed.has(c.name));
      if (forbidden) {
        this.logger?.warn('tool_not_allowed', { tool: forbidden.name, provider: provider.name });
        throw new ProviderError('tool_not_allowed', 'A IA pediu uma ferramenta que não está autorizada.', { status: 502 });
      }
      // a saída da IA é dado não confiável: confere tipos, limites e campos extras antes de repassar ao app
      for (const call of result.toolCalls) {
        const checked = validateToolArgs(call.name, call.arguments);
        if (!checked.ok) {
          this.logger?.warn('tool_invalid_args', { tool: call.name, provider: provider.name });
          throw new ProviderError('tool_invalid_args', `A IA pediu a ferramenta ${call.name} com argumentos inválidos (${checked.error}). Bloqueei.`, { status: 502 });
        }
        call.arguments = checked.args;
      }
      if (rounds + 1 > this.config.maxToolRounds) {
        throw new HttpError(422, 'too_many_tool_rounds', 'A IA pediu ferramentas demais para uma única pergunta.');
      }
      const sessionId = this.sessions.create({
        provider: provider.name,
        routing: { model: routing.model, modelClass: routing.modelClass, reason: routing.reason },
        state: result.state,
        pendingCallIds: result.toolCalls.map((c) => c.callId),
        rounds: rounds + 1,
        settings,
      });
      return { status: 'tool_calls', sessionId, calls: result.toolCalls, text: result.text || '', model: result.model, route: routeInfo };
    }
    return { status: 'final', text: result.text, sources: result.sources, webSearchUsed: result.webSearchUsed, model: result.model, route: routeInfo, sessionId: null };
  }

  #validate(body) {
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw bad('Corpo inválido.');
    const options = body.options && typeof body.options === 'object' ? body.options : {};

    const mode = options.mode === undefined ? 'chat' : options.mode;
    if (!MODES.has(mode)) throw bad('options.mode inválido.');

    const enabledTools = options.enabledTools === undefined ? [] : options.enabledTools;
    if (!Array.isArray(enabledTools)) throw bad('options.enabledTools deve ser uma lista.');
    for (const t of enabledTools) {
      if (!CLIENT_TOOL_NAMES.includes(t)) throw bad(`Ferramenta desconhecida: ${String(t).slice(0, 40)}`);
    }

    const gameContext = typeof options.gameContext === 'string' ? options.gameContext.slice(0, 2000) : '';
    const language = typeof options.language === 'string' && options.language.length <= 20 ? options.language : 'pt-BR';
    const timeZone = typeof options.timeZone === 'string' && options.timeZone.length <= 64 ? options.timeZone : '';

    const task = options.task === undefined ? 'general' : options.task;
    if (!TASKS.includes(task)) throw bad('options.task inválido.');
    const text = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
    const proactivity = PROACTIVITY.has(String(options.proactivity || 'OFF').toUpperCase()) ? String(options.proactivity || 'OFF').toUpperCase() : 'OFF';

    const settings = {
      task,
      niche: sanitizeNiche(options.niche),
      modeName: text(options.modeName, 60),
      modeInstructions: text(options.modeInstructions, 600),
      modeNotes: text(options.modeNotes, 800),
      proactivity,
      verbosity: [-1, 0, 1].includes(options.verbosity) ? options.verbosity : 0,
      modelClass: MODEL_CLASSES.has(options.modelClass) ? options.modelClass : '',
      mode,
      language,
      timeZone,
      gameContext,
      brief: task === 'general' && (Boolean(options.brief) || mode === 'gamer'),
      allowWebSearch: Boolean(options.allowWebSearch),
      provider: ['auto', 'openai', 'anthropic', 'gemini'].includes(options.provider) ? options.provider : 'auto',
      fallbackAllowed: options.fallbackAllowed === true,
      assistantName: typeof options.assistantName === 'string' ? options.assistantName.trim().slice(0, 30) : '',
      enabledTools: [...new Set(enabledTools)],
    };

    const sessionId = typeof body.sessionId === 'string' && body.sessionId ? body.sessionId : null;
    if (sessionId) {
      const results = body.toolResults;
      if (!Array.isArray(results) || results.length === 0) throw bad('toolResults é obrigatório ao continuar uma sessão.');
      const toolResults = results.map((r) => {
        if (!r || typeof r.callId !== 'string') throw bad('toolResults[].callId inválido.');
        const out = { callId: r.callId };
        if (typeof r.text === 'string') out.text = r.text.slice(0, 8000);
        if (typeof r.error === 'string') out.error = r.error.slice(0, 1000);
        if (r.imageDataUrl !== undefined && r.imageDataUrl !== null) {
          if (typeof r.imageDataUrl !== 'string' || !IMAGE_PREFIX.test(r.imageDataUrl) || r.imageDataUrl.length > MAX_IMAGE_CHARS) {
            throw bad('toolResults[].imageDataUrl inválido ou grande demais.');
          }
          out.imageDataUrl = r.imageDataUrl;
        }
        return out;
      });
      return { sessionId, toolResults, settings, messages: [], attachments: [] };
    }

    const messages = body.messages;
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > MAX_MESSAGES) {
      throw bad(`messages deve ter de 1 a ${MAX_MESSAGES} itens.`);
    }
    const cleanMessages = messages.map((m) => {
      if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.text !== 'string') throw bad('messages[] inválido.');
      const text = m.text.trim();
      if (!text || text.length > MAX_TEXT) throw bad('messages[].text vazio ou grande demais.');
      return { role: m.role, text };
    });
    if (cleanMessages[cleanMessages.length - 1].role !== 'user') throw bad('A última mensagem deve ser do usuário.');

    const attachments = Array.isArray(body.attachments) ? body.attachments : [];
    if (attachments.length > MAX_IMAGES) throw bad(`No máximo ${MAX_IMAGES} imagens por pergunta.`);
    const cleanAttachments = attachments.map((a) => {
      if (!a || a.type !== 'image' || typeof a.dataUrl !== 'string' || !IMAGE_PREFIX.test(a.dataUrl) || a.dataUrl.length > MAX_IMAGE_CHARS) {
        throw bad('attachments[] inválido (use data URL de imagem png, jpeg ou webp).');
      }
      return { dataUrl: a.dataUrl };
    });

    return { sessionId: null, toolResults: [], settings, messages: cleanMessages, attachments: cleanAttachments };
  }
}
