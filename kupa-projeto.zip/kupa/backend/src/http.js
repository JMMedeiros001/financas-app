import crypto from 'node:crypto';

export class HttpError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = 'HttpError';
    this.status = status;
    this.code = code;
  }
}

export function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  });
  res.end(body);
}

export async function readJsonBody(req, maxBytes) {
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > maxBytes) throw new HttpError(413, 'payload_too_large', 'Corpo da requisição grande demais.');
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > maxBytes) throw new HttpError(413, 'payload_too_large', 'Corpo da requisição grande demais.');
    chunks.push(chunk);
  }
  if (size === 0) throw new HttpError(400, 'bad_request', 'Corpo JSON ausente.');
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new HttpError(400, 'bad_request', 'JSON inválido.');
  }
}

const sha = (value) => crypto.createHash('sha256').update(String(value)).digest();

/** Comparação em tempo constante (evita vazar o token por diferença de tempo). */
export function safeEqual(a, b) {
  return crypto.timingSafeEqual(sha(a), sha(b));
}

export function hashKey(value) {
  return crypto.createHash('sha256').update(String(value)).digest('hex').slice(0, 16);
}
