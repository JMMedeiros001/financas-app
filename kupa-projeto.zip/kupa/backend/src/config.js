import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

/** Lê um arquivo .env simples (sem dependências). Variáveis já definidas no ambiente têm prioridade. */
export function loadDotEnv(file = path.join(here, '..', '.env'), env = process.env) {
  if (!fs.existsSync(file)) return false;
  for (const raw of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    let value = line.slice(eq + 1).trim();
    const quoted = (value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"));
    if (quoted && value.length >= 2) value = value.slice(1, -1);
    if (env[key] === undefined) env[key] = value;
  }
  return true;
}

const toBool = (value, fallback) => {
  if (value === undefined || value === '') return fallback;
  return ['1', 'true', 'yes', 'on'].includes(String(value).toLowerCase());
};
const toInt = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) ? n : fallback;
};

export function readConfig(env = process.env) {
  return Object.freeze({
    port: toInt(env.PORT, 8787),
    host: env.HOST || '0.0.0.0',
    logLevel: env.LOG_LEVEL || 'info',
    appToken: env.KUPA_APP_TOKEN || '',
    allowNoAuth: toBool(env.KUPA_ALLOW_NO_AUTH, false),
    rateLimitPerMinute: toInt(env.KUPA_RATE_LIMIT_PER_MINUTE, 60),
    maxBodyBytes: toInt(env.KUPA_MAX_BODY_MB, 8) * 1024 * 1024,
    sessionTtlMs: toInt(env.KUPA_SESSION_TTL_SECONDS, 300) * 1000,
    maxToolRounds: toInt(env.KUPA_MAX_TOOL_ROUNDS, 4),
    provider: 'openai',
    openai: Object.freeze({
      apiKey: env.OPENAI_API_KEY || '',
      model: env.OPENAI_MODEL || '',
      baseUrl: (env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/+$/, ''),
      timeoutMs: toInt(env.OPENAI_TIMEOUT_MS, 60000),
      reasoningEffort: env.OPENAI_REASONING_EFFORT || '',
      maxOutputTokens: toInt(env.OPENAI_MAX_OUTPUT_TOKENS, 0),
      store: toBool(env.OPENAI_STORE, false),
      encryptedReasoning: toBool(env.OPENAI_ENCRYPTED_REASONING, true),
      webSearch: toBool(env.OPENAI_WEB_SEARCH, true),
      searchContextSize: env.OPENAI_SEARCH_CONTEXT_SIZE || 'medium',
    }),
  });
}
