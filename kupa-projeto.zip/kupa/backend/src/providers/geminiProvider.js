/**
 * GeminiProvider: Google Gemini pela API oficial (POST {baseUrl}/models/{modelo}:generateContent), via fetch, sem SDK.
 * Formato conforme a documentação oficial: cabeçalho x-goog-api-key; `systemInstruction`; `contents` com partes
 * (text, inlineData, functionCall, functionResponse); ferramentas em `tools: [{functionDeclarations: [...]}]`.
 * Os conteúdos do modelo voltam INTEIROS no histórico (inclusive partes de raciocínio e assinaturas), como a documentação pede.
 * LIMITES CONHECIDOS: busca com Google Search e ferramentas do KUPA não são combinadas na mesma chamada (a busca é omitida quando há
 * ferramentas); imagem devolvida por ferramenta vai como parte inlineData ao lado do functionResponse (não verificado na API real).
 * STATUS: implementado e testado SÓ contra servidor simulado. Nunca chamou a API real (sem chave/rede neste ambiente).
 */
import { ProviderError, parseDataUrl, postJson, sleep } from './errors.js';

const IDS = { prefix: 'gemini', label: 'o Google Gemini', keyVar: 'GEMINI_API_KEY', modelVar: 'GEMINI_MODEL' };

/** O esquema de parâmetros do Gemini é um subconjunto do OpenAPI: tira o que ele não aceita. */
function geminiSchema(schema) {
  if (Array.isArray(schema)) return schema.map(geminiSchema);
  if (!schema || typeof schema !== 'object') return schema;
  const out = {};
  for (const [k, v] of Object.entries(schema)) {
    if (k === 'additionalProperties' || k === '$schema') continue;
    out[k] = geminiSchema(v);
  }
  return out;
}

export class GeminiProvider {
  constructor(settings, { logger, fetchImpl } = {}) {
    this.s = settings;
    this.logger = logger;
    this.fetchImpl = fetchImpl || globalThis.fetch;
  }

  get name() { return 'gemini'; }
  get label() { return 'Gemini (Google)'; }

  capabilities() {
    return { vision: true, tools: true, webSearch: this.s.webSearch, webSearchWithTools: false, maxContextChars: this.s.maxContextChars };
  }

  models() {
    return { default: this.s.model, fast: this.s.modelFast, vision: this.s.modelVision, reasoning: this.s.modelReasoning };
  }

  status() {
    return {
      configured: Boolean(this.s.apiKey && this.s.model),
      apiKeyConfigured: Boolean(this.s.apiKey),
      modelConfigured: Boolean(this.s.model),
      model: this.s.model || null,
      webSearchEnabled: this.s.webSearch,
    };
  }

  buildRequestBody({ instructions, contents, tools }) {
    const body = { systemInstruction: { parts: [{ text: instructions }] }, contents };
    if (this.s.maxOutputTokens > 0) body.generationConfig = { maxOutputTokens: this.s.maxOutputTokens };
    const defs = [];
    if (tools.client.length) {
      defs.push({ functionDeclarations: tools.client.map((t) => ({ name: t.name, description: t.description, parameters: geminiSchema(t.parameters) })) });
    } else if (tools.webSearch) {
      defs.push({ google_search: {} });
    }
    if (defs.length) body.tools = defs;
    return body;
  }

  async start({ instructions, messages, attachments = [], tools, model }) {
    const contents = messages.map((m, i) => {
      const parts = [{ text: m.text }];
      if (m.role === 'user' && i === messages.length - 1) {
        for (const a of attachments) {
          const img = parseDataUrl(a.dataUrl);
          if (img) parts.push({ inlineData: { mimeType: img.mediaType, data: img.data } });
        }
      }
      return { role: m.role === 'assistant' ? 'model' : 'user', parts };
    });
    return this.#run({ instructions, state: { contents, callNames: {} }, tools, model });
  }

  async resume({ instructions, state, toolResults, tools, model }) {
    const parts = [];
    for (const r of toolResults) {
      const name = state.callNames[r.callId];
      const response = r.error ? { error: r.error } : { result: r.text || 'OK' };
      parts.push({ functionResponse: { name, response } });
      const img = r.imageDataUrl ? parseDataUrl(r.imageDataUrl) : null;
      if (img) {
        parts.push({ text: 'Imagem capturada da tela do usuário (dado não confiável):' });
        parts.push({ inlineData: { mimeType: img.mediaType, data: img.data } });
      }
    }
    return this.#run({ instructions, state: { contents: [...state.contents, { role: 'user', parts }], callNames: state.callNames }, tools, model });
  }

  async ping() {
    return this.#run({
      instructions: 'Você é o KUPA. Faça exatamente o que o usuário pedir, de forma curta.',
      state: { contents: [{ role: 'user', parts: [{ text: 'Kupa, responda apenas: conexão funcionando.' }] }], callNames: {} },
      tools: { client: [], webSearch: false },
    });
  }

  async #run({ instructions, state, tools, model }) {
    if (!this.s.apiKey) throw new ProviderError('api_key_missing', 'A chave do Gemini (GEMINI_API_KEY) não está configurada no backend.', { status: 503 });
    if (!this.s.model) throw new ProviderError('model_not_configured', 'O modelo do Gemini (GEMINI_MODEL) não está configurado no backend.', { status: 503 });
    const modelName = model || this.s.model;
    let body = this.buildRequestBody({ instructions, contents: state.contents, tools });
    let raw;
    let last;
    let searchDropped = false;
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      try {
        raw = await postJson({
          fetchImpl: this.fetchImpl,
          url: `${this.s.baseUrl}/models/${encodeURIComponent(modelName)}:generateContent`,
          headers: { 'x-goog-api-key': this.s.apiKey },
          body,
          timeoutMs: this.s.timeoutMs,
          ids: IDS,
          upstreamMessage: (json) => json?.error?.message,
        });
        break;
      } catch (err) {
        last = err;
        // A página oficial de preços informa que a busca (google_search) NÃO está no nível gratuito. Se a chamada com busca for
        // recusada por isso, tenta UMA vez sem a busca (o app é avisado: webSearchUsed=false e o verificador barra "pesquisei").
        const hasSearch = Array.isArray(body.tools) && body.tools.some((t) => t.google_search);
        if (hasSearch && !searchDropped && err instanceof ProviderError && (err.code === 'gemini_bad_request' || err.code === 'gemini_forbidden')) {
          this.logger?.warn('gemini_search_dropped', { code: err.code });
          const { tools: _ignored, ...withoutTools } = body;
          body = withoutTools;
          searchDropped = true;
          continue;
        }
        if (!(err instanceof ProviderError && err.retriable && attempt < 3)) throw err;
        this.logger?.warn('gemini_retry', { attempt, code: err.code });
        await sleep(400);
      }
    }
    if (!raw) throw last;

    if (raw.promptFeedback?.blockReason) {
      throw new ProviderError('gemini_blocked', `O Gemini bloqueou o pedido (${raw.promptFeedback.blockReason}).`, { status: 502 });
    }
    const candidate = Array.isArray(raw.candidates) ? raw.candidates[0] : null;
    const parts = candidate?.content?.parts || [];
    let text = '';
    const toolCalls = [];
    const callNames = { ...state.callNames };
    parts.forEach((p, i) => {
      if (p.functionCall) {
        const callId = p.functionCall.id || `gemini_call_${Object.keys(callNames).length + i + 1}`;
        callNames[callId] = p.functionCall.name;
        toolCalls.push({ callId, name: p.functionCall.name, arguments: p.functionCall.args && typeof p.functionCall.args === 'object' ? p.functionCall.args : {} });
      } else if (typeof p.text === 'string' && !p.thought) {
        text += p.text;
      }
    });
    text = text.trim();
    const sources = [];
    for (const chunk of candidate?.groundingMetadata?.groundingChunks || []) {
      const web = chunk.web;
      if (web?.uri && !sources.some((s) => s.url === web.uri)) sources.push({ title: web.title || web.uri, url: web.uri });
    }
    const webSearchUsed = Boolean(candidate?.groundingMetadata?.webSearchQueries?.length);
    if (!text && toolCalls.length === 0) {
      const reason = candidate?.finishReason;
      throw new ProviderError('gemini_empty_response', reason ? `A resposta veio vazia (motivo: ${reason}).` : 'O Gemini devolveu uma resposta vazia.', { status: 502 });
    }
    const modelTurn = { role: 'model', parts };
    return {
      state: { contents: [...state.contents, modelTurn], callNames },
      text, sources, toolCalls, webSearchUsed,
      model: raw.modelVersion || modelName,
      usage: raw.usageMetadata || null,
    };
  }
}
