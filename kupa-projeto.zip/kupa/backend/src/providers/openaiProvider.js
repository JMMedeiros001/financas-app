/**
 * OpenAIProvider: único lugar do projeto que conhece a API da OpenAI.
 * Usa a API oficial Responses (POST {baseUrl}/responses) via fetch, sem SDK.
 */
export class ProviderError extends Error {
  constructor(code, message, { status = 502, retriable = false, upstreamStatus } = {}) {
    super(message);
    this.name = 'ProviderError';
    this.code = code;
    this.httpStatus = status;
    this.retriable = retriable;
    this.upstreamStatus = upstreamStatus;
  }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const clip = (text, max = 300) => (text.length > max ? `${text.slice(0, max)}…` : text);

export class OpenAIProvider {
  constructor(settings, { logger, fetchImpl } = {}) {
    this.s = settings;
    this.logger = logger;
    this.fetchImpl = fetchImpl || globalThis.fetch;
  }

  get name() {
    return 'openai';
  }

  status() {
    return {
      apiKeyConfigured: Boolean(this.s.apiKey),
      modelConfigured: Boolean(this.s.model),
      model: this.s.model || null,
      webSearchEnabled: this.s.webSearch,
    };
  }

  buildRequestBody({ instructions, items, tools = [] }) {
    const body = { model: this.s.model, instructions, input: items, store: this.s.store };
    if (tools.length) body.tools = tools;
    if (this.s.reasoningEffort) body.reasoning = { effort: this.s.reasoningEffort };
    if (this.s.maxOutputTokens > 0) body.max_output_tokens = this.s.maxOutputTokens;
    const include = [];
    if (!this.s.store && this.s.encryptedReasoning) include.push('reasoning.encrypted_content');
    if (tools.some((t) => t.type === 'web_search')) include.push('web_search_call.action.sources');
    if (include.length) body.include = include;
    return body;
  }

  /**
   * @returns {{items:object[], text:string, sources:{title:string,url:string}[], toolCalls:{callId:string,name:string,arguments:object}[], webSearchUsed:boolean, model:string, usage:object|null}}
   */
  async generate({ instructions, items, tools = [] }) {
    if (!this.s.apiKey) {
      throw new ProviderError('api_key_missing', 'A chave da OpenAI (OPENAI_API_KEY) não está configurada no backend.', { status: 503 });
    }
    if (!this.s.model) {
      throw new ProviderError('model_not_configured', 'O modelo (OPENAI_MODEL) não está configurado no backend.', { status: 503 });
    }
    const body = this.buildRequestBody({ instructions, items, tools });
    let lastError;
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      try {
        return this.#parse(await this.#post(body));
      } catch (err) {
        lastError = err;
        const canRetry = err instanceof ProviderError && err.retriable && attempt < 2;
        if (!canRetry) throw err;
        this.logger?.warn('openai_retry', { attempt, code: err.code });
        await sleep(400);
      }
    }
    throw lastError;
  }

  async #post(body) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.s.timeoutMs);
    try {
      let res;
      try {
        res = await this.fetchImpl(`${this.s.baseUrl}/responses`, {
          method: 'POST',
          headers: { 'content-type': 'application/json', authorization: `Bearer ${this.s.apiKey}` },
          body: JSON.stringify(body),
          signal: controller.signal,
        });
      } catch (err) {
        if (err?.name === 'AbortError') {
          throw new ProviderError('openai_timeout', 'A OpenAI demorou demais para responder.', { status: 504 });
        }
        throw new ProviderError('openai_unreachable', 'Não consegui falar com a OpenAI (problema de rede).', { status: 502, retriable: true });
      }
      let text;
      try {
        text = await res.text();
      } catch (err) {
        if (err?.name === 'AbortError') {
          throw new ProviderError('openai_timeout', 'A OpenAI demorou demais para responder.', { status: 504 });
        }
        throw new ProviderError('openai_unreachable', 'A conexão com a OpenAI caiu no meio da resposta.', { status: 502, retriable: true });
      }
      let json = null;
      try {
        json = text ? JSON.parse(text) : null;
      } catch {
        json = null;
      }
      if (!res.ok) throw this.#mapHttpError(res.status, json);
      if (!json || typeof json !== 'object') {
        throw new ProviderError('openai_invalid_response', 'A OpenAI devolveu uma resposta que não consegui entender.', { status: 502 });
      }
      return json;
    } finally {
      clearTimeout(timer);
    }
  }

  #mapHttpError(status, json) {
    const upstream = clip(String(json?.error?.message || ''));
    const opts = { upstreamStatus: status };
    if (status === 401) {
      return new ProviderError('openai_auth_error', 'A OpenAI recusou a chave (401). Confira a OPENAI_API_KEY no backend.', { status: 502, ...opts });
    }
    if (status === 403) {
      return new ProviderError('openai_forbidden', `A OpenAI negou o acesso (403). ${upstream}`.trim(), { status: 502, ...opts });
    }
    if (status === 404) {
      return new ProviderError('openai_model_not_found', `A OpenAI não encontrou o modelo ou o recurso (404). Confira a OPENAI_MODEL. ${upstream}`.trim(), { status: 502, ...opts });
    }
    if (status === 429) {
      return new ProviderError('openai_rate_limited', `A OpenAI limitou as requisições ou a cota acabou (429). ${upstream}`.trim(), { status: 429, ...opts });
    }
    if (status === 400 || status === 422) {
      return new ProviderError('openai_bad_request', `A OpenAI recusou a requisição (${status}). ${upstream}`.trim(), { status: 502, ...opts });
    }
    if (status >= 500) {
      return new ProviderError('openai_unavailable', 'A OpenAI está indisponível no momento.', { status: 502, retriable: true, ...opts });
    }
    return new ProviderError('openai_error', `Erro inesperado da OpenAI (${status}). ${upstream}`.trim(), { status: 502, ...opts });
  }

  #parse(raw) {
    if (raw.status === 'failed' || raw.error) {
      const msg = clip(String(raw.error?.message || 'a geração falhou'));
      throw new ProviderError('openai_failed', `A OpenAI não conseguiu gerar a resposta: ${msg}`, { status: 502 });
    }
    const items = Array.isArray(raw.output) ? raw.output : [];
    let text = '';
    const sources = [];
    const seen = new Set();
    const toolCalls = [];
    let webSearchUsed = false;

    const addSource = (title, url) => {
      if (!url || seen.has(url)) return;
      seen.add(url);
      sources.push({ title: title || url, url });
    };

    for (const item of items) {
      if (item.type === 'message') {
        for (const part of item.content || []) {
          if (part.type === 'output_text') {
            text += part.text || '';
            for (const ann of part.annotations || []) if (ann.type === 'url_citation') addSource(ann.title, ann.url);
          } else if (part.type === 'refusal') {
            text += part.refusal || '';
          }
        }
      } else if (item.type === 'function_call') {
        let args = {};
        try {
          args = item.arguments ? JSON.parse(item.arguments) : {};
        } catch {
          args = {};
        }
        toolCalls.push({ callId: item.call_id, name: item.name, arguments: args });
      } else if (item.type === 'web_search_call') {
        webSearchUsed = true;
        for (const src of item.action?.sources || []) addSource(src.title, src.url);
      }
    }

    text = text.trim();
    if (!text && toolCalls.length === 0) {
      const reason = raw.incomplete_details?.reason;
      throw new ProviderError(
        'openai_empty_response',
        reason ? `A resposta veio vazia (motivo: ${reason}).` : 'A OpenAI devolveu uma resposta vazia.',
        { status: 502 },
      );
    }
    return { items, text, sources, toolCalls, webSearchUsed, model: raw.model || this.s.model, usage: raw.usage || null };
  }
}
