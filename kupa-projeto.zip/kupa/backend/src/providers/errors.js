/** Erros e mapeamento HTTP compartilhados por todos os provedores de IA. */
export class ProviderError extends Error {
  constructor(code, message, { status = 502, retriable = false, upstreamStatus } = {}) {
    super(message);
    this.name = 'ProviderError';
    this.code = code;
    this.httpStatus = status;
    this.retriable = retriable;
    this.upstreamStatus = upstreamStatus;
  }

  /** Falhas do PROVEDOR (não do pedido): só nestas um fallback autorizado pelo usuário faz sentido. */
  get fallbackEligible() {
    return /_(unreachable|timeout|unavailable|rate_limited|auth_error|model_not_found)$/.test(this.code) ||
      this.code === 'api_key_missing' || this.code === 'model_not_configured' ||
      /_(api_key_missing|model_not_configured)$/.test(this.code);
  }
}

const clip = (text, max = 300) => (text.length > max ? `${text.slice(0, max)}…` : text);
export const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** Converte uma resposta HTTP de erro em ProviderError (códigos: <prefixo>_auth_error, _rate_limited, ...). */
export function mapHttpError({ prefix, label, keyVar, modelVar }, status, upstreamMessage) {
  const upstream = clip(String(upstreamMessage || ''));
  const opts = { upstreamStatus: status };
  if (status === 401) return new ProviderError(`${prefix}_auth_error`, `${label} recusou a chave (401). Confira ${keyVar} no backend.`, { status: 502, ...opts });
  if (status === 403) return new ProviderError(`${prefix}_forbidden`, `${label} negou o acesso (403). ${upstream}`.trim(), { status: 502, ...opts });
  if (status === 404) return new ProviderError(`${prefix}_model_not_found`, `${label} não encontrou o modelo ou o recurso (404). Confira ${modelVar}. ${upstream}`.trim(), { status: 502, ...opts });
  if (status === 429) return new ProviderError(`${prefix}_rate_limited`, `${label} limitou as requisições ou a cota acabou (429). ${upstream}`.trim(), { status: 429, ...opts });
  if (status === 400 || status === 413 || status === 422) return new ProviderError(`${prefix}_bad_request`, `${label} recusou a requisição (${status}). ${upstream}`.trim(), { status: 502, ...opts });
  if (status >= 500) return new ProviderError(`${prefix}_unavailable`, `${label} está indisponível no momento (${status}).`, { status: 502, retriable: true, ...opts });
  return new ProviderError(`${prefix}_error`, `Erro inesperado de ${label} (${status}). ${upstream}`.trim(), { status: 502, ...opts });
}

/**
 * POST JSON com timeout, sem seguir segredos para logs. Lança ProviderError com códigos <prefixo>_timeout,
 * _unreachable, _invalid_response e os de mapHttpError.
 */
export async function postJson({ fetchImpl, url, headers, body, timeoutMs, ids, upstreamMessage }) {
  const { prefix, label } = ids;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let res;
    try {
      res = await fetchImpl(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: controller.signal });
    } catch (err) {
      if (err?.name === 'AbortError') throw new ProviderError(`${prefix}_timeout`, `${label} demorou demais para responder.`, { status: 504 });
      throw new ProviderError(`${prefix}_unreachable`, `Não consegui falar com ${label} (problema de rede).`, { status: 502, retriable: true });
    }
    let text;
    try {
      text = await res.text();
    } catch (err) {
      if (err?.name === 'AbortError') throw new ProviderError(`${prefix}_timeout`, `${label} demorou demais para responder.`, { status: 504 });
      throw new ProviderError(`${prefix}_unreachable`, `A conexão com ${label} caiu no meio da resposta.`, { status: 502, retriable: true });
    }
    let json = null;
    try {
      json = text ? JSON.parse(text) : null;
    } catch {
      json = null;
    }
    if (!res.ok) throw mapHttpError(ids, res.status, upstreamMessage(json));
    if (!json || typeof json !== 'object') throw new ProviderError(`${prefix}_invalid_response`, `${label} devolveu uma resposta que não consegui entender.`, { status: 502 });
    return json;
  } finally {
    clearTimeout(timer);
  }
}

/** Divide "data:image/png;base64,AAAA" em { mediaType, data }. */
export function parseDataUrl(dataUrl) {
  const m = /^data:(image\/(?:png|jpe?g|webp));base64,(.*)$/is.exec(dataUrl || '');
  if (!m) return null;
  return { mediaType: m[1].toLowerCase().replace('image/jpg', 'image/jpeg'), data: m[2] };
}
