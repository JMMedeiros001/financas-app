/**
 * AIProviderManager: registro dos provedores de IA disponíveis.
 * Hoje só existe um provedor REAL (OpenAI). Para adicionar outro (Anthropic, Google, modelo local...),
 * implemente a mesma interface do OpenAIProvider (name, status(), generate()) com a API oficial verificada e
 * registre aqui; o AIRouter passa a poder escolhê-lo. Nenhum provedor é "simulado".
 */
export class AIProviderManager {
  constructor() {
    this.providers = new Map();
    this.defaultName = null;
  }

  register(provider, { isDefault = false } = {}) {
    const ok = provider && typeof provider.name === 'string' && ['start', 'resume', 'ping', 'status', 'capabilities', 'models'].every((m) => typeof provider[m] === 'function');
    if (!ok) {
      throw new Error('Provedor inválido: precisa de name, start(), resume(), ping(), status(), capabilities() e models().');
    }
    this.providers.set(provider.name, provider);
    if (isDefault || !this.defaultName) this.defaultName = provider.name;
    return this;
  }

  get(name) {
    const p = this.providers.get(name || this.defaultName);
    if (!p) throw new Error(`Provedor de IA não registrado: ${name}`);
    return p;
  }

  find(name) {
    return this.providers.get(name) || null;
  }

  all() {
    return [...this.providers.values()];
  }

  names() {
    return [...this.providers.keys()];
  }
}
