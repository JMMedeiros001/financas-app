/**
 * AIProviderManager: registro dos provedores de IA disponíveis.
 * Hoje só existe um provedor REAL (OpenAI). Para adicionar outro (Anthropic, Google, modelo local...),
 * implemente a mesma interface do OpenAIProvider (name, status(), generate()) com a API oficial verificada e
 * registre aqui; o AIRouter passa a poder escolhê-lo. Nenhum provedor é "simulado".
 */
export class AIProviderManager {
  constructor() {
    this.providers = new Map();
    this.defaultName = null;
  }

  register(provider, { isDefault = false } = {}) {
    if (!provider || typeof provider.name !== 'string' || typeof provider.generate !== 'function') {
      throw new Error('Provedor inválido: precisa de name e generate().');
    }
    this.providers.set(provider.name, provider);
    if (isDefault || !this.defaultName) this.defaultName = provider.name;
    return this;
  }

  get(name) {
    const p = this.providers.get(name || this.defaultName);
    if (!p) throw new Error(`Provedor de IA não registrado: ${name}`);
    return p;
  }

  names() {
    return [...this.providers.keys()];
  }
}
