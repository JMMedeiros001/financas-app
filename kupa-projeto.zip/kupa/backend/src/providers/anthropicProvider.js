/**
 * AnthropicProvider: Claude pela API oficial Messages (POST {baseUrl}/v1/messages), via fetch, sem SDK.
 * Formato conforme a documentação oficial: cabeçalhos x-api-key e anthropic-version; `system` no topo; mensagens com blocos de conteúdo;
 * ferramentas do cliente = tool_use / tool_result (o resultado volta numa mensagem de usuário só com blocos tool_result);
 * busca na web = ferramenta de servidor `web_search_20250305` (executada pela Anthropic; pode devolver stop_reason "pause_turn").
 * STATUS: implementado e testado SÓ contra servidor simulado. Nunca chamou a API real (sem chave/rede neste ambiente).
 */
import { ProviderError, parseDataUrl, postJson, sleep } from './errors.js';

const IDS = { prefix: 'anthropic', label: 'a Anthropic (Claude)', keyVar: 'ANTHROPIC_API_KEY', modelVar: 'ANTHROPIC_MODEL' };
const MAX_PAUSE_CONTINUATIONS = 3;

function toUserContent(text, attachments) {
  if (!attachments.length) return text;
  const blocks = [];
  for (const a of attachments) {
    const img = parseDataUrl(a.dataUrl);
    if (img) blocks.push({ type: 'image', source: { type: 'base64', media_type: img.mediaType, data: img.data } });
  }
  blocks.push({ type: 'text', text });
  return blocks;
}

function toToolResultBlock(r) {
  const block = { type: 'tool_result', tool_use_id: r.callId };
  if (r.error) {
    block.is_error = true;
    block.content = `ERRO: ${r.error}`;
  } else if (r.imageDataUrl && parseDataUrl(r.imageDataUrl)) {
    const img = parseDataUrl(r.imageDataUrl);
    block.content = [
      { type: 'text', text: r.text || 'Captura da tela do usuário.' },
      { type: 'image', source: { type: 'base64', media_type: img.mediaType, data: img.data } },
    ];
  } else {
    block.content = r.text || 'OK';
  }
  return block;
}

export class AnthropicProvider {
  constructor(settings, { logger, fetchImpl } = {}) {
    this.s = settings;
    this.logger = logger;
    this.fetchImpl = fetchImpl || globalThis.fetch;
  }

  get name() { return 'anthropic'; }
  get label() { return 'Claude (Anthropic)'; }

  capabilities() {
    return { vision: true, tools: true, webSearch: this.s.webSearch, webSearchWithTools: true, maxContextChars: this.s.maxContextChars };
  }

  models() {
    return { default: this.s.model, fast: this.s.modelFast, vision: this.s.modelVision, reasoning: this.s.modelReasoning };
  }

  status() {
    return {
      configured: Boolean(this.s.apiKey && this.s.model),
      apiKeyConfigured: Boolean(this.s.apiKey),
      modelConfigured: Boolean(this.s.model),
      model: this.s.model || null,
      webSearchEnabled: this.s.webSearch,
    };
  }

  buildRequestBody({ instructions, messages, tools, model }) {
    const body = { model: model || this.s.model, max_tokens: this.s.maxTokens, system: instructions, messages };
    const defs = tools.client.map((t) => ({ name: t.name, description: t.description, input_schema: t.parameters }));
    if (tools.webSearch) defs.push({ type: 'web_search_20250305', name: 'web_search', max_uses: this.s.webSearchMaxUses });
    if (defs.length) body.tools = defs;
    return body;
  }

  async start({ instructions, messages, attachments = [], tools, model }) {
    const msgs = messages.map((m, i) => ({
      role: m.role,
      content: m.role === 'user' && i === messages.length - 1 ? toUserContent(m.text, attachments) : m.text,
    }));
    return this.#run({ instructions, messages: msgs, tools, model });
  }

  async resume({ instructions, state, toolResults, tools, model }) {
    const msgs = [...state, { role: 'user', content: toolResults.map(toToolResultBlock) }];
    return this.#run({ instructions, messages: msgs, tools, model });
  }

  async ping() {
    return this.#run({
      instructions: 'Você é o KUPA. Faça exatamente o que o usuário pedir, de forma curta.',
      messages: [{ role: 'user', content: 'Kupa, responda apenas: conexão funcionando.' }],
      tools: { client: [], webSearch: false },
    });
  }

  async #run({ instructions, messages, tools, model }) {
    if (!this.s.apiKey) throw new ProviderError('api_key_missing', 'A chave da Anthropic (ANTHROPIC_API_KEY) não está configurada no backend.', { status: 503 });
    if (!this.s.model) throw new ProviderError('model_not_configured', 'O modelo da Anthropic (ANTHROPIC_MODEL) não está configurado no backend.', { status: 503 });

    let msgs = messages;
    const sources = [];
    let webSearchUsed = false;
    for (let pause = 0; pause <= MAX_PAUSE_CONTINUATIONS; pause += 1) {
      const raw = await this.#postWithRetry(this.buildRequestBody({ instructions, messages: msgs, tools, model }));
      const parsed = this.#parse(raw);
      for (const s of parsed.sources) if (!sources.some((x) => x.url === s.url)) sources.push(s);
      webSearchUsed = webSearchUsed || parsed.webSearchUsed;
      const assistant = { role: 'assistant', content: raw.content };
      if (raw.stop_reason === 'pause_turn') { // a busca de servidor pausou o turno: continuar com o mesmo conteúdo (sem tool_result)
        msgs = [...msgs, assistant];
        continue;
      }
      if (parsed.toolCalls.length === 0 && !parsed.text) {
        throw new ProviderError('anthropic_empty_response', raw.stop_reason ? `A resposta veio vazia (motivo: ${raw.stop_reason}).` : 'A Anthropic devolveu uma resposta vazia.', { status: 502 });
      }
      return { state: [...msgs, assistant], text: parsed.text, sources, toolCalls: parsed.toolCalls, webSearchUsed, model: raw.model || model || this.s.model, usage: raw.usage || null };
    }
    throw new ProviderError('anthropic_too_many_pauses', 'A busca da Anthropic pausou vezes demais; desisti para não gastar à toa.', { status: 502 });
  }

  async #postWithRetry(body) {
    let last;
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      try {
        return await postJson({
          fetchImpl: this.fetchImpl,
          url: `${this.s.baseUrl}/v1/messages`,
          headers: { 'x-api-key': this.s.apiKey, 'anthropic-version': this.s.version },
          body,
          timeoutMs: this.s.timeoutMs,
          ids: IDS,
          upstreamMessage: (json) => json?.error?.message,
        });
      } catch (err) {
        last = err;
        if (!(err instanceof ProviderError && err.retriable && attempt < 2)) throw err;
        this.logger?.warn('anthropic_retry', { attempt, code: err.code });
        await sleep(400);
      }
    }
    throw last;
  }

  #parse(raw) {
    if (raw.type === 'error' || raw.error) {
      throw new ProviderError('anthropic_failed', `A Anthropic não conseguiu gerar a resposta: ${String(raw.error?.message || 'falha').slice(0, 300)}`, { status: 502 });
    }
    let text = '';
    const sources = [];
    const toolCalls = [];
    let webSearchUsed = false;
    const addSource = (title, url) => { if (url && !sources.some((s) => s.url === url)) sources.push({ title: title || url, url }); };
    for (const block of Array.isArray(raw.content) ? raw.content : []) {
      if (block.type === 'text') {
        text += block.text || '';
        for (const c of block.citations || []) addSource(c.title, c.url);
      } else if (block.type === 'tool_use') {
        toolCalls.push({ callId: block.id, name: block.name, arguments: block.input && typeof block.input === 'object' ? block.input : {} });
      } else if (block.type === 'server_tool_use') {
        webSearchUsed = true;
      } else if (block.type === 'web_search_tool_result' && Array.isArray(block.content)) {
        for (const r of block.content) if (r.type === 'web_search_result') addSource(r.title, r.url);
      }
    }
    return { text: text.trim(), sources, toolCalls, webSearchUsed };
  }
}
