import http from 'node:http';
import { pathToFileURL } from 'node:url';
import { loadDotEnv, readConfig } from './config.js';
import { createLogger } from './logger.js';
import { HttpError, hashKey, readJsonBody, safeEqual, sendJson } from './http.js';
import { RateLimiter } from './rateLimiter.js';
import { OpenAIProvider, ProviderError } from './providers/openaiProvider.js';
import { AIService } from './services/aiService.js';
import { SessionStore } from './services/sessionStore.js';

export const VERSION = '0.1.0';

export function createApp(config, { logger, provider, fetchImpl } = {}) {
  const log =
    logger ||
    createLogger({ level: config.logLevel, secrets: [config.openai.apiKey, config.appToken] });
  const prov = provider || new OpenAIProvider(config.openai, { logger: log, fetchImpl });
  const sessions = new SessionStore({ ttlMs: config.sessionTtlMs });
  const aiService = new AIService({ config, provider: prov, sessions, logger: log });
  const limiter = new RateLimiter({ limit: config.rateLimitPerMinute });
  const startedAt = Date.now();

  function authenticate(req) {
    if (!config.appToken) {
      if (config.allowNoAuth) return 'anon';
      throw new HttpError(503, 'auth_not_configured', 'O backend não tem KUPA_APP_TOKEN configurado.');
    }
    const match = /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '');
    if (!match || !safeEqual(match[1].trim(), config.appToken)) {
      throw new HttpError(401, 'unauthorized', 'Token inválido ou ausente.');
    }
    return hashKey(match[1].trim());
  }

  function errorPayload(err) {
    if (err instanceof HttpError) return { status: err.status, code: err.code, message: err.message };
    if (err instanceof ProviderError) return { status: err.httpStatus, code: err.code, message: err.message };
    log.error('internal_error', { message: err?.message, stack: err?.stack });
    return { status: 500, code: 'internal_error', message: 'Erro interno do backend.' };
  }

  async function route(req, res) {
    const url = new URL(req.url, 'http://localhost');
    const key = `${req.method} ${url.pathname}`;

    if (key === 'GET /health') {
      return sendJson(res, 200, {
        ok: true,
        service: 'kupa-backend',
        version: VERSION,
        uptimeSeconds: Math.round((Date.now() - startedAt) / 1000),
      });
    }

    if (!url.pathname.startsWith('/v1/')) throw new HttpError(404, 'not_found', 'Rota não encontrada.');
    const clientKey = authenticate(req);
    limiter.check(clientKey === 'anon' ? req.socket.remoteAddress || 'anon' : clientKey);

    switch (key) {
      case 'GET /v1/config':
        return sendJson(res, 200, aiService.describe());
      case 'POST /v1/ai/test':
        return sendJson(res, 200, await aiService.test());
      case 'POST /v1/ai/respond': {
        const body = await readJsonBody(req, config.maxBodyBytes);
        return sendJson(res, 200, await aiService.ask(body));
      }
      default:
        throw new HttpError(404, 'not_found', 'Rota não encontrada.');
    }
  }

  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    let status = 500;
    try {
      await route(req, res);
      status = res.statusCode;
    } catch (err) {
      const { status: code, code: errCode, message } = errorPayload(err);
      status = code;
      if (!res.headersSent) sendJson(res, code, { error: { code: errCode, message } });
      else res.end();
    } finally {
      const path = (req.url || '').split('?')[0];
      log.info('request', { method: req.method, path, status, ms: Date.now() - started });
    }
  });

  return { server, aiService, sessions, logger: log };
}

async function main() {
  loadDotEnv();
  const config = readConfig();
  const { server, logger } = createApp(config);
  if (!config.openai.apiKey) logger.warn('config', { aviso: 'OPENAI_API_KEY não configurada: a IA responderá com erro até você configurar.' });
  if (!config.openai.model) logger.warn('config', { aviso: 'OPENAI_MODEL não configurado.' });
  if (!config.appToken && !config.allowNoAuth) logger.warn('config', { aviso: 'KUPA_APP_TOKEN não configurado: rotas /v1 respondem 503.' });
  server.listen(config.port, config.host, () => {
    logger.info('listening', { host: config.host, port: config.port, provider: config.provider, model: config.openai.model || null });
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch((err) => {
    process.stderr.write(`Falha ao iniciar: ${err?.message}\n`);
    process.exit(1);
  });
}
