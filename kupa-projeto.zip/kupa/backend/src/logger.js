const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };

/** Remove chaves, tokens e valores secretos conhecidos de qualquer texto/objeto antes de logar. */
export function createRedactor(secrets = []) {
  const literals = secrets.filter((s) => typeof s === 'string' && s.length >= 6);
  return function redact(value) {
    let text = typeof value === 'string' ? value : JSON.stringify(value);
    if (text === undefined) return '';
    for (const secret of literals) text = text.split(secret).join('[REDACTED]');
    text = text.replace(/sk-[A-Za-z0-9_-]{8,}/g, 'sk-[REDACTED]');
    text = text.replace(/(Bearer\s+)[A-Za-z0-9._~+/=-]{8,}/gi, '$1[REDACTED]');
    return text;
  };
}

export function createLogger({ level = 'info', secrets = [], sink = (line) => process.stdout.write(`${line}\n`) } = {}) {
  const redact = createRedactor(secrets);
  const min = LEVELS[level] ?? LEVELS.info;
  const emit = (lvl, msg, fields) => {
    if (LEVELS[lvl] < min) return;
    sink(redact({ t: new Date().toISOString(), level: lvl, msg, ...fields }));
  };
  return {
    redact,
    debug: (msg, fields) => emit('debug', msg, fields),
    info: (msg, fields) => emit('info', msg, fields),
    warn: (msg, fields) => emit('warn', msg, fields),
    error: (msg, fields) => emit('error', msg, fields),
  };
}
