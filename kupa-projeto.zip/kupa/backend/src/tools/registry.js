/**
 * Registro de ferramentas que a IA pode pedir.
 * - Ferramentas "de cliente" rodam no aparelho, sob controle do KUPA CORE (que decide se autoriza).
 * - A busca na web é a ferramenta oficial hospedada pela OpenAI.
 * A IA NUNCA recebe acesso irrestrito ao aparelho: só as ferramentas listadas aqui e habilitadas pelo app.
 */
export const CLIENT_TOOLS = Object.freeze({
  analyze_screen: {
    description:
      'Captura uma imagem da tela atual do usuário (somente com autorização dele) e devolve para você analisar. Use quando a pergunta depender do que está visível na tela.',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: 'O que você quer descobrir olhando a tela.' },
      },
      required: ['question'],
      additionalProperties: false,
    },
  },
  start_timer: {
    description: 'Inicia um temporizador no aparelho do usuário.',
    parameters: {
      type: 'object',
      properties: {
        seconds: { type: 'integer', minimum: 1, maximum: 86400, description: 'Duração em segundos.' },
        label: { type: 'string', description: 'Nome opcional do temporizador.' },
      },
      required: ['seconds'],
      additionalProperties: false,
    },
  },
});

export const CLIENT_TOOL_NAMES = Object.freeze(Object.keys(CLIENT_TOOLS));

export function buildTools({ allowWebSearch, webSearchConfig, enabledClientTools }) {
  const tools = [];
  const clientTools = [];
  if (allowWebSearch) {
    tools.push({ type: 'web_search', search_context_size: webSearchConfig.searchContextSize });
  }
  for (const name of enabledClientTools) {
    const def = CLIENT_TOOLS[name];
    if (!def) continue;
    tools.push({ type: 'function', name, description: def.description, parameters: def.parameters, strict: false });
    clientTools.push(name);
  }
  return { tools, clientTools };
}
