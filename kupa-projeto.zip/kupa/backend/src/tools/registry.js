/**
 * Registro de ferramentas que a IA pode pedir.
 * - Ferramentas "de cliente" rodam no aparelho, sob controle do KUPA CORE (que decide se autoriza).
 * - A busca na web é a ferramenta oficial hospedada pela OpenAI.
 * A IA NUNCA recebe acesso irrestrito ao aparelho: só as ferramentas listadas aqui e habilitadas pelo app.
 */
export const CLIENT_TOOLS = Object.freeze({
  analyze_screen: {
    description:
      'Captura uma imagem da tela atual do usuário (somente com autorização dele) e devolve para você analisar. Use quando a pergunta depender do que está visível na tela.',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: 'O que você quer descobrir olhando a tela.' },
      },
      required: ['question'],
      additionalProperties: false,
    },
  },
  open_app: {
    description:
      'Abre um aplicativo instalado no celular do usuário. Use SOMENTE quando o próprio usuário pedir para abrir um app. O app procura o aplicativo instalado e informa se conseguiu.',
    parameters: {
      type: 'object',
      properties: {
        app_name: { type: 'string', description: 'Nome do aplicativo como o usuário falou (ex.: "WhatsApp").' },
      },
      required: ['app_name'],
      additionalProperties: false,
    },
  },
  call_contact: {
    description:
      'Liga para um contato da agenda do usuário. Use SOMENTE quando o próprio usuário pedir para ligar. O app consulta os contatos, pode pedir confirmação ou escolha ao usuário e informa o resultado. Nunca invente números.',
    parameters: {
      type: 'object',
      properties: {
        contact_name: { type: 'string', description: 'Nome do contato como o usuário falou (ex.: "Dudu").' },
      },
      required: ['contact_name'],
      additionalProperties: false,
    },
  },
  incoming_call: {
    description:
      'Informa quem está ligando ou age sobre a chamada que está tocando agora: who (quem está ligando), answer (atender), reject (recusar), ignore (deixar tocar sem fazer nada). Use SOMENTE a pedido do usuário.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['who', 'answer', 'reject', 'ignore'], description: 'O que fazer com a chamada atual.' },
      },
      required: ['action'],
      additionalProperties: false,
    },
  },
  start_timer: {
    description: 'Inicia um temporizador no aparelho do usuário.',
    parameters: {
      type: 'object',
      properties: {
        seconds: { type: 'integer', minimum: 1, maximum: 86400, description: 'Duração em segundos.' },
        label: { type: 'string', description: 'Nome opcional do temporizador.' },
      },
      required: ['seconds'],
      additionalProperties: false,
    },
  },
});

export const CLIENT_TOOL_NAMES = Object.freeze(Object.keys(CLIENT_TOOLS));

export function buildTools({ allowWebSearch, webSearchConfig, enabledClientTools }) {
  const tools = [];
  const clientTools = [];
  if (allowWebSearch) {
    tools.push({ type: 'web_search', search_context_size: webSearchConfig.searchContextSize });
  }
  for (const name of enabledClientTools) {
    const def = CLIENT_TOOLS[name];
    if (!def) continue;
    tools.push({ type: 'function', name, description: def.description, parameters: def.parameters, strict: false });
    clientTools.push(name);
  }
  return { tools, clientTools };
}

/**
 * Valida os argumentos de uma chamada de ferramenta pedida pela IA contra o esquema do registro.
 * A saída de uma IA externa é DADO NÃO CONFIÁVEL: tipos, limites e campos extras são conferidos aqui, no servidor.
 * @returns {{ok:true,args:object}|{ok:false,error:string}}
 */
export function validateToolArgs(name, args) {
  const def = CLIENT_TOOLS[name];
  if (!def) return { ok: false, error: `ferramenta desconhecida: ${String(name).slice(0, 40)}` };
  if (!args || typeof args !== 'object' || Array.isArray(args)) return { ok: false, error: 'argumentos devem ser um objeto' };
  const schema = def.parameters;
  const clean = {};
  for (const key of Object.keys(args)) {
    if (!schema.properties[key]) return { ok: false, error: `campo não permitido: ${key.slice(0, 40)}` };
  }
  for (const key of schema.required || []) {
    if (args[key] === undefined || args[key] === null || args[key] === '') return { ok: false, error: `campo obrigatório ausente: ${key}` };
  }
  for (const [key, spec] of Object.entries(schema.properties)) {
    const v = args[key];
    if (v === undefined) continue;
    if (spec.type === 'string') {
      if (typeof v !== 'string') return { ok: false, error: `${key} deve ser texto` };
      if (v.length > 200) return { ok: false, error: `${key} é longo demais` };
      if (spec.enum && !spec.enum.includes(v)) return { ok: false, error: `${key} com valor inválido` };
      clean[key] = v.trim();
    } else if (spec.type === 'integer') {
      if (!Number.isInteger(v)) return { ok: false, error: `${key} deve ser inteiro` };
      if (spec.minimum !== undefined && v < spec.minimum) return { ok: false, error: `${key} abaixo do mínimo` };
      if (spec.maximum !== undefined && v > spec.maximum) return { ok: false, error: `${key} acima do máximo` };
      clean[key] = v;
    } else {
      return { ok: false, error: `tipo de campo não suportado: ${key}` };
    }
  }
  return { ok: true, args: clean };
}
