/**
 * Registro de ferramentas que a IA pode pedir.
 * - Ferramentas "de cliente" rodam no aparelho, sob controle do KUPA CORE (que decide se autoriza).
 * - A busca na web é a ferramenta oficial hospedada pela OpenAI.
 * A IA NUNCA recebe acesso irrestrito ao aparelho: só as ferramentas listadas aqui e habilitadas pelo app.
 */
export const CLIENT_TOOLS = Object.freeze({
  analyze_screen: {
    description:
      'Captura uma imagem da tela atual do usuário (somente com autorização dele) e devolve para você analisar. Use quando a pergunta depender do que está visível na tela.',
    parameters: {
      type: 'object',
      properties: {
        question: { type: 'string', description: 'O que você quer descobrir olhando a tela.' },
      },
      required: ['question'],
      additionalProperties: false,
    },
  },
  open_app: {
    description:
      'Abre um aplicativo instalado no celular do usuário. Use SOMENTE quando o próprio usuário pedir para abrir um app. O app procura o aplicativo instalado e informa se conseguiu.',
    parameters: {
      type: 'object',
      properties: {
        app_name: { type: 'string', description: 'Nome do aplicativo como o usuário falou (ex.: "WhatsApp").' },
      },
      required: ['app_name'],
      additionalProperties: false,
    },
  },
  call_contact: {
    description:
      'Liga para um contato da agenda do usuário. Use SOMENTE quando o próprio usuário pedir para ligar. O app consulta os contatos, pode pedir confirmação ou escolha ao usuário e informa o resultado. Nunca invente números.',
    parameters: {
      type: 'object',
      properties: {
        contact_name: { type: 'string', description: 'Nome do contato como o usuário falou (ex.: "Dudu").' },
      },
      required: ['contact_name'],
      additionalProperties: false,
    },
  },
  incoming_call: {
    description:
      'Informa quem está ligando ou age sobre a chamada que está tocando agora: who (quem está ligando), answer (atender), reject (recusar), ignore (deixar tocar sem fazer nada). Use SOMENTE a pedido do usuário.',
    parameters: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['who', 'answer', 'reject', 'ignore'], description: 'O que fazer com a chamada atual.' },
      },
      required: ['action'],
      additionalProperties: false,
    },
  },
  start_timer: {
    description: 'Inicia um temporizador no aparelho do usuário.',
    parameters: {
      type: 'object',
      properties: {
        seconds: { type: 'integer', minimum: 1, maximum: 86400, description: 'Duração em segundos.' },
        label: { type: 'string', description: 'Nome opcional do temporizador.' },
      },
      required: ['seconds'],
      additionalProperties: false,
    },
  },
});

export const CLIENT_TOOL_NAMES = Object.freeze(Object.keys(CLIENT_TOOLS));

export function buildTools({ allowWebSearch, webSearchConfig, enabledClientTools }) {
  const tools = [];
  const clientTools = [];
  if (allowWebSearch) {
    tools.push({ type: 'web_search', search_context_size: webSearchConfig.searchContextSize });
  }
  for (const name of enabledClientTools) {
    const def = CLIENT_TOOLS[name];
    if (!def) continue;
    tools.push({ type: 'function', name, description: def.description, parameters: def.parameters, strict: false });
    clientTools.push(name);
  }
  return { tools, clientTools };
}
