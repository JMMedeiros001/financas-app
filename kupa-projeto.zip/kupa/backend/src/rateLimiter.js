import { HttpError } from './http.js';

/** Limite simples por janela deslizante, em memória (suficiente para um backend pessoal de instância única). */
export class RateLimiter {
  constructor({ limit, windowMs = 60_000, now = () => Date.now() }) {
    this.limit = limit;
    this.windowMs = windowMs;
    this.now = now;
    this.hits = new Map();
  }

  check(key) {
    if (!this.limit || this.limit <= 0) return;
    const t = this.now();
    const recent = (this.hits.get(key) || []).filter((ts) => t - ts < this.windowMs);
    if (recent.length >= this.limit) {
      this.hits.set(key, recent);
      throw new HttpError(429, 'rate_limited', 'Muitas solicitações em pouco tempo. Tente de novo em instantes.');
    }
    recent.push(t);
    this.hits.set(key, recent);
    if (this.hits.size > 2000) {
      for (const [k, v] of this.hits) if (!v.some((ts) => t - ts < this.windowMs)) this.hits.delete(k);
    }
  }
}
