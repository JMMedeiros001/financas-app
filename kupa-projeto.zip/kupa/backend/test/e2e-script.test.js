/**
 * Testa o SCRIPT de verificação ponta a ponta (scripts/e2e-real.mjs) contra um backend local e um "modelo" SIMULADO.
 * Isto valida o encanamento e as defesas do script (que um texto fixo NÃO passa). NÃO prova uma IA real: para isso o script
 * precisa rodar contra o backend hospedado, com chave real.
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { startStack, APP_TOKEN } from './helpers/stack.js';
import { textResponse } from './helpers/mockOpenAI.js';

function runScript(env) {
  return new Promise((resolve) => {
    const child = spawn(process.execPath, ['scripts/e2e-real.mjs'], { env: { PATH: process.env.PATH, ...env }, cwd: new URL('..', import.meta.url).pathname });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    child.stderr.on('data', (d) => { out += d; });
    child.on('close', (code) => resolve({ code, out }));
  });
}

/** Modelo simulado que REALMENTE lê o contexto: devolve o código que aparece numa mensagem anterior do usuário. */
const smartModel = (req) => {
  const items = req.body.input || [];
  const userTexts = items.filter((i) => i.role === 'user').map((i) => (typeof i.content === 'string' ? i.content : ''));
  const last = userTexts.at(-1) || '';
  if (/Qual era o código/.test(last)) {
    const code = userTexts.join(' ').match(/KUPA-[0-9A-F]{8}/)?.[0] || 'nao sei';
    return { body: textResponse(code) };
  }
  if (/conexão funcionando/i.test(last)) return { body: textResponse('conexão funcionando.') };
  return { body: textResponse('OK') };
};

test('script e2e: passa quando o modelo realmente usa o contexto e imprime a evidência sem vazar o token', async () => {
  await withStack(smartModel, async (s) => {
    const r = await runScript({ KUPA_BACKEND_URL: s.base, KUPA_APP_TOKEN: APP_TOKEN, E2E_ALLOW_HTTP: '1' });
    assert.equal(r.code, 0, r.out);
    assert.match(r.out, /CONEXÃO REAL COMPROVADA/);
    assert.match(r.out, /\[openai\] a IA lembrou do código aleatório/);
    assert.ok(!r.out.includes(APP_TOKEN), 'o token nunca aparece na saída');
  });
});

test('script e2e: um servidor com RESPOSTA FIXA não passa (não finge IA real)', async () => {
  await withStack(() => ({ body: textResponse('Olá! Sou o KUPA e estou funcionando.') }), async (s) => {
    const r = await runScript({ KUPA_BACKEND_URL: s.base, KUPA_APP_TOKEN: APP_TOKEN, E2E_ALLOW_HTTP: '1' });
    assert.equal(r.code, 1, r.out);
    assert.match(r.out, /FALHOU .*lembrou do código/);
    assert.match(r.out, /RESULTADO: FALHOU/);
  });
});

test('script e2e: falha com clareza sem provedor configurado, com token errado e com URL http sem permissão', async () => {
  await withStack(smartModel, async (s) => {
    const noProv = await runScript({ KUPA_BACKEND_URL: s.base, KUPA_APP_TOKEN: APP_TOKEN, E2E_ALLOW_HTTP: '1', E2E_PROVIDER: 'gemini' });
    assert.equal(noProv.code, 1);
    assert.match(noProv.out, /não está entre|NENHUM provedor/);
    const wrong = await runScript({ KUPA_BACKEND_URL: s.base, KUPA_APP_TOKEN: ['token', 'que', 'nao', 'existe', '123456'].join('-'), E2E_ALLOW_HTTP: '1' });
    assert.equal(wrong.code, 1);
    assert.match(wrong.out, /FALHOU +3\./);
    const http = await runScript({ KUPA_BACKEND_URL: s.base, KUPA_APP_TOKEN: APP_TOKEN });
    assert.equal(http.code, 1);
    assert.match(http.out, /precisa ser https/);
  });
  const missing = await runScript({});
  assert.equal(missing.code, 1);
  assert.match(missing.out, /KUPA_BACKEND_URL não definida/);
  const onlyUrl = await runScript({ KUPA_BACKEND_URL: 'https://exemplo.invalid' });
  assert.match(onlyUrl.out, /KUPA_APP_TOKEN não definido/);
});

test('script e2e: backend que não é do KUPA ou fora do ar é reportado', async () => {
  const r = await runScript({ KUPA_BACKEND_URL: 'http://127.0.0.1:9', KUPA_APP_TOKEN: APP_TOKEN, E2E_ALLOW_HTTP: '1', E2E_TIMEOUT_MS: '3000' });
  assert.equal(r.code, 1);
  assert.match(r.out, /FALHOU +1\. \/health/);
});

async function withStack(handler, fn) {
  const stack = await startStack({ handler });
  try {
    await fn(stack);
  } finally {
    await stack.close();
  }
}
