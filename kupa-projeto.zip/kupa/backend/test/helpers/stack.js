import { createApp } from '../../src/server.js';
import { readConfig } from '../../src/config.js';
import { createLogger } from '../../src/logger.js';
import { createMockOpenAI } from './mockOpenAI.js';

export const API_KEY = 'sk-test-SECRETKEY1234567890';
export const APP_TOKEN = 'app-token-ABCDEFG123456';

export async function startStack({ env = {}, handler = () => ({ status: 500, body: {} }) } = {}) {
  const upstream = createMockOpenAI(handler);
  const upstreamPort = await upstream.listen();
  const fullEnv = {
    OPENAI_API_KEY: API_KEY,
    OPENAI_MODEL: 'test-model',
    KUPA_APP_TOKEN: APP_TOKEN,
    OPENAI_BASE_URL: `http://127.0.0.1:${upstreamPort}/v1`,
    ...env,
  };
  for (const [k, v] of Object.entries(env)) if (v === null) delete fullEnv[k];

  const config = readConfig(fullEnv);
  const logs = [];
  const logger = createLogger({ level: 'debug', secrets: [config.openai.apiKey, config.appToken], sink: (l) => logs.push(l) });
  const { server, sessions } = createApp(config, { logger });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;

  async function call(method, path, { body, token = config.appToken, headers = {} } = {}) {
    const h = { ...headers };
    if (token) h.authorization = `Bearer ${token}`;
    if (body !== undefined) h['content-type'] = 'application/json';
    const res = await fetch(base + path, { method, headers: h, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await res.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
    return { status: res.status, json, text };
  }

  return {
    base,
    upstream,
    logs,
    config,
    sessions,
    call,
    async close() {
      server.closeAllConnections?.();
      await new Promise((resolve) => server.close(() => resolve()));
      await upstream.close();
    },
  };
}
