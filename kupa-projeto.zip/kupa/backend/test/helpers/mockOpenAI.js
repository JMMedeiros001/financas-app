import http from 'node:http';

/** Servidor falso que imita só o formato do POST /v1/responses, usado APENAS nos testes automatizados. */
export function createMockOpenAI(handler) {
  const requests = [];
  const server = http.createServer(async (req, res) => {
    const chunks = [];
    for await (const chunk of req) chunks.push(chunk);
    let body = null;
    try {
      body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    } catch {
      body = null;
    }
    requests.push({ method: req.method, url: req.url, headers: req.headers, body });
    const out = (await handler({ method: req.method, url: req.url, headers: req.headers, body }, requests.length)) || {};
    if (out.delayMs) await new Promise((r) => setTimeout(r, out.delayMs));
    res.writeHead(out.status ?? 200, { 'content-type': 'application/json' });
    res.end(JSON.stringify(out.body ?? {}));
  });
  return {
    requests,
    listen: () => new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port))),
    close: () =>
      new Promise((resolve) => {
        server.closeAllConnections?.();
        server.close(() => resolve());
      }),
  };
}

export const textResponse = (text, { annotations = [], before = [] } = {}) => ({
  id: 'resp_test',
  status: 'completed',
  model: 'test-model',
  output: [
    ...before,
    { type: 'message', id: 'msg_1', role: 'assistant', status: 'completed', content: [{ type: 'output_text', text, annotations }] },
  ],
  usage: { input_tokens: 5, output_tokens: 7, total_tokens: 12 },
});

export const functionCallResponse = (name, args, callId = 'call_1') => ({
  id: 'resp_tool',
  status: 'completed',
  model: 'test-model',
  output: [
    { type: 'reasoning', id: 'rs_1', summary: [], encrypted_content: 'enc' },
    { type: 'function_call', id: 'fc_1', call_id: callId, name, arguments: JSON.stringify(args), status: 'completed' },
  ],
});
