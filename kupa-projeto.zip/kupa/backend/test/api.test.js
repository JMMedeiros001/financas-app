import test from 'node:test';
import assert from 'node:assert/strict';
import { startStack, API_KEY, APP_TOKEN } from './helpers/stack.js';
import { textResponse, functionCallResponse } from './helpers/mockOpenAI.js';
import { createLogger } from '../src/logger.js';
import { RateLimiter } from '../src/rateLimiter.js';
import { loadDotEnv, readConfig } from '../src/config.js';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const userMsg = (text) => ({ messages: [{ role: 'user', text }] });

async function withStack(opts, fn) {
  const stack = await startStack(opts);
  try {
    await fn(stack);
  } finally {
    await stack.close();
  }
}

test('GET /health responde sem autenticação e sem expor segredos', async () => {
  await withStack({}, async (s) => {
    const r = await s.call('GET', '/health', { token: '' });
    assert.equal(r.status, 200);
    assert.equal(r.json.ok, true);
    assert.ok(!r.text.includes(API_KEY));
    assert.equal(s.upstream.requests.length, 0, 'health não pode chamar a OpenAI');
  });
});

test('rotas /v1 exigem token e rejeitam token errado', async () => {
  await withStack({}, async (s) => {
    assert.equal((await s.call('GET', '/v1/config', { token: '' })).status, 401);
    assert.equal((await s.call('GET', '/v1/config', { token: 'errado' })).status, 401);
    assert.equal((await s.call('GET', '/v1/config')).status, 200);
  });
});

test('sem KUPA_APP_TOKEN as rotas /v1 respondem 503 (a menos que KUPA_ALLOW_NO_AUTH)', async () => {
  await withStack({ env: { KUPA_APP_TOKEN: null } }, async (s) => {
    const r = await s.call('GET', '/v1/config', { token: '' });
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'auth_not_configured');
  });
  await withStack({ env: { KUPA_APP_TOKEN: null, KUPA_ALLOW_NO_AUTH: '1' } }, async (s) => {
    assert.equal((await s.call('GET', '/v1/config', { token: '' })).status, 200);
  });
});

test('/v1/config mostra provedor/modelo/status mas nunca a chave', async () => {
  await withStack({}, async (s) => {
    const r = await s.call('GET', '/v1/config');
    assert.equal(r.json.provider, 'openai');
    assert.equal(r.json.model, 'test-model');
    assert.equal(r.json.apiKeyConfigured, true);
    assert.ok(!r.text.includes(API_KEY));
  });
  await withStack({ env: { OPENAI_API_KEY: null, OPENAI_MODEL: null } }, async (s) => {
    const r = await s.call('GET', '/v1/config');
    assert.equal(r.json.apiKeyConfigured, false);
    assert.equal(r.json.modelConfigured, false);
    assert.equal(r.json.model, null);
  });
});

test('/v1/ai/test faz uma chamada REAL ao provedor com chave, modelo e pergunta corretos', async () => {
  await withStack({ handler: () => ({ body: textResponse('Conexão funcionando.') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/test');
    assert.equal(r.status, 200);
    assert.equal(r.json.ok, true);
    assert.equal(r.json.replyMatches, true);
    assert.equal(s.upstream.requests.length, 1);
    const up = s.upstream.requests[0];
    assert.equal(up.url, '/v1/responses');
    assert.equal(up.headers.authorization, `Bearer ${API_KEY}`);
    assert.equal(up.body.model, 'test-model');
    assert.match(JSON.stringify(up.body.input), /conexão funcionando/);
    assert.equal(up.body.store, false);
  });
});

test('/v1/ai/test sem chave ou sem modelo NÃO chama a OpenAI e explica o que falta', async () => {
  await withStack({ env: { OPENAI_API_KEY: null } }, async (s) => {
    const r = await s.call('POST', '/v1/ai/test');
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'api_key_missing');
    assert.equal(s.upstream.requests.length, 0);
  });
  await withStack({ env: { OPENAI_MODEL: null } }, async (s) => {
    const r = await s.call('POST', '/v1/ai/test');
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'model_not_configured');
    assert.equal(s.upstream.requests.length, 0);
  });
});

test('erros da OpenAI viram mensagens compreensíveis e sem vazar a chave', async () => {
  const cases = [
    [401, 'openai_auth_error'],
    [404, 'openai_model_not_found'],
    [429, 'openai_rate_limited'],
    [400, 'openai_bad_request'],
  ];
  for (const [upstreamStatus, code] of cases) {
    await withStack(
      { handler: () => ({ status: upstreamStatus, body: { error: { message: `falha com ${API_KEY} no upstream` } } }) },
      async (s) => {
        const r = await s.call('POST', '/v1/ai/test');
        assert.equal(r.json.error.code, code, `status ${upstreamStatus}`);
        assert.ok(!s.logs.join('\n').includes(API_KEY));
      },
    );
  }
});

test('erro 5xx da OpenAI é tentado de novo uma vez antes de falhar', async () => {
  await withStack(
    { handler: (_req, n) => (n === 1 ? { status: 500, body: { error: { message: 'x' } } } : { body: textResponse('ok depois') }) },
    async (s) => {
      const r = await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
      assert.equal(r.status, 200);
      assert.equal(r.json.text, 'ok depois');
      assert.equal(s.upstream.requests.length, 2);
    },
  );
  await withStack({ handler: () => ({ status: 503, body: {} }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
    assert.equal(r.status, 502);
    assert.equal(r.json.error.code, 'openai_unavailable');
    assert.equal(s.upstream.requests.length, 2);
  });
});

test('timeout da OpenAI vira 504', async () => {
  await withStack(
    { env: { OPENAI_TIMEOUT_MS: '150' }, handler: () => ({ delayMs: 1200, body: textResponse('tarde demais') }) },
    async (s) => {
      const r = await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
      assert.equal(r.status, 504);
      assert.equal(r.json.error.code, 'openai_timeout');
    },
  );
});

test('resposta final com busca na web devolve texto, fontes e webSearchUsed', async () => {
  const resp = textResponse('Hoje choveu em Recife, segundo a pesquisa.', {
    before: [{ type: 'web_search_call', id: 'ws_1', status: 'completed', action: { type: 'search', query: 'clima', sources: [{ type: 'url', url: 'https://exemplo.com/a' }] } }],
    annotations: [{ type: 'url_citation', title: 'Clima hoje', url: 'https://exemplo.com/b', start_index: 0, end_index: 5 }],
  });
  await withStack({ handler: () => ({ body: resp }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', {
      body: { ...userMsg('como está o clima hoje?'), options: { allowWebSearch: true, mode: 'search', gameContext: '' } },
    });
    assert.equal(r.status, 200);
    assert.equal(r.json.status, 'final');
    assert.equal(r.json.webSearchUsed, true);
    assert.deepEqual(r.json.sources.map((x) => x.url).sort(), ['https://exemplo.com/a', 'https://exemplo.com/b']);
    const up = s.upstream.requests[0].body;
    assert.ok(up.tools.some((t) => t.type === 'web_search'));
    assert.match(up.instructions, /busca na web/);
    assert.ok(up.include.includes('web_search_call.action.sources'));
  });
});

test('sem allowWebSearch a ferramenta de busca não é enviada à OpenAI', async () => {
  await withStack({ handler: () => ({ body: textResponse('oi!') }) }, async (s) => {
    await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
    const up = s.upstream.requests[0].body;
    assert.equal(up.tools, undefined);
    assert.match(up.instructions, /não está disponível/);
  });
  await withStack({ env: { OPENAI_WEB_SEARCH: 'false' }, handler: () => ({ body: textResponse('oi!') }) }, async (s) => {
    await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { allowWebSearch: true } } });
    assert.equal(s.upstream.requests[0].body.tools, undefined);
  });
});

test('histórico, imagem anexada e contexto de jogo chegam ao modelo no formato oficial', async () => {
  await withStack({ handler: () => ({ body: textResponse('Compre o item X.') }) }, async (s) => {
    const img = 'data:image/jpeg;base64,/9j/AAAA';
    const r = await s.call('POST', '/v1/ai/respond', {
      body: {
        messages: [
          { role: 'user', text: 'oi' },
          { role: 'assistant', text: 'Oi!' },
          { role: 'user', text: 'qual item contra essa?' },
        ],
        attachments: [{ type: 'image', dataUrl: img }],
        options: { mode: 'gamer', gameContext: 'jogo: Mobile Legends; herói do usuário: Popol' },
      },
    });
    assert.equal(r.status, 200);
    const up = s.upstream.requests[0].body;
    assert.equal(up.input.length, 3);
    assert.deepEqual(up.input[1], { role: 'assistant', content: 'Oi!' });
    const last = up.input[2];
    assert.equal(last.content[0].type, 'input_text');
    assert.equal(last.content[1].type, 'input_image');
    assert.equal(last.content[1].image_url, img);
    assert.match(up.instructions, /Mobile Legends/);
    assert.match(up.instructions, /duas frases/);
  });
});

test('ferramenta de tela: IA pede analyze_screen, app devolve a imagem, IA responde', async () => {
  const handler = (_req, n) =>
    n === 1 ? { body: functionCallResponse('analyze_screen', { question: 'o que é isso?' }, 'call_42') } : { body: textResponse('É um botão de compartilhar.') };
  await withStack({ handler }, async (s) => {
    const first = await s.call('POST', '/v1/ai/respond', {
      body: { ...userMsg('Kupa, o que é isso?'), options: { enabledTools: ['analyze_screen'] } },
    });
    assert.equal(first.status, 200);
    assert.equal(first.json.status, 'tool_calls');
    assert.equal(first.json.calls[0].name, 'analyze_screen');
    assert.equal(first.json.calls[0].callId, 'call_42');
    assert.ok(first.json.sessionId);
    const tool = s.upstream.requests[0].body.tools.find((t) => t.name === 'analyze_screen');
    assert.equal(tool.type, 'function');

    const img = 'data:image/jpeg;base64,/9j/BBBB';
    const second = await s.call('POST', '/v1/ai/respond', {
      body: { sessionId: first.json.sessionId, toolResults: [{ callId: 'call_42', text: 'Captura feita.', imageDataUrl: img }] },
    });
    assert.equal(second.status, 200);
    assert.equal(second.json.status, 'final');
    assert.equal(second.json.text, 'É um botão de compartilhar.');
    const input = s.upstream.requests[1].body.input;
    const out = input.find((i) => i.type === 'function_call_output');
    assert.equal(out.call_id, 'call_42');
    assert.equal(out.output[1].type, 'input_image');
    assert.equal(out.output[1].image_url, img);
    assert.ok(input.some((i) => i.type === 'function_call'), 'itens da IA devem voltar no input');
    assert.ok(input.some((i) => i.type === 'reasoning'));

    const replay = await s.call('POST', '/v1/ai/respond', {
      body: { sessionId: first.json.sessionId, toolResults: [{ callId: 'call_42', text: 'de novo' }] },
    });
    assert.equal(replay.status, 410, 'sessão é de uso único');
  });
});

test('falha da ferramenta é repassada à IA como erro, sem inventar sucesso', async () => {
  const handler = (_req, n) =>
    n === 1 ? { body: functionCallResponse('analyze_screen', { question: 'x' }) } : { body: textResponse('Não consegui ver a tela.') };
  await withStack({ handler }, async (s) => {
    const first = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('o que é isso?'), options: { enabledTools: ['analyze_screen'] } } });
    const second = await s.call('POST', '/v1/ai/respond', {
      body: { sessionId: first.json.sessionId, toolResults: [{ callId: 'call_1', error: 'A captura de tela está bloqueada neste app.' }] },
    });
    assert.equal(second.json.status, 'final');
    const out = s.upstream.requests[1].body.input.find((i) => i.type === 'function_call_output');
    assert.match(out.output, /^ERRO: .*bloqueada/);
  });
});

test('IA não consegue chamar ferramenta que o app não habilitou', async () => {
  await withStack({ handler: () => ({ body: functionCallResponse('start_timer', { seconds: 5 }) }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('timer'), options: { enabledTools: ['analyze_screen'] } } });
    assert.equal(r.status, 502);
    assert.equal(r.json.error.code, 'tool_not_allowed');
  });
});

test('limite de rodadas de ferramenta evita laço infinito', async () => {
  await withStack({ env: { KUPA_MAX_TOOL_ROUNDS: '1' }, handler: () => ({ body: functionCallResponse('analyze_screen', { question: 'x' }) }) }, async (s) => {
    const first = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('x'), options: { enabledTools: ['analyze_screen'] } } });
    assert.equal(first.json.status, 'tool_calls');
    const second = await s.call('POST', '/v1/ai/respond', { body: { sessionId: first.json.sessionId, toolResults: [{ callId: 'call_1', text: 'ok' }] } });
    assert.equal(second.status, 422);
    assert.equal(second.json.error.code, 'too_many_tool_rounds');
  });
});

test('validação de entrada: 400 para pedidos malformados', async () => {
  await withStack({}, async (s) => {
    const bad = [
      {},
      { messages: [] },
      { messages: [{ role: 'assistant', text: 'oi' }] },
      { messages: [{ role: 'user', text: '   ' }] },
      { messages: [{ role: 'user', text: 'oi' }], attachments: [{ type: 'image', dataUrl: 'http://x/y.png' }] },
      { messages: [{ role: 'user', text: 'oi' }], options: { enabledTools: ['apagar_tudo'] } },
      { messages: [{ role: 'user', text: 'oi' }], options: { mode: 'hacker' } },
      { sessionId: 'abc' },
    ];
    for (const body of bad) {
      const r = await s.call('POST', '/v1/ai/respond', { body });
      assert.equal(r.status, 400, JSON.stringify(body).slice(0, 80));
    }
    const unknown = await s.call('POST', '/v1/ai/respond', { body: { sessionId: 'nao-existe', toolResults: [{ callId: 'x', text: 'y' }] } });
    assert.equal(unknown.status, 410);
    assert.equal(s.upstream.requests.length, 0, 'nada inválido pode chegar à OpenAI');
  });
});

test('corpo grande demais é recusado com 413', async () => {
  await withStack({ env: { KUPA_MAX_BODY_MB: '1' } }, async (s) => {
    const huge = 'x'.repeat(1_200_000);
    const r = await s.call('POST', '/v1/ai/respond', { body: { messages: [{ role: 'user', text: huge }] } });
    assert.equal(r.status, 413);
  });
});

test('limite de requisições por minuto responde 429', async () => {
  await withStack({ env: { KUPA_RATE_LIMIT_PER_MINUTE: '3' } }, async (s) => {
    for (let i = 0; i < 3; i += 1) assert.equal((await s.call('GET', '/v1/config')).status, 200);
    const r = await s.call('GET', '/v1/config');
    assert.equal(r.status, 429);
    assert.equal(r.json.error.code, 'rate_limited');
  });
});

test('rota desconhecida: 404', async () => {
  await withStack({}, async (s) => {
    assert.equal((await s.call('GET', '/v1/nada')).status, 404);
    assert.equal((await s.call('GET', '/qualquer', { token: '' })).status, 404);
  });
});

test('logs nunca contêm a chave da OpenAI nem o token do app, mesmo em falhas', async () => {
  await withStack({ handler: () => ({ status: 401, body: { error: { message: `Incorrect API key provided: ${API_KEY}` } } }) }, async (s) => {
    await s.call('POST', '/v1/ai/test');
    await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
    await s.call('GET', '/v1/config', { token: 'token-errado-123456' });
    const all = s.logs.join('\n');
    assert.ok(all.length > 0);
    assert.ok(!all.includes(API_KEY));
    assert.ok(!all.includes(APP_TOKEN));
    assert.ok(!all.includes('data:image'));
  });
});

test('redator de logs remove sk-..., Bearer e segredos conhecidos', () => {
  const lines = [];
  const log = createLogger({ secrets: ['meu-segredo-xyz'], sink: (l) => lines.push(l) });
  log.info('teste', { a: 'chave sk-abcdefghijklmnop e meu-segredo-xyz', h: 'Authorization: Bearer abc.def-123456789' });
  const out = lines[0];
  assert.ok(!out.includes('abcdefghijklmnop'));
  assert.ok(!out.includes('meu-segredo-xyz'));
  assert.ok(!out.includes('abc.def-123456789'));
});

test('RateLimiter libera de novo depois da janela', () => {
  let now = 0;
  const rl = new RateLimiter({ limit: 2, windowMs: 1000, now: () => now });
  rl.check('a');
  rl.check('a');
  assert.throws(() => rl.check('a'), /Muitas solicitações/);
  now = 1500;
  rl.check('a');
});

test('loadDotEnv lê .env sem sobrescrever variáveis já definidas', () => {
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'kupa-')), '.env');
  fs.writeFileSync(file, '# comentário\nOPENAI_MODEL=modelo-x\nPORT="9001"\nJA_DEFINIDA=do-arquivo\n');
  const env = { JA_DEFINIDA: 'do-ambiente' };
  assert.equal(loadDotEnv(file, env), true);
  assert.equal(env.OPENAI_MODEL, 'modelo-x');
  assert.equal(env.PORT, '9001');
  assert.equal(env.JA_DEFINIDA, 'do-ambiente');
  assert.equal(readConfig(env).port, 9001);
});
