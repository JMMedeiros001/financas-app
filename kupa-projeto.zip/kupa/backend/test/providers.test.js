/**
 * Testes dos provedores Claude (Anthropic) e Gemini (Google) e do roteamento/fallback.
 * ATENÇÃO: todos usam um servidor SIMULADO que só imita o formato documentado das APIs. Eles provam que o código monta
 * as requisições e lê as respostas como a documentação descreve; NÃO provam que a API real aceita (nunca houve chamada real).
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { startStack, APP_TOKEN } from './helpers/stack.js';
import { textResponse } from './helpers/mockOpenAI.js';
import { planProviders } from '../src/services/aiRouter.js';
import { AIProviderManager } from '../src/providers/providerManager.js';

const A_KEY = ['sk', 'ant', 'MOCKKEY1234567890ABCDEFG'].join('-');
const G_KEY = ['AIza', 'MOCKGEMINIKEY1234567890ABCDEFGHI'].join('');
const userMsg = (text) => ({ messages: [{ role: 'user', text }] });
const ENV_ALL = { ANTHROPIC_API_KEY: A_KEY, ANTHROPIC_MODEL: 'claude-mock', GEMINI_API_KEY: G_KEY, GEMINI_MODEL: 'gemini-mock' };

async function withStack(opts, fn) {
  const stack = await startStack(opts);
  try {
    await fn(stack);
  } finally {
    await stack.close();
  }
}

const anthropicText = (text, extra = {}) => ({ id: 'msg_1', type: 'message', role: 'assistant', model: 'claude-mock', stop_reason: 'end_turn', content: [{ type: 'text', text }], usage: { input_tokens: 5, output_tokens: 5 }, ...extra });
const geminiText = (text, extra = {}) => ({ candidates: [{ content: { role: 'model', parts: [{ text }] }, finishReason: 'STOP' }], modelVersion: 'gemini-mock', ...extra });
const isAnthropic = (r) => r.url === '/v1/messages';
const isGemini = (r) => r.url.startsWith('/v1beta/models/');

// ------------------------------------------------------------------ Claude
test('[MOCK] Claude: requisição segue o formato oficial (cabeçalhos, system, messages, modelo)', async () => {
  await withStack({ env: ENV_ALL, handler: () => ({ body: anthropicText('Oi do Claude') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'anthropic' } } });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.text, 'Oi do Claude');
    assert.equal(r.json.route.provider, 'anthropic');
    const up = s.upstream.requests[0];
    assert.equal(up.method, 'POST');
    assert.equal(up.url, '/v1/messages');
    assert.equal(up.headers['x-api-key'], A_KEY);
    assert.equal(up.headers['anthropic-version'], '2023-06-01');
    assert.equal(up.body.model, 'claude-mock');
    assert.equal(up.body.max_tokens, 1024);
    assert.match(up.body.system, /DADO NÃO CONFIÁVEL/);
    assert.deepEqual(up.body.messages, [{ role: 'user', content: 'oi' }]);
    assert.ok(!('tools' in up.body), 'sem ferramentas habilitadas não envia tools');
  });
});

test('[MOCK] Claude: ferramenta do KUPA vira tool_use, e o resultado volta como tool_result numa mensagem de usuário', async () => {
  let n = 0;
  await withStack({
    env: ENV_ALL,
    handler: () => {
      n += 1;
      if (n === 1) {
        return { body: { type: 'message', role: 'assistant', model: 'claude-mock', stop_reason: 'tool_use', content: [{ type: 'text', text: 'Vou abrir.' }, { type: 'tool_use', id: 'toolu_1', name: 'open_app', input: { app_name: 'WhatsApp' } }] } };
      }
      return { body: anthropicText('Pedi para abrir.') };
    },
  }, async (s) => {
    const first = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('abre o zap'), options: { provider: 'anthropic', enabledTools: ['open_app'] } } });
    assert.equal(first.json.status, 'tool_calls', first.text);
    assert.deepEqual(first.json.calls, [{ callId: 'toolu_1', name: 'open_app', arguments: { app_name: 'WhatsApp' } }]);
    const tools = s.upstream.requests[0].body.tools;
    assert.equal(tools[0].name, 'open_app');
    assert.equal(tools[0].input_schema.type, 'object');
    const second = await s.call('POST', '/v1/ai/respond', { body: { sessionId: first.json.sessionId, toolResults: [{ callId: 'toolu_1', text: 'Abri o WhatsApp.' }] } });
    assert.equal(second.json.status, 'final', second.text);
    assert.equal(second.json.route.provider, 'anthropic', 'a continuação usa o MESMO provedor');
    const msgs = s.upstream.requests[1].body.messages;
    assert.equal(msgs.length, 3);
    assert.equal(msgs[1].role, 'assistant');
    assert.equal(msgs[1].content[1].type, 'tool_use', 'o conteúdo do assistente volta INTEIRO');
    assert.deepEqual(msgs[2], { role: 'user', content: [{ type: 'tool_result', tool_use_id: 'toolu_1', content: 'Abri o WhatsApp.' }] });
  });
});

test('[MOCK] Claude: imagem anexada vai como bloco image base64; erro de ferramenta vira is_error', async () => {
  await withStack({ env: ENV_ALL, handler: () => ({ body: anthropicText('Vejo um gato.') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('o que é isso?'), attachments: [{ type: 'image', dataUrl: 'data:image/png;base64,iVBORw0KGgo=' }], options: { provider: 'anthropic' } } });
    assert.equal(r.status, 200, r.text);
    const content = s.upstream.requests[0].body.messages[0].content;
    assert.deepEqual(content[0], { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'iVBORw0KGgo=' } });
    assert.deepEqual(content[1], { type: 'text', text: 'o que é isso?' });
  });
});

test('[MOCK] Claude: busca na web (ferramenta de servidor), fontes e pause_turn', async () => {
  let n = 0;
  await withStack({
    env: ENV_ALL,
    handler: () => {
      n += 1;
      if (n === 1) {
        return { body: { type: 'message', role: 'assistant', model: 'claude-mock', stop_reason: 'pause_turn', content: [{ type: 'server_tool_use', id: 'srvtoolu_1', name: 'web_search', input: { query: 'x' } }] } };
      }
      return {
        body: {
          type: 'message', role: 'assistant', model: 'claude-mock', stop_reason: 'end_turn',
          content: [
            { type: 'web_search_tool_result', tool_use_id: 'srvtoolu_1', content: [{ type: 'web_search_result', title: 'Fonte A', url: 'https://a.example/x' }] },
            { type: 'text', text: 'Resposta com fonte.', citations: [{ type: 'web_search_result_location', title: 'Fonte B', url: 'https://b.example/y' }] },
          ],
        },
      };
    },
  }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('notícias'), options: { provider: 'anthropic', allowWebSearch: true } } });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.text, 'Resposta com fonte.');
    assert.equal(r.json.webSearchUsed, true);
    assert.deepEqual(r.json.sources.map((x) => x.url).sort(), ['https://a.example/x', 'https://b.example/y']);
    const first = s.upstream.requests[0].body.tools.find((t) => t.type === 'web_search_20250305');
    assert.equal(first.name, 'web_search');
    assert.equal(s.upstream.requests.length, 2, 'pause_turn continua o turno uma vez');
    assert.equal(s.upstream.requests[1].body.messages.at(-1).role, 'assistant', 'continua com o conteúdo pausado, sem tool_result');
  });
});

test('[MOCK] Claude: erros viram mensagens claras; chave nunca vaza; 529 tenta de novo', async () => {
  await withStack({ env: ENV_ALL, handler: () => ({ status: 401, body: { type: 'error', error: { type: 'authentication_error', message: `invalid x-api-key ${A_KEY}` } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'anthropic' } } });
    assert.equal(r.json.error.code, 'anthropic_auth_error');
    assert.ok(!r.text.includes(A_KEY));
    assert.ok(!s.logs.join('\n').includes(A_KEY), 'a chave não pode aparecer nos logs');
  });
  await withStack({ env: ENV_ALL, handler: () => ({ status: 529, body: { type: 'error', error: { type: 'overloaded_error', message: 'Overloaded' } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'anthropic' } } });
    assert.equal(r.json.error.code, 'anthropic_unavailable');
    assert.equal(s.upstream.requests.length, 2, 'uma nova tentativa');
  });
  await withStack({ env: { ...ENV_ALL, ANTHROPIC_API_KEY: null }, handler: () => ({ body: anthropicText('x') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'anthropic' } } });
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'provider_not_available', 'provedor escolhido e não configurado: não troca em silêncio');
    assert.equal(s.upstream.requests.length, 0);
  });
});

// ------------------------------------------------------------------ Gemini
test('[MOCK] Gemini: requisição segue o formato oficial (caminho, cabeçalho, systemInstruction, papéis)', async () => {
  await withStack({ env: ENV_ALL, handler: () => ({ body: geminiText('Oi do Gemini') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', {
      body: { messages: [{ role: 'user', text: 'oi' }, { role: 'assistant', text: 'olá' }, { role: 'user', text: 'tudo bem?' }], options: { provider: 'gemini' } },
    });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.text, 'Oi do Gemini');
    assert.equal(r.json.route.provider, 'gemini');
    const up = s.upstream.requests[0];
    assert.equal(up.url, '/v1beta/models/gemini-mock:generateContent');
    assert.equal(up.headers['x-goog-api-key'], G_KEY);
    assert.match(up.body.systemInstruction.parts[0].text, /DADO NÃO CONFIÁVEL/);
    assert.deepEqual(up.body.contents.map((c) => c.role), ['user', 'model', 'user']);
    assert.ok(!('tools' in up.body));
  });
});

test('[MOCK] Gemini: functionCall vira chamada de ferramenta e o resultado volta como functionResponse; esquema sem additionalProperties', async () => {
  let n = 0;
  const modelParts = [{ text: 'pensando', thought: true }, { functionCall: { name: 'open_app', args: { app_name: 'YouTube' } } }];
  await withStack({
    env: ENV_ALL,
    handler: () => {
      n += 1;
      if (n === 1) return { body: { candidates: [{ content: { role: 'model', parts: modelParts }, finishReason: 'STOP' }], modelVersion: 'gemini-mock' } };
      return { body: geminiText('Pedi para abrir o YouTube.') };
    },
  }, async (s) => {
    const first = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('abre o youtube'), options: { provider: 'gemini', enabledTools: ['open_app'], allowWebSearch: true } } });
    assert.equal(first.json.status, 'tool_calls', first.text);
    assert.equal(first.json.calls[0].name, 'open_app');
    assert.deepEqual(first.json.calls[0].arguments, { app_name: 'YouTube' });
    const decl = s.upstream.requests[0].body.tools[0].functionDeclarations[0];
    assert.equal(decl.name, 'open_app');
    assert.ok(!JSON.stringify(decl).includes('additionalProperties'), 'o Gemini não aceita additionalProperties');
    assert.equal(s.upstream.requests[0].body.tools.length, 1, 'com ferramentas do KUPA a busca do Google não é combinada');
    assert.ok(!JSON.stringify(s.upstream.requests[0].body.tools).includes('google_search'));
    const second = await s.call('POST', '/v1/ai/respond', { body: { sessionId: first.json.sessionId, toolResults: [{ callId: first.json.calls[0].callId, text: 'Abri o YouTube.' }] } });
    assert.equal(second.json.status, 'final', second.text);
    const contents = s.upstream.requests[1].body.contents;
    assert.deepEqual(contents[1].parts, modelParts, 'o turno do modelo volta INTEIRO (inclusive partes de raciocínio)');
    assert.deepEqual(contents[2], { role: 'user', parts: [{ functionResponse: { name: 'open_app', response: { result: 'Abri o YouTube.' } } }] });
  });
});

test('[MOCK] Gemini: busca (google_search) só sem ferramentas; fontes do grounding; raciocínio fora do texto; bloqueio vira erro', async () => {
  await withStack({
    env: ENV_ALL,
    handler: () => ({ body: { candidates: [{ content: { role: 'model', parts: [{ text: 'interno', thought: true }, { text: 'Resposta pesquisada.' }] }, finishReason: 'STOP', groundingMetadata: { webSearchQueries: ['q'], groundingChunks: [{ web: { uri: 'https://g.example/1', title: 'G1' } }] } }] } }),
  }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('notícias'), options: { provider: 'gemini', allowWebSearch: true } } });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.text, 'Resposta pesquisada.');
    assert.equal(r.json.webSearchUsed, true);
    assert.deepEqual(r.json.sources, [{ title: 'G1', url: 'https://g.example/1' }]);
    assert.deepEqual(s.upstream.requests[0].body.tools, [{ google_search: {} }]);
    assert.match(s.upstream.requests[0].body.systemInstruction.parts[0].text, /pesquisar na internet|busca/i);
  });
  await withStack({ env: ENV_ALL, handler: () => ({ body: { promptFeedback: { blockReason: 'SAFETY' } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('x'), options: { provider: 'gemini' } } });
    assert.equal(r.json.error.code, 'gemini_blocked');
  });
  await withStack({ env: ENV_ALL, handler: () => ({ status: 429, body: { error: { message: `quota ${G_KEY}` } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('x'), options: { provider: 'gemini' } } });
    assert.equal(r.json.error.code, 'gemini_rate_limited');
    assert.ok(!r.text.includes(G_KEY) && !s.logs.join('\n').includes(G_KEY));
  });
});

test('[MOCK] Gemini: imagem anexada vira inlineData', async () => {
  await withStack({ env: ENV_ALL, handler: () => ({ body: geminiText('ok') }) }, async (s) => {
    await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('o que é?'), attachments: [{ type: 'image', dataUrl: 'data:image/jpeg;base64,/9j/AAAA' }], options: { provider: 'gemini' } } });
    assert.deepEqual(s.upstream.requests[0].body.contents[0].parts[1], { inlineData: { mimeType: 'image/jpeg', data: '/9j/AAAA' } });
  });
});

// ------------------------------------------------------------------ roteamento
test('roteamento automático usa só provedores configurados, na ordem configurada', async () => {
  await withStack({ env: { ANTHROPIC_API_KEY: null, GEMINI_API_KEY: G_KEY, GEMINI_MODEL: 'gemini-mock', OPENAI_API_KEY: null }, handler: (req) => ({ body: isGemini(req) ? geminiText('do gemini') : textResponse('do openai') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
    assert.equal(r.json.route.provider, 'gemini', r.text);
    assert.equal(r.json.text, 'do gemini');
  });
  await withStack({ env: { ...ENV_ALL, KUPA_PROVIDER_ORDER: 'gemini,openai' }, handler: (req) => ({ body: isGemini(req) ? geminiText('do gemini') : textResponse('do openai') }) }, async (s) => {
    assert.equal((await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') })).json.route.provider, 'gemini', 'a ordem vem da configuração');
    assert.equal((await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'openai' } } })).json.route.provider, 'openai', 'escolha manual vence');
  });
  await withStack({ env: { OPENAI_API_KEY: null }, handler: () => ({ body: textResponse('x') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: userMsg('oi') });
    assert.equal(r.status, 503);
    assert.equal(r.json.error.code, 'no_provider_available');
  });
});

test('planProviders respeita capacidades e limite de contexto informado (sem inventar limites)', () => {
  const fake = (name, caps, configured = true) => ({
    name, label: name, start() {}, resume() {}, ping() {},
    status: () => ({ configured }), capabilities: () => caps, models: () => ({ default: `${name}-m` }),
  });
  const m = new AIProviderManager()
    .register(fake('a', { vision: false, tools: true, maxContextChars: 0 }))
    .register(fake('b', { vision: true, tools: false, maxContextChars: 100 }))
    .register(fake('c', { vision: true, tools: true, maxContextChars: 0 }, false));
  const names = (plan) => plan.candidates.map((c) => c.provider);
  assert.deepEqual(names(planProviders({}, m, ['a', 'b', 'c'])), ['a', 'b'], 'não configurado fica de fora');
  assert.deepEqual(names(planProviders({ hasImage: true }, m, ['a', 'b', 'c'])), ['b'], 'sem visão fica de fora');
  assert.deepEqual(names(planProviders({ needsTools: true }, m, ['a', 'b', 'c'])), ['a'], 'sem ferramentas fica de fora');
  assert.deepEqual(names(planProviders({ contextChars: 500 }, m, ['a', 'b', 'c'])), ['a'], 'contexto acima do limite informado');
  assert.equal(planProviders({ preference: 'c' }, m, ['a', 'b', 'c']).error.code, 'provider_not_available');
  assert.equal(planProviders({ preference: 'zzz' }, m, ['a', 'b', 'c']).error.code, 'provider_unknown');
  assert.deepEqual(names(planProviders({ preference: 'b' }, m, ['a', 'b', 'c'])), ['b', 'a'], 'preferido primeiro, depois reservas');
  assert.equal(planProviders({}, m, ['c']).error.code, 'no_provider_available');
});

// ------------------------------------------------------------------ fallback seguro
test('fallback: só com autorização do usuário, só para falha do provedor, uma vez, e informando', async () => {
  const handler = (req) => (isAnthropic(req) ? { body: anthropicText('Respondi pelo Claude.') } : { status: 500, body: { error: { message: 'boom' } } });
  await withStack({ env: ENV_ALL, handler }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'openai', fallbackAllowed: true } } });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.text, 'Respondi pelo Claude.');
    assert.equal(r.json.route.provider, 'anthropic');
    assert.deepEqual(r.json.route.fallback, { from: 'openai', to: 'anthropic', reason: 'openai_unavailable' });
    const hits = s.upstream.requests.map((q) => (isAnthropic(q) ? 'anthropic' : 'openai'));
    assert.equal(hits.filter((h) => h === 'anthropic').length, 1, 'o reserva é chamado uma única vez');
  });
  await withStack({ env: ENV_ALL, handler }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'openai' } } });
    assert.equal(r.status, 502, 'sem autorização: não envia para outro provedor');
    assert.ok(s.upstream.requests.every((q) => !isAnthropic(q)), 'nenhuma chamada ao reserva');
  });
  await withStack({ env: ENV_ALL, handler: (req) => (isAnthropic(req) ? { body: anthropicText('x') } : { status: 400, body: { error: { message: 'pedido ruim' } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'openai', fallbackAllowed: true } } });
    assert.equal(r.json.error.code, 'openai_bad_request', 'erro do PEDIDO não vira fallback');
    assert.ok(s.upstream.requests.every((q) => !isAnthropic(q)));
  });
  await withStack({ env: ENV_ALL, handler: () => ({ status: 503, body: { error: { message: 'fora' } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'openai', fallbackAllowed: true } } });
    assert.equal(r.status, 502, 'se o reserva também falhar, o erro aparece (sem loop)');
  });
});

test('/v1/ai/test testa o provedor pedido com uma chamada de verdade (ao servidor simulado) e /v1/config nunca mostra chaves', async () => {
  await withStack({ env: ENV_ALL, handler: (req) => ({ body: isAnthropic(req) ? anthropicText('conexão funcionando.') : geminiText('conexão funcionando.') }) }, async (s) => {
    const a = await s.call('POST', '/v1/ai/test', { body: { provider: 'anthropic' } });
    assert.equal(a.status, 200, a.text);
    assert.equal(a.json.provider, 'anthropic');
    assert.equal(a.json.replyMatches, true);
    const g = await s.call('POST', '/v1/ai/test', { body: { provider: 'gemini' } });
    assert.equal(g.json.provider, 'gemini');
    const cfg = await s.call('GET', '/v1/config');
    for (const secret of [A_KEY, G_KEY, APP_TOKEN]) assert.ok(!cfg.text.includes(secret));
    assert.ok(cfg.json.providers.every((p) => typeof p.configured === 'boolean'));
    const unknown = await s.call('POST', '/v1/ai/test', { body: { provider: 'xyz' } });
    assert.equal(unknown.status, 400);
  });
  await withStack({ env: { ...ENV_ALL, GEMINI_API_KEY: null }, handler: () => ({ body: geminiText('x') }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/test', { body: { provider: 'gemini' } });
    assert.equal(r.json.error.code, 'api_key_missing');
    assert.equal(s.upstream.requests.length, 0, 'sem chave não chama ninguém');
  });
});

test('[MOCK] Gemini: se a busca (google_search) for recusada (nível gratuito), tenta uma vez sem ela e informa que não pesquisou', async () => {
  let calls = 0;
  await withStack({
    env: ENV_ALL,
    handler: (req) => {
      calls += 1;
      if (JSON.stringify(req.body.tools || []).includes('google_search')) return { status: 400, body: { error: { message: 'Search grounding is not supported for this tier.' } } };
      return { body: geminiText('Respondi sem pesquisar.') };
    },
  }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('notícias'), options: { provider: 'gemini', allowWebSearch: true } } });
    assert.equal(r.status, 200, r.text);
    assert.equal(r.json.text, 'Respondi sem pesquisar.');
    assert.equal(r.json.webSearchUsed, false, 'não houve pesquisa: o app não pode afirmar que pesquisou');
    assert.equal(calls, 2, 'uma tentativa com busca e UMA sem');
    assert.ok(!('tools' in s.upstream.requests[1].body), 'a segunda chamada vai sem a ferramenta de busca');
  });
  // um erro que não é da busca continua sendo erro (sem "recuar" à toa)
  await withStack({ env: ENV_ALL, handler: () => ({ status: 400, body: { error: { message: 'pedido ruim' } } }) }, async (s) => {
    const r = await s.call('POST', '/v1/ai/respond', { body: { ...userMsg('oi'), options: { provider: 'gemini' } } });
    assert.equal(r.json.error.code, 'gemini_bad_request');
    assert.equal(s.upstream.requests.length, 1, 'sem busca na requisição, nada de segunda tentativa');
  });
});
