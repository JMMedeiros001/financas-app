package com.kupa.assistant.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import com.kupa.assistant.core.KupaLog
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Autenticação NATIVA do Android (biometria, PIN, padrão ou senha do aparelho) pela tela oficial de confirmação de credencial.
 * O KUPA nunca vê a senha/biometria: só recebe "confirmou" ou "não confirmou". Voz NUNCA substitui isto.
 */
object NativeAuth {
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var pending: ((Boolean) -> Unit)? = null

    @Volatile
    var title: String = "KUPA"
        private set

    @Volatile
    var description: String = ""
        private set

    /** O aparelho tem bloqueio de tela configurado (condição para autenticar)? Sem isso não há como verificar com segurança. */
    fun isAvailable(context: Context): Boolean {
        val km = context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager ?: return false
        return km.isDeviceSecure
    }

    /** Pede a autenticação. [callback] roda na thread principal com true só se o usuário confirmou. */
    fun request(context: Context, title: String, description: String, callback: (Boolean) -> Unit) {
        if (!isAvailable(context)) {
            main.post { callback(false) }
            return
        }
        this.title = title
        this.description = description
        pending = callback
        try {
            context.startActivity(Intent(context, NativeAuthActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            KupaLog.e("autenticacao", "não consegui abrir a confirmação do aparelho", e)
            deliver(false)
        }
    }

    /** Versão que BLOQUEIA (use só em thread de trabalho). Sem resposta em [timeoutMs] = não autenticado. */
    fun requestBlocking(context: Context, title: String, description: String, timeoutMs: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        request(context, title, description) { result ->
            ok = result
            latch.countDown()
        }
        return latch.await(timeoutMs, TimeUnit.MILLISECONDS) && ok
    }

    internal fun deliver(ok: Boolean) {
        val cb = pending
        pending = null
        if (cb != null) main.post { cb(ok) }
    }
}

/** Tela transparente que mostra a confirmação oficial do aparelho e devolve o resultado. */
class NativeAuthActivity : Activity() {
    private var finished = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val intent = km?.createConfirmDeviceCredentialIntent(NativeAuth.title, NativeAuth.description)
        if (intent == null) {
            finishWith(false)
            return
        }
        try {
            startActivityForResult(intent, REQUEST)
        } catch (e: Exception) {
            KupaLog.e("autenticacao", "falha ao abrir a confirmação", e)
            finishWith(false)
        }
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        finishWith(requestCode == REQUEST && resultCode == RESULT_OK)
    }

    private fun finishWith(ok: Boolean) {
        if (finished) return
        finished = true
        NativeAuth.deliver(ok)
        finish()
    }

    override fun onDestroy() {
        if (!finished) {
            finished = true
            NativeAuth.deliver(false)
        }
        super.onDestroy()
    }

    companion object {
        private const val REQUEST = 9001
    }
}
