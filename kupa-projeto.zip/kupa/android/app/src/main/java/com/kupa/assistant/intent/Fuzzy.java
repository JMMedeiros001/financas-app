package com.kupa.assistant.intent;

/** Comparações aproximadas para nomes ditos por voz (o reconhecimento erra letras). */
final class Fuzzy {
    private Fuzzy() {}

    /** true se a distância de edição entre a e b é no máximo 1 (e as palavras são longas o bastante). */
    static boolean withinOne(String a, String b, int minLen) {
        if (a.length() < minLen || b.length() < minLen) return false;
        int la = a.length();
        int lb = b.length();
        if (Math.abs(la - lb) > 1) return false;
        int i = 0;
        int j = 0;
        int edits = 0;
        while (i < la && j < lb) {
            if (a.charAt(i) == b.charAt(j)) {
                i++;
                j++;
                continue;
            }
            edits++;
            if (edits > 1) return false;
            if (la > lb) i++;
            else if (lb > la) j++;
            else {
                i++;
                j++;
            }
        }
        edits += (la - i) + (lb - j);
        return edits <= 1;
    }
}
