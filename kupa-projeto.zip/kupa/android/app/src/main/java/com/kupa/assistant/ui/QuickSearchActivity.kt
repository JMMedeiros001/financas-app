package com.kupa.assistant.ui

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.kupa.assistant.KupaApp
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.history.HistoryType
import com.kupa.assistant.overlay.KupaService

/** Pesquisa rápida: pergunta curta e a resposta aparece no balão ao lado do Popol (sem abrir tela grande). */
class QuickSearchActivity : Activity(), KupaCore.Listener {
    private lateinit var app: KupaApp
    private lateinit var result: TextView
    private lateinit var input: EditText
    private var waiting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        val pad = Ui.dp(this, 16)
        root.setPadding(pad, pad, pad, pad)
        root.addView(Ui.text(this, "Pesquisa rápida", 18f, Ui.TEXT, bold = true))
        input = EditText(this)
        input.hint = "O que você quer saber?"
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                run()
                true
            } else {
                false
            }
        }
        root.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        Ui.button(root, "Pesquisar", primary = true) { run() }
        result = Ui.text(this, "", 14f, Ui.TEXT)
        result.setTextIsSelectable(true)
        root.addView(result)
        setContentView(root)
    }

    private fun run() {
        val q = input.text.toString().trim()
        if (q.isEmpty()) return
        waiting = true
        result.text = ""
        app.core.submitText(q, HistoryType.SEARCH, forceSearch = true)
        // com o Popol flutuante ativo, a resposta aparece no balão dele: fecha esta janela
        if (KupaService.running && app.settings.overlayEnabled && app.settings.showBubble) finish()
        else result.text = "Pesquisando…"
    }

    override fun onStart() {
        super.onStart()
        app.core.addListener(this)
    }

    override fun onStop() {
        app.core.removeListener(this)
        super.onStop()
    }

    override fun onExchange(exchange: KupaCore.Exchange) {
        if (!waiting) return
        waiting = false
        val sources = if (exchange.sources.isEmpty()) "" else "\n\nFontes: " + exchange.sources.joinToString(", ") { it.title.ifEmpty { it.url } }
        result.text = exchange.answer + sources
    }

    override fun onProblem(message: String) {
        if (!waiting) return
        waiting = false
        result.setTextColor(Ui.BAD)
        result.text = message
    }

    override fun onBubble(text: String?, isError: Boolean) {}
}
