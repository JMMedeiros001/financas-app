package com.kupa.assistant.actions

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.provider.Settings as AndroidSettings
import com.kupa.assistant.intent.AppMatcher
import com.kupa.assistant.intent.TextNorm

/** Descobre os aplicativos instalados (com ícone de abrir) e monta o Intent de abrir. Sem lista fixa de apps. */
class AppLauncher(private val context: Context) {
    private var cache: List<AppMatcher.AppEntry> = emptyList()
    private var cachedAt = 0L

    /** Apps que aparecem na tela inicial do aparelho. Precisa do <queries> do manifesto (Android 11+). */
    @Synchronized
    fun listApps(forceRefresh: Boolean = false): List<AppMatcher.AppEntry> {
        val now = SystemClock.elapsedRealtime()
        if (!forceRefresh && cache.isNotEmpty() && now - cachedAt < 60_000) return cache
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val infos = pm.queryIntentActivities(query, 0)
        val seen = HashSet<String>()
        val list = ArrayList<AppMatcher.AppEntry>()
        for (info in infos) {
            val pkg = info.activityInfo.packageName
            if (pkg == context.packageName || !seen.add(pkg)) continue
            val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
            if (label.isNotEmpty()) list.add(AppMatcher.AppEntry(pkg, label))
        }
        cache = list
        cachedAt = now
        return list
    }

    fun launchIntentFor(pkg: String): Intent? = context.packageManager.getLaunchIntentForPackage(pkg)

    /** Alvos do sistema que não são "apps da lista": câmera, configurações e discador. */
    fun systemTarget(spoken: String): SystemTarget? {
        val n = TextNorm.normalize(spoken)
        return when (n) {
            "camera", "a camera", "camera do celular", "camara" -> SystemTarget("a câmera", Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "configuracoes", "configuracao", "ajustes", "settings", "as configuracoes", "configuracoes do celular" ->
                SystemTarget("as configurações", Intent(AndroidSettings.ACTION_SETTINGS))
            "telefone", "discador", "o discador", "teclado do telefone" -> SystemTarget("o discador", Intent(Intent.ACTION_DIAL))
            else -> null
        }
    }

    class SystemTarget(val label: String, val intent: Intent)
}
