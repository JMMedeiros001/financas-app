package com.kupa.assistant.character

import android.os.SystemClock
import android.view.View
import kotlin.random.Random

/**
 * Anima UMA camada (Popol ou Kupa). Os dois controladores são independentes e só recebem o nome da animação
 * do StateManager: assim cada personagem pode ganhar animações próprias sem mexer no sistema principal.
 */
open class LayerAnimator(private val role: String) {
    private var target: View? = null
    private var animation = "idle"
    private var startedAt = SystemClock.uptimeMillis()
    private var enabled = true

    // micro-movimentos aleatórios do estado de espera
    private var nextFidgetAt = 0L
    private var fidgetStart = 0L
    private var fidgetKind = 0
    private val fidgetDuration = 0.9f

    val currentAnimation: String get() = animation

    fun attach(view: View?) {
        target = view
        if (view != null) {
            view.post {
                view.pivotX = view.width / 2f
                view.pivotY = view.height.toFloat()
            }
        }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
        if (!value) applyTransform(LayerTransform.NONE)
    }

    fun play(name: String) {
        animation = name
        startedAt = SystemClock.uptimeMillis()
        fidgetStart = 0L
        nextFidgetAt = startedAt + Random.nextLong(2500, 6500)
    }

    /** Chamado a cada quadro (~60 vezes por segundo) enquanto o personagem estiver visível. */
    fun tick(nowMs: Long) {
        if (!enabled) return
        val t = (nowMs - startedAt) / 1000f
        var transform = AnimationMath.transformFor(animation, t)
        if (animation == "idle" || animation == "idle_random") {
            if (fidgetStart == 0L && nowMs >= nextFidgetAt) {
                fidgetStart = nowMs
                fidgetKind = Random.nextInt(0, 3)
            }
            if (fidgetStart != 0L) {
                val ft = (nowMs - fidgetStart) / 1000f
                if (ft > fidgetDuration) {
                    fidgetStart = 0L
                    nextFidgetAt = nowMs + Random.nextLong(3000, 9000)
                } else {
                    val f = AnimationMath.fidget(fidgetKind, ft, fidgetDuration)
                    transform = LayerTransform(
                        transform.dxFrac + f.dxFrac, transform.dyFrac + f.dyFrac, transform.rotationDeg + f.rotationDeg,
                        transform.scaleX * f.scaleX, transform.scaleY * f.scaleY,
                    )
                }
            }
        }
        applyTransform(transform)
    }

    private fun applyTransform(t: LayerTransform) {
        val v = target ?: return
        v.translationX = t.dxFrac * v.width
        v.translationY = t.dyFrac * v.height
        v.rotation = t.rotationDeg
        v.scaleX = t.scaleX
        v.scaleY = t.scaleY
    }

    override fun toString(): String = "$role:$animation"
}

class PopolAnimationController : LayerAnimator("popol")

class KupaAnimationController : LayerAnimator("kupa")
