package com.kupa.assistant.ai

import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.tools.ToolRegistry

/**
 * Conduz uma pergunta até a resposta final: envia à IA e, enquanto ela pedir ferramentas,
 * executa as AUTORIZADAS no aparelho e devolve os resultados. Bloqueante (rode em thread de trabalho).
 */
class AiOrchestrator(private val provider: AiProvider, private val tools: ToolRegistry) {

    interface Progress {
        fun isCancelled(): Boolean
        fun onToolStarted(name: String)
        fun onToolFinished(name: String)
    }

    class Outcome(val result: AiResult, val usedScreen: Boolean)

    fun run(
        messages: List<AiMessage>,
        options: AiOptions,
        gamerActive: Boolean,
        progress: Progress,
    ): Outcome {
        var usedScreen = false
        var result: AiResult = provider.respond(messages, options, emptyList())
        var rounds = 0
        while (true) {
            val current = result
            if (current !is AiResult.ToolCalls) break
            if (progress.isCancelled()) return cancelled(usedScreen)
            rounds++
            if (rounds > MAX_ROUNDS) {
                return Outcome(AiResult.Failure(AiError(AiErrorKind.OTHER, "too_many_tool_rounds", "A IA pediu ferramentas demais para uma pergunta só.")), usedScreen)
            }
            val outputs = ArrayList<AiToolResult>()
            for (call in current.calls) {
                progress.onToolStarted(call.name)
                val out = tools.execute(call, gamerActive)
                if (call.name == ToolRegistry.ANALYZE_SCREEN && out.error == null) usedScreen = true
                KupaLog.i("ferramentas", "${call.name} -> ${if (out.error == null) "ok" else "erro: " + out.error}")
                progress.onToolFinished(call.name)
                outputs.add(AiToolResult(call.callId, out.text, out.error, out.imageDataUrl))
            }
            if (progress.isCancelled()) return cancelled(usedScreen)
            result = provider.continueWithTools(current.sessionId, outputs, options)
        }
        return Outcome(result, usedScreen)
    }

    private fun cancelled(usedScreen: Boolean) =
        Outcome(AiResult.Failure(AiError(AiErrorKind.CANCELLED, "cancelled", "Cancelado.")), usedScreen)

    companion object {
        private const val MAX_ROUNDS = 4
    }
}
