package com.kupa.assistant.actions

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.SystemClock
import android.telephony.TelephonyManager
import com.kupa.assistant.core.KupaLog
import java.util.concurrent.Executors

/**
 * Acompanha o estado das chamadas (tocando / em andamento / livre) pelo broadcast oficial do Android.
 * Exige READ_PHONE_STATE; para ver o NÚMERO de quem liga o Android exige também READ_CALL_LOG.
 * Só funciona enquanto o KUPA estiver em execução (o serviço liga e desliga este rastreador).
 */
class CallStateTracker(
    private val context: Context,
    private val contacts: ContactResolver,
    private val state: ConversationContext,
) : BroadcastReceiver() {
    private val io = Executors.newSingleThreadExecutor()
    private var registered = false
    private var lastIncomingNumber: String? = null
    private var lastIncomingName: String? = null
    private var wasRinging = false

    @Synchronized
    fun start() {
        if (registered) return
        val filter = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(this, filter, Context.RECEIVER_EXPORTED) // é um broadcast do sistema
        } else {
            context.registerReceiver(this, filter)
        }
        registered = true
        KupaLog.i("telefone", "acompanhando o estado das chamadas")
    }

    @Synchronized
    fun stop() {
        if (!registered) return
        try {
            context.unregisterReceiver(this)
        } catch (e: IllegalArgumentException) {
            KupaLog.w("telefone", "receptor já estava removido")
        }
        registered = false
    }

    @Suppress("DEPRECATION")
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val raw = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
        val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)?.trim()?.ifEmpty { null }
        val now = SystemClock.elapsedRealtime()
        when (raw) {
            TelephonyManager.EXTRA_STATE_RINGING -> {
                // o Android costuma avisar duas vezes: a 1ª pode vir sem número; guardamos o primeiro número que chegar
                wasRinging = true
                if (number != null && number != lastIncomingNumber) {
                    lastIncomingNumber = number
                    lastIncomingName = null
                }
                val shownNumber = lastIncomingNumber
                state.setCall(CallSnapshot(CallState.RINGING, shownNumber, lastIncomingName, true, now))
                if (shownNumber != null && lastIncomingName == null) {
                    io.execute {
                        val name = contacts.nameForNumber(shownNumber)
                        if (name != null && lastIncomingNumber == shownNumber) {
                            lastIncomingName = name
                            state.setCall(CallSnapshot(CallState.RINGING, shownNumber, name, true, SystemClock.elapsedRealtime()))
                        }
                    }
                }
            }
            TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                val previous = state.call()
                val incoming = wasRinging
                state.setCall(CallSnapshot(CallState.OFFHOOK, if (incoming) lastIncomingNumber else previous?.number, if (incoming) lastIncomingName else previous?.contactName, incoming, now))
            }
            TelephonyManager.EXTRA_STATE_IDLE -> {
                val previous = state.call()
                state.setCall(CallSnapshot(CallState.IDLE, previous?.number, previous?.contactName, previous?.incoming ?: false, now))
                wasRinging = false
                lastIncomingNumber = null
                lastIncomingName = null
            }
        }
    }

    /** Espera (bloqueando) o estado desejado por até [timeoutMs]. Fora da thread principal. */
    fun awaitState(target: CallState, timeoutMs: Long): Boolean {
        val deadline = SystemClock.elapsedRealtime() + timeoutMs
        while (SystemClock.elapsedRealtime() < deadline) {
            if (state.call()?.state == target) return true
            try {
                Thread.sleep(120)
            } catch (e: InterruptedException) {
                return false
            }
        }
        return state.call()?.state == target
    }
}
