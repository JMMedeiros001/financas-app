package com.kupa.assistant.voice;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Motor da palavra de ativação (o nome pelo qual o usuário CHAMA o assistente). Lógica pura, testada.
 * A palavra de ativação só INICIA uma interação: não identifica quem falou e não autoriza nada.
 *
 * Regras contra falsos positivos:
 *  - o nome exato vale no começo da frase ou depois de um chamado ("oi", "ei"...), ou até a 3ª palavra;
 *  - VARIANTES (erros comuns do reconhecimento de fala) só valem no começo ou depois de um chamado;
 *  - nenhuma correspondência aproximada automática: variantes novas só entram com confirmação do usuário.
 */
public final class ActivationNameEngine {
    public static final String DEFAULT_NAME = "kupa";
    /** Variantes embutidas, só para o nome padrão: erros reais do reconhecimento de fala para "Kupa". */
    public static final List<String> DEFAULT_PHONETIC_VARIANTS = Collections.unmodifiableList(Arrays.asList("cupa", "culpa", "kuppa", "cuppa", "kupah"));

    private static final Set<String> GREETINGS = new HashSet<>(Arrays.asList("oi", "ei", "ola", "e", "ai", "fala", "opa", "hey", "hei", "ok", "okay", "alo"));
    /** Palavras que NUNCA podem ser o nome do assistente (confundiriam comandos e conversa comum). */
    private static final Set<String> FORBIDDEN_NAMES = new HashSet<>(Arrays.asList(
        "abrir", "abra", "ligar", "ligue", "atender", "atende", "recusar", "recusa", "desligar", "para", "pare", "parar", "sim", "nao", "ok", "oi", "ola", "ei",
        "quero", "pode", "vai", "voce", "aqui", "agora", "hoje", "tudo", "nada", "obrigado", "obrigada", "por", "favor", "cancela", "cancelar", "modo", "tela"));

    public static final class Match {
        public final String command;
        public final boolean exact;

        Match(String command, boolean exact) {
            this.command = command;
            this.exact = exact;
        }
    }

    private final String name;
    private final Set<String> variants;

    /** @param variantWords variantes ATIVAS (embutidas habilitadas + personalizadas + aprendidas e confirmadas), já sem o nome principal. */
    public ActivationNameEngine(String activationName, List<String> variantWords) {
        this.name = fold(activationName == null ? "" : activationName.trim());
        Set<String> v = new LinkedHashSet<>();
        if (variantWords != null) for (String w : variantWords) {
            String f = fold(w.trim());
            if (!f.isEmpty() && !f.equals(name) && isSingleToken(f)) v.add(f);
        }
        this.variants = Collections.unmodifiableSet(v);
    }

    public String name() { return name; }

    public Set<String> variants() { return variants; }

    /** Todas as palavras que, no começo da frase, contam como chamado (usado para limpar o comando). */
    public Set<String> allWords() {
        Set<String> all = new LinkedHashSet<>();
        if (!name.isEmpty()) all.add(name);
        all.addAll(variants);
        return all;
    }

    // ------------------------------------------------------------------ correspondência

    public Match match(String text, boolean acceptVariants) {
        if (name.isEmpty() || text == null) return null;
        List<int[]> spans = new ArrayList<>();
        List<String> words = new ArrayList<>();
        String folded = fold(text);
        int i = 0;
        while (i < folded.length()) {
            if (Character.isLetterOrDigit(folded.charAt(i))) {
                int j = i;
                while (j < folded.length() && Character.isLetterOrDigit(folded.charAt(j))) j++;
                spans.add(new int[]{i, j});
                words.add(folded.substring(i, j));
                i = j;
            } else {
                i++;
            }
        }
        int limit = Math.min(words.size(), 4);
        for (int index = 0; index < limit; index++) {
            String word = words.get(index);
            boolean isExact = word.equals(name);
            boolean isVariant = acceptVariants && variants.contains(word);
            if (!isExact && !isVariant) continue;
            boolean onlyGreetingsBefore = true;
            for (int k = 0; k < index; k++) if (!GREETINGS.contains(words.get(k))) onlyGreetingsBefore = false;
            if (isVariant && !onlyGreetingsBefore) continue;
            if (isExact && !onlyGreetingsBefore && index > 2) continue;
            String rest = text.substring(spans.get(index)[1]).trim();
            int cut = 0;
            while (cut < rest.length() && ",.!?:;- ".indexOf(rest.charAt(cut)) >= 0) cut++;
            return new Match(rest.substring(cut).trim(), isExact);
        }
        return null;
    }

    // ------------------------------------------------------------------ validação de nomes e variantes

    /** @return null se o nome é aceitável; senão a explicação em português. */
    public static String validateName(String raw) {
        String n = fold(raw == null ? "" : raw.trim());
        if (n.isEmpty()) return "Digite um nome.";
        if (!isSingleToken(n)) return "Use uma palavra só, com letras e números (sem espaços).";
        if (n.length() < 3) return "O nome precisa ter pelo menos 3 letras, para não ser confundido com outras palavras.";
        if (n.length() > 20) return "O nome pode ter no máximo 20 letras.";
        if (GREETINGS.contains(n) || FORBIDDEN_NAMES.contains(n)) return "\"" + raw.trim() + "\" é uma palavra comum de comandos ou conversa e faria o assistente ativar sem querer. Escolha outro nome.";
        boolean hasLetter = false;
        for (char c : n.toCharArray()) if (Character.isLetter(c)) hasLetter = true;
        if (!hasLetter) return "O nome precisa ter letras.";
        return null;
    }

    /** Variante é uma palavra só, que não seja chamado comum nem palavra proibida, e diferente do nome. */
    public static String validateVariant(String raw, String activationName) {
        String v = fold(raw == null ? "" : raw.trim());
        if (v.isEmpty()) return "Digite a variante.";
        if (!isSingleToken(v)) return "Use uma palavra só.";
        if (v.length() < 3) return "A variante precisa ter pelo menos 3 letras.";
        if (v.equals(fold(activationName))) return "Essa já é o nome principal.";
        if (GREETINGS.contains(v) || FORBIDDEN_NAMES.contains(v)) return "\"" + raw.trim() + "\" é uma palavra comum e faria o assistente ativar sem querer.";
        return null;
    }

    // ------------------------------------------------------------------ sugestões (aprendizado com confirmação)

    /**
     * Procura, no começo de uma frase que NÃO ativou, uma palavra QUASE igual ao nome (1 letra de diferença, nome com 4+ letras).
     * Só devolve um CANDIDATO: ele nunca vira variante sem o usuário confirmar. Guarda-se só essa palavra, nunca a frase.
     */
    public String suggestCandidate(String text) {
        if (name.length() < 4 || text == null) return null;
        String folded = fold(text);
        String[] parts = folded.split("[^\\p{L}\\p{N}]+");
        int checked = 0;
        for (String p : parts) {
            if (p.isEmpty()) continue;
            if (++checked > 2) break;
            if (GREETINGS.contains(p)) continue;
            if (p.equals(name) || variants.contains(p)) return null;
            if (validateVariant(p, name) == null && Math.abs(p.length() - name.length()) <= 1 && distance(p, name) == 1) return p;
            break;
        }
        return null;
    }

    public static int distance(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }

    // ------------------------------------------------------------------ util

    private static boolean isSingleToken(String s) {
        if (s.isEmpty()) return false;
        for (int i = 0; i < s.length(); i++) if (!Character.isLetterOrDigit(s.charAt(i))) return false;
        return true;
    }

    /** Remove acentos e põe em minúsculas SEM mudar o tamanho do texto (os índices valem no original). */
    public static String fold(String text) {
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            String decomposed = Normalizer.normalize(String.valueOf(ch), Normalizer.Form.NFD);
            char base = ch;
            for (int k = 0; k < decomposed.length(); k++) {
                char d = decomposed.charAt(k);
                if (Character.getType(d) != Character.NON_SPACING_MARK) {
                    base = d;
                    break;
                }
            }
            out.append(Character.toLowerCase(base));
        }
        return out.toString();
    }
}
