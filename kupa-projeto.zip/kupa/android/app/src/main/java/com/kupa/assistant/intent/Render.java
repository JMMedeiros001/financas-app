package com.kupa.assistant.intent;

import java.util.List;

/** Texto canônico de uma intenção (o que o interpretador entende de volta) e descrição para falar ao usuário. */
public final class Render {
    private Render() {}

    public static String canonical(KupaIntent i) {
        switch (i.kind) {
            case OPEN_APP: return "abra " + i.appName;
            case CALL_CONTACT: return "ligue para " + i.contactName;
            case OPEN_CHAT: return "abra a conversa com " + i.contactName + (i.appName != null ? " no " + i.appName : "");
            case WHO_IS_CALLING: return "quem esta me ligando";
            case ANSWER_CALL: return "atenda";
            case REJECT_CALL: return "recuse";
            case END_CALL: return "desligue a ligacao";
            case IGNORE_CALL: return "deixa tocar";
            default: return null;
        }
    }

    public static String canonical(List<KupaIntent> list) {
        StringBuilder sb = new StringBuilder();
        for (KupaIntent i : list) {
            String c = canonical(i);
            if (c == null) return null;
            if (sb.length() > 0) sb.append(" e depois ");
            sb.append(c);
        }
        return sb.toString();
    }

    /** Frase curta em português para o app dizer ("abrir mobile legends"). */
    public static String describe(KupaIntent i) {
        switch (i.kind) {
            case OPEN_APP: return "abrir " + i.appName;
            case CALL_CONTACT: return "ligar para " + i.contactName;
            case OPEN_CHAT: return "abrir a conversa com " + i.contactName;
            case WHO_IS_CALLING: return "dizer quem está ligando";
            case ANSWER_CALL: return "atender a ligação";
            case REJECT_CALL: return "recusar a ligação";
            case END_CALL: return "desligar a ligação";
            case IGNORE_CALL: return "deixar tocar";
            default: return i.kind.name().toLowerCase();
        }
    }

    public static String describe(List<KupaIntent> list) {
        StringBuilder sb = new StringBuilder();
        for (int n = 0; n < list.size(); n++) {
            if (n > 0) sb.append(" e depois ");
            sb.append(describe(list.get(n)));
        }
        return sb.toString();
    }
}
