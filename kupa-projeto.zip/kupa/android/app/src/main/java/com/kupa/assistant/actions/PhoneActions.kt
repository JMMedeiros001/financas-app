package com.kupa.assistant.actions

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.telecom.TelecomManager
import com.kupa.assistant.core.KupaLog

/** Ações reais de telefonia (APIs oficiais do Android). Cada função diz honestamente o que conseguiu. */
class PhoneActions(private val context: Context) {
    enum class CallOutcome { PLACED, NO_PERMISSION, FAILED }

    private val telecom: TelecomManager? = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager

    fun has(permission: String): Boolean = context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    fun canPlaceCalls(): Boolean = has(Manifest.permission.CALL_PHONE)
    fun canAnswerCalls(): Boolean = has(Manifest.permission.ANSWER_PHONE_CALLS)
    fun canSeeCallState(): Boolean = has(Manifest.permission.READ_PHONE_STATE)
    fun canSeeCallNumbers(): Boolean = has(Manifest.permission.READ_CALL_LOG)

    fun placeCall(number: String): CallOutcome {
        if (!canPlaceCalls()) return CallOutcome.NO_PERMISSION
        val tm = telecom ?: return CallOutcome.FAILED
        return try {
            tm.placeCall(Uri.fromParts("tel", number, null), Bundle())
            CallOutcome.PLACED
        } catch (e: SecurityException) {
            KupaLog.e("telefone", "ligar: o Android recusou", e)
            CallOutcome.NO_PERMISSION
        } catch (e: Exception) {
            KupaLog.e("telefone", "ligar: falhou", e)
            CallOutcome.FAILED
        }
    }

    /** Abre o discador com o número já digitado (a pessoa só toca em ligar). */
    fun openDialer(number: String): Boolean = try {
        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        KupaLog.e("telefone", "discador: falhou", e)
        false
    }

    /** Atende a chamada que está tocando. Exige ANSWER_PHONE_CALLS. O Android não devolve confirmação: confira pelo estado. */
    fun answerRinging(): Boolean {
        val tm = telecom ?: return false
        return try {
            tm.acceptRingingCall()
            true
        } catch (e: SecurityException) {
            KupaLog.e("telefone", "atender: o Android recusou", e)
            false
        } catch (e: Exception) {
            KupaLog.e("telefone", "atender: falhou", e)
            false
        }
    }

    /** Encerra/recusa a chamada (tocando ou em andamento). Exige Android 9+ e ANSWER_PHONE_CALLS. null = não suportado. */
    @Suppress("DEPRECATION")
    fun endCall(): Boolean? {
        if (Build.VERSION.SDK_INT < 28) return null
        val tm = telecom ?: return false
        return try {
            tm.endCall()
        } catch (e: SecurityException) {
            KupaLog.e("telefone", "encerrar: o Android recusou", e)
            false
        } catch (e: Exception) {
            KupaLog.e("telefone", "encerrar: falhou", e)
            false
        }
    }
}
