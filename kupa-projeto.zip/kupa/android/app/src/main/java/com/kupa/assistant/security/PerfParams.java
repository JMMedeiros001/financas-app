package com.kupa.assistant.security;

/** Parâmetros aplicados de verdade pelo app: quadros por segundo do Popol, cache de imagens, fade e qualidade da captura. */
public final class PerfParams {
    public final int animationFps;
    public final int spriteCacheMb;
    public final int crossfadeMs;
    public final int captureMaxSidePx;
    public final int jpegQuality;

    PerfParams(int animationFps, int spriteCacheMb, int crossfadeMs, int captureMaxSidePx, int jpegQuality) {
        this.animationFps = animationFps;
        this.spriteCacheMb = spriteCacheMb;
        this.crossfadeMs = crossfadeMs;
        this.captureMaxSidePx = captureMaxSidePx;
        this.jpegQuality = jpegQuality;
    }

    @Override public String toString() {
        return animationFps + "fps, cache " + spriteCacheMb + "MB, fade " + crossfadeMs + "ms, captura " + captureMaxSidePx + "px q" + jpegQuality;
    }
}
