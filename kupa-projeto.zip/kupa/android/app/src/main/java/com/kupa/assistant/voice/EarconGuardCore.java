package com.kupa.assistant.voice;

/**
 * Lógica do botão "Silenciar bipe do microfone". Pura (sem Android): o Android entrega o áudio por uma interface.
 *
 * O bipe de início/fim do reconhecimento é tocado pelo serviço de reconhecimento de voz do aparelho, não pelo KUPA, e o Android não
 * oferece uma opção oficial para desligá-lo. A alternativa SEGURA que existe: silenciar por uma JANELA CURTA o canal de mídia
 * (STREAM_MUSIC) em volta do início/fim da escuta. Regras de segurança aplicadas aqui:
 *  - só com a preferência ligada;
 *  - NUNCA quando outro app está tocando mídia (não silencia outros aplicativos; neste caso o bipe pode tocar);
 *  - NUNCA mexe se o canal já estava mudo por outro motivo, e só desfaz o que o próprio KUPA fez;
 *  - o volume NÃO é alterado (usa mudo/desmudo, que preserva o nível);
 *  - o mudo é desfeito ao fim da janela, antes de o KUPA falar e ao encerrar; e há recuperação se o processo morrer no meio.
 */
public final class EarconGuardCore {
    public interface Audio {
        boolean isMusicActive();

        boolean isMusicMuted();

        /** @return true se o canal foi silenciado de fato (false: o sistema recusou). */
        boolean muteMusic();

        void unmuteMusic();
    }

    /** Memória persistente: "fui eu que silenciei" (para recuperar se o app morrer com o canal mudo). */
    public interface Store {
        boolean mutedByUs();

        void setMutedByUs(boolean value);
    }

    public static final class Window {
        public final boolean muting;
        public final long epoch;
        public final long durationMs;

        Window(boolean muting, long epoch, long durationMs) {
            this.muting = muting;
            this.epoch = epoch;
            this.durationMs = durationMs;
        }
    }

    private static final Window NONE = new Window(false, 0L, 0L);

    private final Audio audio;
    private final Store store;
    private boolean weMuted = false;
    private long epoch = 0L;
    private int mutes = 0;
    private int unmutes = 0;

    public EarconGuardCore(Audio audio, Store store) {
        this.audio = audio;
        this.store = store;
    }

    /** Pede uma janela de mudo de [durationMs]. Se devolver muting=true, o chamador deve agendar onWindowEnd(epoch) para durationMs depois. */
    public synchronized Window request(boolean preferenceEnabled, long durationMs) {
        if (!preferenceEnabled) {
            release(); // desligou a preferência no meio de uma janela: solta na hora
            return NONE;
        }
        if (weMuted) { // já estamos mudos: só estende a janela (a janela anterior fica obsoleta)
            epoch++;
            return new Window(true, epoch, durationMs);
        }
        if (audio.isMusicActive()) return NONE; // outro app tocando mídia: NÃO silencia
        if (audio.isMusicMuted()) return NONE;  // já estava mudo por outro motivo: não mexe
        store.setMutedByUs(true);                // grava ANTES de silenciar: recuperável se o processo morrer
        if (!audio.muteMusic()) {
            store.setMutedByUs(false);
            return NONE;
        }
        weMuted = true;
        mutes++;
        epoch++;
        return new Window(true, epoch, durationMs);
    }

    /** O temporizador da janela disparou. Janelas antigas (já estendidas) são ignoradas. */
    public synchronized boolean onWindowEnd(long windowEpoch) {
        if (windowEpoch != epoch) return false;
        release();
        return true;
    }

    /** Desfaz o mudo AGORA (antes de o KUPA falar, ao parar a escuta, ao encerrar). Idempotente. */
    public synchronized void release() {
        if (!weMuted) return;
        audio.unmuteMusic();
        weMuted = false;
        store.setMutedByUs(false);
        unmutes++;
        epoch++; // invalida qualquer temporizador pendente
    }

    /** Ao iniciar o app: se o processo morreu enquanto estávamos mudos, desfaz o mudo que NÓS fizemos. */
    public synchronized void recoverAfterCrash() {
        if (!weMuted && store.mutedByUs()) {
            audio.unmuteMusic();
            store.setMutedByUs(false);
        }
    }

    public synchronized boolean isMuting() { return weMuted; }

    public synchronized int mutes() { return mutes; }

    public synchronized int unmutes() { return unmutes; }
}
