package com.kupa.assistant.core

/**
 * Sinais REAIS que o núcleo visual usa para reagir: o nível do microfone vem do próprio reconhecedor (onRmsChanged) e o pulso da fala
 * vem do início de cada palavra pronunciada pelo TTS (quando o motor informa). Sem sinal recente, o valor é 0: nada é inventado.
 */
object CoreSignals {
    @Volatile private var micValue = 0f
    @Volatile private var micAtMs = 0L
    @Volatile private var speechAtMs = 0L

    /** [rmsDb]: nível do reconhecedor (valores típicos de -2 a 10). */
    fun setMicRms(rmsDb: Float, nowMs: Long) {
        val n = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
        micValue = maxOf(n, micValue * 0.82f) // sobe na hora, desce suave
        micAtMs = nowMs
    }

    /** Nível do microfone 0..1; zero se o reconhecedor não informou nada nos últimos 400 ms. */
    fun micLevel(nowMs: Long): Float = if (nowMs - micAtMs > 400L) 0f else micValue

    /** Uma palavra da resposta começou a ser falada. */
    fun speechWord(nowMs: Long) {
        speechAtMs = nowMs
    }

    /** Pulso 0..1 que decai em ~320 ms depois de cada palavra. */
    fun speechPulse(nowMs: Long): Float {
        val dt = nowMs - speechAtMs
        return if (dt < 0L || dt > 320L) 0f else 1f - dt / 320f
    }
}
