package com.kupa.assistant.intent;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Entende a resposta a uma pergunta do KUPA: sim, não, ou a escolha de uma opção ("o segundo", "o do trabalho"). */
public final class ReplyParser {
    public enum Type { YES, NO, CHOICE, UNKNOWN }

    public static final class Reply {
        public final Type type;
        /** Índice (0..n-1) quando type == CHOICE. */
        public final int index;

        Reply(Type type, int index) {
            this.type = type;
            this.index = index;
        }

        @Override public String toString() { return type + (type == Type.CHOICE ? "#" + index : ""); }
    }

    private static final Set<String> YES = new HashSet<>(Arrays.asList(
        "sim", "pode", "claro", "confirmo", "confirma", "confirmado", "isso", "certo", "ok", "okay", "beleza", "positivo", "afirmativo",
        "faz", "faca", "manda", "liga", "ligue", "fechou", "bora", "uhum", "aham", "yes", "exato", "perfeito", "salva", "salve"));
    private static final Set<String> VERB_YES = new HashSet<>(Arrays.asList("faz", "faca", "manda", "liga", "ligue", "salva", "salve"));
    private static final Set<String> NO = new HashSet<>(Arrays.asList(
        "nao", "nope", "negativo", "cancela", "cancelar", "cancele", "deixa", "deixe", "esquece", "esqueca", "para", "pare", "nem", "melhor"));
    private static final Set<String> STOP = new HashSet<>(Arrays.asList(
        "o", "a", "os", "as", "do", "da", "de", "no", "na", "e", "que", "quero", "pode", "esse", "essa", "ai", "com", "um", "uma", "opcao", "numero", "mesmo", "pra", "para"));

    private ReplyParser() {}

    public static Reply parse(String raw, List<String> optionLabels) {
        String n = TextNorm.stripWake(TextNorm.normalize(raw));
        List<String> t = TextNorm.tokens(n);
        if (t.isEmpty()) return new Reply(Type.UNKNOWN, -1);
        boolean hasOptions = optionLabels != null && optionLabels.size() > 1;

        if (hasOptions) {
            int idx = choiceIndex(t, optionLabels);
            if (idx >= 0) return new Reply(Type.CHOICE, idx);
        }
        // "não ..." em qualquer uma das duas primeiras palavras vale como NÃO ("não pode", "melhor não", "pode não")
        if (t.get(0).equals("nao") || (t.size() > 1 && t.get(1).equals("nao")) || t.get(0).equals("nem") || t.get(0).equals("negativo")) {
            return new Reply(Type.NO, -1);
        }
        if (NO.contains(t.get(0)) && !t.get(0).equals("melhor")) return new Reply(Type.NO, -1);
        if (t.get(0).equals("melhor") && t.contains("nao")) return new Reply(Type.NO, -1);
        if (hasOptions) return new Reply(Type.UNKNOWN, -1); // com várias opções, "sim" não escolhe nenhuma
        if (VERB_YES.contains(t.get(0)) && t.size() > 2) return new Reply(Type.UNKNOWN, -1); // "ligue para maria" é um comando novo, não um "sim"
        if (YES.contains(t.get(0))) return new Reply(Type.YES, -1);
        if (t.size() > 1 && (t.get(0).equals("com") && t.get(1).equals("certeza"))) return new Reply(Type.YES, -1);
        return new Reply(Type.UNKNOWN, -1);
    }

    private static int choiceIndex(List<String> t, List<String> labels) {
        int count = labels.size();
        for (String w : t) {
            int idx = ordinal(w);
            if (idx == Integer.MAX_VALUE) return count - 1; // "o último"
            if (idx >= 0 && idx < count) return idx;
        }
        // por nome/descrição: palavras da resposta que aparecem em UMA só das opções
        int best = -1;
        int bestScore = 0;
        boolean tie = false;
        for (int i = 0; i < count; i++) {
            List<String> lt = TextNorm.tokens(TextNorm.normalize(labels.get(i)));
            int score = 0;
            for (String w : t) if (!STOP.contains(w) && w.length() >= 2 && lt.contains(w)) score++;
            if (score > bestScore) {
                best = i;
                bestScore = score;
                tie = false;
            } else if (score == bestScore && score > 0) {
                tie = true;
            }
        }
        return (bestScore > 0 && !tie) ? best : -1;
    }

    private static int ordinal(String w) {
        switch (w) {
            case "primeiro": case "primeira": case "um": case "uma": case "1": return 0;
            case "segundo": case "segunda": case "dois": case "duas": case "2": return 1;
            case "terceiro": case "terceira": case "tres": case "3": return 2;
            case "quarto": case "quarta": case "quatro": case "4": return 3;
            case "quinto": case "quinta": case "cinco": case "5": return 4;
            case "ultimo": case "ultima": return Integer.MAX_VALUE;
            default: return -1;
        }
    }
}
