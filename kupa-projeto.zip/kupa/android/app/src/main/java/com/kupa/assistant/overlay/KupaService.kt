package com.kupa.assistant.overlay

import android.Manifest
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import com.kupa.assistant.KupaApp
import com.kupa.assistant.character.PopolView
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.gamer.GamerModeController
import com.kupa.assistant.voice.VoiceController

/**
 * Serviço em primeiro plano do KUPA: mantém ativos o personagem flutuante, a escuta da palavra de ativação
 * e a captura de tela autorizada. O Android exige a notificação fixa enquanto isso estiver rodando.
 */
class KupaService : Service() {
    private lateinit var app: KupaApp
    private val main = Handler(Looper.getMainLooper())
    private var overlay: OverlayController? = null
    private var voice: VoiceController? = null
    private var started = false

    private val gamerListener = GamerModeController.Listener {
        main.post {
            updateNotification()
            voice?.refresh()
        }
    }
    private val foregroundListener = KupaApp.ForegroundListener {
        main.post { overlay?.refreshVisibility() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        app = KupaApp.from(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_LISTEN_NOW -> {
                ensureStarted()
                app.core.listenNow()
            }
            ACTION_PROJECTION -> {
                ensureStarted()
                startProjection(intent)
            }
            ACTION_STOP_CAPTURE -> {
                app.screen.stop()
                startForegroundCompat(withProjection = false)
            }
            else -> ensureStarted()
        }
        // Não pede para o Android reiniciar sozinho: microfone em segundo plano só pode começar com o app à vista.
        return START_NOT_STICKY
    }

    private fun ensureStarted() {
        if (started) return
        started = true
        running = true
        KupaLog.i("servico", "KUPA em execução")
        startForegroundCompat(withProjection = false)

        val popolView = PopolView(this, app.sprites)
        popolView.bindTo(app.states)
        popolView.onLoadError = { app.core.reportProblem("Não consegui carregar o visual do Popol.") }
        val controller = OverlayController(this, app.settings, app.core, popolView, { app.isForeground }, { stopSelfCompletely() })
        overlay = controller
        val vc = VoiceController(this, app.settings, app.core)
        voice = vc
        app.core.voiceControl = vc
        app.core.speech.ensureInit()

        if (!controller.show()) {
            KupaLog.w("servico", "personagem flutuante indisponível (permissão de sobreposição ou opção desligada)")
        }
        app.gamer.addListener(gamerListener)
        app.addForegroundListener(foregroundListener)
        app.settings.onChange {
            main.post {
                overlay?.applySettings()
                overlay?.refreshVisibility()
                voice?.refresh()
            }
        }
        vc.refresh()
    }

    private fun stopSelfCompletely() {
        shutdown()
    }

    private fun shutdown() {
        KupaLog.i("servico", "KUPA encerrado")
        started = false
        running = false
        app.gamer.removeListener(gamerListener)
        app.removeForegroundListener(foregroundListener)
        app.core.voiceControl = null
        app.core.speech.stop()
        voice?.destroy()
        voice = null
        overlay?.destroy()
        overlay = null
        app.screen.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (started) {
            started = false
            running = false
            voice?.destroy()
            overlay?.destroy()
            app.core.voiceControl = null
            app.gamer.removeListener(gamerListener)
            app.removeForegroundListener(foregroundListener)
        }
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        main.post { overlay?.applySettings() }
    }

    // ------------------------------------------------------------------ primeiro plano

    private fun foregroundTypeFlags(withProjection: Boolean): Int {
        var type = 0
        if (Build.VERSION.SDK_INT >= 29 && withProjection) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (Build.VERSION.SDK_INT >= 30 && mic) type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        if (type == 0 && Build.VERSION.SDK_INT >= 34) type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        return type
    }

    private fun startForegroundCompat(withProjection: Boolean) {
        val notification = Notifications.serviceNotification(this, app.gamer.active)
        val type = foregroundTypeFlags(withProjection)
        try {
            if (Build.VERSION.SDK_INT >= 29 && type != 0) {
                startForeground(Notifications.ID_SERVICE, notification, type)
            } else {
                startForeground(Notifications.ID_SERVICE, notification)
            }
        } catch (e: Exception) {
            KupaLog.e("servico", "o Android recusou o modo de primeiro plano", e)
            app.core.reportProblem("O Android não deixou o KUPA ficar ativo em segundo plano. Abra o app e toque em Iniciar KUPA.")
        }
    }

    private fun updateNotification() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.notify(Notifications.ID_SERVICE, Notifications.serviceNotification(this, app.gamer.active))
    }

    // ------------------------------------------------------------------ captura de tela autorizada

    private fun startProjection(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (resultCode == 0 || data == null) {
            app.core.reportProblem("A autorização de captura de tela não chegou ao serviço.")
            return
        }
        // Android 14+: o serviço precisa estar no modo "mediaProjection" ANTES de usar a autorização.
        startForegroundCompat(withProjection = true)
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = manager.getMediaProjection(resultCode, data)
            app.screen.onStopped = { main.post { startForegroundCompat(withProjection = false) } }
            app.screen.start(projection)
            KupaLog.i("servico", "captura de tela autorizada e iniciada")
        } catch (e: Exception) {
            KupaLog.e("servico", "não consegui iniciar a captura de tela", e)
            startForegroundCompat(withProjection = false)
            app.core.reportProblem("Não consegui iniciar a captura de tela.")
        }
    }

    companion object {
        const val ACTION_START = "com.kupa.assistant.START"
        const val ACTION_STOP = "com.kupa.assistant.STOP"
        const val ACTION_LISTEN_NOW = "com.kupa.assistant.LISTEN_NOW"
        const val ACTION_PROJECTION = "com.kupa.assistant.PROJECTION"
        const val ACTION_STOP_CAPTURE = "com.kupa.assistant.STOP_CAPTURE"
        private const val EXTRA_RESULT_CODE = "resultCode"
        private const val EXTRA_DATA = "data"

        @Volatile
        var running: Boolean = false
            private set

        fun start(context: Context) {
            context.startForegroundService(Intent(context, KupaService::class.java).setAction(ACTION_START))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, KupaService::class.java))
        }

        fun listenNow(context: Context) {
            context.startForegroundService(Intent(context, KupaService::class.java).setAction(ACTION_LISTEN_NOW))
        }

        fun stopCapture(context: Context) {
            if (running) context.startService(Intent(context, KupaService::class.java).setAction(ACTION_STOP_CAPTURE))
        }

        /** Chamado pela tela de permissão de captura com o resultado do pedido oficial do Android. */
        fun deliverProjection(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, KupaService::class.java)
                .setAction(ACTION_PROJECTION)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            context.startForegroundService(intent)
        }
    }
}
