package com.kupa.assistant.ai

import com.kupa.assistant.core.KupaLog
import org.json.JSONArray
import org.json.JSONObject

/** AiProvider que conversa com o backend KUPA (que, por sua vez, usa a API oficial da OpenAI). */
class KupaBackendProvider(private val client: KupaBackendClient) : AiProvider {
    override val name: String = "OpenAI (via backend KUPA)"

    override fun respond(messages: List<AiMessage>, options: AiOptions, attachments: List<String>): AiResult {
        val body = JSONObject()
        val msgs = JSONArray()
        for (m in messages) msgs.put(JSONObject().put("role", m.role).put("text", m.text))
        body.put("messages", msgs)
        if (attachments.isNotEmpty()) {
            val atts = JSONArray()
            for (a in attachments) atts.put(JSONObject().put("type", "image").put("dataUrl", a))
            body.put("attachments", atts)
        }
        body.put("options", optionsJson(options))
        return send(body)
    }

    override fun continueWithTools(sessionId: String, results: List<AiToolResult>, options: AiOptions): AiResult {
        val body = JSONObject()
        body.put("sessionId", sessionId)
        val arr = JSONArray()
        for (r in results) {
            val o = JSONObject().put("callId", r.callId)
            if (r.text != null) o.put("text", r.text)
            if (r.error != null) o.put("error", r.error)
            if (r.imageDataUrl != null) o.put("imageDataUrl", r.imageDataUrl)
            arr.put(o)
        }
        body.put("toolResults", arr)
        body.put("options", optionsJson(options))
        return send(body)
    }

    private fun optionsJson(o: AiOptions): JSONObject {
        val tools = JSONArray()
        for (t in o.enabledTools) tools.put(t)
        return JSONObject()
            .put("mode", o.mode.wire)
            .put("allowWebSearch", o.allowWebSearch)
            .put("enabledTools", tools)
            .put("brief", o.brief)
            .put("gameContext", o.gameContext)
            .put("language", o.language)
            .put("timeZone", o.timeZone)
    }

    private fun send(body: JSONObject): AiResult {
        val http = try {
            client.request("POST", "/v1/ai/respond", body.toString(), true, 90_000)
        } catch (f: KupaBackendClient.Failure) {
            return AiResult.Failure(f.error)
        }
        if (http.status != 200) return AiResult.Failure(client.errorFrom(http))
        return try {
            parse(JSONObject(http.body))
        } catch (e: Exception) {
            KupaLog.e("ai", "resposta do backend ilegível", e)
            AiResult.Failure(AiError(AiErrorKind.INVALID_RESPONSE, "invalid_response", "O backend devolveu uma resposta que não consegui entender."))
        }
    }

    private fun parse(json: JSONObject): AiResult {
        return when (json.optString("status")) {
            "final" -> {
                val sources = ArrayList<AiSource>()
                val arr = json.optJSONArray("sources")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val s = arr.optJSONObject(i) ?: continue
                        sources.add(AiSource(s.optString("title", ""), s.optString("url", "")))
                    }
                }
                val text = json.optString("text", "").trim()
                if (text.isEmpty()) {
                    AiResult.Failure(AiError(AiErrorKind.INVALID_RESPONSE, "empty_text", "A IA respondeu sem texto."))
                } else {
                    AiResult.Final(text, sources, json.optBoolean("webSearchUsed", false), if (json.isNull("model")) null else json.optString("model"))
                }
            }
            "tool_calls" -> {
                val calls = ArrayList<AiToolCall>()
                val arr = json.getJSONArray("calls")
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    calls.add(AiToolCall(c.getString("callId"), c.getString("name"), c.optJSONObject("arguments") ?: JSONObject()))
                }
                AiResult.ToolCalls(json.getString("sessionId"), calls)
            }
            else -> AiResult.Failure(AiError(AiErrorKind.INVALID_RESPONSE, "unknown_status", "Resposta do backend em formato desconhecido."))
        }
    }
}
