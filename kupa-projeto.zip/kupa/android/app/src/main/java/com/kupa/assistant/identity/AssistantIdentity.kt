package com.kupa.assistant.identity

import com.kupa.assistant.core.WakeWord
import com.kupa.assistant.intent.TextNorm
import com.kupa.assistant.settings.Settings
import com.kupa.assistant.voice.ActivationNameEngine

/**
 * Identidade do assistente: nome mostrado, palavra de ativação e variantes. É o MESMO app (nenhum outro aplicativo é criado).
 * A palavra de ativação só INICIA uma interação; não identifica o falante e não autoriza nada.
 * Variantes aprendidas só entram DEPOIS da confirmação do usuário.
 */
class AssistantIdentity(private val settings: Settings) {
    @Volatile
    private var engine: ActivationNameEngine = build()

    /** Nome mostrado nas mensagens e enviado à IA (o aplicativo continua se chamando KUPA). */
    val displayName: String get() = settings.assistantName.trim().ifEmpty { "KUPA" }

    /** Palavra que o usuário fala para chamar (uma palavra só, sem acento). */
    val activationName: String get() = ActivationNameEngine.fold(settings.activationName.trim()).ifEmpty { ActivationNameEngine.DEFAULT_NAME }

    fun engine(): ActivationNameEngine = engine

    private fun lines(value: String): List<String> = value.lines().map { it.trim() }.filter { it.isNotEmpty() }
    private fun join(list: Collection<String>): String = list.joinToString("\n")

    /** Variantes fonéticas embutidas: só existem para o nome padrão "kupa" (erros reais do reconhecimento de fala). */
    fun builtInVariants(): List<String> = if (activationName == ActivationNameEngine.DEFAULT_NAME) ActivationNameEngine.DEFAULT_PHONETIC_VARIANTS else emptyList()

    fun disabledBuiltIn(): Set<String> = lines(settings.disabledVariants).toSet()
    fun customVariants(): List<String> = lines(settings.customVariants)
    fun learnedVariants(): List<String> = lines(settings.learnedVariants)

    fun activeVariants(): List<String> =
        (builtInVariants().filter { it !in disabledBuiltIn() } + customVariants() + learnedVariants()).distinct()

    private fun build() = ActivationNameEngine(activationName, activeVariants())

    /** Reconstrói o motor e reaplica nos pontos que usam a palavra de ativação. Chame depois de qualquer mudança. */
    fun apply() {
        engine = build()
        TextNorm.setWakeWords(engine.allWords())
        WakeWord.install(engine)
    }

    /**
     * Troca o nome. @return null se deu certo, ou a explicação do problema (nada é alterado se houver problema).
     * Por padrão o nome antigo deixa de ativar; [keepOld] o mantém como variante.
     */
    fun rename(newDisplay: String, newActivation: String, keepOld: Boolean): String? {
        val problem = ActivationNameEngine.validateName(newActivation)
        if (problem != null) return problem
        val display = newDisplay.trim().ifEmpty { newActivation.trim() }
        if (display.length > 30) return "O nome mostrado pode ter no máximo 30 letras."
        val oldActivation = activationName
        val newFolded = ActivationNameEngine.fold(newActivation.trim())
        settings.assistantName = display
        settings.activationName = newFolded
        // variantes de outro nome não fazem sentido para o novo: limpa as aprendidas e as embutidas desativadas
        if (newFolded != oldActivation) {
            settings.learnedVariants = ""
            settings.disabledVariants = ""
            settings.variantCandidates = ""
            settings.ignoredCandidates = ""
            val custom = customVariants().filter { it != newFolded }.toMutableList()
            if (keepOld && oldActivation != newFolded && !custom.contains(oldActivation)) custom.add(oldActivation)
            settings.customVariants = join(custom)
        }
        apply()
        return null
    }

    fun addCustomVariant(word: String): String? {
        val problem = ActivationNameEngine.validateVariant(word, activationName)
        if (problem != null) return problem
        val v = ActivationNameEngine.fold(word.trim())
        if (activeVariants().contains(v)) return "Essa variante já existe."
        settings.customVariants = join(customVariants() + v)
        apply()
        return null
    }

    fun removeCustomVariant(word: String) {
        settings.customVariants = join(customVariants().filter { it != word })
        settings.learnedVariants = join(learnedVariants().filter { it != word })
        apply()
    }

    fun setBuiltInEnabled(word: String, enabled: Boolean) {
        val disabled = disabledBuiltIn().toMutableSet()
        if (enabled) disabled.remove(word) else disabled.add(word)
        settings.disabledVariants = join(disabled)
        apply()
    }

    /** Volta ao nome padrão e às variantes embutidas (apaga as personalizadas e as aprendidas). */
    fun restoreDefaults() {
        settings.assistantName = ""
        settings.activationName = ""
        settings.customVariants = ""
        settings.learnedVariants = ""
        settings.disabledVariants = ""
        settings.variantCandidates = ""
        settings.ignoredCandidates = ""
        apply()
    }

    // ------------------------------------------------------------------ sugestões com confirmação

    private fun candidateMap(): MutableMap<String, Int> {
        val map = LinkedHashMap<String, Int>()
        for (l in lines(settings.variantCandidates)) {
            val i = l.lastIndexOf('=')
            if (i > 0) map[l.substring(0, i)] = l.substring(i + 1).toIntOrNull() ?: 1
        }
        return map
    }

    fun candidates(): List<Pair<String, Int>> = candidateMap().entries.map { Pair(it.key, it.value) }.sortedByDescending { it.second }

    /**
     * Chamado quando uma frase NÃO ativou o assistente. Só guarda uma PALAVRA parecida com o nome (nunca a frase) e quantas vezes
     * ela apareceu. Ela só vira variante se o usuário aceitar.
     */
    @Synchronized
    fun noteUtterance(text: String) {
        val word = engine.suggestCandidate(text) ?: return
        if (word in lines(settings.ignoredCandidates)) return
        val map = candidateMap()
        map[word] = (map[word] ?: 0) + 1
        if (map.size > 8) map.remove(map.keys.first())
        settings.variantCandidates = join(map.entries.map { "${it.key}=${it.value}" })
    }

    fun acceptCandidate(word: String): String? {
        val problem = addCustomVariant(word)
        if (problem != null && problem != "Essa variante já existe.") return problem
        dropCandidate(word)
        return null
    }

    fun dismissCandidate(word: String) {
        settings.ignoredCandidates = join((lines(settings.ignoredCandidates) + word).distinct())
        dropCandidate(word)
    }

    private fun dropCandidate(word: String) {
        val map = candidateMap()
        map.remove(word)
        settings.variantCandidates = join(map.entries.map { "${it.key}=${it.value}" })
    }
}
