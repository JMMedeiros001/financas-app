package com.kupa.assistant.core

/** Comandos que o próprio app entende sem chamar a IA (rápidos e confiáveis). Todo o resto vai para a IA. */
sealed class LocalCommand {
    object GamerOn : LocalCommand()
    object GamerOff : LocalCommand()
    object Cancel : LocalCommand()
    object ClearGameContext : LocalCommand()
    data class SetGame(val game: String) : LocalCommand()
    data class SetHero(val hero: String) : LocalCommand()
}

object CommandRouter {
    private val cancelWords = setOf("cancela", "cancelar", "para", "parar", "chega", "silencio", "fica quieto", "fica quieta", "esquece", "deixa pra la")

    fun route(raw: String): LocalCommand? {
        val text = raw.trim()
        if (text.isEmpty()) return null
        val folded = foldText(text).trim().trimEnd('.', '!', '?', ',')

        if (folded.contains("modo gamer") || folded.contains("modo game ") || folded.endsWith("modo game")) {
            val off = folded.contains("desativ") || folded.contains("desligar") || folded.contains("desliga") ||
                folded.contains("sair") || folded.contains("sai do") || folded.contains("encerrar") || folded.contains("tirar")
            if (off) return LocalCommand.GamerOff
            return LocalCommand.GamerOn
        }
        if (folded in cancelWords) return LocalCommand.Cancel

        if (folded.startsWith("limpar contexto") || folded.startsWith("apagar contexto") || folded.startsWith("esquecer o jogo") ||
            folded.startsWith("limpa o contexto") || folded.startsWith("fim do jogo") || folded.startsWith("terminei o jogo")
        ) {
            return LocalCommand.ClearGameContext
        }

        // "estou jogando de Popol" / "estou jogando com Popol" => herói; "estou jogando Mobile Legends" => jogo
        for (prefix in listOf("estou jogando de ", "estou jogando com ", "estou jogando como ", "to jogando de ", "to jogando com ", "meu heroi e ", "minha personagem e ", "meu personagem e ")) {
            if (folded.startsWith(prefix)) {
                val value = text.substring(prefix.length).trim().trimEnd('.', '!', '?', ',')
                if (value.isNotEmpty() && value.length <= 60) return LocalCommand.SetHero(value)
            }
        }
        for (prefix in listOf("estou jogando ", "to jogando ", "o jogo e ", "o jogo é ")) {
            if (folded.startsWith(prefix)) {
                val value = text.substring(prefix.length).trim().trimEnd('.', '!', '?', ',')
                // frases longas ou perguntas provavelmente não são só o nome do jogo: deixa a IA tratar
                if (value.isNotEmpty() && value.length <= 40 && !value.contains('?') && value.split(' ').size <= 5) {
                    return LocalCommand.SetGame(value)
                }
            }
        }
        return null
    }
}
