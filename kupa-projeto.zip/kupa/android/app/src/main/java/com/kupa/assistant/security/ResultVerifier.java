package com.kupa.assistant.security;

import com.kupa.assistant.intent.TextNorm;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Confere se a resposta da IA afirma ter feito algo que NENHUMA ferramenta confirmou ("abri", "liguei", "atendi", "pesquisei"...).
 * Se afirma sem prova, acrescenta um aviso claro. Nunca deixa um "feito" não verificado passar sem aviso.
 */
public final class ResultVerifier {
    private ResultVerifier() {}

    public static final String OPEN = "open_app";
    public static final String CALL = "call_contact";
    public static final String CALL_CONTROL = "incoming_call";
    public static final String TIMER = "start_timer";
    public static final String SCREEN = "analyze_screen";
    public static final String SEARCH = "web_search";

    private static final String[][] CLAIMS = {
        {OPEN, "\\b(abri|abrindo|abrimos)\\b"},
        {CALL, "\\b(liguei|ligando para|chamei|telefonei)\\b"},
        {CALL_CONTROL, "\\b(atendi|recusei|desliguei|rejeitei)\\b"},
        {TIMER, "\\b(criei|iniciei|programei|configurei) (o |um |uma )?(temporizador|timer|cronometro|alarme)\\b"},
        {SCREEN, "\\b(vi na sua tela|analisei a tela|olhei a sua tela|olhei sua tela|capturei a tela|capturando a tela)\\b"},
        {SEARCH, "\\b(pesquisei|busquei na internet|segundo a pesquisa|de acordo com a pesquisa|encontrei na web)\\b"},
    };
    private static final Set<String> NEGATIONS = new HashSet<>(Arrays.asList("nao", "nunca", "sem", "nem", "ainda", "jamais"));

    public static final class Result {
        public final boolean ok;
        public final String text;
        public final List<String> unsupportedClaims;

        Result(boolean ok, String text, List<String> claims) {
            this.ok = ok;
            this.text = text;
            this.unsupportedClaims = claims;
        }
    }

    public static Result verify(String answer, Set<String> evidence) {
        if (answer == null || answer.isEmpty()) return new Result(true, answer, new ArrayList<String>());
        String folded = TextNorm.fold(answer);
        Set<String> unsupported = new LinkedHashSet<>();
        for (String[] c : CLAIMS) {
            if (evidence != null && evidence.contains(c[0])) continue;
            Matcher m = Pattern.compile(c[1]).matcher(folded);
            while (m.find()) {
                if (!negatedBefore(folded, m.start())) {
                    unsupported.add(c[0]);
                    break;
                }
            }
        }
        if (unsupported.isEmpty()) return new Result(true, answer, new ArrayList<String>());
        String fixed = answer + "\n\nAtenção: nenhuma ferramenta confirmou isso. Considere que a ação NÃO foi feita.";
        return new Result(false, fixed, new ArrayList<>(unsupported));
    }

    private static boolean negatedBefore(String folded, int index) {
        String before = folded.substring(Math.max(0, index - 24), index);
        List<String> tokens = TextNorm.tokens(TextNorm.normalize(before));
        int from = Math.max(0, tokens.size() - 3);
        for (int i = from; i < tokens.size(); i++) if (NEGATIONS.contains(tokens.get(i))) return true;
        return false;
    }
}
