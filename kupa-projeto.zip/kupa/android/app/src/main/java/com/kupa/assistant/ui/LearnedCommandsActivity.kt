package com.kupa.assistant.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import com.kupa.assistant.KupaApp
import com.kupa.assistant.intent.CommandInterpreter
import com.kupa.assistant.intent.LearnedCommand
import com.kupa.assistant.intent.LearningPlanner
import com.kupa.assistant.intent.Render

/**
 * Comandos que VOCÊ ensinou ao KUPA ("quando eu disser X, quero dizer Y"). Dá para ver, editar, remover e adicionar.
 * Nada é aprendido em silêncio: tudo aqui foi pedido por você e confirmado.
 */
class LearnedCommandsActivity : Activity() {
    private lateinit var app: KupaApp
    private lateinit var column: LinearLayout
    private val interpreter = CommandInterpreter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        column = Ui.screen(this, "Comandos aprendidos")
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun describe(c: LearnedCommand): String {
        if (c.kind == LearnedCommand.Kind.ENTITY) return "num comando, \"${c.trigger}\" significa \"${c.expansion}\""
        val parsed = interpreter.interpret(c.expansion)
        return if (parsed.isEmpty) c.expansion else Render.describe(parsed.intents)
    }

    private fun render() {
        while (column.childCount > 1) column.removeViewAt(1)
        column.addView(
            Ui.text(
                this,
                "Você ensina por voz (\"Kupa, quando eu disser 'chama Dudu', quero dizer ligar para Dudu\") ou aqui. Comandos de controle como atender e recusar não podem ser redefinidos.",
                13f, Ui.MUTED,
            ),
        )
        Ui.button(column, "Adicionar comando", primary = true) { showEditor(null) }
        val all = app.learned.all()
        if (all.isEmpty()) {
            column.addView(Ui.text(this, "Você ainda não ensinou nenhum comando.", 14f, Ui.MUTED))
            return
        }
        for (c in all.sortedBy { it.trigger }) addRow(c)
    }

    private fun addRow(c: LearnedCommand) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.rounded(this, Ui.CARD)
        val pad = Ui.dp(this, 12)
        card.setPadding(pad, pad, pad, pad)
        card.addView(Ui.text(this, "Quando você disser: \"${c.trigger}\"", 15f, Ui.TEXT, bold = true))
        card.addView(Ui.text(this, "O KUPA vai: ${describe(c)}", 14f, Ui.MUTED))
        Ui.button(card, "Editar") { showEditor(c) }
        Ui.button(card, "Remover") {
            AlertDialog.Builder(this)
                .setMessage("Remover o comando \"${c.trigger}\"?")
                .setPositiveButton("Remover") { _, _ ->
                    app.learned.remove(c.id)
                    render()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 10)
        column.addView(card, lp)
    }

    private fun showEditor(existing: LearnedCommand?) {
        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(this, 16)
        form.setPadding(pad, pad, pad, 0)
        val trigger = EditText(this)
        trigger.hint = "Quando eu disser… (ex.: chama dudu)"
        trigger.inputType = InputType.TYPE_CLASS_TEXT
        trigger.setText(existing?.trigger.orEmpty())
        val meaning = EditText(this)
        meaning.hint = "Quero dizer… (ex.: ligar para dudu, ou mobile legends)"
        meaning.inputType = InputType.TYPE_CLASS_TEXT
        meaning.setText(existing?.expansion.orEmpty())
        form.addView(trigger)
        form.addView(meaning)
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Novo comando" else "Editar comando")
            .setView(form)
            .setPositiveButton("Continuar") { _, _ -> confirm(existing, trigger.text.toString(), meaning.text.toString()) }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirm(existing: LearnedCommand?, trigger: String, meaning: String) {
        val plan = LearningPlanner.plan(trigger, meaning, interpreter)
        if (!plan.ok) {
            AlertDialog.Builder(this).setMessage(plan.error ?: "Não consegui entender.").setPositiveButton("OK", null).show()
            return
        }
        val clash = app.learned.findByTrigger(plan.trigger)
        val replacing = clash != null && clash.id != existing?.id
        val message = (if (replacing) "Já existe um comando para \"${plan.trigger}\" e ele será substituído.\n\n" else "") + "Entendi: ${plan.description}.\nSalvar?"
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton("Salvar") { _, _ ->
                if (existing != null) app.learned.remove(existing.id)
                app.learned.put(plan.kind ?: LearnedCommand.Kind.PHRASE, plan.trigger, plan.expansion)
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
