package com.kupa.assistant.security;

/** Perfis de desempenho. Cada um só ajusta parâmetros reais de {@link PerfParams}; nenhum mexe em segurança. */
public enum PerformanceProfile {
    AUTO, PERFORMANCE_MAX, BALANCED, BATTERY_SAVER, THERMAL_SAFE, AI_HEAVY, SCREEN_ANALYSIS, VOICE_LOW_LATENCY, ANIMATION_MAX
}
