package com.kupa.assistant.core

/** Os 15 estados do Popol, exatamente na numeração pedida. `spriteName` é o recurso visual principal. */
enum class KupaState(val id: Int, val label: String, val spriteName: String) {
    SPEAKING(1, "Falando", "state_01_speaking"),
    IDLE(2, "Esperando", "state_02_idle"),
    SEARCHING(3, "Pesquisando", "state_03_searching"),
    LISTENING(4, "Ouvindo", "state_04_listening"),
    THINKING(5, "Pensando", "state_05_thinking"),
    SCREEN_ANALYSIS(6, "Analisando tela", "state_06_screen_analysis"),
    ERROR(7, "Erro", "state_07_error"),
    ACTIVATED(8, "Ativado", "state_08_activated"),
    EXECUTING(9, "Executando comando", "state_09_executing"),
    SURPRISED(10, "Surpreso", "state_10_surprised"),
    HAPPY(11, "Feliz", "state_11_happy"),
    CONFUSED(12, "Confuso", "state_12_confused"),
    TRANSLATING(13, "Traduzindo", "state_13_translating"),
    READING(14, "Lendo", "state_14_reading"),
    COMPLETED(15, "Concluído", "state_15_completed");

    /** Sufixo "01_speaking" usado nos recursos opcionais popol_* e kupa_* (camadas separadas). */
    val suffix: String get() = spriteName.removePrefix("state_")
}
