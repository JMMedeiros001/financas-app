package com.kupa.assistant.history

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

enum class HistoryType { VOICE, TEXT, SEARCH, SCREEN_ANALYSIS, GAMER }

data class HistoryEntry(
    val id: Long,
    val question: String,
    val answer: String,
    val timestampMs: Long,
    val type: HistoryType,
)

/** Histórico local (somente no aparelho): pergunta, resposta, data/hora e tipo. */
class HistoryDb(context: Context) : SQLiteOpenHelper(context.applicationContext, "kupa_history.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE history (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT NOT NULL, " +
                "answer TEXT NOT NULL, ts INTEGER NOT NULL, type TEXT NOT NULL)",
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // versão 1: nada a migrar ainda
    }

    @Synchronized
    fun add(question: String, answer: String, type: HistoryType, timestampMs: Long = System.currentTimeMillis()): Long {
        val values = ContentValues()
        values.put("question", question)
        values.put("answer", answer)
        values.put("ts", timestampMs)
        values.put("type", type.name)
        return writableDatabase.insert("history", null, values)
    }

    @Synchronized
    fun list(limit: Int = 200): List<HistoryEntry> {
        val out = ArrayList<HistoryEntry>()
        readableDatabase.rawQuery(
            "SELECT id, question, answer, ts, type FROM history ORDER BY ts DESC, id DESC LIMIT ?",
            arrayOf(limit.toString()),
        ).use { c ->
            while (c.moveToNext()) {
                val type = try {
                    HistoryType.valueOf(c.getString(4))
                } catch (e: IllegalArgumentException) {
                    HistoryType.TEXT
                }
                out.add(HistoryEntry(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3), type))
            }
        }
        return out
    }

    @Synchronized
    fun delete(id: Long) {
        writableDatabase.delete("history", "id = ?", arrayOf(id.toString()))
    }

    @Synchronized
    fun clear() {
        writableDatabase.delete("history", null, null)
    }
}
