package com.kupa.assistant.actions

import android.content.Context
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.intent.LearnedCommand
import com.kupa.assistant.intent.TextNorm
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Comandos ensinados pelo usuário: persistentes, editáveis, removíveis e cifrados no aparelho. */
class LearnedStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("kupa_learned", Context.MODE_PRIVATE)
    private var items: MutableList<LearnedCommand> = ArrayList()
    private var loaded = false

    @Synchronized
    private fun ensureLoaded() {
        if (loaded) return
        loaded = true
        val stored = prefs.getString("data", null) ?: return
        val json = SecureStore.decrypt(stored)
        if (json == null) {
            KupaLog.w("aprendizado", "não consegui ler os comandos aprendidos; começando vazio")
            return
        }
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val kind = try {
                    LearnedCommand.Kind.valueOf(o.getString("kind"))
                } catch (e: IllegalArgumentException) {
                    continue
                }
                items.add(LearnedCommand(o.getString("id"), kind, o.getString("trigger"), o.getString("expansion"), o.optLong("createdAt", 0L)))
            }
        } catch (e: Exception) {
            KupaLog.e("aprendizado", "dados dos comandos aprendidos inválidos", e)
            items = ArrayList()
        }
    }

    @Synchronized
    private fun persist() {
        val arr = JSONArray()
        for (c in items) {
            arr.put(JSONObject().put("id", c.id).put("kind", c.kind.name).put("trigger", c.trigger).put("expansion", c.expansion).put("createdAt", c.createdAtMs))
        }
        val encrypted = SecureStore.encrypt(arr.toString())
        if (encrypted == null) {
            KupaLog.e("aprendizado", "não consegui salvar com segurança; nada foi gravado")
            return
        }
        prefs.edit().putString("data", encrypted).apply()
    }

    @Synchronized
    fun all(): List<LearnedCommand> {
        ensureLoaded()
        return ArrayList(items)
    }

    @Synchronized
    fun findByTrigger(trigger: String): LearnedCommand? {
        ensureLoaded()
        val t = TextNorm.normalize(trigger)
        return items.firstOrNull { it.trigger == t }
    }

    /** Adiciona; se já existir o mesmo gatilho, substitui (o chamador deve ter confirmado antes). */
    @Synchronized
    fun put(kind: LearnedCommand.Kind, trigger: String, expansion: String): LearnedCommand {
        ensureLoaded()
        val t = TextNorm.normalize(trigger)
        items.removeAll { it.trigger == t }
        val c = LearnedCommand(UUID.randomUUID().toString(), kind, t, expansion, System.currentTimeMillis())
        items.add(c)
        persist()
        KupaLog.i("aprendizado", "comando aprendido salvo (total ${items.size})")
        return c
    }

    @Synchronized
    fun remove(id: String): Boolean {
        ensureLoaded()
        val removed = items.removeAll { it.id == id }
        if (removed) persist()
        return removed
    }

    @Synchronized
    fun removeByTrigger(trigger: String): Boolean {
        ensureLoaded()
        val t = TextNorm.normalize(trigger)
        val removed = items.removeAll { it.trigger == t }
        if (removed) persist()
        return removed
    }

    @Synchronized
    fun clear() {
        ensureLoaded()
        items.clear()
        persist()
    }
}
