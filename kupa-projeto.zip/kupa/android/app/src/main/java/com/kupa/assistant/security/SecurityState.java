package com.kupa.assistant.security;

/** Estado de segurança do KUPA (separado dos 15 estados visuais do Popol). */
public enum SecurityState {
    NORMAL, WARNING, SUSPICIOUS, COMPROMISED, SAFE_SHUTDOWN;

    /** Nestes estados nenhuma ação (além de informar) pode ser executada. */
    public boolean blocksActions() {
        return this == COMPROMISED || this == SAFE_SHUTDOWN;
    }
}
