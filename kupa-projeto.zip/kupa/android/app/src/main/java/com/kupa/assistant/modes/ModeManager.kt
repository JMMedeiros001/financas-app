package com.kupa.assistant.modes

import android.content.Context
import com.kupa.assistant.actions.SecureJsonStore
import com.kupa.assistant.intent.TextNorm
import com.kupa.assistant.settings.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Modo personalizado. Só pode RESTRINGIR ou orientar o estilo: nunca libera nada que a segurança ou as configurações globais proíbem
 * (o app combina as permissões do modo com as globais por "E": os dois precisam permitir).
 */
data class ModeProfile(
    val id: String,
    val name: String,
    val description: String,
    /** Foco e estilo (vão para a IA como instruções do USUÁRIO, abaixo das regras de segurança). */
    val instructions: String,
    /** Memória própria do modo (preferências, tom, formato...). Nunca senhas. */
    val notes: String,
    /** OFF, LOW, MEDIUM ou HIGH. */
    val proactivity: String,
    val allowScreen: Boolean,
    val allowWeb: Boolean,
    /** "" (padrão), "fast" ou "reasoning". */
    val modelClass: String,
)

class ModeManager(context: Context, private val settings: Settings) {
    private val store = SecureJsonStore(context, "modes")

    @Synchronized
    fun all(): List<ModeProfile> {
        val arr = store.read().optJSONArray("modes") ?: return emptyList()
        val out = ArrayList<ModeProfile>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                ModeProfile(
                    o.optString("id"), o.optString("name"), o.optString("description"), o.optString("instructions"), o.optString("notes"),
                    o.optString("proactivity", "OFF"), o.optBoolean("allowScreen", true), o.optBoolean("allowWeb", true), o.optString("modelClass", ""),
                ),
            )
        }
        return out
    }

    @Synchronized
    private fun persist(list: List<ModeProfile>): Boolean {
        val arr = JSONArray()
        for (m in list) {
            arr.put(
                JSONObject().put("id", m.id).put("name", m.name).put("description", m.description).put("instructions", m.instructions)
                    .put("notes", m.notes).put("proactivity", m.proactivity).put("allowScreen", m.allowScreen).put("allowWeb", m.allowWeb).put("modelClass", m.modelClass),
            )
        }
        return store.write(JSONObject().put("modes", arr))
    }

    fun newId(): String = UUID.randomUUID().toString()

    @Synchronized
    fun save(mode: ModeProfile): Boolean {
        val list = all().filter { it.id != mode.id }.toMutableList()
        list.add(mode.copy(name = mode.name.trim().take(40), instructions = mode.instructions.trim().take(600), notes = mode.notes.trim().take(800)))
        return persist(list)
    }

    @Synchronized
    fun delete(id: String) {
        if (settings.activeModeId == id) settings.activeModeId = ""
        persist(all().filter { it.id != id })
    }

    fun find(id: String): ModeProfile? = all().firstOrNull { it.id == id }

    /** Acha um modo pelo nome falado ("estudo", "metodo dark"), sem acento e sem diferenciar maiúsculas. */
    fun findByName(spoken: String): ModeProfile? {
        val q = TextNorm.normalize(spoken)
        if (q.isEmpty()) return null
        val modes = all()
        return modes.firstOrNull { TextNorm.normalize(it.name) == q } ?: modes.firstOrNull { TextNorm.normalize(it.name).contains(q) || q.contains(TextNorm.normalize(it.name)) }
    }

    fun active(): ModeProfile? = settings.activeModeId.takeIf { it.isNotEmpty() }?.let { find(it) }

    fun activate(id: String): Boolean {
        if (find(id) == null) return false
        settings.activeModeId = id
        return true
    }

    fun exit() {
        settings.activeModeId = ""
    }

    companion object {
        /** Modelo pronto para criação de conteúdo. Não faz nada além de orientar o estilo das respostas de TEXTO. */
        fun metodoDarkTemplate(id: String) = ModeProfile(
            id = id,
            name = "Método Dark",
            description = "Criação e análise de conteúdo digital.",
            instructions = "Ajude a criar e melhorar roteiros, hooks, títulos, legendas e CTAs. Ao analisar, separe sempre FATO, OBSERVAÇÃO, HIPÓTESE e RECOMENDAÇÃO. Nunca invente métricas nem prometa viralização.",
            notes = "",
            proactivity = "LOW",
            allowScreen = false,
            allowWeb = true,
            modelClass = "",
        )
    }
}
