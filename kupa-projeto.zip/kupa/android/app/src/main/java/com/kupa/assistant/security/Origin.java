package com.kupa.assistant.security;

/** De onde veio o pedido. Voz NÃO é autenticação: reconhecer o texto não prova quem falou. */
public enum Origin {
    /** Toque na tela/botão do próprio KUPA. */
    USER_TOUCH,
    /** Texto digitado no KUPA. */
    USER_TEXT,
    /** Voz (falante NÃO verificado: o Android não oferece verificação de falante nas APIs oficiais). */
    USER_VOICE,
    /** Ferramenta pedida por uma IA externa: dado NÃO confiável. */
    AI_TOOL
}
