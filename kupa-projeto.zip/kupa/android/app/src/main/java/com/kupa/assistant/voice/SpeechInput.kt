package com.kupa.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.kupa.assistant.core.KupaLog

/** Reconhecimento de voz do Android (SpeechRecognizer). Tudo na thread principal. */
class SpeechInput(private val context: Context) {
    enum class Failure { NO_MATCH, TIMEOUT, BUSY, PERMISSION, NOT_AVAILABLE, NETWORK, OTHER }

    interface Listener {
        fun onReady()
        fun onPartial(text: String)
        fun onResult(alternatives: List<String>)
        fun onFailure(failure: Failure)
    }

    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    val isAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(context)
    val isListening: Boolean get() = listening

    fun start(listener: Listener) {
        if (!isAvailable) {
            listener.onFailure(Failure.NOT_AVAILABLE)
            return
        }
        cancel()
        val r = try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            KupaLog.e("fala", "não consegui criar o reconhecedor", e)
            listener.onFailure(Failure.NOT_AVAILABLE)
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listener.onReady()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!list.isNullOrEmpty()) listener.onPartial(list[0])
            }

            override fun onResults(results: Bundle?) {
                listening = false
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (list.isNullOrEmpty()) listener.onFailure(Failure.NO_MATCH) else listener.onResult(list)
            }

            override fun onError(error: Int) {
                listening = false
                val failure = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> Failure.NO_MATCH
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> Failure.TIMEOUT
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> Failure.BUSY
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> Failure.PERMISSION
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> Failure.NETWORK
                    SpeechRecognizer.ERROR_CLIENT -> Failure.OTHER
                    else -> Failure.OTHER
                }
                if (failure != Failure.NO_MATCH && failure != Failure.TIMEOUT) KupaLog.w("fala", "erro do reconhecedor: código $error")
                listener.onFailure(failure)
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        try {
            listening = true
            r.startListening(intent)
        } catch (e: Exception) {
            listening = false
            KupaLog.e("fala", "startListening falhou", e)
            listener.onFailure(Failure.OTHER)
        }
    }

    /** Encerra a escuta atual sem entregar resultado. */
    fun cancel() {
        listening = false
        val r = recognizer ?: return
        recognizer = null
        try {
            r.setRecognitionListener(null)
            r.cancel()
            r.destroy()
        } catch (e: Exception) {
            KupaLog.w("fala", "erro ao cancelar: ${e.message}")
        }
    }
}
