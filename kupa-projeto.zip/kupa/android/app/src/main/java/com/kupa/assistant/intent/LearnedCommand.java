package com.kupa.assistant.intent;

/** Associação ensinada explicitamente pelo usuário. */
public final class LearnedCommand {
    public enum Kind {
        /** frase inteira -> comando (ex.: "abre o jogo" -> "abra mobile legends"). */
        PHRASE,
        /** nome -> outro nome dentro de um comando (ex.: "zap" -> "whatsapp"). */
        ENTITY
    }

    public final String id;
    public final Kind kind;
    /** Normalizado (minúsculas, sem acento). */
    public final String trigger;
    /** Texto canônico do comando (PHRASE) ou o nome (ENTITY). */
    public final String expansion;
    public final long createdAtMs;

    public LearnedCommand(String id, Kind kind, String trigger, String expansion, long createdAtMs) {
        this.id = id;
        this.kind = kind;
        this.trigger = trigger;
        this.expansion = expansion;
        this.createdAtMs = createdAtMs;
    }
}
