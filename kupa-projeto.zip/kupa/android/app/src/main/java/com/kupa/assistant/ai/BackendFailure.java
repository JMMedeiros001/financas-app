package com.kupa.assistant.ai;

import java.io.IOException;
import java.net.ConnectException;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLException;

/**
 * Classifica uma falha de conexão com o backend em categorias que o usuário entende (DNS, TLS, recusada, timeout, HTTP...).
 * Lógica pura (testada). Nunca sugere ignorar erro de certificado.
 */
public final class BackendFailure {
    private BackendFailure() {}

    public enum Kind { DNS, TLS, CONNECTION_REFUSED, UNREACHABLE, TIMEOUT, HTTP_NOT_BACKEND, HTTP_AUTH, HTTP_STARTING, HTTP_SERVER, HTTP_RATE_LIMIT, HTTP_OTHER, INVALID_RESPONSE, UNKNOWN }

    public static final class Info {
        public final Kind kind;
        public final String code;
        public final String message;

        Info(Kind kind, String code, String message) {
            this.kind = kind;
            this.code = code;
            this.message = message;
        }
    }

    public static Info fromException(Throwable t) {
        Throwable cause = t;
        // procura a causa mais específica na cadeia
        for (int i = 0; i < 6 && cause != null; i++) {
            if (cause instanceof UnknownHostException) {
                return new Info(Kind.DNS, "dns", "Não encontrei o endereço do backend (DNS). Confira se a URL está escrita certa e se o celular tem internet.");
            }
            if (cause instanceof SSLException || cause instanceof CertificateException) {
                return new Info(Kind.TLS, "tls", "Falha de segurança TLS: o certificado do servidor não é confiável ou não combina com o endereço, ou a hora do celular está errada. O KUPA não ignora erros de certificado. Confira a URL e a data/hora do aparelho.");
            }
            if (cause instanceof SocketTimeoutException) {
                return new Info(Kind.TIMEOUT, "timeout", "O backend demorou demais para responder. Se ele roda num plano gratuito, pode estar acordando: tente de novo em 1 minuto.");
            }
            if (cause instanceof ConnectException) {
                return new Info(Kind.CONNECTION_REFUSED, "connection_refused", "O servidor recusou a conexão: o backend pode estar desligado ou a porta/endereço está errada.");
            }
            if (cause instanceof NoRouteToHostException) {
                return new Info(Kind.UNREACHABLE, "unreachable", "Não há caminho até o servidor. Confira a internet do celular e o endereço.");
            }
            cause = cause.getCause();
        }
        if (t instanceof IOException) {
            return new Info(Kind.UNREACHABLE, "network", "Não consegui falar com o backend. Confira a internet do celular.");
        }
        return new Info(Kind.UNKNOWN, "unknown", "Falha inesperada ao falar com o backend.");
    }

    /** @param isHealthRoute true quando a rota consultada foi /health (404 ali significa "este endereço não é o backend do KUPA"). */
    public static Info fromHttpStatus(int status, boolean isHealthRoute) {
        if (status == 404 && isHealthRoute) {
            return new Info(Kind.HTTP_NOT_BACKEND, "http_404", "O endereço respondeu, mas não é o backend do KUPA (rota /health não encontrada, HTTP 404). Confira a URL.");
        }
        if (status == 401 || status == 403) {
            return new Info(Kind.HTTP_AUTH, "http_" + status, "O backend recusou o token (HTTP " + status + "). Digite o mesmo KUPA_APP_TOKEN que está configurado no backend.");
        }
        if (status == 429) {
            return new Info(Kind.HTTP_RATE_LIMIT, "http_429", "O backend limitou as requisições (HTTP 429). Aguarde um pouco e tente de novo.");
        }
        if (status == 502 || status == 503 || status == 504) {
            return new Info(Kind.HTTP_STARTING, "http_" + status, "O backend está indisponível ou ainda iniciando (HTTP " + status + "). Em plano gratuito isso acontece quando ele estava dormindo: tente de novo em 1 minuto.");
        }
        if (status >= 500) {
            return new Info(Kind.HTTP_SERVER, "http_" + status, "O backend teve um erro interno (HTTP " + status + "). Veja os logs da hospedagem.");
        }
        return new Info(Kind.HTTP_OTHER, "http_" + status, "O backend respondeu algo inesperado (HTTP " + status + ").");
    }

    public static Info invalidResponse() {
        return new Info(Kind.INVALID_RESPONSE, "invalid_response", "O endereço respondeu, mas não parece ser o backend do KUPA (resposta inesperada). Confira a URL.");
    }
}
