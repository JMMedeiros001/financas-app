package com.kupa.assistant

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import com.kupa.assistant.actions.ActionExecutor
import com.kupa.assistant.actions.AppLauncher
import com.kupa.assistant.actions.CallStateTracker
import com.kupa.assistant.actions.CommandCenter
import com.kupa.assistant.actions.ContactResolver
import com.kupa.assistant.actions.ConversationContext
import com.kupa.assistant.actions.LearnedStore
import com.kupa.assistant.actions.PhoneActions
import com.kupa.assistant.ai.ConnectionStatus
import com.kupa.assistant.character.SpriteRepository
import com.kupa.assistant.content.ContentProjects
import com.kupa.assistant.content.NicheProfile
import com.kupa.assistant.core.WakeWord
import com.kupa.assistant.identity.AssistantIdentity
import com.kupa.assistant.modes.ModeManager
import com.kupa.assistant.perf.PerformanceEngine
import com.kupa.assistant.profile.AdaptiveUserProfile
import com.kupa.assistant.security.SecurityGuard
import com.kupa.assistant.voice.EarconGuard
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.game.GameContextService
import com.kupa.assistant.gamer.GamerModeController
import com.kupa.assistant.history.HistoryDb
import com.kupa.assistant.screen.ScreenCaptureManager
import com.kupa.assistant.settings.Settings

/** Aplicativo: cria uma vez os componentes compartilhados entre telas, serviço e overlay. */
class KupaApp : Application() {
    lateinit var settings: Settings
        private set
    lateinit var history: HistoryDb
        private set
    lateinit var states: StateManager
        private set
    lateinit var gameContext: GameContextService
        private set
    lateinit var gamer: GamerModeController
        private set
    lateinit var screen: ScreenCaptureManager
        private set
    lateinit var sprites: SpriteRepository
        private set
    lateinit var conversation: ConversationContext
        private set
    lateinit var learned: LearnedStore
        private set
    lateinit var contacts: ContactResolver
        private set
    lateinit var phone: PhoneActions
        private set
    lateinit var callTracker: CallStateTracker
        private set
    lateinit var commands: CommandCenter
        private set
    lateinit var identity: AssistantIdentity
        private set
    lateinit var earcon: EarconGuard
        private set
    lateinit var connection: ConnectionStatus
        private set
    lateinit var security: SecurityGuard
        private set
    lateinit var modes: ModeManager
        private set
    lateinit var profile: AdaptiveUserProfile
        private set
    lateinit var niche: NicheProfile
        private set
    lateinit var projects: ContentProjects
        private set
    lateinit var performance: PerformanceEngine
        private set
    lateinit var core: KupaCore
        private set

    fun interface ForegroundListener {
        fun onForegroundChanged(foreground: Boolean)
    }

    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private var startedActivities = 0
    private val foregroundListeners = java.util.concurrent.CopyOnWriteArrayList<ForegroundListener>()

    /** true enquanto alguma tela do KUPA estiver visível (usado quando "sempre no topo" está desligado). */
    val isForeground: Boolean get() = startedActivities > 0

    fun addForegroundListener(l: ForegroundListener) {
        foregroundListeners.add(l)
    }

    fun removeForegroundListener(l: ForegroundListener) {
        foregroundListeners.remove(l)
    }

    override fun onCreate() {
        super.onCreate()
        KupaLog.i("app", "KUPA iniciado")
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                startedActivities++
                if (startedActivities == 1) for (l in foregroundListeners) l.onForegroundChanged(true)
            }

            override fun onActivityStopped(activity: Activity) {
                startedActivities = maxOf(0, startedActivities - 1)
                if (startedActivities == 0) for (l in foregroundListeners) l.onForegroundChanged(false)
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
        settings = Settings(this)
        history = HistoryDb(this)
        states = StateManager()
        gameContext = GameContextService()
        gamer = GamerModeController(settings)
        screen = ScreenCaptureManager(this)
        sprites = SpriteRepository(this)
        conversation = ConversationContext()
        earcon = EarconGuard(this, settings)
        earcon.recoverAfterCrash() // se o processo morreu com a mídia silenciada pelo botão antibaip, desfaz
        identity = AssistantIdentity(settings)
        identity.apply()
        WakeWord.onMiss = { text -> identity.noteUtterance(text) }
        security = SecurityGuard(this)
        modes = ModeManager(this, settings)
        profile = AdaptiveUserProfile(this)
        niche = NicheProfile(this)
        projects = ContentProjects(this)
        performance = PerformanceEngine(this, settings)
        performance.addListener { params -> sprites.setCacheMb(params.spriteCacheMb) }
        learned = LearnedStore(this)
        contacts = ContactResolver(this)
        phone = PhoneActions(this)
        callTracker = CallStateTracker(this, contacts, conversation)
        val executor = ActionExecutor(this, settings, conversation, AppLauncher(this), contacts, phone, learned, callTracker, security, profile) { isForeground }
        // "parar tudo" por voz chama o núcleo (criado logo abaixo) na hora em que for usado
        commands = CommandCenter(conversation, executor, learned, modes, security) { main.post { core.stopEverything() } }
        core = KupaCore(this, settings, history, states, gameContext, gamer, screen, commands, phone, conversation, security, modes, profile, niche, performance, identity)
        core.speech.onBeforeSpeak = { earcon.release() }
        connection = ConnectionStatus(settings) { core.client }
        core.onRealAiAnswer = { model -> connection.markAiVerified(model) }
        core.onAiFailure = { error -> connection.markFailure(error) }
    }

    companion object {
        fun from(context: Context): KupaApp = context.applicationContext as KupaApp
    }
}
