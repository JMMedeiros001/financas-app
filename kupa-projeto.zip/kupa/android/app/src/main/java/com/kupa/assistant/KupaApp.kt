package com.kupa.assistant

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import com.kupa.assistant.character.SpriteRepository
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.game.GameContextService
import com.kupa.assistant.gamer.GamerModeController
import com.kupa.assistant.history.HistoryDb
import com.kupa.assistant.screen.ScreenCaptureManager
import com.kupa.assistant.settings.Settings

/** Aplicativo: cria uma vez os componentes compartilhados entre telas, serviço e overlay. */
class KupaApp : Application() {
    lateinit var settings: Settings
        private set
    lateinit var history: HistoryDb
        private set
    lateinit var states: StateManager
        private set
    lateinit var gameContext: GameContextService
        private set
    lateinit var gamer: GamerModeController
        private set
    lateinit var screen: ScreenCaptureManager
        private set
    lateinit var sprites: SpriteRepository
        private set
    lateinit var core: KupaCore
        private set

    fun interface ForegroundListener {
        fun onForegroundChanged(foreground: Boolean)
    }

    private var startedActivities = 0
    private val foregroundListeners = java.util.concurrent.CopyOnWriteArrayList<ForegroundListener>()

    /** true enquanto alguma tela do KUPA estiver visível (usado quando "sempre no topo" está desligado). */
    val isForeground: Boolean get() = startedActivities > 0

    fun addForegroundListener(l: ForegroundListener) {
        foregroundListeners.add(l)
    }

    fun removeForegroundListener(l: ForegroundListener) {
        foregroundListeners.remove(l)
    }

    override fun onCreate() {
        super.onCreate()
        KupaLog.i("app", "KUPA iniciado")
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                startedActivities++
                if (startedActivities == 1) for (l in foregroundListeners) l.onForegroundChanged(true)
            }

            override fun onActivityStopped(activity: Activity) {
                startedActivities = maxOf(0, startedActivities - 1)
                if (startedActivities == 0) for (l in foregroundListeners) l.onForegroundChanged(false)
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
        settings = Settings(this)
        history = HistoryDb(this)
        states = StateManager()
        gameContext = GameContextService()
        gamer = GamerModeController(settings)
        screen = ScreenCaptureManager(this)
        sprites = SpriteRepository(this)
        core = KupaCore(this, settings, history, states, gameContext, gamer, screen)
    }

    companion object {
        fun from(context: Context): KupaApp = context.applicationContext as KupaApp
    }
}
