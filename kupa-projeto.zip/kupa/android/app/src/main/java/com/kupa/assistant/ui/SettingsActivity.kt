package com.kupa.assistant.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import com.kupa.assistant.KupaApp
import com.kupa.assistant.ai.BackendConfig
import com.kupa.assistant.intent.TextNorm
import com.kupa.assistant.security.NativeAuth
import com.kupa.assistant.security.PerformanceProfile
import android.widget.EditText
import android.widget.Toast
import android.text.InputType
import android.widget.LinearLayout
import com.kupa.assistant.overlay.KupaService
import com.kupa.assistant.screen.ScreenPermissionActivity

/** Configurações: personagem, voz, ativação, tela, IA e Modo Gamer. */
class SettingsActivity : Activity() {
    private lateinit var app: KupaApp
    private var captureStatus: TextView? = null
    private var backendStatus: TextView? = null
    private lateinit var permissionsBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val s = app.settings
        val core = app.core
        val column = Ui.screen(this, "Configurações")

        // ---------------------------------------------------------------- personagem
        val character = Ui.section(column, "Personagem")
        Ui.note(character, "Popol é o personagem principal; Kupa é o lobo companheiro. Você também pode arrastar o Popol na tela e usar pinça para mudar o tamanho.")
        Ui.switchRow(character, "Mostrar Popol flutuante sobre outros apps", "Precisa da permissão de sobreposição de tela.", { s.overlayEnabled }, { s.overlayEnabled = it })
        Ui.sliderRow(character, "Tamanho", 80, 320, { s.sizeDp }, { s.sizeDp = it }, { "$it dp" })
        Ui.sliderRow(character, "Transparência (opacidade)", 20, 100, { s.alphaPercent }, { s.alphaPercent = it }, { "$it%" })
        Ui.switchRow(character, "Sempre no topo", "Desligado: o Popol só aparece quando o app KUPA está aberto.", { s.alwaysOnTop }, { s.alwaysOnTop = it })
        Ui.switchRow(character, "Posição automática", "Ao soltar, o Popol gruda na borda mais próxima da tela.", { s.autoPosition }, { s.autoPosition = it })
        Ui.switchRow(character, "Animações", "Desligue para economizar bateria.", { s.animationsEnabled }, { s.animationsEnabled = it })
        Ui.switchRow(character, "Mostrar respostas em balão perto do Popol", null, { s.showBubble }, { s.showBubble = it })
        val kupaLayer = app.sprites.hasSeparateKupaLayer()
        Ui.note(
            character,
            if (kupaLayer) "Camada separada do Kupa: ENCONTRADA. Popol e Kupa animam de forma independente."
            else "Camada separada do Kupa: não encontrada. Os visuais atuais trazem Popol e Kupa juntos, então os dois se movem como um conjunto. Para animar o Kupa sozinho, adicione os arquivos popol_XX_nome e kupa_XX_nome (veja o README).",
            if (kupaLayer) Ui.OK else Ui.WARN,
        )

        // ---------------------------------------------------------------- voz
        val voice = Ui.section(column, "Voz")
        Ui.switchRow(voice, "Voz ativada", "Liga juntos o microfone, o reconhecimento de fala e a resposta por voz. Desligada: só texto, e o resto continua funcionando.", { s.voiceEnabled }, { core.setVoiceEnabled(it) })
        Ui.sliderRow(voice, "Volume", 0, 100, { s.volumePercent }, { s.volumePercent = it }, { "$it%" })
        Ui.sliderRow(voice, "Tom da voz", 70, 160, { s.pitchPercent }, { s.pitchPercent = it }, { "$it%" })
        Ui.sliderRow(voice, "Velocidade", 70, 160, { s.ratePercent }, { s.ratePercent = it }, { "$it%" })
        Ui.button(voice, "Escolher voz do aparelho") { chooseVoice() }
        Ui.button(voice, "Testar voz") {
            core.speech.speak("Oi! Eu sou o KUPA. Vamos nessa?", s.volumePercent, flush = true, onError = { m -> Ui.note(voice, m, Ui.BAD) }, onDone = {})
        }
        Ui.note(voice, "Predefinições (só ajustam tom e velocidade; o Android não oferece controle de emoção nem de pausas):")
        Ui.button(voice, "Energética (tom 115%, velocidade 105%)") { s.pitchPercent = 115; s.ratePercent = 105; recreate() }
        Ui.button(voice, "Calma (tom 100%, velocidade 92%)") { s.pitchPercent = 100; s.ratePercent = 92; recreate() }
        Ui.button(voice, "Neutra (tom 100%, velocidade 100%)") { s.pitchPercent = 100; s.ratePercent = 100; recreate() }
        core.speech.ensureInit()
        Ui.note(voice, core.speech.describeEngine())
        Ui.note(voice, "A voz é a sintetizada do motor de texto para fala instalado no Android (sem áudio de jogo e sem clonar a voz de ninguém). Tom e velocidade mudam o jeito de falar, mas NÃO transformam uma voz comum em uma voz de personagem: o resultado depende do motor e das vozes instaladas. Para mais naturalidade, instale vozes de maior qualidade em Configurações do Android > Texto para fala. Voz de nuvem (síntese pelo backend) não está implementada.")

        // ---------------------------------------------------------------- nome do assistente e palavra de ativação
        val ident = Ui.section(column, "Nome do assistente e palavra de ativação")
        Ui.note(ident, "O app continua sendo o KUPA; aqui você escolhe como o assistente se chama e a palavra que você fala para chamá-lo. A palavra de ativação só INICIA a conversa: ela não identifica quem falou e não autoriza nenhuma ação.")
        val displayEdit = Ui.inputRow(ident, "Nome mostrado", "ex.: Luna", { app.identity.displayName }, { })
        val activationEdit = Ui.inputRow(ident, "Palavra de ativação (uma palavra, sem espaços)", "ex.: luna", { app.identity.activationName }, { })
        var keepOld = false
        Ui.switchRow(ident, "Manter o nome antigo também ativando", "Desligado: o nome antigo deixa de ativar.", { keepOld }, { keepOld = it })
        Ui.button(ident, "Salvar nome", primary = true) {
            val problem = app.identity.rename(displayEdit.text.toString(), activationEdit.text.toString(), keepOld)
            if (problem != null) {
                Toast.makeText(this, problem, Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Nome salvo. Para chamar, diga \"${app.identity.activationName}\".", Toast.LENGTH_LONG).show()
                recreate()
            }
        }
        ident.addView(Ui.text(this, "Variantes (jeitos que o reconhecimento de voz costuma ouvir)", 15f, Ui.TEXT))
        Ui.note(ident, "Variantes só valem no começo da frase ou depois de \"oi\"/\"ei\". Nada é aprendido sozinho: o KUPA só sugere e você decide.")
        for (v in app.identity.builtInVariants()) {
            Ui.switchRow(ident, "\"$v\" (embutida)", "", { v !in app.identity.disabledBuiltIn() }, { app.identity.setBuiltInEnabled(v, it) })
        }
        for (v in app.identity.customVariants() + app.identity.learnedVariants()) {
            Ui.button(ident, "Remover variante \"$v\"") {
                app.identity.removeCustomVariant(v)
                recreate()
            }
        }
        val variantEdit = Ui.inputRow(ident, "Adicionar variante", "uma palavra", { "" }, { })
        Ui.button(ident, "Adicionar variante") {
            val problem = app.identity.addCustomVariant(variantEdit.text.toString())
            if (problem != null) Toast.makeText(this, problem, Toast.LENGTH_LONG).show() else recreate()
        }
        val suggestions = app.identity.candidates()
        if (suggestions.isNotEmpty()) {
            ident.addView(Ui.text(this, "Sugestões (palavras parecidas que o KUPA ouviu no começo de frases)", 15f, Ui.TEXT))
            for ((word, count) in suggestions) {
                Ui.button(ident, "Aceitar \"$word\" (ouvida $count vez(es))") {
                    val problem = app.identity.acceptCandidate(word)
                    if (problem != null) Toast.makeText(this, problem, Toast.LENGTH_LONG).show()
                    recreate()
                }
                Ui.button(ident, "Ignorar \"$word\"") {
                    app.identity.dismissCandidate(word)
                    recreate()
                }
            }
        }
        Ui.button(ident, "Restaurar nome e variantes padrão") {
            app.identity.restoreDefaults()
            recreate()
        }

        // ---------------------------------------------------------------- modo de escuta
        val listen = Ui.section(column, "Modo de escuta")
        Ui.choiceRow(
            listen, "Como o KUPA ouve",
            listOf(Pair("Ativação por \"${app.identity.activationName}\"", "wake"), Pair("Escuta contínua", "continuous")),
            { s.listenMode }, { s.listenMode = it },
        )
        Ui.note(listen, "Ativação por \"Kupa\": fica esperando a palavra \"Kupa\" (ou \"cupa\"/\"culpa\" no começo da frase), ouve UM comando e volta a aguardar.")
        Ui.note(listen, "Escuta contínua: dá para falar vários comandos seguidos sem dizer \"Kupa\" ( \"abra o WhatsApp\", depois \"ligue para Dudu\"). Só comandos de celular reconhecidos viram ação; conversa solta é ignorada. Ligações sempre pedem confirmação se você não disse \"Kupa\".")
        Ui.note(listen, "Estado agora: " + (app.core.voiceControl?.statusText() ?: "o KUPA não está em execução."))
        Ui.button(listen, "Tentar de novo a escuta") { app.core.voiceControl?.retryNow() }
        Ui.switchRow(listen, "Microfone sempre ligado", "Desligado: o KUPA só ouve quando você toca em Falar (app ou notificação).", { s.wakeListening }, { s.wakeListening = it })
        var freeSwitch: android.widget.Switch? = null
        freeSwitch = Ui.switchRow(
            listen, "Frases soltas também vão para a IA (modo contínuo)",
            "Desligado por padrão: evita enviar conversas do ambiente à IA e gastar sua cota. Ligar exige a confirmação do aparelho.",
            { s.continuousFreeText },
            { checked ->
                if (!checked) {
                    s.continuousFreeText = false
                } else {
                    requireAuth("Enviar frases soltas do ambiente à IA", onDenied = { freeSwitch?.isChecked = false }) { s.continuousFreeText = true }
                }
            },
        )
        Ui.sliderRow(listen, "Pausar sozinho após (modo contínuo)", 0, 60, { s.continuousIdleMinutes }, { s.continuousIdleMinutes = it }, { if (it == 0) "nunca" else "$it min" })
        Ui.switchRow(listen, "Pausar com a tela desligada", "Poupa bateria e privacidade. Desligue se quiser usar com o celular no bolso.", { s.pauseWhenScreenOff }, { s.pauseWhenScreenOff = it })
        Ui.switchRow(listen, "Preferir reconhecimento no aparelho", "Pede ao Android para reconhecer a voz sem internet quando o pacote de voz estiver instalado. Nenhum áudio vai para o backend do KUPA.", { s.preferOfflineRecognition }, { s.preferOfflineRecognition = it })
        Ui.switchRow(listen, "Aceitar variantes da palavra de ativação", "Só vale no começo da frase ou depois de \"oi\"/\"ei\" (ex.: \"a culpa é minha\" não ativa).", { s.wakeAcceptVariants }, { s.wakeAcceptVariants = it })
        Ui.note(listen, "Limite do Android: a escuta contínua gasta bateria e pode brigar com o microfone de outros apps. Sensibilidade não é ajustável pelo reconhecedor do Android.")

        // ---------------------------------------------------------------- ações sensíveis
        val sensitive = Ui.section(column, "Ações sensíveis")
        Ui.choiceRow(
            sensitive, "Antes de ligar para alguém",
            listOf(Pair("Confirmar", "confirm"), Pair("Executar direto", "direct")),
            { if (s.confirmSensitive) "confirm" else "direct" },
            { v ->
                if (v == "confirm") {
                    s.confirmSensitive = true
                } else {
                    // enfraquecer uma proteção exige a confirmação do aparelho (voz nunca basta)
                    requireAuth("Executar ligações sem pedir confirmação") {
                        s.confirmSensitive = false
                        recreate()
                    }
                }
            },
        )
        Ui.note(sensitive, "Confirmar: \"Encontrei Dudu. Quer que eu faça a ligação?\". Executar direto: liga sem perguntar (as proteções do Android continuam valendo). Abrir apps sempre é direto. Se o nome for só parecido, se houver mais de um contato ou se o pedido vier da IA, o KUPA sempre pergunta.")

        // ---------------------------------------------------------------- comandos aprendidos
        val learnedSection = Ui.section(column, "Comandos aprendidos")
        Ui.note(learnedSection, "Atalhos que você ensinou. Hoje: ${app.learned.all().size} comando(s).")
        Ui.button(learnedSection, "Ver e editar comandos aprendidos") { startActivity(Intent(this, LearnedCommandsActivity::class.java)) }

        // ---------------------------------------------------------------- permissões
        // ---------------------------------------------------------------- segurança e privacidade
        val sec = Ui.section(column, "Segurança e privacidade")
        Ui.note(sec, "Estado de segurança agora: ${app.security.state().name}. Nenhum modo, IA ou ferramenta consegue desativar o núcleo de segurança.")
        Ui.note(sec, "Voz NÃO é autenticação: o Android não oferece verificação de falante, então o KUPA não finge reconhecer quem fala. Risco alto pede duas confirmações; ações críticas pedem a confirmação do aparelho (biometria/PIN).")
        Ui.note(sec, com.kupa.assistant.voice.VoiceVerification.UnavailableSpeakerVerifier().describe(), Ui.WARN)
        Ui.note(sec, "O que o KUPA NÃO faz: não grava nem guarda áudio, não guarda capturas de tela (captura, analisa, descarta), não captura senhas, não tem telemetria e remove senhas, cartões e chaves antes de enviar texto à IA.")
        Ui.button(sec, "⛔ PARAR KUPA agora") {
            app.core.stopEverything()
            Toast.makeText(this, "KUPA parado.", Toast.LENGTH_SHORT).show()
        }
        if (app.security.state().blocksActions()) {
            Ui.button(sec, "Reativar o KUPA (confirmação do aparelho)", primary = true) {
                app.core.rearm { ok ->
                    Toast.makeText(this, if (ok) "KUPA reativado." else "Não confirmado: continua em modo seguro.", Toast.LENGTH_LONG).show()
                    recreate()
                }
            }
        }
        sec.addView(Ui.text(this, "Zonas de privacidade (um app por linha)", 15f, Ui.TEXT))
        Ui.note(sec, "Nestes apps o KUPA não analisa a tela, além dos padrões (bancos, carteiras, senhas, autenticadores). Limite honesto: o KUPA só sabe qual app está na frente quando ele mesmo o abriu.")
        val zones = EditText(this)
        zones.setText(s.privacyZones)
        zones.setTextColor(Ui.TEXT)
        zones.minLines = 3
        zones.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        sec.addView(zones)
        Ui.button(sec, "Salvar zonas de privacidade") { saveZones(zones.text.toString()) }

        // ---------------------------------------------------------------- modos, proatividade e conteúdo
        val modesSection = Ui.section(column, "Modos, proatividade e conteúdo")
        Ui.note(modesSection, "Modo ativo: " + (app.modes.active()?.name ?: "padrão"))
        Ui.button(modesSection, "Gerenciar modos") { startActivity(Intent(this, ModesActivity::class.java)) }
        Ui.choiceRow(
            modesSection, "Proatividade (sugestões que você não pediu)",
            listOf(Pair("Desligada", "OFF"), Pair("Baixa", "LOW"), Pair("Média", "MEDIUM"), Pair("Alta", "HIGH")),
            { s.proactivity }, { s.proactivity = it },
        )
        Ui.note(modesSection, "Toda sugestão vem rotulada como Observação, Hipótese ou Recomendação. Você pode dar 👍/👎 e \"sem sugestões\" na conversa: o KUPA ajusta.")
        Ui.button(modesSection, "Conteúdo: nicho, hooks e roteiro") { startActivity(Intent(this, ContentActivity::class.java)) }

        // ---------------------------------------------------------------- desempenho
        val perf = Ui.section(column, "Desempenho (celular e tablet)")
        Ui.note(perf, app.performance.describe())
        Ui.button(perf, "Perfil de desempenho (atual: ${s.performanceProfile})") {
            val names = PerformanceProfile.values().map { it.name }.toTypedArray()
            android.app.AlertDialog.Builder(this)
                .setTitle("Perfil de desempenho")
                .setItems(names) { _, which ->
                    s.performanceProfile = names[which]
                    app.performance.refresh()
                    recreate()
                }
                .show()
        }
        Ui.note(perf, "Os perfis só ajustam quadros do Popol, cache de imagens e qualidade da captura. Nenhum mexe em segurança. AUTO considera a memória, a bateria e a temperatura quando o Android informa.")

        // ---------------------------------------------------------------- memória adaptativa
        val memory = Ui.section(column, "Memória adaptativa")
        Ui.note(memory, app.profile.summary())
        Ui.note(memory, "Guarda só o que você mostra com os botões de feedback e os apps que você pede para abrir. Cifrada no aparelho. Nunca senhas nem chaves.")
        Ui.button(memory, "Apagar memória adaptativa") {
            app.profile.clear()
            Toast.makeText(this, "Memória adaptativa apagada.", Toast.LENGTH_SHORT).show()
            recreate()
        }

        permissionsBox = Ui.section(column, "Permissões")

        // ---------------------------------------------------------------- tela
        val screen = Ui.section(column, "Tela")
        Ui.switchRow(screen, "Permitir análise de tela", "O KUPA só olha a tela quando você pedir e depois de você autorizar a captura no aviso do Android.", { s.screenAnalysisEnabled }, { s.screenAnalysisEnabled = it })
        captureStatus = Ui.text(this, "", 13f, Ui.MUTED)
        screen.addView(captureStatus)
        Ui.button(screen, "Iniciar captura (pede permissão ao Android)") {
            startActivity(Intent(this, ScreenPermissionActivity::class.java))
            captureStatus?.postDelayed({ renderCapture() }, 1500)
        }
        Ui.button(screen, "Parar captura") {
            if (KupaService.running) KupaService.stopCapture(this) else app.screen.stop()
            captureStatus?.postDelayed({ renderCapture() }, 500)
        }
        Ui.note(screen, "Alguns jogos e apps bloqueiam captura de tela. Nesses casos o KUPA avisa que não consegue ver a tela, mas perguntas por voz continuam funcionando.")

        // ---------------------------------------------------------------- IA
        val ai = Ui.section(column, "IA")
        Ui.note(ai, "Provedor: OpenAI, pela API oficial, através do backend do KUPA (a chave secreta fica só no backend).")
        val urlSource = BackendConfig.source(s)
        Ui.note(
            ai,
            when (urlSource) {
                BackendConfig.Source.USER_OVERRIDE -> "URL do backend: personalizada neste aparelho."
                BackendConfig.Source.BUILD -> "URL do backend: embutida no APK (android/kupa.properties)."
                BackendConfig.Source.NONE -> "URL do backend: NÃO CONFIGURADA. " + BackendConfig.NOT_CONFIGURED_MESSAGE
            },
            if (urlSource == BackendConfig.Source.NONE) Ui.WARN else Ui.MUTED,
        )
        val backendLine = Ui.text(this, "Backend: verificando…", 14f, Ui.MUTED)
        backendStatus = backendLine
        ai.addView(backendLine)
        Ui.switchRow(ai, "Permitir pesquisa na internet", "Usa a ferramenta oficial de busca na web quando a pergunta pede informação atual.", { s.webSearchAllowed }, { s.webSearchAllowed = it })
        Ui.button(ai, "Configuração e diagnóstico da IA", primary = true) { startActivity(Intent(this, DiagnosticsActivity::class.java)) }

        // ---------------------------------------------------------------- modo gamer
        val gamer = Ui.section(column, "Modo gamer")
        Ui.note(gamer, "Esconder o Popol não desliga o assistente: o núcleo, a IA, a voz e as ferramentas continuam funcionando. Diga \"Kupa, ativar modo gamer\" e \"Kupa, desativar modo gamer\".")
        val toggle = Ui.button(gamer, if (app.gamer.active) "Desativar modo gamer agora" else "Ativar modo gamer agora", primary = true) {
            if (app.gamer.active) app.gamer.disable() else core.submitText("ativar modo gamer")
            finish()
        }
        toggle.isAllCaps = false
        Ui.switchRow(gamer, "Ocultar personagem", "Popol e Kupa somem da tela durante o jogo.", { s.gamerHideCharacter }, { s.gamerHideCharacter = it })
        Ui.switchRow(gamer, "Manter voz", "Responde por voz mesmo com o personagem escondido.", { s.gamerKeepVoice }, { s.gamerKeepVoice = it })
        Ui.switchRow(gamer, "Manter pesquisa", null, { s.gamerKeepSearch }, { s.gamerKeepSearch = it })
        Ui.switchRow(gamer, "Permitir análise de tela", "Só funciona se a análise de tela e a captura estiverem autorizadas, e se o jogo não bloquear captura.", { s.gamerAllowScreen }, { s.gamerAllowScreen = it })
        Ui.switchRow(gamer, "Respostas rápidas (bem curtas)", null, { s.gamerQuickAnswers }, { s.gamerQuickAnswers = it })
        Ui.sliderRow(gamer, "Volume no modo gamer", 0, 100, { s.gamerVolumePercent }, { s.gamerVolumePercent = it }, { "$it%" })
        Ui.choiceRow(
            gamer, "Microfone no modo gamer",
            listOf(Pair("Sempre ouvindo", "continuous"), Pair("Só no botão Falar", "paused")),
            { s.gamerMicMode }, { s.gamerMicMode = it },
        )
        Ui.note(gamer, "\"Só no botão Falar\" poupa bateria e evita conflito com o microfone do jogo. O botão Falar fica na notificação do KUPA.")
        Ui.switchRow(gamer, "Restaurar posição ao sair", null, { s.gamerRestorePosition }, { s.gamerRestorePosition = it })
        Ui.switchRow(gamer, "Mostrar balão durante o jogo", "Desligado por padrão para não atrapalhar a tela.", { s.gamerShowBubble }, { s.gamerShowBubble = it })
        Ui.switchRow(gamer, "Resposta também em notificação silenciosa", null, { s.gamerNotify }, { s.gamerNotify = it })
        Ui.switchRow(gamer, "Lembrar contexto da sessão de jogo", "Ex.: \"estou jogando de Popol\". Fica só na memória do app.", { s.gamerSessionContext }, { s.gamerSessionContext = it })
        val ctx = Ui.text(this, "Contexto atual: " + app.gameContext.summaryForUser(), 13f, Ui.MUTED)
        gamer.addView(ctx)
        Ui.button(gamer, "Apagar contexto do jogo") {
            app.gameContext.clear()
            ctx.text = "Contexto atual: " + app.gameContext.summaryForUser()
        }

        // ---------------------------------------------------------------- histórico
        val history = Ui.section(column, "Histórico")
        Ui.button(history, "Abrir histórico") { startActivity(Intent(this, HistoryActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        renderCapture()
        Permissions.render(this, permissionsBox)
        checkBackend()
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Permissions.render(this, permissionsBox)
    }

    /**
     * Alterações que ENFRAQUECEM a segurança/privacidade exigem a confirmação do aparelho. Sem bloqueio de tela configurado
     * não há como verificar com segurança: a alteração é recusada (fail-closed).
     */
    private fun requireAuth(reason: String, onDenied: () -> Unit = {}, action: () -> Unit) {
        if (!NativeAuth.isAvailable(this)) {
            Toast.makeText(this, "Este aparelho não tem bloqueio de tela configurado. Não consigo verificar isso com segurança, então não alterei.", Toast.LENGTH_LONG).show()
            onDenied()
            return
        }
        NativeAuth.request(this, "Confirmar alteração de segurança", reason) { ok ->
            if (ok) {
                action()
            } else {
                Toast.makeText(this, "Não confirmado. Nada foi alterado.", Toast.LENGTH_SHORT).show()
                onDenied()
            }
        }
    }

    private fun zoneSet(text: String): Set<String> = text.lines().map { TextNorm.normalize(it) }.filter { it.isNotEmpty() }.toSet()

    private fun saveZones(newText: String) {
        val removed = zoneSet(app.settings.privacyZones) - zoneSet(newText)
        val apply = {
            app.settings.privacyZones = newText.lines().map { it.trim() }.filter { it.isNotEmpty() }.joinToString("\n")
            Toast.makeText(this, "Zonas de privacidade salvas.", Toast.LENGTH_SHORT).show()
        }
        if (removed.isNotEmpty()) requireAuth("Remover uma zona de privacidade") { apply() } else apply()
    }

    /** "Conectado" só aparece depois de uma verificação REAL do /health do backend. */
    private fun checkBackend() {
        val view = backendStatus ?: return
        if (BackendConfig.effectiveUrl(app.settings).isEmpty()) {
            view.text = "Backend: NÃO CONFIGURADO"
            view.setTextColor(Ui.WARN)
            return
        }
        view.text = "Backend: verificando…"
        view.setTextColor(Ui.MUTED)
        Thread {
            val health = app.core.client.health()
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (health.ok) {
                    view.text = "Backend: CONECTADO"
                    view.setTextColor(Ui.OK)
                } else {
                    view.text = "Backend: INDISPONÍVEL — " + health.message
                    view.setTextColor(Ui.BAD)
                }
            }
        }.start()
    }

    private fun renderCapture() {
        val status = captureStatus ?: return
        val active = app.screen.isActive
        status.text = if (active) "Captura de tela: ATIVA" else "Captura de tela: inativa"
        status.setTextColor(if (active) Ui.OK else Ui.MUTED)
    }

    private fun chooseVoice() {
        app.core.speech.ensureInit()
        val infos = app.core.speech.portugueseVoiceInfos()
        val voices = infos.map { it.name }
        if (voices.isEmpty()) {
            AlertDialog.Builder(this)
                .setMessage("Ainda não encontrei vozes em português. Espere um instante e tente de novo, ou instale uma voz em Configurações do Android > Texto para fala.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val items = (listOf("Padrão do aparelho") + infos.map { "${it.name} · qualidade ${it.quality} · ${if (it.needsNetwork) "precisa de internet" else "offline"} · ${it.latency}" }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Voz")
            .setItems(items) { _, which ->
                app.settings.ttsVoiceName = if (which == 0) "" else voices[which - 1]
            }
            .show()
    }
}
