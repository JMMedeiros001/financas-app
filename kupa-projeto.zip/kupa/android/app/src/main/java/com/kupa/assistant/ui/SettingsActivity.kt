package com.kupa.assistant.ui

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import com.kupa.assistant.KupaApp
import com.kupa.assistant.ai.BackendConfig
import android.widget.LinearLayout
import com.kupa.assistant.overlay.KupaService
import com.kupa.assistant.screen.ScreenPermissionActivity

/** Configurações: personagem, voz, ativação, tela, IA e Modo Gamer. */
class SettingsActivity : Activity() {
    private lateinit var app: KupaApp
    private var captureStatus: TextView? = null
    private var backendStatus: TextView? = null
    private lateinit var permissionsBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val s = app.settings
        val core = app.core
        val column = Ui.screen(this, "Configurações")

        // ---------------------------------------------------------------- personagem
        val character = Ui.section(column, "Personagem")
        Ui.note(character, "Popol é o personagem principal; Kupa é o lobo companheiro. Você também pode arrastar o Popol na tela e usar pinça para mudar o tamanho.")
        Ui.switchRow(character, "Mostrar Popol flutuante sobre outros apps", "Precisa da permissão de sobreposição de tela.", { s.overlayEnabled }, { s.overlayEnabled = it })
        Ui.sliderRow(character, "Tamanho", 80, 320, { s.sizeDp }, { s.sizeDp = it }, { "$it dp" })
        Ui.sliderRow(character, "Transparência (opacidade)", 20, 100, { s.alphaPercent }, { s.alphaPercent = it }, { "$it%" })
        Ui.switchRow(character, "Sempre no topo", "Desligado: o Popol só aparece quando o app KUPA está aberto.", { s.alwaysOnTop }, { s.alwaysOnTop = it })
        Ui.switchRow(character, "Posição automática", "Ao soltar, o Popol gruda na borda mais próxima da tela.", { s.autoPosition }, { s.autoPosition = it })
        Ui.switchRow(character, "Animações", "Desligue para economizar bateria.", { s.animationsEnabled }, { s.animationsEnabled = it })
        Ui.switchRow(character, "Mostrar respostas em balão perto do Popol", null, { s.showBubble }, { s.showBubble = it })
        val kupaLayer = app.sprites.hasSeparateKupaLayer()
        Ui.note(
            character,
            if (kupaLayer) "Camada separada do Kupa: ENCONTRADA. Popol e Kupa animam de forma independente."
            else "Camada separada do Kupa: não encontrada. Os visuais atuais trazem Popol e Kupa juntos, então os dois se movem como um conjunto. Para animar o Kupa sozinho, adicione os arquivos popol_XX_nome e kupa_XX_nome (veja o README).",
            if (kupaLayer) Ui.OK else Ui.WARN,
        )

        // ---------------------------------------------------------------- voz
        val voice = Ui.section(column, "Voz")
        Ui.switchRow(voice, "Voz ativada", "Liga juntos o microfone, o reconhecimento de fala e a resposta por voz. Desligada: só texto, e o resto continua funcionando.", { s.voiceEnabled }, { core.setVoiceEnabled(it) })
        Ui.sliderRow(voice, "Volume", 0, 100, { s.volumePercent }, { s.volumePercent = it }, { "$it%" })
        Ui.sliderRow(voice, "Tom da voz", 70, 160, { s.pitchPercent }, { s.pitchPercent = it }, { "$it%" })
        Ui.sliderRow(voice, "Velocidade", 70, 160, { s.ratePercent }, { s.ratePercent = it }, { "$it%" })
        Ui.button(voice, "Escolher voz do aparelho") { chooseVoice() }
        Ui.button(voice, "Testar voz") {
            core.speech.speak("Oi! Eu sou o KUPA. Vamos nessa?", s.volumePercent, flush = true, onError = { m -> Ui.note(voice, m, Ui.BAD) }, onDone = {})
        }
        Ui.note(voice, "A voz é a sintetizada do próprio Android (original, sem áudio de jogo). A energia jovem vem do tom e da velocidade acima.")

        // ---------------------------------------------------------------- modo de escuta
        val listen = Ui.section(column, "Modo de escuta")
        Ui.choiceRow(
            listen, "Como o KUPA ouve",
            listOf(Pair("Ativação por \"Kupa\"", "wake"), Pair("Escuta contínua", "continuous")),
            { s.listenMode }, { s.listenMode = it },
        )
        Ui.note(listen, "Ativação por \"Kupa\": fica esperando a palavra \"Kupa\" (ou \"cupa\"/\"culpa\" no começo da frase), ouve UM comando e volta a aguardar.")
        Ui.note(listen, "Escuta contínua: dá para falar vários comandos seguidos sem dizer \"Kupa\" ( \"abra o WhatsApp\", depois \"ligue para Dudu\"). Só comandos de celular reconhecidos viram ação; conversa solta é ignorada. Ligações sempre pedem confirmação se você não disse \"Kupa\".")
        Ui.switchRow(listen, "Microfone sempre ligado", "Desligado: o KUPA só ouve quando você toca em Falar (app ou notificação).", { s.wakeListening }, { s.wakeListening = it })
        Ui.switchRow(listen, "Frases soltas também vão para a IA (modo contínuo)", "Desligado por padrão: evita enviar conversas do ambiente à IA e gastar sua cota.", { s.continuousFreeText }, { s.continuousFreeText = it })
        Ui.sliderRow(listen, "Pausar sozinho após (modo contínuo)", 0, 60, { s.continuousIdleMinutes }, { s.continuousIdleMinutes = it }, { if (it == 0) "nunca" else "$it min" })
        Ui.switchRow(listen, "Pausar com a tela desligada", "Poupa bateria e privacidade. Desligue se quiser usar com o celular no bolso.", { s.pauseWhenScreenOff }, { s.pauseWhenScreenOff = it })
        Ui.switchRow(listen, "Preferir reconhecimento no aparelho", "Pede ao Android para reconhecer a voz sem internet quando o pacote de voz estiver instalado. Nenhum áudio vai para o backend do KUPA.", { s.preferOfflineRecognition }, { s.preferOfflineRecognition = it })
        Ui.switchRow(listen, "Aceitar variações (\"cupa\", \"culpa\")", "Só vale no começo da frase ou depois de \"oi\"/\"ei\", para \"a culpa é minha\" não ativar o KUPA.", { s.wakeAcceptVariants }, { s.wakeAcceptVariants = it })
        Ui.note(listen, "Limite do Android: a escuta contínua gasta bateria e pode brigar com o microfone de outros apps. Sensibilidade não é ajustável pelo reconhecedor do Android.")

        // ---------------------------------------------------------------- ações sensíveis
        val sensitive = Ui.section(column, "Ações sensíveis")
        Ui.choiceRow(
            sensitive, "Antes de ligar para alguém",
            listOf(Pair("Confirmar", "confirm"), Pair("Executar direto", "direct")),
            { if (s.confirmSensitive) "confirm" else "direct" }, { s.confirmSensitive = (it == "confirm") },
        )
        Ui.note(sensitive, "Confirmar: \"Encontrei Dudu. Quer que eu faça a ligação?\". Executar direto: liga sem perguntar (as proteções do Android continuam valendo). Abrir apps sempre é direto. Se o nome for só parecido, se houver mais de um contato ou se o pedido vier da IA, o KUPA sempre pergunta.")

        // ---------------------------------------------------------------- comandos aprendidos
        val learnedSection = Ui.section(column, "Comandos aprendidos")
        Ui.note(learnedSection, "Atalhos que você ensinou. Hoje: ${app.learned.all().size} comando(s).")
        Ui.button(learnedSection, "Ver e editar comandos aprendidos") { startActivity(Intent(this, LearnedCommandsActivity::class.java)) }

        // ---------------------------------------------------------------- permissões
        permissionsBox = Ui.section(column, "Permissões")

        // ---------------------------------------------------------------- tela
        val screen = Ui.section(column, "Tela")
        Ui.switchRow(screen, "Permitir análise de tela", "O KUPA só olha a tela quando você pedir e depois de você autorizar a captura no aviso do Android.", { s.screenAnalysisEnabled }, { s.screenAnalysisEnabled = it })
        captureStatus = Ui.text(this, "", 13f, Ui.MUTED)
        screen.addView(captureStatus)
        Ui.button(screen, "Iniciar captura (pede permissão ao Android)") {
            startActivity(Intent(this, ScreenPermissionActivity::class.java))
            captureStatus?.postDelayed({ renderCapture() }, 1500)
        }
        Ui.button(screen, "Parar captura") {
            if (KupaService.running) KupaService.stopCapture(this) else app.screen.stop()
            captureStatus?.postDelayed({ renderCapture() }, 500)
        }
        Ui.note(screen, "Alguns jogos e apps bloqueiam captura de tela. Nesses casos o KUPA avisa que não consegue ver a tela, mas perguntas por voz continuam funcionando.")

        // ---------------------------------------------------------------- IA
        val ai = Ui.section(column, "IA")
        Ui.note(ai, "Provedor: OpenAI, pela API oficial, através do backend do KUPA (a chave secreta fica só no backend).")
        val urlSource = BackendConfig.source(s)
        Ui.note(
            ai,
            when (urlSource) {
                BackendConfig.Source.USER_OVERRIDE -> "URL do backend: personalizada neste aparelho."
                BackendConfig.Source.BUILD -> "URL do backend: embutida no APK (android/kupa.properties)."
                BackendConfig.Source.NONE -> "URL do backend: NÃO CONFIGURADA. " + BackendConfig.NOT_CONFIGURED_MESSAGE
            },
            if (urlSource == BackendConfig.Source.NONE) Ui.WARN else Ui.MUTED,
        )
        val backendLine = Ui.text(this, "Backend: verificando…", 14f, Ui.MUTED)
        backendStatus = backendLine
        ai.addView(backendLine)
        Ui.switchRow(ai, "Permitir pesquisa na internet", "Usa a ferramenta oficial de busca na web quando a pergunta pede informação atual.", { s.webSearchAllowed }, { s.webSearchAllowed = it })
        Ui.button(ai, "Configuração e diagnóstico da IA", primary = true) { startActivity(Intent(this, DiagnosticsActivity::class.java)) }

        // ---------------------------------------------------------------- modo gamer
        val gamer = Ui.section(column, "Modo gamer")
        Ui.note(gamer, "Esconder o Popol não desliga o assistente: o núcleo, a IA, a voz e as ferramentas continuam funcionando. Diga \"Kupa, ativar modo gamer\" e \"Kupa, desativar modo gamer\".")
        val toggle = Ui.button(gamer, if (app.gamer.active) "Desativar modo gamer agora" else "Ativar modo gamer agora", primary = true) {
            if (app.gamer.active) app.gamer.disable() else core.submitText("ativar modo gamer")
            finish()
        }
        toggle.isAllCaps = false
        Ui.switchRow(gamer, "Ocultar personagem", "Popol e Kupa somem da tela durante o jogo.", { s.gamerHideCharacter }, { s.gamerHideCharacter = it })
        Ui.switchRow(gamer, "Manter voz", "Responde por voz mesmo com o personagem escondido.", { s.gamerKeepVoice }, { s.gamerKeepVoice = it })
        Ui.switchRow(gamer, "Manter pesquisa", null, { s.gamerKeepSearch }, { s.gamerKeepSearch = it })
        Ui.switchRow(gamer, "Permitir análise de tela", "Só funciona se a análise de tela e a captura estiverem autorizadas, e se o jogo não bloquear captura.", { s.gamerAllowScreen }, { s.gamerAllowScreen = it })
        Ui.switchRow(gamer, "Respostas rápidas (bem curtas)", null, { s.gamerQuickAnswers }, { s.gamerQuickAnswers = it })
        Ui.sliderRow(gamer, "Volume no modo gamer", 0, 100, { s.gamerVolumePercent }, { s.gamerVolumePercent = it }, { "$it%" })
        Ui.choiceRow(
            gamer, "Microfone no modo gamer",
            listOf(Pair("Sempre ouvindo", "continuous"), Pair("Só no botão Falar", "paused")),
            { s.gamerMicMode }, { s.gamerMicMode = it },
        )
        Ui.note(gamer, "\"Só no botão Falar\" poupa bateria e evita conflito com o microfone do jogo. O botão Falar fica na notificação do KUPA.")
        Ui.switchRow(gamer, "Restaurar posição ao sair", null, { s.gamerRestorePosition }, { s.gamerRestorePosition = it })
        Ui.switchRow(gamer, "Mostrar balão durante o jogo", "Desligado por padrão para não atrapalhar a tela.", { s.gamerShowBubble }, { s.gamerShowBubble = it })
        Ui.switchRow(gamer, "Resposta também em notificação silenciosa", null, { s.gamerNotify }, { s.gamerNotify = it })
        Ui.switchRow(gamer, "Lembrar contexto da sessão de jogo", "Ex.: \"estou jogando de Popol\". Fica só na memória do app.", { s.gamerSessionContext }, { s.gamerSessionContext = it })
        val ctx = Ui.text(this, "Contexto atual: " + app.gameContext.summaryForUser(), 13f, Ui.MUTED)
        gamer.addView(ctx)
        Ui.button(gamer, "Apagar contexto do jogo") {
            app.gameContext.clear()
            ctx.text = "Contexto atual: " + app.gameContext.summaryForUser()
        }

        // ---------------------------------------------------------------- histórico
        val history = Ui.section(column, "Histórico")
        Ui.button(history, "Abrir histórico") { startActivity(Intent(this, HistoryActivity::class.java)) }
    }

    override fun onResume() {
        super.onResume()
        renderCapture()
        Permissions.render(this, permissionsBox)
        checkBackend()
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Permissions.render(this, permissionsBox)
    }

    /** "Conectado" só aparece depois de uma verificação REAL do /health do backend. */
    private fun checkBackend() {
        val view = backendStatus ?: return
        if (BackendConfig.effectiveUrl(app.settings).isEmpty()) {
            view.text = "Backend: NÃO CONFIGURADO"
            view.setTextColor(Ui.WARN)
            return
        }
        view.text = "Backend: verificando…"
        view.setTextColor(Ui.MUTED)
        Thread {
            val health = app.core.client.health()
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (health.ok) {
                    view.text = "Backend: CONECTADO"
                    view.setTextColor(Ui.OK)
                } else {
                    view.text = "Backend: INDISPONÍVEL — " + health.message
                    view.setTextColor(Ui.BAD)
                }
            }
        }.start()
    }

    private fun renderCapture() {
        val status = captureStatus ?: return
        val active = app.screen.isActive
        status.text = if (active) "Captura de tela: ATIVA" else "Captura de tela: inativa"
        status.setTextColor(if (active) Ui.OK else Ui.MUTED)
    }

    private fun chooseVoice() {
        app.core.speech.ensureInit()
        val voices = app.core.speech.portugueseVoices()
        if (voices.isEmpty()) {
            AlertDialog.Builder(this)
                .setMessage("Ainda não encontrei vozes em português. Espere um instante e tente de novo, ou instale uma voz em Configurações do Android > Texto para fala.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val items = (listOf("Padrão do aparelho") + voices).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Voz")
            .setItems(items) { _, which ->
                app.settings.ttsVoiceName = if (which == 0) "" else voices[which - 1]
            }
            .show()
    }
}
