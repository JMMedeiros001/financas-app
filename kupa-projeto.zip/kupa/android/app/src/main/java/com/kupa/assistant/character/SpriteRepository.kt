package com.kupa.assistant.character

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.KupaState

/**
 * Carrega os visuais por NOME de recurso, então dá para trocar os arquivos sem mexer no código.
 *  - state_XX_nome        : imagem principal do estado (hoje: Popol + Kupa juntos)
 *  - popol_XX_nome        : (opcional) só o Popol, se você tiver as camadas separadas
 *  - kupa_XX_nome         : (opcional) só o Kupa, para ele animar de forma independente
 * Se existirem popol_* e kupa_*, o app usa as camadas separadas automaticamente.
 */
class SpriteRepository(private val context: Context) {
    class StateSprites(val popol: Bitmap, val kupa: Bitmap?)

    private val cache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing = HashSet<String>()

    private fun load(resourceName: String): Bitmap? {
        cache.get(resourceName)?.let { return it }
        if (resourceName in missing) return null
        val id = context.resources.getIdentifier(resourceName, "drawable", context.packageName)
        if (id == 0) {
            missing.add(resourceName)
            return null
        }
        val bmp = try {
            BitmapFactory.decodeResource(context.resources, id)
        } catch (e: OutOfMemoryError) {
            KupaLog.e("sprites", "sem memória ao carregar $resourceName")
            null
        }
        if (bmp == null) {
            missing.add(resourceName)
            return null
        }
        cache.put(resourceName, bmp)
        return bmp
    }

    /** Devolve os visuais do estado, ou null se NADA puder ser carregado (erro de carregamento do Popol). */
    fun forState(state: KupaState): StateSprites? {
        val separatePopol = load("popol_${state.suffix}")
        val separateKupa = load("kupa_${state.suffix}")
        if (separatePopol != null && separateKupa != null) return StateSprites(separatePopol, separateKupa)
        val combined = load(state.spriteName) ?: load(KupaState.IDLE.spriteName) ?: return null
        return StateSprites(combined, null)
    }

    /** Para saber, na tela de configurações, o que está disponível. */
    fun hasSeparateKupaLayer(): Boolean = load("kupa_${KupaState.IDLE.suffix}") != null
}
