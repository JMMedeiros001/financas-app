package com.kupa.assistant.intent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Acha, entre os contatos do aparelho, o que o usuário quis dizer. Nunca inventa: sem boa correspondência, devolve nada. */
public final class ContactMatcher {
    private ContactMatcher() {}

    public static final class ContactEntry {
        public final long id;
        public final String displayName;
        final String norm;
        final List<String> tokens;

        public ContactEntry(long id, String displayName) {
            this.id = id;
            this.displayName = displayName;
            this.norm = TextNorm.normalize(displayName);
            this.tokens = TextNorm.tokens(this.norm);
        }
    }

    public static final class Scored {
        public final long id;
        public final String displayName;
        public final int score;

        Scored(long id, String displayName, int score) {
            this.id = id;
            this.displayName = displayName;
            this.score = score;
        }

        @Override public String toString() { return displayName + "(" + score + ")"; }
    }

    public static final class Result {
        /** Candidatos em ordem (melhor primeiro). */
        public final List<Scored> ranked;
        /** O contato escolhido com segurança, ou null. */
        public final Scored chosen;
        /** true quando há mais de um contato igualmente provável. */
        public final boolean ambiguous;
        /** true quando o escolhido é só parecido ("Maria" -> "Mariana"): sempre confirmar antes de ligar. */
        public final boolean weak;

        Result(List<Scored> ranked, Scored chosen, boolean ambiguous) {
            this.ranked = ranked;
            this.chosen = chosen;
            this.ambiguous = ambiguous;
            this.weak = chosen != null && chosen.score < 80;
        }
    }

    private static final Set<String> NOISE = new HashSet<>(Arrays.asList("o", "a", "meu", "minha", "seu", "sua", "do", "da"));
    private static final int MIN_SCORE = 50;
    private static final int MARGIN = 10;

    public static Result resolve(String query, List<ContactEntry> all) {
        List<String> q = new ArrayList<>(TextNorm.tokens(TextNorm.normalize(query)));
        while (q.size() > 1 && NOISE.contains(q.get(0))) q.remove(0);
        if (q.isEmpty()) return new Result(Collections.<Scored>emptyList(), null, false);
        String qn = TextNorm.join(q, 0, q.size());

        Map<Long, Scored> best = new LinkedHashMap<>();
        for (ContactEntry c : all) {
            int s = score(q, qn, c);
            if (s < MIN_SCORE) continue;
            Scored prev = best.get(c.id);
            if (prev == null || s > prev.score) best.put(c.id, new Scored(c.id, c.displayName, s));
        }
        List<Scored> ranked = new ArrayList<>(best.values());
        Collections.sort(ranked, new Comparator<Scored>() {
            @Override public int compare(Scored a, Scored b) {
                if (a.score != b.score) return b.score - a.score;
                return a.displayName.compareToIgnoreCase(b.displayName);
            }
        });
        if (ranked.isEmpty()) return new Result(ranked, null, false);
        if (ranked.size() == 1) return new Result(ranked, ranked.get(0), false);
        if (ranked.get(0).score - ranked.get(1).score >= MARGIN) return new Result(ranked, ranked.get(0), false);
        List<Scored> close = new ArrayList<>();
        for (Scored s : ranked) if (ranked.get(0).score - s.score < MARGIN && close.size() < 5) close.add(s);
        return new Result(close, null, true);
    }

    static int score(List<String> q, String qn, ContactEntry c) {
        if (c.norm.equals(qn)) return 100;
        List<String> nt = c.tokens;
        if (nt.isEmpty()) return 0;
        // todas as palavras do que foi dito aparecem (como palavra inteira) no nome
        boolean allWhole = true;
        boolean allPrefix = true;
        for (String w : q) {
            boolean whole = nt.contains(w);
            boolean prefix = whole;
            if (!whole) for (String t : nt) if (t.startsWith(w) && w.length() >= 2) prefix = true;
            allWhole &= whole;
            allPrefix &= prefix;
        }
        if (allWhole) return q.size() == 1 && nt.get(0).equals(q.get(0)) ? 90 : 85;
        if (c.norm.startsWith(qn + " ")) return 80;
        if (allPrefix) return 70;
        if (c.norm.contains(qn) && qn.length() >= 3) return 55;
        // erro de reconhecimento de 1 letra em palavras longas ("dudo" -> "dudu")
        if (q.size() == 1) for (String t : nt) if (Fuzzy.withinOne(q.get(0), t, 4)) return 55;
        return 0;
    }
}
