package com.kupa.assistant.core

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArrayList

/** Guarda o estado atual e avisa quem estiver ouvindo (sempre na thread principal). */
class StateManager {
    fun interface Listener {
        fun onStateChanged(previous: KupaState, current: KupaState)
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile
    var current: KupaState = KupaState.IDLE
        private set

    @Volatile
    var changedAtMs: Long = SystemClock.uptimeMillis()
        private set

    fun addListener(listener: Listener) {
        listeners.add(listener)
    }

    fun removeListener(listener: Listener) {
        listeners.remove(listener)
    }

    fun set(next: KupaState) {
        if (Looper.myLooper() == Looper.getMainLooper()) apply(next) else main.post { apply(next) }
    }

    private fun apply(next: KupaState) {
        val previous = current
        if (previous == next) return
        current = next
        changedAtMs = SystemClock.uptimeMillis()
        KupaLog.i("estado", "${previous.id} ${previous.label} -> ${next.id} ${next.label}")
        for (listener in listeners) listener.onStateChanged(previous, next)
    }
}
