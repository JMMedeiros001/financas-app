package com.kupa.assistant.intent;

import java.util.Collections;
import java.util.List;

/** Resultado de interpretar uma frase: uma ou mais intenções, ou nada (aí a frase vai para a IA). */
public final class Interpretation {
    public final List<KupaIntent> intents;
    public final String normalized;

    public Interpretation(List<KupaIntent> intents, String normalized) {
        this.intents = Collections.unmodifiableList(intents);
        this.normalized = normalized;
    }

    public boolean isEmpty() { return intents.isEmpty(); }

    @Override public String toString() { return intents.toString(); }
}
