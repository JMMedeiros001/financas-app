package com.kupa.assistant.intent;

import java.util.List;

/**
 * Transforma "quando eu disser X, quero dizer Y" num atalho seguro.
 * Só aceita o que o interpretador entende; comandos padrão importantes (atender, recusar, sim/não, aprender...) são protegidos.
 */
public final class LearningPlanner {
    private LearningPlanner() {}

    public static final class Plan {
        public final boolean ok;
        public final LearnedCommand.Kind kind;
        public final String trigger;
        public final String expansion;
        /** Frase para o KUPA falar ao pedir confirmação. */
        public final String description;
        public final String error;

        private Plan(boolean ok, LearnedCommand.Kind kind, String trigger, String expansion, String description, String error) {
            this.ok = ok;
            this.kind = kind;
            this.trigger = trigger;
            this.expansion = expansion;
            this.description = description;
            this.error = error;
        }

        static Plan ok(LearnedCommand.Kind kind, String trigger, String expansion, String description) {
            return new Plan(true, kind, trigger, expansion, description, null);
        }

        static Plan error(String message) {
            return new Plan(false, null, null, null, null, message);
        }
    }

    public static Plan plan(String triggerRaw, String meaningRaw, CommandInterpreter interpreter) {
        String trigger = TextNorm.stripWake(TextNorm.normalize(triggerRaw));
        String meaning = TextNorm.normalize(meaningRaw);
        if (trigger.isEmpty() || meaning.isEmpty()) return Plan.error("Não entendi a frase ou o significado.");
        if (TextNorm.tokens(trigger).size() > 8 || TextNorm.tokens(meaning).size() > 10) {
            return Plan.error("Essa frase ficou comprida demais para virar um atalho.");
        }
        if (trigger.equals(meaning)) return Plan.error("A frase e o significado são iguais.");

        Interpretation it = interpreter.interpret(trigger);
        if (!it.isEmpty() && it.intents.get(0).isProtected()) {
            return Plan.error("\"" + trigger + "\" é um comando padrão importante e eu não deixo redefinir.");
        }

        Interpretation im = interpreter.interpret(meaning);
        if (!im.isEmpty()) {
            for (KupaIntent k : im.intents) {
                if (k.isProtected()) return Plan.error("Esse significado é um comando de controle e não pode virar atalho.");
            }
            String expansion = Render.canonical(im.intents);
            if (expansion == null) return Plan.error("Não consegui entender esse significado como comando.");
            return Plan.ok(LearnedCommand.Kind.PHRASE, trigger, expansion, "quando você disser \"" + trigger + "\", vou " + Render.describe(im.intents));
        }

        // significado é só um nome: troca o nome dentro do comando do gatilho ("abre o jogo" + "mobile legends")
        List<KupaIntent> list = it.intents;
        if (list.size() == 1 && (list.get(0).kind == KupaIntent.Kind.OPEN_APP || list.get(0).kind == KupaIntent.Kind.CALL_CONTACT)) {
            String entity = stripArticles(meaning);
            if (entity.isEmpty() || TextNorm.tokens(entity).size() > 5) return Plan.error("Não entendi esse nome.");
            KupaIntent base = list.get(0);
            KupaIntent replaced = base.kind == KupaIntent.Kind.OPEN_APP ? KupaIntent.openApp(entity) : KupaIntent.callContact(entity, false);
            return Plan.ok(LearnedCommand.Kind.PHRASE, trigger, Render.canonical(replaced),
                "quando você disser \"" + trigger + "\", vou " + Render.describe(replaced));
        }

        // nem frase de comando nem comando: vira apelido de nome ("zap" -> "whatsapp")
        if (it.isEmpty() && TextNorm.tokens(trigger).size() <= 3 && TextNorm.tokens(meaning).size() <= 5) {
            String entity = stripArticles(meaning);
            return Plan.ok(LearnedCommand.Kind.ENTITY, trigger, entity,
                "quando você disser \"" + trigger + "\" num comando, vou entender \"" + entity + "\"");
        }
        return Plan.error("Não entendi como transformar isso em comando.");
    }

    private static String stripArticles(String s) {
        List<String> t = TextNorm.tokens(s);
        int i = 0;
        while (i < t.size() - 1 && (t.get(i).equals("o") || t.get(i).equals("a") || t.get(i).equals("os") || t.get(i).equals("as") || t.get(i).equals("do") || t.get(i).equals("da"))) i++;
        return TextNorm.join(t, i, t.size());
    }

    /** Se o texto falado é exatamente um gatilho PHRASE ensinado, devolve o comando que ele significa; senão null. */
    public static String expandPhrase(String spoken, List<LearnedCommand> learned) {
        String n = TextNorm.stripWake(TextNorm.normalize(spoken));
        if (n.isEmpty()) return null;
        for (LearnedCommand c : learned) if (c.kind == LearnedCommand.Kind.PHRASE && c.trigger.equals(n)) return c.expansion;
        return null;
    }

    /** Troca um nome por um apelido ensinado (ENTITY), se houver. */
    public static String aliasEntity(String name, List<LearnedCommand> learned) {
        String n = TextNorm.normalize(name);
        for (LearnedCommand c : learned) if (c.kind == LearnedCommand.Kind.ENTITY && c.trigger.equals(n)) return c.expansion;
        return name;
    }
}
