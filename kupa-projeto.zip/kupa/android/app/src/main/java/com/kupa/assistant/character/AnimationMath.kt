package com.kupa.assistant.character

import com.kupa.assistant.core.KupaState
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Transformação de uma camada em um instante. Deslocamentos em fração do tamanho da camada. */
data class LayerTransform(
    val dxFrac: Float = 0f,
    val dyFrac: Float = 0f,
    val rotationDeg: Float = 0f,
    val scaleX: Float = 1f,
    val scaleY: Float = 1f,
) {
    companion object {
        val NONE = LayerTransform()
    }
}

/** Qual animação o Popol e o Kupa fazem em cada estado (tabela do StateManager -> controladores). */
data class StateAnimation(val popol: String, val kupa: String)

object StateAnimations {
    fun forState(state: KupaState): StateAnimation = when (state) {
        KupaState.IDLE -> StateAnimation("idle", "idle_random")
        KupaState.ACTIVATED -> StateAnimation("alert", "alert")
        KupaState.LISTENING -> StateAnimation("attentive", "alert")
        KupaState.THINKING -> StateAnimation("think", "tilt_observe")
        KupaState.SEARCHING -> StateAnimation("search", "observe")
        KupaState.SCREEN_ANALYSIS -> StateAnimation("analyze", "observe")
        KupaState.SPEAKING -> StateAnimation("talk", "talk_react")
        KupaState.ERROR -> StateAnimation("error", "worried")
        KupaState.EXECUTING -> StateAnimation("work", "observe")
        KupaState.SURPRISED -> StateAnimation("surprised", "surprised")
        KupaState.HAPPY -> StateAnimation("happy", "happy_wag")
        KupaState.CONFUSED -> StateAnimation("confused", "tilt")
        KupaState.TRANSLATING -> StateAnimation("translate", "observe")
        KupaState.READING -> StateAnimation("read", "calm")
        KupaState.COMPLETED -> StateAnimation("done", "done")
    }
}

/** Animações programáticas (leves, só transformações). Funções puras: mesmo tempo, mesmo resultado. */
object AnimationMath {
    private const val TAU = (2.0 * PI).toFloat()

    private fun wave(t: Float, periodSec: Float): Float = sin(TAU * t / periodSec)

    private fun damped(t: Float, decay: Float, freq: Float): Float = exp(-decay * t) * cos(TAU * freq * t)

    /**
     * @param name nome da animação (ver StateAnimations)
     * @param t segundos desde que a animação começou
     */
    fun transformFor(name: String, t: Float): LayerTransform = when (name) {
        "idle", "idle_random" -> {
            val breath = wave(t, 3.4f)
            LayerTransform(dyFrac = -0.002f * breath, scaleY = 1f + 0.012f * breath, scaleX = 1f - 0.004f * breath)
        }
        "alert" -> {
            val pop = 0.07f * exp(-6f * t) * cos(TAU * 2.4f * t)
            val breath = wave(t, 1.6f)
            LayerTransform(dyFrac = -0.004f * breath, scaleX = 1f + pop, scaleY = 1f + pop + 0.006f * breath)
        }
        "attentive" -> {
            val breath = wave(t, 1.9f)
            LayerTransform(dxFrac = 0.004f, dyFrac = 0.004f - 0.004f * breath, rotationDeg = 1.6f + 0.5f * breath, scaleY = 1f + 0.008f * breath)
        }
        "think", "tilt_observe" -> LayerTransform(dxFrac = 0.006f * wave(t, 2.6f), rotationDeg = 2.2f * wave(t, 2.6f), scaleY = 1f + 0.006f * wave(t, 1.7f))
        "search", "observe" -> LayerTransform(dxFrac = 0.022f * wave(t, 1.5f), rotationDeg = 1.6f * wave(t, 1.5f), scaleY = 1f + 0.006f * wave(t, 1.1f))
        "analyze" -> {
            val s = 1f + 0.02f * wave(t, 1.9f)
            LayerTransform(dyFrac = -0.004f * wave(t, 1.9f), scaleX = s, scaleY = s)
        }
        "talk", "talk_react" -> {
            val bob = 0.5f + 0.5f * wave(t, 0.34f)
            LayerTransform(dyFrac = -0.014f * bob, rotationDeg = 1.1f * wave(t, 0.9f), scaleY = 1f + 0.012f * bob, scaleX = 1f - 0.005f * bob)
        }
        "error", "worried" -> {
            val shake = 0.032f * exp(-1.4f * t) * sin(TAU * 7f * t)
            LayerTransform(dxFrac = shake, dyFrac = 0.012f * min(1f, t * 3f), rotationDeg = -1.5f * min(1f, t * 2f), scaleY = 0.985f)
        }
        "work" -> LayerTransform(dyFrac = -0.007f * abs(wave(t, 0.8f)), rotationDeg = 0.8f * wave(t, 1.6f))
        "surprised" -> {
            val jump = -0.07f * max(0f, sin((PI * min(t / 0.38f, 1f)).toFloat()))
            val hold = 1f + 0.03f * min(1f, t * 4f)
            LayerTransform(dyFrac = jump, scaleX = hold, scaleY = hold)
        }
        "happy", "happy_wag" -> {
            val hop = abs(wave(t, 1.2f))
            LayerTransform(dyFrac = -0.05f * hop, rotationDeg = 2.4f * wave(t, 1.2f), scaleY = 1f + 0.015f * hop)
        }
        "confused", "tilt" -> {
            val ease = 1f - exp(-5f * t)
            LayerTransform(rotationDeg = 4.2f * ease + 0.8f * wave(t, 2.2f), dxFrac = 0.006f * ease)
        }
        "translate" -> LayerTransform(dxFrac = 0.01f * wave(t, 1.8f), rotationDeg = 2f * wave(t, 1.8f))
        "read", "calm" -> {
            val b = wave(t, 4f)
            LayerTransform(dyFrac = 0.003f - 0.002f * b, scaleY = 1f + 0.008f * b)
        }
        "done" -> {
            val hop = -0.045f * max(0f, sin((PI * min(t / 0.42f, 1f)).toFloat()))
            LayerTransform(dyFrac = hop, scaleY = 1f + 0.01f * max(0f, sin((PI * min(t / 0.42f, 1f)).toFloat())))
        }
        else -> LayerTransform.NONE
    }

    /** Micro-movimento ocasional do estado de espera (evita parecer estático). Vem do controlador, com horário aleatório. */
    fun fidget(kind: Int, t: Float, durationSec: Float): LayerTransform {
        if (t < 0f || t > durationSec) return LayerTransform.NONE
        val envelope = sin((PI * t / durationSec).toFloat())
        return when (kind % 3) {
            0 -> LayerTransform(rotationDeg = 2.2f * envelope)
            1 -> LayerTransform(rotationDeg = -2f * envelope, dxFrac = -0.006f * envelope)
            else -> LayerTransform(dyFrac = -0.012f * envelope, scaleY = 1f + 0.01f * envelope)
        }
    }
}
