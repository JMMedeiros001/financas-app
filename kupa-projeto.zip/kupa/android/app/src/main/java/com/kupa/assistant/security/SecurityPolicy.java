package com.kupa.assistant.security;

/**
 * Política central. Quem chama NÃO pode escolher o veredito: só informa os fatos.
 * Fail-closed: se não dá para verificar com segurança, bloqueia.
 */
public final class SecurityPolicy {
    private SecurityPolicy() {}

    /**
     * @param base             risco da ação em si
     * @param origin           de onde veio o pedido
     * @param state            estado de segurança atual
     * @param confirmSetting   configuração "confirmar ações sensíveis"
     * @param weakMatch        o alvo (contato/app) é só parecido com o que foi dito
     * @param authAvailable    o aparelho tem bloqueio de tela para autenticação nativa
     */
    public static Verdict decide(RiskLevel base, Origin origin, SecurityState state, boolean confirmSetting, boolean weakMatch, boolean authAvailable) {
        if (base == RiskLevel.NONE) return new Verdict(Verdict.Kind.ALLOW, base, "Somente informativo.");
        if (state.blocksActions()) {
            return new Verdict(Verdict.Kind.BLOCK, base, "O KUPA está em modo seguro e não executa ações. Reative com a confirmação do aparelho.");
        }
        RiskLevel risk = base;
        if (state == SecurityState.WARNING) risk = risk.raised();
        if (state == SecurityState.SUSPICIOUS) {
            if (risk.atLeast(RiskLevel.MEDIUM)) {
                return new Verdict(Verdict.Kind.BLOCK, risk, "Detectei sinais suspeitos e bloqueei ações sensíveis por precaução.");
            }
            risk = risk.raised();
        }
        switch (risk) {
            case NONE:
            case LOW:
                return new Verdict(Verdict.Kind.ALLOW, risk, "Ação de baixo risco.");
            case MEDIUM:
                if (confirmSetting || weakMatch || origin == Origin.AI_TOOL || state == SecurityState.WARNING) {
                    return new Verdict(Verdict.Kind.CONFIRM, risk, origin == Origin.AI_TOOL ? "Pedido vindo da IA: só você pode confirmar." : "Ação sensível.");
                }
                return new Verdict(Verdict.Kind.ALLOW, risk, "Execução direta permitida pelas suas configurações.");
            case HIGH:
                return new Verdict(Verdict.Kind.CONFIRM_TWICE, risk, "Ação de risco alto: preciso de duas confirmações.");
            default:
                if (!authAvailable) {
                    return new Verdict(Verdict.Kind.BLOCK, risk, "Não consigo verificar isso com segurança: o aparelho não tem bloqueio de tela para a autenticação.");
                }
                return new Verdict(Verdict.Kind.NATIVE_AUTH, risk, "Ação crítica: duas confirmações e autenticação do aparelho.");
        }
    }

    /** Alterar uma configuração que ENFRAQUECE a segurança exige autenticação nativa (voz nunca basta). */
    public static boolean weakeningSettingNeedsAuth() {
        return true;
    }
}
