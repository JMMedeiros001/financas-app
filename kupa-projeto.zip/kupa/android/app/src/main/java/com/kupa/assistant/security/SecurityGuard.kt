package com.kupa.assistant.security

import android.content.Context
import android.content.pm.ApplicationInfo
import android.os.Build
import android.os.Debug
import android.os.SystemClock
import com.kupa.assistant.BuildConfig
import com.kupa.assistant.core.KupaLog
import java.io.File

/**
 * SECURITY CORE no Android: dono do estado de segurança e da política. Nada abaixo dele (IA, modos, automação,
 * voz, ferramentas) consegue desativá-lo: todos só podem PERGUNTAR (decide) ou INFORMAR (report).
 * Fail-closed: sem como verificar com segurança, não executa.
 */
class SecurityGuard(private val context: Context) {
    private val engine = SecurityCore()

    /** Quem reage aos sinais (o KUPA CORE: alerta o usuário, para tudo se for SAFE_SHUTDOWN). */
    @Volatile
    var reactor: ((SecurityCore.Reaction) -> Unit)? = null

    private fun now(): Long = SystemClock.elapsedRealtime()

    fun state(): SecurityState = engine.state(now())

    fun events(): List<SecurityCore.Event> = engine.events()

    fun report(signal: SecurityCore.Signal): SecurityCore.Reaction {
        val reaction = engine.report(signal, now())
        // log mínimo: só o código do sinal e o estado, nunca conteúdo
        KupaLog.w("seguranca", "sinal=${signal.name} estado=${reaction.state.name}")
        if (reaction.alertUser || reaction.safeShutdown) reactor?.invoke(reaction)
        return reaction
    }

    /** Pergunta à política o que fazer. Quem chama não escolhe o veredito. */
    fun decide(base: RiskLevel, origin: Origin, confirmSetting: Boolean, weakMatch: Boolean): Verdict =
        SecurityPolicy.decide(base, origin, state(), confirmSetting, weakMatch, NativeAuth.isAvailable(context))

    /** Reativa depois de SAFE_SHUTDOWN/COMPROMISED SÓ com a autenticação do aparelho. */
    fun rearm(onResult: (Boolean) -> Unit) {
        if (!state().blocksActions()) {
            onResult(true)
            return
        }
        NativeAuth.request(context, "Reativar o KUPA", "Confirme que é você para tirar o KUPA do modo seguro.") { ok ->
            val done = ok && engine.rearm(true, now())
            if (done) KupaLog.i("seguranca", "KUPA reativado pelo usuário com autenticação")
            onResult(done)
        }
    }

    /**
     * Sinais FRACOS de integridade (não provam nada): depurador ligado, chave de teste, binário su, app depurável no release.
     * Só geram WARNING. Play Integrity não é usado (exigiria os Serviços do Google Play e configuração externa).
     */
    fun checkIntegritySignals(): List<String> {
        val found = ArrayList<String>()
        if (!BuildConfig.DEBUG && Debug.isDebuggerConnected()) found.add("depurador conectado")
        if (!BuildConfig.DEBUG && (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0) found.add("app marcado como depurável fora do build de teste")
        if (Build.TAGS?.contains("test-keys") == true) found.add("sistema assinado com chaves de teste")
        if (listOf("/system/bin/su", "/system/xbin/su", "/sbin/su").any { File(it).exists() }) found.add("binário su presente (aparelho possivelmente com root)")
        if (found.isNotEmpty() && !BuildConfig.DEBUG) report(SecurityCore.Signal.INTEGRITY_WEAK_SIGNAL)
        return found
    }
}
