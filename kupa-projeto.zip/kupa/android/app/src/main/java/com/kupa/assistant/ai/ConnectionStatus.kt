package com.kupa.assistant.ai

import com.kupa.assistant.settings.Settings
import com.kupa.assistant.visual.Palette

/**
 * Estado REAL da conexão com a IA, mostrado no cabeçalho. Só vira "IA verificada" depois de uma chamada de verdade que deu certo
 * (teste de provedor no Diagnóstico ou uma resposta real da IA). Internet disponível ou o servidor responder NÃO bastam.
 */
class ConnectionStatus(private val settings: Settings, private val client: () -> KupaBackendClient) {
    enum class Kind { UNKNOWN, NOT_CONFIGURED, CHECKING, BACKEND_DOWN, AUTH_FAILED, NO_PROVIDER, BACKEND_OK, AI_VERIFIED }

    class Label(val text: String, val color: Int)

    @Volatile
    var kind: Kind = Kind.UNKNOWN
        private set

    @Volatile
    var detail: String = ""
        private set

    @Volatile
    private var atMs = 0L

    @Volatile
    private var verifiedAtMs = 0L

    fun label(nowMs: Long = System.currentTimeMillis()): Label = when (kind) {
        Kind.NOT_CONFIGURED -> Label("IA: sem backend", Palette.AMBER)
        Kind.UNKNOWN -> Label("IA: não verificada", Palette.MUTED)
        Kind.CHECKING -> Label("IA: verificando…", Palette.MUTED)
        Kind.BACKEND_DOWN -> Label("IA: backend indisponível", Palette.ERROR_RED)
        Kind.AUTH_FAILED -> Label("IA: token recusado", Palette.ERROR_RED)
        Kind.NO_PROVIDER -> Label("IA: backend ok, sem provedor", Palette.AMBER)
        Kind.BACKEND_OK -> Label("IA: backend ok · não testada", Palette.CYAN)
        Kind.AI_VERIFIED -> {
            val minutes = ((nowMs - verifiedAtMs) / 60_000L).toInt()
            val ago = if (minutes <= 0) "agora" else "há $minutes min"
            Label("IA: verificada $ago", if (minutes <= 30) Palette.OK_GREEN else Palette.MUTED)
        }
    }

    /** Verifica o backend (health + configuração) numa thread, sem gastar IA. [onDone] roda na thread de trabalho. */
    fun refreshAsync(force: Boolean, onDone: () -> Unit = {}) {
        val check = BackendConfig.check(settings)
        if (!check.ok()) {
            kind = if (check.problem == BackendUrlValidator.Problem.EMPTY) Kind.NOT_CONFIGURED else Kind.NOT_CONFIGURED
            detail = check.message
            atMs = System.currentTimeMillis()
            onDone()
            return
        }
        val now = System.currentTimeMillis()
        if (kind == Kind.CHECKING) return
        if (!force && now - atMs < 60_000L && kind != Kind.UNKNOWN && kind != Kind.NOT_CONFIGURED) return
        val previous = kind
        kind = Kind.CHECKING
        Thread {
            val health = client().health()
            if (!health.ok) {
                kind = Kind.BACKEND_DOWN
                detail = health.message
            } else {
                val config = client().config()
                if (!config.ok) {
                    val authProblem = config.message.contains("token", ignoreCase = true)
                    kind = if (authProblem) Kind.AUTH_FAILED else Kind.BACKEND_DOWN
                    detail = config.message
                } else if (config.providers.none { it.configured }) {
                    kind = Kind.NO_PROVIDER
                    detail = "Nenhum provedor com chave e modelo no backend."
                } else {
                    // uma verificação real recente continua valendo; senão, o backend está ok mas a IA ainda não foi testada
                    val recentlyVerified = previous == Kind.AI_VERIFIED && System.currentTimeMillis() - verifiedAtMs < 30 * 60_000L
                    kind = if (recentlyVerified) Kind.AI_VERIFIED else Kind.BACKEND_OK
                    detail = ""
                }
            }
            atMs = System.currentTimeMillis()
            onDone()
        }.start()
    }

    /** Uma chamada real à IA deu certo (teste de provedor ou resposta de verdade). */
    fun markAiVerified(model: String?) {
        kind = Kind.AI_VERIFIED
        detail = model ?: ""
        atMs = System.currentTimeMillis()
        verifiedAtMs = atMs
    }

    /** Uma chamada real falhou: reflete a camada responsável. */
    fun markFailure(error: AiError) {
        when (error.kind) {
            AiErrorKind.BACKEND_NOT_CONFIGURED -> kind = Kind.NOT_CONFIGURED
            AiErrorKind.BACKEND_UNREACHABLE -> kind = Kind.BACKEND_DOWN
            AiErrorKind.BACKEND_AUTH -> kind = Kind.AUTH_FAILED
            AiErrorKind.BACKEND_CONFIG -> kind = Kind.NO_PROVIDER
            AiErrorKind.PROVIDER -> kind = Kind.BACKEND_OK
            else -> return
        }
        detail = error.message
        atMs = System.currentTimeMillis()
    }
}
