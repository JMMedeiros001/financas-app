package com.kupa.assistant.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings as AndroidSettings
import android.widget.LinearLayout
import android.widget.Toast
import com.kupa.assistant.overlay.OverlayController

/**
 * Lista única de permissões do KUPA, com o motivo de cada uma (só pedimos o que a função precisa)
 * e o botão para conceder. Usada na tela inicial e em Configurações.
 */
object Permissions {
    class Item(val title: String, val why: String, val optional: Boolean, val granted: (Context) -> Boolean, val request: (Activity) -> Unit)

    private const val BASE_CODE = 300

    private fun runtime(index: Int, title: String, why: String, permission: String, optional: Boolean = false): Item =
        Item(title, why, optional, { c -> c.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED }, { a ->
            a.requestPermissions(arrayOf(permission), BASE_CODE + index)
        })

    fun items(): List<Item> = listOf(
        runtime(0, "Microfone", "Para ouvir você (\"Kupa\" e seus comandos). Sem ele o texto continua funcionando.", Manifest.permission.RECORD_AUDIO),
        Item("Notificações", "O Android exige o aviso fixo enquanto o KUPA fica ativo em segundo plano.", false,
            { c -> Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED },
            { a -> if (Build.VERSION.SDK_INT >= 33) a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), BASE_CODE + 1) }),
        Item("Aparecer sobre outros apps", "Para o Popol flutuante e para o Android deixar o KUPA abrir aplicativos com a tela fora dele.", true,
            { c -> AndroidSettings.canDrawOverlays(c) }, { a -> OverlayController.openOverlaySettings(a) }),
        runtime(3, "Contatos", "Para achar o número de quem você pede para ligar. Os contatos não saem do aparelho.", Manifest.permission.READ_CONTACTS),
        runtime(4, "Ligações", "Para ligar para um contato quando você pedir.", Manifest.permission.CALL_PHONE),
        runtime(5, "Atender e recusar chamadas", "Para atender ou recusar a ligação que está tocando quando você mandar.", Manifest.permission.ANSWER_PHONE_CALLS),
        runtime(6, "Estado do telefone", "Para saber quando uma ligação está tocando ou em andamento.", Manifest.permission.READ_PHONE_STATE),
        runtime(7, "Registro de chamadas", "Só para ver o número de quem está ligando (\"quem está me ligando?\"). Opcional.", Manifest.permission.READ_CALL_LOG, optional = true),
    )

    /** Quantas permissões obrigatórias (não opcionais) ainda faltam. */
    fun missingRequired(context: Context): Int = items().count { !it.optional && !it.granted(context) }

    fun render(activity: Activity, parent: LinearLayout) {
        parent.removeAllViews()
        for (item in items()) {
            val ok = item.granted(activity)
            val (_, value) = Ui.statusLine(parent, item.title + if (item.optional) " (opcional)" else "")
            value.text = if (ok) "CONCEDIDA ✓" else "FALTA"
            value.setTextColor(if (ok) Ui.OK else if (item.optional) Ui.MUTED else Ui.WARN)
            if (!ok) {
                Ui.note(parent, item.why)
                Ui.button(parent, "Conceder: ${item.title}") { item.request(activity) }
            }
        }
    }
}
