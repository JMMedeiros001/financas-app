package com.kupa.assistant.overlay

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.kupa.assistant.character.PopolView
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.OverlayHider
import com.kupa.assistant.gamer.GamerModeController
import com.kupa.assistant.history.HistoryType
import com.kupa.assistant.screen.ScreenPermissionActivity
import com.kupa.assistant.settings.Settings
import com.kupa.assistant.ui.ChatActivity
import com.kupa.assistant.ui.HistoryActivity
import com.kupa.assistant.ui.QuickSearchActivity
import com.kupa.assistant.ui.SettingsActivity
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Popol + Kupa flutuantes sobre outros apps, usando só o mecanismo oficial (janela de sobreposição).
 * Se a permissão não existir, nada é mostrado (e o app avisa); o personagem continua na tela do próprio app.
 */
class OverlayController(
    private val context: Context,
    private val settings: Settings,
    private val core: KupaCore,
    private val popol: PopolView,
    private val appVisible: () -> Boolean,
    private val onCloseRequested: () -> Unit,
) : OverlayHider, KupaCore.Listener, GamerModeController.Listener {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private var spriteParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var menuParams: WindowManager.LayoutParams? = null

    private val spriteRoot = android.widget.FrameLayout(context)
    private val bubbleView = TextView(context)
    private var menuRoot: ScrollView? = null

    private var spriteAdded = false
    private var bubbleAdded = false
    private var menuAdded = false
    private var bubbleText: String? = null
    private var hiddenForCapture = false
    private var userHidden = false

    private val screenW: Int get() = context.resources.displayMetrics.widthPixels
    private val screenH: Int get() = context.resources.displayMetrics.heightPixels

    private val spriteWidthPx: Int get() = (settings.sizeDp * density).roundToInt()
    private val spriteHeightPx: Int get() = (spriteWidthPx * PopolView.ASPECT_HEIGHT_OVER_WIDTH).roundToInt()
    private val padPx: Int get() = (spriteWidthPx * 0.10f).roundToInt()
    private val windowW: Int get() = spriteWidthPx + 2 * padPx
    private val windowH: Int get() = spriteHeightPx + 2 * padPx

    fun canDrawOverlay(): Boolean = AndroidSettings.canDrawOverlays(context)

    init {
        bubbleView.setTextColor(Color.parseColor("#EDEFFA"))
        bubbleView.textSize = 14f
        val bg = GradientDrawable()
        bg.cornerRadius = 18f * density
        bg.setColor(Color.parseColor("#E61E2140"))
        bg.setStroke((1 * density).roundToInt(), Color.parseColor("#7C8CFF"))
        bubbleView.background = bg
        val pad = (10 * density).roundToInt()
        bubbleView.setPadding(pad, pad, pad, pad)
        bubbleView.maxWidth = (screenW * 0.7f).roundToInt()
    }

    // ------------------------------------------------------------------ mostrar / esconder

    /** @return false se não dá para mostrar (sem permissão de sobreposição). */
    fun show(): Boolean {
        if (!settings.overlayEnabled) return false
        if (!canDrawOverlay()) {
            KupaLog.w("overlay", "sem permissão de sobreposição de tela")
            return false
        }
        if (spriteAdded) {
            refreshVisibility()
            return true
        }
        buildSprite()
        core.addListener(this)
        core.gamer.addListener(this)
        core.overlayHider = this
        refreshVisibility()
        return true
    }

    private fun buildSprite() {
        (popol.parent as? android.view.ViewGroup)?.removeView(popol)
        spriteRoot.removeAllViews()
        spriteRoot.setPadding(padPx, padPx, padPx, padPx)
        spriteRoot.clipChildren = false
        spriteRoot.clipToPadding = false
        spriteRoot.addView(popol, android.widget.FrameLayout.LayoutParams(spriteWidthPx, spriteHeightPx))
        popol.setAnimationsEnabled(settings.animationsEnabled)

        val p = WindowManager.LayoutParams(
            windowW, windowH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.START
        val start = startPosition()
        p.x = start.first
        p.y = start.second
        p.alpha = settings.alphaPercent.coerceIn(20, 100) / 100f
        spriteParams = p
        spriteRoot.setOnTouchListener(touchListener())
        try {
            wm.addView(spriteRoot, p)
            spriteAdded = true
        } catch (e: Exception) {
            KupaLog.e("overlay", "não consegui adicionar o personagem à tela", e)
        }
    }

    private fun startPosition(): Pair<Int, Int> {
        if (settings.posX >= 0 && settings.posY >= 0) return clamp(settings.posX, settings.posY)
        return clamp(screenW - windowW - (8 * density).roundToInt(), screenH - windowH - (140 * density).roundToInt())
    }

    private fun clamp(x: Int, y: Int): Pair<Int, Int> {
        val maxX = maxOf(0, screenW - windowW)
        val maxY = maxOf(0, screenH - windowH)
        return Pair(x.coerceIn(0, maxX), y.coerceIn(0, maxY))
    }

    /** Aplica tamanho, transparência e animação das configurações ao vivo. */
    fun applySettings() {
        val p = spriteParams ?: return
        if (!spriteAdded) return
        val lp = popol.layoutParams
        lp.width = spriteWidthPx
        lp.height = spriteHeightPx
        popol.layoutParams = lp
        spriteRoot.setPadding(padPx, padPx, padPx, padPx)
        p.width = windowW
        p.height = windowH
        p.alpha = settings.alphaPercent.coerceIn(20, 100) / 100f
        val pos = clamp(if (settings.posX >= 0) settings.posX else p.x, if (settings.posY >= 0) settings.posY else p.y)
        p.x = pos.first
        p.y = pos.second
        popol.setAnimationsEnabled(settings.animationsEnabled)
        updateSprite()
        positionBubble()
    }

    private fun shouldShowSprite(): Boolean {
        if (userHidden || hiddenForCapture) return false
        if (core.gamer.characterHidden) return false
        if (!settings.alwaysOnTop && !appVisible()) return false
        return true
    }

    private fun shouldShowBubble(): Boolean {
        if (userHidden || hiddenForCapture) return false
        if (bubbleText.isNullOrEmpty()) return false
        if (core.gamer.active) return settings.gamerShowBubble
        if (!settings.alwaysOnTop && !appVisible()) return false
        return settings.showBubble
    }

    fun refreshVisibility() {
        updateSprite()
        updateBubble()
        if (!shouldShowSprite()) removeMenu()
    }

    private fun updateSprite() {
        val p = spriteParams ?: return
        if (!spriteAdded) return
        val visible = shouldShowSprite()
        spriteRoot.visibility = if (visible) View.VISIBLE else View.GONE
        try {
            wm.updateViewLayout(spriteRoot, p)
        } catch (e: Exception) {
            KupaLog.w("overlay", "updateViewLayout: ${e.message}")
        }
    }

    // ------------------------------------------------------------------ balão de fala (janela própria, sem tocar no jogo)

    private fun updateBubble() {
        if (!shouldShowBubble()) {
            removeBubble()
            return
        }
        bubbleView.text = bubbleText
        if (!bubbleAdded) {
            val p = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT,
            )
            p.gravity = Gravity.TOP or Gravity.START
            p.alpha = 0.8f // acima disso o Android 12+ não deixa o toque passar por janelas "não tocáveis"
            bubbleParams = p
            try {
                wm.addView(bubbleView, p)
                bubbleAdded = true
            } catch (e: Exception) {
                KupaLog.e("overlay", "não consegui mostrar o balão", e)
                return
            }
        }
        positionBubble()
    }

    private fun positionBubble() {
        val p = bubbleParams ?: return
        val s = spriteParams ?: return
        if (!bubbleAdded) return
        bubbleView.measure(
            View.MeasureSpec.makeMeasureSpec((screenW * 0.7f).roundToInt(), View.MeasureSpec.AT_MOST),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
        )
        val bw = bubbleView.measuredWidth
        val bh = bubbleView.measuredHeight
        val spriteLeft = s.x + padPx
        val spriteTop = s.y + padPx
        var x = spriteLeft + spriteWidthPx / 2 - bw / 2
        x = x.coerceIn(0, maxOf(0, screenW - bw))
        var y = spriteTop - bh - (6 * density).roundToInt()
        if (y < 0) y = spriteTop + spriteHeightPx + (6 * density).roundToInt()
        y = y.coerceIn(0, maxOf(0, screenH - bh))
        p.x = x
        p.y = y
        try {
            wm.updateViewLayout(bubbleView, p)
        } catch (e: Exception) {
            KupaLog.w("overlay", "posicionar balão: ${e.message}")
        }
    }

    private fun removeBubble() {
        if (!bubbleAdded) return
        try {
            wm.removeView(bubbleView)
        } catch (e: Exception) {
            KupaLog.w("overlay", "remover balão: ${e.message}")
        }
        bubbleAdded = false
    }

    // ------------------------------------------------------------------ toque: arrastar, pinça, menu

    private fun touchListener(): View.OnTouchListener {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var dragging = false
        val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                val next = (settings.sizeDp * detector.scaleFactor).roundToInt().coerceIn(80, 320)
                if (next != settings.sizeDp) {
                    settings.sizeDp = next
                    applySettings()
                }
                return true
            }
        })
        return View.OnTouchListener { _, event ->
            scale.onTouchEvent(event)
            if (scale.isInProgress) {
                dragging = true
                return@OnTouchListener true
            }
            val p = spriteParams ?: return@OnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = p.x
                    startY = p.y
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (event.pointerCount == 1) {
                        val dx = event.rawX - downX
                        val dy = event.rawY - downY
                        if (!dragging && (abs(dx) > slop || abs(dy) > slop)) dragging = true
                        if (dragging) {
                            val pos = clamp(startX + dx.roundToInt(), startY + dy.roundToInt())
                            p.x = pos.first
                            p.y = pos.second
                            try {
                                wm.updateViewLayout(spriteRoot, p)
                            } catch (e: Exception) {
                                KupaLog.w("overlay", "mover: ${e.message}")
                            }
                            positionBubble()
                            if (menuAdded) removeMenu()
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        toggleMenu()
                    } else {
                        if (settings.autoPosition) snapToEdge()
                        settings.posX = p.x
                        settings.posY = p.y
                    }
                }
                MotionEvent.ACTION_CANCEL -> dragging = false
            }
            true
        }
    }

    private fun snapToEdge() {
        val p = spriteParams ?: return
        val center = p.x + windowW / 2
        p.x = if (center < screenW / 2) 0 else maxOf(0, screenW - windowW)
        try {
            wm.updateViewLayout(spriteRoot, p)
        } catch (e: Exception) {
            KupaLog.w("overlay", "encaixar: ${e.message}")
        }
        positionBubble()
    }

    fun resetPosition() {
        val pos = clamp(screenW - windowW - (8 * density).roundToInt(), screenH - windowH - (140 * density).roundToInt())
        settings.posX = pos.first
        settings.posY = pos.second
        val p = spriteParams ?: return
        p.x = pos.first
        p.y = pos.second
        updateSprite()
        positionBubble()
    }

    // ------------------------------------------------------------------ menu do Popol

    private data class Item(val label: String, val action: () -> Unit)

    private fun menuItems(): List<Item> {
        val gamerLabel = if (core.gamer.active) "🎮 Desligar Modo Gamer" else "🎮 Modo Gamer"
        return listOf(
            Item("💬 Conversar") { openActivity(ChatActivity::class.java) },
            Item(if (settings.voiceEnabled) "🎤 Voz: ligada" else "🎤 Voz: desligada") { core.setVoiceEnabled(!settings.voiceEnabled) },
            Item("🔍 Pesquisa rápida") { openActivity(QuickSearchActivity::class.java) },
            Item("👁 Analisar tela") { analyzeScreen() },
            Item(gamerLabel) {
                if (core.gamer.active) core.gamer.disable() else core.submitText("ativar modo gamer", HistoryType.GAMER)
            },
            Item("📜 Histórico") { openActivity(HistoryActivity::class.java) },
            Item("🎨 Personagem") { openActivity(SettingsActivity::class.java) },
            Item("⚙ Configurações") { openActivity(SettingsActivity::class.java) },
            Item(if (settings.alwaysOnTop) "📌 Sempre no topo: sim" else "📌 Sempre no topo: não") {
                settings.alwaysOnTop = !settings.alwaysOnTop
                refreshVisibility()
            },
            Item("📍 Posição: voltar ao padrão") { resetPosition() },
            Item("🔊 Volume: ${settings.volumePercent}%") {
                settings.volumePercent = when {
                    settings.volumePercent < 40 -> 40
                    settings.volumePercent < 60 -> 60
                    settings.volumePercent < 80 -> 80
                    settings.volumePercent < 100 -> 100
                    else -> 20
                }
            },
            Item("❌ Fechar") { onCloseRequested() },
        )
    }

    private fun toggleMenu() {
        if (menuAdded) removeMenu() else showMenu()
    }

    private fun showMenu() {
        val p = spriteParams ?: return
        val scroll = ScrollView(context)
        val column = LinearLayout(context)
        column.orientation = LinearLayout.VERTICAL
        val pad = (6 * density).roundToInt()
        column.setPadding(pad, pad, pad, pad)
        for (item in menuItems()) {
            val tv = TextView(context)
            tv.text = item.label
            tv.setTextColor(Color.parseColor("#EDEFFA"))
            tv.textSize = 15f
            tv.setPadding((14 * density).roundToInt(), (10 * density).roundToInt(), (14 * density).roundToInt(), (10 * density).roundToInt())
            tv.setOnClickListener {
                removeMenu()
                try {
                    item.action()
                } catch (e: Exception) {
                    KupaLog.e("overlay", "ação do menu falhou", e)
                }
            }
            column.addView(tv)
        }
        scroll.addView(column)
        val bg = GradientDrawable()
        bg.cornerRadius = 16f * density
        bg.setColor(Color.parseColor("#F21E2140"))
        bg.setStroke((1 * density).roundToInt(), Color.parseColor("#7C8CFF"))
        scroll.background = bg

        val width = (230 * density).roundToInt()
        val height = minOf((screenH * 0.7f).roundToInt(), (menuItems().size * 44 * density).roundToInt() + 2 * pad)
        val mp = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        mp.gravity = Gravity.TOP or Gravity.START
        val spriteLeft = p.x + padPx
        val spriteTop = p.y + padPx
        var x = if (spriteLeft + spriteWidthPx / 2 < screenW / 2) spriteLeft + spriteWidthPx else spriteLeft - width
        x = x.coerceIn(0, maxOf(0, screenW - width))
        val y = spriteTop.coerceIn(0, maxOf(0, screenH - height))
        mp.x = x
        mp.y = y
        scroll.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_OUTSIDE) {
                removeMenu()
                true
            } else {
                false
            }
        }
        try {
            wm.addView(scroll, mp)
            menuRoot = scroll
            menuParams = mp
            menuAdded = true
        } catch (e: Exception) {
            KupaLog.e("overlay", "não consegui abrir o menu", e)
        }
    }

    private fun removeMenu() {
        val m = menuRoot ?: return
        try {
            wm.removeView(m)
        } catch (e: Exception) {
            KupaLog.w("overlay", "remover menu: ${e.message}")
        }
        menuRoot = null
        menuAdded = false
    }

    private fun openActivity(cls: Class<*>) {
        val intent = Intent(context, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun analyzeScreen() {
        if (!settings.screenAnalysisEnabled) {
            core.reportProblem("A análise de tela está desligada. Ative em Configurações > Tela.")
            return
        }
        if (!core.screen.isActive) {
            context.startActivity(Intent(context, ScreenPermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        core.submitText("Explique o que está na minha tela agora.", HistoryType.SCREEN_ANALYSIS)
    }

    // ------------------------------------------------------------------ eventos do núcleo

    override fun onBubble(text: String?, isError: Boolean) {
        bubbleText = text
        updateBubble()
    }

    override fun onExchange(exchange: KupaCore.Exchange) {}

    override fun onProblem(message: String) {}

    override fun onGamerModeChanged(active: Boolean) {
        if (!active && settings.gamerRestorePosition) applySettings()
        refreshVisibility()
    }

    // ------------------------------------------------------------------ captura de tela: esconde por um instante

    override fun hideForCapture() {
        hiddenForCapture = true
        refreshVisibility()
    }

    override fun restoreAfterCapture() {
        hiddenForCapture = false
        refreshVisibility()
    }

    /** O usuário fechou o KUPA: tira tudo da tela. */
    fun destroy() {
        core.removeListener(this)
        core.gamer.removeListener(this)
        if (core.overlayHider === this) core.overlayHider = null
        removeMenu()
        removeBubble()
        if (spriteAdded) {
            try {
                wm.removeView(spriteRoot)
            } catch (e: Exception) {
                KupaLog.w("overlay", "remover personagem: ${e.message}")
            }
            spriteAdded = false
        }
        spriteRoot.removeAllViews()
    }

    companion object {
        fun openOverlaySettings(context: Context) {
            val intent = Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }
    }
}
