package com.kupa.assistant.security;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Risco de discar um número: emergência, tarifa premium, códigos USSD e ligação internacional. */
public final class NumberRisk {
    private NumberRisk() {}

    private static final Set<String> EMERGENCY = new HashSet<>(Arrays.asList("190", "191", "192", "193", "194", "197", "198", "199", "100", "180", "911", "112", "999"));

    public static final class Assessment {
        public final RiskLevel level;
        public final String why;
        public final boolean international;

        Assessment(RiskLevel level, String why, boolean international) {
            this.level = level;
            this.why = why;
            this.international = international;
        }
    }

    public static Assessment assess(String number) {
        String raw = number == null ? "" : number.trim();
        if (raw.contains("*") || raw.contains("#")) {
            return new Assessment(RiskLevel.HIGH, "o número tem * ou #, que pode ser um código de operadora (USSD) e alterar a linha", false);
        }
        String digits = raw.replaceAll("[^0-9+]", "");
        String plain = digits.replace("+", "");
        if (EMERGENCY.contains(plain)) return new Assessment(RiskLevel.HIGH, "é um número de emergência", false);
        if (plain.startsWith("0900") || plain.startsWith("0500")) return new Assessment(RiskLevel.HIGH, "parece um número de tarifa especial, que pode cobrar caro", false);
        boolean intl = (digits.startsWith("+") && !digits.startsWith("+55")) || (plain.startsWith("00") && !plain.startsWith("0055"));
        if (intl) return new Assessment(RiskLevel.MEDIUM, "é uma ligação internacional, que pode custar caro", true);
        return new Assessment(RiskLevel.MEDIUM, "ligação comum", false);
    }
}
