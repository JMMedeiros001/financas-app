package com.kupa.assistant.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.kupa.assistant.KupaApp
import com.kupa.assistant.character.PopolView
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.overlay.KupaService

/**
 * Tela inicial. É UM único KUPA: no celular as seções ficam em uma coluna; em tela grande (tablet, paisagem, janela larga)
 * ficam em duas áreas (comandos à esquerda; Popol + conversa à direita). O layout é recalculado com o tamanho REAL da janela.
 */
class MainActivity : Activity(), KupaCore.Listener {
    private lateinit var app: KupaApp
    private lateinit var popol: PopolView
    private lateinit var stateText: TextView
    private lateinit var bubble: TextView
    private lateinit var indicators: TextView
    private lateinit var securityBox: LinearLayout
    private lateinit var securityText: TextView
    private lateinit var modeText: TextView
    private lateinit var permissionsBox: LinearLayout
    private lateinit var startButton: Button
    private val ui = Handler(Looper.getMainLooper())
    private val stateListener = StateManager.Listener { _, current ->
        stateText.text = "Estado ${current.id}: ${current.label}"
        refreshStatus()
    }
    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 1000)
        }
    }

    /** Janela larga o bastante para duas áreas (considera multi-janela e rotação, não só o aparelho). */
    private fun isWide(): Boolean {
        val c = resources.configuration
        return c.screenWidthDp >= 720
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        popol = PopolView(this, app.sprites)
        popol.perfProvider = { app.performance.params }
        popol.bindTo(app.states)
        popol.setAnimationsEnabled(app.settings.animationsEnabled)
        popol.onLoadError = { app.core.reportProblem("Não consegui carregar o visual do Popol.") }

        val root: View = if (isWide()) buildWide() else buildNarrow()
        setContentView(root)
    }

    // ------------------------------------------------------------------ layouts

    private fun scrollColumn(): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.isFillViewport = true
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(Ui.dp(this, 16), Ui.dp(this, 24), Ui.dp(this, 16), Ui.dp(this, 32))
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return Pair(scroll, column)
    }

    private fun popolHolder(sizeDp: Int): FrameLayout {
        val holder = FrameLayout(this)
        val size = Ui.dp(this, sizeDp)
        holder.addView(popol, FrameLayout.LayoutParams(size, (size * PopolView.ASPECT_HEIGHT_OVER_WIDTH).toInt(), Gravity.CENTER_HORIZONTAL))
        return holder
    }

    private fun addStatusViews(parent: LinearLayout) {
        bubble = Ui.text(this, "", 14f, Ui.TEXT)
        bubble.gravity = Gravity.CENTER
        bubble.visibility = View.GONE
        parent.addView(bubble)
        stateText = Ui.text(this, "Estado ${app.states.current.id}: ${app.states.current.label}", 12f, Ui.MUTED)
        stateText.gravity = Gravity.CENTER
        parent.addView(stateText)
        modeText = Ui.text(this, "", 12f, Ui.MUTED)
        modeText.gravity = Gravity.CENTER
        parent.addView(modeText)
        indicators = Ui.text(this, "", 12f, Ui.MUTED)
        indicators.gravity = Gravity.CENTER
        parent.addView(indicators)
    }

    private fun buildNarrow(): View {
        val (scroll, column) = scrollColumn()
        column.addView(Ui.text(this, "KUPA", 24f, Ui.TEXT, bold = true))
        column.addView(Ui.text(this, "Seu assistente pessoal com o Popol e o lobo Kupa.", 14f, Ui.MUTED))
        buildSecurityBanner(column)
        column.addView(popolHolder(200))
        addStatusViews(column)
        buildActions(column)
        permissionsBox = Ui.section(column, "Permissões")
        return scroll
    }

    private fun buildWide(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Ui.BG)

        val (leftScroll, left) = scrollColumn()
        left.addView(Ui.text(this, "KUPA", 24f, Ui.TEXT, bold = true))
        left.addView(Ui.text(this, "Seu assistente pessoal com o Popol e o lobo Kupa.", 14f, Ui.MUTED))
        buildSecurityBanner(left)
        buildActions(left)
        permissionsBox = Ui.section(left, "Permissões")
        root.addView(leftScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 4f))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.setPadding(Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 16), Ui.dp(this, 12))
        right.addView(popolHolder(150))
        addStatusViews(right)
        right.addView(ChatPanel(this, app), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 6f))
        return root
    }

    private fun buildSecurityBanner(parent: LinearLayout) {
        securityBox = LinearLayout(this)
        securityBox.orientation = LinearLayout.VERTICAL
        securityBox.background = Ui.rounded(this, android.graphics.Color.parseColor("#3A2230"), 12)
        val pad = Ui.dp(this, 12)
        securityBox.setPadding(pad, pad, pad, pad)
        securityText = Ui.text(this, "", 14f, Ui.WARN)
        securityBox.addView(securityText)
        Ui.button(securityBox, "Reativar o KUPA (confirmação do aparelho)", primary = true) {
            app.core.rearm { ok ->
                Toast.makeText(this, if (ok) "KUPA reativado." else "Não confirmado: o KUPA continua em modo seguro.", Toast.LENGTH_LONG).show()
                refreshStatus()
            }
        }
        securityBox.visibility = View.GONE
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 12)
        parent.addView(securityBox, lp)
    }

    private fun buildActions(column: LinearLayout) {
        val actions = Ui.section(column, "Usar")
        startButton = Ui.button(actions, "Iniciar KUPA", primary = true) { toggleService() }
        Ui.button(actions, "⛔ PARAR KUPA (interrompe tudo agora)") {
            app.core.stopEverything()
            Toast.makeText(this, "KUPA parado: IA, voz, tela e automação interrompidas.", Toast.LENGTH_LONG).show()
        }
        Ui.button(actions, "Falar agora (sem dizer \"Kupa\")") { talkNow() }
        if (!isWide()) Ui.button(actions, "Conversar por texto") { startActivity(Intent(this, ChatActivity::class.java)) }
        Ui.button(actions, "Modos") { startActivity(Intent(this, ModesActivity::class.java)) }
        Ui.button(actions, "Conteúdo (nicho, hooks, roteiro)") { startActivity(Intent(this, ContentActivity::class.java)) }
        Ui.button(actions, "Histórico") { startActivity(Intent(this, HistoryActivity::class.java)) }
        Ui.button(actions, "Configurações") { startActivity(Intent(this, SettingsActivity::class.java)) }
        Ui.button(actions, "Diagnóstico da IA") { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onStart() {
        super.onStart()
        app.states.addListener(stateListener)
        app.core.addListener(this)
        renderPermissions()
        updateStartButton()
        ui.post(ticker)
    }

    override fun onStop() {
        ui.removeCallbacks(ticker)
        app.states.removeListener(stateListener)
        app.core.removeListener(this)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        renderPermissions()
        updateStartButton()
        refreshStatus()
    }

    /** Estado de segurança, modo ativo e indicadores de privacidade (o que o KUPA está fazendo AGORA). */
    private fun refreshStatus() {
        val st = app.security.state()
        if (st.name == "NORMAL") {
            securityBox.visibility = View.GONE
        } else {
            securityBox.visibility = View.VISIBLE
            securityText.text = "Segurança: ${st.name}. " + when (st.name) {
                "WARNING" -> "Detectei algo estranho; ações sensíveis pedem mais confirmação."
                "SUSPICIOUS" -> "Bloqueei ações sensíveis por precaução."
                else -> "O KUPA parou e não executa comandos até você reativar."
            }
            // só COMPROMISED/SAFE_SHUTDOWN têm botão de reativar
            securityBox.getChildAt(1).visibility = if (st.blocksActions()) View.VISIBLE else View.GONE
        }
        val mode = app.modes.active()
        modeText.text = if (mode != null) "Modo ativo: ${mode.name}" else "Modo: padrão"
        val active = app.core.indicators()
        indicators.text = if (active.isEmpty()) "Nada ativo no momento (sem microfone, tela ou envio)." else active.joinToString("   ")
        indicators.setTextColor(if (active.isEmpty()) Ui.MUTED else Ui.WARN)
    }

    private fun hasMic(): Boolean = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun renderPermissions() {
        Permissions.render(this, permissionsBox)
    }

    private fun updateStartButton() {
        startButton.text = if (KupaService.running) "Parar KUPA (encerra o serviço)" else "Iniciar KUPA"
    }

    private fun toggleService() {
        if (KupaService.running) {
            KupaService.stop(this)
            startButton.postDelayed({ updateStartButton() }, 300)
            return
        }
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            app.core.reportProblem("Conceda o microfone para eu ouvir você. Depois toque em Iniciar KUPA.")
            return
        }
        KupaService.start(this)
        startButton.postDelayed({ updateStartButton() }, 400)
    }

    private fun talkNow() {
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!KupaService.running) {
            KupaService.start(this)
            startButton.postDelayed({ app.core.listenNow(); updateStartButton() }, 500)
        } else {
            app.core.listenNow()
        }
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        renderPermissions()
    }

    // ---- KupaCore.Listener ----
    override fun onBubble(text: String?, isError: Boolean) {
        bubble.text = text ?: ""
        bubble.setTextColor(if (isError) Ui.BAD else Ui.TEXT)
        bubble.visibility = if (text.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    override fun onExchange(exchange: KupaCore.Exchange) {}

    override fun onProblem(message: String) {
        if (!app.settings.showBubble) onBubble(message, true)
    }

    companion object {
        private const val REQ_MIC = 101
    }
}
