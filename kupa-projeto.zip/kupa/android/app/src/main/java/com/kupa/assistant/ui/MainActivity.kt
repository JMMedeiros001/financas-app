package com.kupa.assistant.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.app.Activity
import com.kupa.assistant.KupaApp
import com.kupa.assistant.character.PopolView
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaState
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.overlay.KupaService
import com.kupa.assistant.overlay.OverlayController

/** Tela inicial: Popol + Kupa, permissões e atalhos. Mostra o personagem aqui mesmo se a sobreposição não for permitida. */
class MainActivity : Activity(), KupaCore.Listener {
    private lateinit var app: KupaApp
    private lateinit var popol: PopolView
    private lateinit var stateText: TextView
    private lateinit var bubble: TextView
    private lateinit var permissionsBox: LinearLayout
    private lateinit var startButton: android.widget.Button
    private val stateListener = StateManager.Listener { _, current -> stateText.text = "Estado ${current.id}: ${current.label}" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val column = Ui.screen(this, "KUPA")
        column.addView(Ui.text(this, "Seu assistente pessoal com o Popol e o lobo Kupa.", 14f, Ui.MUTED))

        popol = PopolView(this, app.sprites)
        popol.bindTo(app.states)
        popol.setAnimationsEnabled(app.settings.animationsEnabled)
        popol.onLoadError = { app.core.reportProblem("Não consegui carregar o visual do Popol.") }
        val holder = FrameLayout(this)
        val size = Ui.dp(this, 200)
        holder.addView(popol, FrameLayout.LayoutParams(size, (size * PopolView.ASPECT_HEIGHT_OVER_WIDTH).toInt(), Gravity.CENTER_HORIZONTAL))
        column.addView(holder, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        bubble = Ui.text(this, "", 14f, Ui.TEXT)
        bubble.gravity = Gravity.CENTER
        bubble.visibility = android.view.View.GONE
        column.addView(bubble)
        stateText = Ui.text(this, "", 12f, Ui.MUTED)
        stateText.gravity = Gravity.CENTER
        column.addView(stateText)
        stateText.text = "Estado ${app.states.current.id}: ${app.states.current.label}"

        val actions = Ui.section(column, "Usar")
        startButton = Ui.button(actions, "Iniciar KUPA", primary = true) { toggleService() }
        Ui.button(actions, "Falar agora (sem dizer \"Kupa\")") { talkNow() }
        Ui.button(actions, "Conversar por texto") { startActivity(Intent(this, ChatActivity::class.java)) }
        Ui.button(actions, "Histórico") { startActivity(Intent(this, HistoryActivity::class.java)) }
        Ui.button(actions, "Configurações") { startActivity(Intent(this, SettingsActivity::class.java)) }
        Ui.button(actions, "Diagnóstico da IA") { startActivity(Intent(this, DiagnosticsActivity::class.java)) }

        permissionsBox = Ui.section(column, "Permissões")
    }

    override fun onStart() {
        super.onStart()
        app.states.addListener(stateListener)
        app.core.addListener(this)
        renderPermissions()
        updateStartButton()
    }

    override fun onStop() {
        app.states.removeListener(stateListener)
        app.core.removeListener(this)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        renderPermissions()
        updateStartButton()
    }

    private fun hasMic(): Boolean = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasNotifications(): Boolean =
        Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun canOverlay(): Boolean = AndroidSettings.canDrawOverlays(this)

    private fun renderPermissions() {
        permissionsBox.removeAllViews()
        permissionRow("Microfone (ouvir você)", hasMic(), "Sem ele não dá para falar com o KUPA, mas o texto continua funcionando.") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
        }
        permissionRow("Notificações (aviso fixo do KUPA)", hasNotifications(), "O Android exige o aviso enquanto o KUPA fica ativo em segundo plano.") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        permissionRow("Aparecer sobre outros apps (Popol flutuante)", canOverlay(), "Sem isso o Popol aparece só dentro do app KUPA.") {
            OverlayController.openOverlaySettings(this)
        }
    }

    private fun permissionRow(label: String, granted: Boolean, why: String, onGrant: () -> Unit) {
        val (_, value) = Ui.statusLine(permissionsBox, label)
        value.text = if (granted) "CONCEDIDA" else "FALTA"
        value.setTextColor(if (granted) Ui.OK else Ui.WARN)
        if (!granted) {
            Ui.note(permissionsBox, why)
            Ui.button(permissionsBox, "Conceder") { onGrant() }
        }
    }

    private fun updateStartButton() {
        startButton.text = if (KupaService.running) "Parar KUPA" else "Iniciar KUPA"
    }

    private fun toggleService() {
        if (KupaService.running) {
            KupaService.stop(this)
            startButton.postDelayed({ updateStartButton() }, 300)
            return
        }
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            app.core.reportProblem("Conceda o microfone para eu ouvir você. Depois toque em Iniciar KUPA.")
            return
        }
        KupaService.start(this)
        startButton.postDelayed({ updateStartButton() }, 400)
    }

    private fun talkNow() {
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!KupaService.running) {
            KupaService.start(this)
            startButton.postDelayed({ app.core.listenNow(); updateStartButton() }, 500)
        } else {
            app.core.listenNow()
        }
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        renderPermissions()
    }

    // ---- KupaCore.Listener ----
    override fun onBubble(text: String?, isError: Boolean) {
        bubble.text = text ?: ""
        bubble.setTextColor(if (isError) Ui.BAD else Ui.TEXT)
        bubble.visibility = if (text.isNullOrEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    override fun onExchange(exchange: KupaCore.Exchange) {}

    override fun onProblem(message: String) {
        // a mensagem já aparece no balão quando ele está ligado; aqui só garante que o usuário veja algo
        if (!app.settings.showBubble) onBubble(message, true)
    }

    companion object {
        private const val REQ_MIC = 101
        private const val REQ_NOTIF = 102
    }
}
