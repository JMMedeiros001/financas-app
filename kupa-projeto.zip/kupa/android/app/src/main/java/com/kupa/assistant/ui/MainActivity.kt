package com.kupa.assistant.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.kupa.assistant.KupaApp
import com.kupa.assistant.character.PopolView
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.history.HistoryType
import com.kupa.assistant.overlay.KupaService
import com.kupa.assistant.visual.CoreMode
import com.kupa.assistant.visual.CoreView
import com.kupa.assistant.visual.MarkView
import com.kupa.assistant.visual.Palette

/**
 * Tela inicial do KUPA — TEMPORAL INTELLIGENCE SYSTEM.
 * É UM único KUPA: no celular as áreas ficam em uma coluna; em tela grande (tablet, paisagem, janela larga) ficam em duas
 * (controles à esquerda; núcleo e conversa à direita). O núcleo mostra SOMENTE o estado real (microfone aberto, processando, falando...).
 */
class MainActivity : Activity(), KupaCore.Listener {
    private lateinit var app: KupaApp
    private lateinit var popol: PopolView
    private lateinit var coreView: CoreView
    private lateinit var stateText: TextView
    private lateinit var hintText: TextView
    private lateinit var bubble: TextView
    private lateinit var indicators: TextView
    private lateinit var connectionChip: TextView
    private lateinit var securityBox: LinearLayout
    private lateinit var securityText: TextView
    private lateinit var modeText: TextView
    private lateinit var listenText: TextView
    private lateinit var retryButton: Button
    private lateinit var wakeButton: Button
    private lateinit var beepButton: Button
    private lateinit var backendBox: LinearLayout
    private lateinit var backendText: TextView
    private lateinit var permissionsBox: LinearLayout
    private lateinit var startButton: Button
    private val ui = Handler(Looper.getMainLooper())
    private val stateListener = StateManager.Listener { _, _ -> refreshStatus() }
    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            ui.postDelayed(this, 1000)
        }
    }

    /** Janela larga o bastante para duas áreas (considera multi-janela e rotação, não só o aparelho). */
    private fun isWide(): Boolean = resources.configuration.screenWidthDp >= 720

    private fun hasMic(): Boolean = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        popol = PopolView(this, app.sprites)
        popol.perfProvider = { app.performance.params }
        popol.bindTo(app.states)
        popol.setAnimationsEnabled(app.settings.animationsEnabled)
        popol.onLoadError = { app.core.reportProblem("Não consegui carregar o visual do Popol.") }

        coreView = CoreView(this)
        coreView.modeProvider = { currentCoreMode() }
        coreView.fpsProvider = { app.performance.params.animationFps }
        coreView.animationsAllowed = { app.settings.animationsEnabled }

        val content: View = if (isWide()) buildWide() else buildNarrow()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(NavBar.build(this), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        Ui.padTopForSystemBars(root)
        setContentView(root)
    }

    /** Modo do núcleo: derivado SÓ de fatos reais, lido a cada quadro. */
    private fun currentCoreMode(): CoreMode {
        val vc = app.core.voiceControl
        return CoreMode.resolve(
            KupaService.running, hasMic(), vc?.isMicOpen() == true, vc?.isCommandOpen() == true,
            app.states.current.name, app.commands.hasPending(), app.security.state().blocksActions(),
        )
    }

    // ------------------------------------------------------------------ peças visuais

    private fun scrollColumn(): Pair<ScrollView, LinearLayout> {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        scroll.isFillViewport = true
        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 24))
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return Pair(scroll, column)
    }

    /** Cabeçalho: símbolo, nome, indicador REAL de conexão com a IA e acesso às configurações. */
    private fun buildHeader(parent: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(MarkView(this), LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)))

        val names = LinearLayout(this)
        names.orientation = LinearLayout.VERTICAL
        names.addView(Ui.text(this, "KUPA", 20f, Ui.TEXT, bold = true))
        val sub = Ui.text(this, "TEMPORAL INTELLIGENCE SYSTEM", 9f, Ui.MUTED)
        sub.letterSpacing = 0.12f
        names.addView(sub)
        val np = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        np.marginStart = Ui.dp(this, 10)
        row.addView(names, np)

        connectionChip = Ui.text(this, "", 11f, Ui.MUTED, bold = true)
        connectionChip.gravity = Gravity.CENTER
        connectionChip.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 6))
        connectionChip.background = Ui.rounded(this, Ui.CHIP, 14, Ui.EDGE)
        connectionChip.contentDescription = "Estado da conexão com a IA"
        connectionChip.setOnClickListener { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        row.addView(connectionChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val gear = FrameLayout(this)
        gear.contentDescription = "Configurações"
        gear.addView(NavIconView(this, NavBar.Tab.SETTINGS, Ui.MUTED), FrameLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 26), Gravity.CENTER))
        gear.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        row.addView(gear, LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)))
        parent.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    /** Núcleo temporal com o Popol no centro (o personagem continua sendo a cara do KUPA). */
    private fun buildCoreArea(sizeDp: Int): FrameLayout {
        val frame = FrameLayout(this)
        val size = Ui.dp(this, sizeDp)
        frame.addView(coreView, FrameLayout.LayoutParams(size, size, Gravity.CENTER))
        val pw = (size * 0.44f).toInt()
        val ph = (pw * PopolView.ASPECT_HEIGHT_OVER_WIDTH).toInt()
        frame.addView(popol, FrameLayout.LayoutParams(pw, ph, Gravity.CENTER))
        return frame
    }

    private fun addStatusViews(parent: LinearLayout) {
        stateText = Ui.text(this, "", 22f, Ui.TEXT, bold = true)
        stateText.gravity = Gravity.CENTER
        parent.addView(stateText)
        hintText = Ui.text(this, "", 13f, Ui.MUTED)
        hintText.gravity = Gravity.CENTER
        parent.addView(hintText)
        bubble = Ui.text(this, "", 14f, Ui.TEXT)
        bubble.gravity = Gravity.CENTER
        bubble.visibility = View.GONE
        val bp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bp.topMargin = Ui.dp(this, 8)
        parent.addView(bubble, bp)
        listenText = Ui.text(this, "", 12f, Ui.MUTED)
        listenText.gravity = Gravity.CENTER
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 8)
        parent.addView(listenText, lp)
        retryButton = Ui.button(parent, "Tentar de novo a escuta") {
            app.core.voiceControl?.retryNow()
            refreshStatus()
        }
        retryButton.visibility = View.GONE
        modeText = Ui.text(this, "", 12f, Ui.MUTED)
        modeText.gravity = Gravity.CENTER
        parent.addView(modeText)
        indicators = Ui.text(this, "", 12f, Ui.MUTED)
        indicators.gravity = Gravity.CENTER
        parent.addView(indicators)
    }

    /** Interação: falar, digitar, parar. */
    private fun buildInteraction(parent: LinearLayout) {
        val talk = Ui.button(parent, "Falar com o KUPA", primary = true) { talkNow() }
        talk.minimumHeight = Ui.dp(this, 56)
        talk.textSize = 17f
        talk.contentDescription = "Ativar a escuta por voz"

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val input = EditText(this)
        input.hint = "Ou digite uma mensagem…"
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.background = Ui.rounded(this, Ui.CHIP, 12, Ui.EDGE)
        input.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12))
        val send = {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(input.windowToken, 0)
                app.core.submitText(text, HistoryType.TEXT)
            }
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendButton = Button(this)
        sendButton.text = "Enviar"
        sendButton.isAllCaps = false
        sendButton.minimumHeight = Ui.dp(this, 48)
        sendButton.setTextColor(Ui.TEXT)
        sendButton.background = Ui.rounded(this, Ui.BLUE, 12, Ui.ACCENT)
        sendButton.setOnClickListener { send() }
        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sp.marginStart = Ui.dp(this, 8)
        row.addView(sendButton, sp)
        val rp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rp.topMargin = Ui.dp(this, 10)
        parent.addView(row, rp)

        Ui.button(parent, "Parar tudo (cancelar a operação atual)") {
            app.core.stopEverything()
            Toast.makeText(this, "KUPA parado: IA, voz, tela e automação interrompidas.", Toast.LENGTH_LONG).show()
        }
    }

    /** Controles do assistente (ficam sempre visíveis e independentes uns dos outros). */
    private fun buildControls(column: LinearLayout) {
        val controls = Ui.section(column, "Controles")
        startButton = Ui.button(controls, "Iniciar KUPA") { toggleService() }
        // Palavra-chave e assistente são controles SEPARADOS: o serviço pode estar ativo com a palavra-chave desligada.
        wakeButton = Ui.button(controls, "") {
            app.settings.wakeListening = !app.settings.wakeListening
            refreshStatus()
        }
        beepButton = Ui.button(controls, "") {
            app.settings.muteMicBeep = !app.settings.muteMicBeep
            if (!app.settings.muteMicBeep) app.earcon.release()
            refreshStatus()
        }
        val tools = Ui.section(column, "Atalhos")
        Ui.button(tools, "Conteúdo: nicho, hooks e roteiros") { startActivity(Intent(this, ContentActivity::class.java)) }
        Ui.button(tools, "Modos do assistente") { startActivity(Intent(this, ModesActivity::class.java)) }
        Ui.button(tools, "Histórico") { startActivity(Intent(this, HistoryActivity::class.java)) }
        Ui.button(tools, "Diagnóstico da IA") { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
    }

    private fun buildBanner(parent: LinearLayout, tint: Int, buttonLabel: String, onClick: () -> Unit): Pair<LinearLayout, TextView> {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = Ui.rounded(this, Palette.mix(Palette.DEEP_BLUE, tint, 0.16f), 12, Palette.withAlpha(tint, 0.55f))
        val pad = Ui.dp(this, 12)
        box.setPadding(pad, pad, pad, pad)
        val text = Ui.text(this, "", 14f, tint)
        box.addView(text)
        Ui.button(box, buttonLabel, primary = true) { onClick() }
        box.visibility = View.GONE
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 12)
        parent.addView(box, lp)
        return Pair(box, text)
    }

    private fun buildBanners(parent: LinearLayout) {
        val backend = buildBanner(parent, Palette.AMBER, "Configurar o backend agora") { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
        backendBox = backend.first
        backendText = backend.second
        val security = buildBanner(parent, Palette.ERROR_RED, "Reativar o KUPA (confirmação do aparelho)") {
            app.core.rearm { ok ->
                Toast.makeText(this, if (ok) "KUPA reativado." else "Não confirmado: o KUPA continua em modo seguro.", Toast.LENGTH_LONG).show()
                refreshStatus()
            }
        }
        securityBox = security.first
        securityText = security.second
    }

    private fun buildNarrow(): View {
        val (scroll, column) = scrollColumn()
        buildHeader(column)
        buildBanners(column)
        val core = buildCoreArea(minOf(resources.configuration.screenWidthDp * 0.84f, 340f).toInt())
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = Ui.dp(this, 8)
        column.addView(core, cp)
        addStatusViews(column)
        buildInteraction(column)
        buildControls(column)
        permissionsBox = Ui.section(column, "Permissões")
        return scroll
    }

    private fun buildWide(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Ui.BG)

        val (leftScroll, left) = scrollColumn()
        buildHeader(left)
        buildBanners(left)
        buildInteraction(left)
        buildControls(left)
        permissionsBox = Ui.section(left, "Permissões")
        root.addView(leftScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 4f))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12))
        right.addView(buildCoreArea(260))
        addStatusViews(right)
        right.addView(ChatPanel(this, app), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 6f))
        return root
    }

    // ------------------------------------------------------------------ ciclo de vida

    override fun onStart() {
        super.onStart()
        app.states.addListener(stateListener)
        app.core.addListener(this)
        renderPermissions()
        updateStartButton()
        app.connection.refreshAsync(false) // verifica o backend (sem gastar IA)
        ui.post(ticker)
    }

    override fun onStop() {
        ui.removeCallbacks(ticker)
        app.states.removeListener(stateListener)
        app.core.removeListener(this)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        renderPermissions()
        updateStartButton()
        refreshStatus()
    }

    /** Atualiza tudo que a tela mostra do estado REAL: núcleo, textos, conexão, escuta, segurança e indicadores de privacidade. */
    private fun refreshStatus() {
        val mode = currentCoreMode()
        stateText.text = mode.title().replaceFirstChar { it.uppercase() }
        hintText.text = mode.hint(app.identity.activationName.replaceFirstChar { it.uppercase() })
        val chip = app.connection.label()
        connectionChip.text = chip.text
        connectionChip.setTextColor(chip.color)

        val urlCheck = com.kupa.assistant.ai.BackendConfig.check(app.settings)
        if (urlCheck.ok()) {
            backendBox.visibility = View.GONE
        } else {
            backendBox.visibility = View.VISIBLE
            backendText.text = if (urlCheck.problem == com.kupa.assistant.ai.BackendUrlValidator.Problem.EMPTY) {
                "A IA ainda não tem backend: este APK foi gerado sem a URL e você não digitou uma. Sem isso o KUPA responde comandos do celular, mas não conversa com a IA."
            } else {
                "A URL do backend é inválida: " + urlCheck.message
            }
        }

        val st = app.security.state()
        if (st.name == "NORMAL") {
            securityBox.visibility = View.GONE
        } else {
            securityBox.visibility = View.VISIBLE
            securityText.text = "Segurança: ${st.name}. " + when (st.name) {
                "WARNING" -> "Detectei algo estranho; ações sensíveis pedem mais confirmação."
                "SUSPICIOUS" -> "Bloqueei ações sensíveis por precaução."
                else -> "O KUPA parou e não executa comandos até você reativar."
            }
            // só COMPROMISED/SAFE_SHUTDOWN têm botão de reativar
            securityBox.getChildAt(1).visibility = if (st.blocksActions()) View.VISIBLE else View.GONE
        }

        wakeButton.text = if (app.settings.wakeListening) "Palavra-chave: LIGADA (toque para desativar)" else "Palavra-chave: DESATIVADA (toque para ativar)"
        beepButton.text = if (app.settings.muteMicBeep) "Bipe do microfone: SILENCIADO (toque para voltar ao normal)" else "Bipe do microfone: normal (toque para silenciar)"
        val vc = app.core.voiceControl
        listenText.text = "Escuta: " + (vc?.statusText() ?: "o KUPA não está em execução (toque em Iniciar KUPA).")
        retryButton.visibility = if (vc != null && vc.needsRetry()) View.VISIBLE else View.GONE
        val activeMode = app.modes.active()
        modeText.text = if (activeMode != null) "Modo ativo: ${activeMode.name}" else "Modo: padrão"
        val active = app.core.indicators()
        indicators.text = if (active.isEmpty()) "Nada ativo no momento (sem microfone, tela ou envio)." else active.joinToString("   ")
        indicators.setTextColor(if (active.isEmpty()) Ui.MUTED else Ui.WARN)
    }

    private fun renderPermissions() {
        Permissions.render(this, permissionsBox)
    }

    private fun updateStartButton() {
        startButton.text = if (KupaService.running) "Parar KUPA (encerra o serviço)" else "Iniciar KUPA"
    }

    private fun toggleService() {
        if (KupaService.running) {
            KupaService.stop(this)
            startButton.postDelayed({ updateStartButton() }, 300)
            return
        }
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            app.core.reportProblem("Conceda o microfone para eu ouvir você. Depois toque em Iniciar KUPA.")
            return
        }
        KupaService.start(this)
        startButton.postDelayed({ updateStartButton() }, 400)
    }

    private fun talkNow() {
        if (!hasMic()) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!KupaService.running) {
            KupaService.start(this)
            startButton.postDelayed({ app.core.listenNow(); updateStartButton() }, 500)
        } else {
            app.core.listenNow()
        }
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        renderPermissions()
    }

    // ---- KupaCore.Listener ----
    override fun onBubble(text: String?, isError: Boolean) {
        bubble.text = text ?: ""
        bubble.setTextColor(if (isError) Ui.BAD else Ui.TEXT)
        bubble.visibility = if (text.isNullOrEmpty()) View.GONE else View.VISIBLE
    }

    override fun onExchange(exchange: KupaCore.Exchange) {}

    override fun onProblem(message: String) {
        if (!app.settings.showBubble) onBubble(message, true)
    }

    companion object {
        private const val REQ_MIC = 101
    }
}
