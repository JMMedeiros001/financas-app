package com.kupa.assistant.ui

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import com.kupa.assistant.KupaApp
import com.kupa.assistant.ai.BackendUrlPolicy
import com.kupa.assistant.ai.NetworkChecker
import com.kupa.assistant.core.KupaLog

/**
 * CONFIGURAÇÃO DA IA + DIAGNÓSTICO DA IA.
 * Cada linha mostra o resultado de uma verificação REAL, feita agora: nada aparece como "conectado"
 * só porque existe uma configuração salva. A chave da OpenAI nunca passa por aqui.
 */
class DiagnosticsActivity : Activity() {
    private lateinit var app: KupaApp
    private lateinit var internetValue: TextView
    private lateinit var backendValue: TextView
    private lateinit var modelValue: TextView
    private lateinit var openaiValue: TextView
    private lateinit var aiValue: TextView
    private lateinit var detail: TextView
    private lateinit var logs: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val s = app.settings
        val column = Ui.screen(this, "Diagnóstico da IA")

        val config = Ui.section(column, "Configuração da IA")
        Ui.statusLine(config, "Provedor").second.text = "OpenAI (via backend KUPA)"
        val urlEdit = Ui.inputRow(config, "Endereço do backend", "https://seu-backend.exemplo.com", { s.backendUrl }, { s.backendUrl = it })
        val tokenEdit = Ui.inputRow(config, "Token do app (KUPA_APP_TOKEN)", "cole aqui", { s.appToken }, { s.appToken = it }, secret = true)
        Ui.note(config, "A chave da OpenAI fica somente no backend (OPENAI_API_KEY) e nunca é mostrada nem guardada neste app. HTTP puro só é aceito em rede local; fora dela use HTTPS.")
        Ui.button(config, "Salvar e verificar", primary = true) {
            val url = urlEdit.text.toString().trim()
            if (url.isNotEmpty() && !BackendUrlPolicy.isAllowed(url)) {
                detail.setTextColor(Ui.BAD)
                detail.text = BackendUrlPolicy.REJECTED_MESSAGE
            } else {
                s.backendUrl = url
                s.appToken = tokenEdit.text.toString().trim()
                runChecks()
            }
        }

        val status = Ui.section(column, "Status (verificação real)")
        internetValue = Ui.statusLine(status, "Internet").second
        backendValue = Ui.statusLine(status, "Backend").second
        modelValue = Ui.statusLine(status, "Modelo").second
        openaiValue = Ui.statusLine(status, "OpenAI").second
        aiValue = Ui.statusLine(status, "IA").second
        detail = Ui.text(this, "", 13f, Ui.MUTED)
        status.addView(detail)
        Ui.button(status, "TESTAR CONEXÃO COM A IA", primary = true) { runAiTest() }
        Ui.note(status, "O teste faz uma pergunta de verdade: app → backend → OpenAI → resposta (\"Kupa, responda apenas: conexão funcionando.\").")

        val dev = Ui.section(column, "Logs de desenvolvimento")
        logs = Ui.text(this, "", 11f, Ui.MUTED)
        logs.setTextIsSelectable(true)
        dev.addView(logs)
        Ui.button(dev, "Atualizar logs") { renderLogs() }
    }

    override fun onResume() {
        super.onResume()
        runChecks()
        renderLogs()
    }

    private fun set(view: TextView, text: String, color: Int) {
        view.text = text
        view.setTextColor(color)
    }

    private fun renderLogs() {
        logs.text = KupaLog.snapshot().takeLast(60).joinToString("\n").ifEmpty { "(sem registros ainda)" }
    }

    /** Internet + backend + modelo (sem gastar a OpenAI). OpenAI/IA só mudam com o teste de verdade. */
    private fun runChecks() {
        val s = app.settings
        val internet = NetworkChecker.hasInternet(this)
        set(internetValue, if (internet) "CONECTADA" else "SEM INTERNET VALIDADA", if (internet) Ui.OK else Ui.WARN)
        if (s.backendUrl.isBlank()) {
            set(backendValue, "NÃO CONFIGURADO", Ui.WARN)
            set(modelValue, "—", Ui.MUTED)
            set(openaiValue, "NÃO TESTADA", Ui.MUTED)
            set(aiValue, "NÃO TESTADA", Ui.MUTED)
            detail.setTextColor(Ui.MUTED)
            detail.text = "Informe o endereço do backend e o token acima."
            return
        }
        set(backendValue, "VERIFICANDO…", Ui.MUTED)
        Thread {
            val health = app.core.client.health()
            val config = if (health.ok) app.core.client.config() else null
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (!health.ok) {
                    set(backendValue, "INDISPONÍVEL", Ui.BAD)
                    set(modelValue, "—", Ui.MUTED)
                    detail.setTextColor(Ui.BAD)
                    detail.text = health.message
                    return@runOnUiThread
                }
                set(backendValue, "CONECTADO" + (health.version?.let { " (v$it)" } ?: ""), Ui.OK)
                if (config == null || !config.ok) {
                    set(modelValue, "—", Ui.MUTED)
                    detail.setTextColor(Ui.BAD)
                    detail.text = config?.message ?: "Não consegui ler a configuração do backend."
                    return@runOnUiThread
                }
                set(modelValue, config.model ?: "NÃO CONFIGURADO NO BACKEND", if (config.modelConfigured) Ui.TEXT else Ui.WARN)
                val missing = ArrayList<String>()
                if (!config.apiKeyConfigured) missing.add("a chave da OpenAI (OPENAI_API_KEY)")
                if (!config.modelConfigured) missing.add("o modelo (OPENAI_MODEL)")
                if (missing.isEmpty()) {
                    detail.setTextColor(Ui.MUTED)
                    detail.text = "Backend e configuração estão no ar. Toque em TESTAR para confirmar a OpenAI de verdade."
                } else {
                    detail.setTextColor(Ui.WARN)
                    detail.text = "No backend falta configurar: " + missing.joinToString(" e ") + "."
                }
            }
        }.start()
    }

    private fun runAiTest() {
        set(openaiValue, "TESTANDO…", Ui.MUTED)
        set(aiValue, "TESTANDO…", Ui.MUTED)
        detail.setTextColor(Ui.MUTED)
        detail.text = "Fazendo uma pergunta de verdade à OpenAI…"
        Thread {
            val result = app.core.client.testAi()
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (result.ok) {
                    set(openaiValue, "CONECTADA", Ui.OK)
                    set(aiValue, "FUNCIONANDO", Ui.OK)
                    if (!result.model.isNullOrEmpty()) set(modelValue, result.model, Ui.TEXT)
                    detail.setTextColor(Ui.OK)
                    detail.text = "Resposta recebida em ${result.latencyMs} ms: \"${result.reply ?: ""}\""
                } else {
                    set(openaiValue, "ERRO", Ui.BAD)
                    set(aiValue, "COM PROBLEMA", Ui.BAD)
                    detail.setTextColor(Ui.BAD)
                    detail.text = result.message
                }
                renderLogs()
            }
        }.start()
        KupaLog.i("diagnostico", "teste real da IA solicitado")
    }
}
