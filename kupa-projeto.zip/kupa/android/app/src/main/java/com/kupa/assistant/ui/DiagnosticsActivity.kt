package com.kupa.assistant.ui

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import com.kupa.assistant.KupaApp
import com.kupa.assistant.ai.BackendConfig
import com.kupa.assistant.ai.BackendUrlPolicy
import com.kupa.assistant.ai.BackendUrlValidator
import com.kupa.assistant.ai.KupaBackendClient
import com.kupa.assistant.ai.NetworkChecker
import com.kupa.assistant.core.KupaLog

/**
 * CONFIGURAÇÃO DA IA + DIAGNÓSTICO.
 * Cada linha mostra o resultado de uma verificação REAL feita agora; nada aparece como "conectado" só porque existe configuração salva.
 * O estado do BACKEND (URL, rede, TLS, HTTP) é separado do estado de CADA PROVEDOR de IA (chave/modelo no backend + teste real).
 * As chaves dos provedores ficam só no backend: nunca passam por aqui.
 */
class DiagnosticsActivity : Activity() {
    private lateinit var app: KupaApp
    private lateinit var internetValue: TextView
    private lateinit var backendValue: TextView
    private lateinit var aiValue: TextView
    private lateinit var detail: TextView
    private lateinit var logs: TextView
    private lateinit var providersBox: LinearLayout
    private val providerValues = HashMap<String, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val s = app.settings
        val column = Ui.screen(this, "Diagnóstico da IA")

        val config = Ui.section(column, "Backend")
        val fromApk = BackendConfig.buildUrl
        Ui.statusLine(config, "URL embutida no APK").second.text = if (fromApk.isEmpty()) "NÃO DEFINIDA" else fromApk + if (BackendConfig.buildUrlIsDev) " (dev)" else ""
        val urlEdit = Ui.inputRow(config, "URL personalizada (opcional; vale mais que a do APK)", "https://… (a que sua hospedagem te deu)", { s.backendUrl }, { s.backendUrl = it })
        val tokenEdit = Ui.inputRow(config, "Token do app (KUPA_APP_TOKEN)", "cole aqui", { s.appToken }, { s.appToken = it }, secret = true)
        Ui.note(config, "As chaves dos provedores de IA ficam somente no backend e nunca são mostradas nem guardadas neste app. O token é guardado cifrado. O app exige HTTPS e não ignora erros de certificado.")
        Ui.button(config, "Salvar e verificar", primary = true) {
            val url = urlEdit.text.toString().trim()
            val check = if (url.isEmpty()) null else BackendUrlPolicy.check(url)
            if (check != null && !check.ok()) {
                set(backendValue, "URL INVÁLIDA", Ui.BAD)
                detail.setTextColor(Ui.BAD)
                detail.text = check.message
            } else {
                s.backendUrl = check?.normalized ?: ""
                s.appToken = tokenEdit.text.toString().trim()
                runChecks()
            }
        }
        Ui.button(config, "Repetir diagnóstico") { runChecks() }

        val providerSection = Ui.section(column, "Qual IA usar")
        Ui.choiceRow(
            providerSection, "Provedor",
            listOf(Pair("Automático", "auto"), Pair("OpenAI", "openai"), Pair("Claude", "anthropic"), Pair("Gemini", "gemini")),
            { s.aiProvider }, { s.aiProvider = it },
        )
        Ui.switchRow(
            providerSection, "Usar outro provedor se o escolhido falhar",
            "Desligado por padrão: ao ligar, se o provedor falhar (rede, limite, indisponível) o KUPA reenvia SÓ aquela pergunta a outro provedor configurado e avisa. Isso compartilha o conteúdo com mais de uma empresa. Pedidos inválidos nunca são reenviados.",
            { s.aiFallbackAllowed }, { s.aiFallbackAllowed = it },
        )
        Ui.note(providerSection, "Automático usa a ordem configurada no backend entre os provedores que estão prontos. Cada modo pode ter seu provedor preferido.")

        val status = Ui.section(column, "Status (verificação real)")
        internetValue = Ui.statusLine(status, "Internet").second
        backendValue = Ui.statusLine(status, "Backend").second
        aiValue = Ui.statusLine(status, "IA").second
        providersBox = LinearLayout(this)
        providersBox.orientation = LinearLayout.VERTICAL
        status.addView(providersBox)
        detail = Ui.text(this, "", 13f, Ui.MUTED)
        status.addView(detail)

        val dev = Ui.section(column, "Logs de desenvolvimento")
        logs = Ui.text(this, "", 11f, Ui.MUTED)
        logs.setTextIsSelectable(true)
        dev.addView(logs)
        Ui.button(dev, "Atualizar logs") { renderLogs() }
    }

    override fun onResume() {
        super.onResume()
        runChecks()
        renderLogs()
    }

    private fun set(view: TextView, text: String, color: Int) {
        view.text = text
        view.setTextColor(color)
    }

    private fun renderLogs() {
        logs.text = KupaLog.snapshot().takeLast(60).joinToString("\n").ifEmpty { "(sem registros ainda)" }
    }

    /** Internet + URL + backend (/health) + configuração dos provedores. Não gasta nenhuma IA: o teste de cada provedor é manual. */
    private fun runChecks() {
        val s = app.settings
        val internet = NetworkChecker.hasInternet(this)
        set(internetValue, if (internet) "CONECTADA" else "SEM INTERNET VALIDADA", if (internet) Ui.OK else Ui.WARN)
        providersBox.removeAllViews()
        providerValues.clear()

        val urlCheck = BackendConfig.check(s)
        when (urlCheck.problem) {
            BackendUrlValidator.Problem.EMPTY -> {
                set(backendValue, "URL AUSENTE", Ui.WARN)
                set(aiValue, "NÃO TESTADA", Ui.MUTED)
                detail.setTextColor(Ui.WARN)
                detail.text = BackendConfig.NOT_CONFIGURED_MESSAGE + "\n\nSe você ainda não hospedou o backend: siga o README_BACKEND.md (Render ou Railway). Depois copie o endereço https que a hospedagem mostrar e cole acima."
                return
            }
            BackendUrlValidator.Problem.NONE -> Unit
            else -> {
                set(backendValue, "URL INVÁLIDA", Ui.BAD)
                set(aiValue, "NÃO TESTADA", Ui.MUTED)
                detail.setTextColor(Ui.BAD)
                detail.text = urlCheck.message
                return
            }
        }
        set(backendValue, "VERIFICANDO…", Ui.MUTED)
        set(aiValue, "—", Ui.MUTED)
        Thread {
            val health = app.core.client.health()
            val config = if (health.ok) app.core.client.config() else null
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (!health.ok) {
                    set(backendValue, "INDISPONÍVEL (${health.code ?: "erro"})", Ui.BAD)
                    set(aiValue, "NÃO TESTADA", Ui.MUTED)
                    detail.setTextColor(Ui.BAD)
                    detail.text = health.message
                    return@runOnUiThread
                }
                set(backendValue, "CONECTADO" + (health.version?.let { " (v$it)" } ?: ""), Ui.OK)
                if (config == null || !config.ok) {
                    set(aiValue, "NÃO VERIFICADA", Ui.MUTED)
                    detail.setTextColor(Ui.BAD)
                    detail.text = config?.message ?: "Não consegui ler a configuração do backend."
                    return@runOnUiThread
                }
                renderProviders(config.providers)
            }
        }.start()
    }

    private fun renderProviders(list: List<KupaBackendClient.ProviderInfo>) {
        providersBox.removeAllViews()
        providerValues.clear()
        if (list.isEmpty()) {
            set(aiValue, "BACKEND ANTIGO (sem lista de provedores)", Ui.WARN)
            detail.setTextColor(Ui.WARN)
            detail.text = "O backend publicado é de uma versão anterior. Publique a versão nova para escolher entre OpenAI, Claude e Gemini."
            return
        }
        val ready = list.filter { it.configured }
        if (ready.isEmpty()) {
            set(aiValue, "NENHUM PROVEDOR CONFIGURADO NO BACKEND", Ui.WARN)
            detail.setTextColor(Ui.WARN)
            detail.text = "O backend está no ar, mas nenhum provedor tem chave e modelo. Configure no painel da hospedagem, por exemplo OPENAI_API_KEY e OPENAI_MODEL (veja o README_BACKEND.md)."
        } else {
            set(aiValue, "${ready.size} PROVEDOR(ES) PRONTO(S) — NÃO TESTADO(S)", Ui.MUTED)
            detail.setTextColor(Ui.MUTED)
            detail.text = "Backend e configuração estão no ar. Toque em Testar para confirmar cada provedor de verdade (uma pergunta real)."
        }
        for (p in list) {
            val row = Ui.statusLine(providersBox, p.label).second
            providerValues[p.name] = row
            if (!p.configured) {
                val missing = ArrayList<String>()
                if (!p.apiKeyConfigured) missing.add("chave")
                if (!p.modelConfigured) missing.add("modelo")
                set(row, "NÃO CONFIGURADO NO BACKEND (falta ${missing.joinToString(" e ")})", Ui.MUTED)
            } else {
                set(row, "CONFIGURADO · modelo ${p.model ?: "?"} · não testado", Ui.TEXT)
                Ui.button(providersBox, "Testar ${p.label}") { testProvider(p) }
            }
        }
    }

    private fun testProvider(p: KupaBackendClient.ProviderInfo) {
        val row = providerValues[p.name] ?: return
        set(row, "TESTANDO…", Ui.MUTED)
        detail.setTextColor(Ui.MUTED)
        detail.text = "Fazendo uma pergunta de verdade a ${p.label} (app → backend → provedor → resposta)…"
        Thread {
            val result = app.core.client.testAi(p.name)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (result.ok) {
                    app.connection.markAiVerified(result.model)
                    set(row, "FUNCIONANDO · ${result.model ?: p.model ?: ""} · ${result.latencyMs} ms", Ui.OK)
                    set(aiValue, "FUNCIONANDO via ${p.label}", Ui.OK)
                    detail.setTextColor(Ui.OK)
                    detail.text = "Resposta recebida: \"${result.reply ?: ""}\""
                } else {
                    set(row, "ERRO (${result.code ?: "?"})", Ui.BAD)
                    detail.setTextColor(Ui.BAD)
                    detail.text = result.message
                }
                renderLogs()
            }
        }.start()
        KupaLog.i("diagnostico", "teste real do provedor ${p.name} solicitado")
    }
}
