package com.kupa.assistant.actions

import android.os.SystemClock

enum class CallState { IDLE, RINGING, OFFHOOK }

/** Foto da chamada atual/última, como o Android informou. Nada é inventado: campos desconhecidos ficam null. */
class CallSnapshot(
    val state: CallState,
    val number: String?,
    val contactName: String?,
    val incoming: Boolean,
    val updatedAtMs: Long,
) {
    val numberKnown: Boolean get() = !number.isNullOrEmpty()
    fun lastDigits(count: Int = 4): String? = number?.filter { it.isDigit() }?.takeLast(count)?.ifEmpty { null }
}

/** Pergunta que o KUPA fez e está esperando resposta. Vale por pouco tempo. */
sealed class Pending(val createdAtMs: Long) {
    var attempts: Int = 0

    class Confirm(val prompt: String, val onYes: () -> ActionResult, val onNoMessage: String, created: Long) : Pending(created)
    class Choice(val prompt: String, val labels: List<String>, val onChoice: (Int) -> ActionResult, created: Long) : Pending(created)
}

/**
 * Contexto entre comandos: último app, último contato, chamada atual e pergunta pendente.
 * Só guarda o que realmente aconteceu; sem informação suficiente, o KUPA pergunta em vez de supor.
 */
class ConversationContext {
    private val lock = Any()
    private var lastAppLabel: String? = null
    private var lastAppPackage: String? = null
    private var lastContact: String? = null
    private var call: CallSnapshot? = null
    private var pending: Pending? = null

    private fun now(): Long = SystemClock.elapsedRealtime()

    fun rememberApp(label: String, pkg: String?) = synchronized(lock) {
        lastAppLabel = label
        lastAppPackage = pkg
    }

    fun lastApp(): Pair<String, String?>? = synchronized(lock) {
        val l = lastAppLabel ?: return@synchronized null
        Pair(l, lastAppPackage)
    }

    fun rememberContact(name: String) = synchronized(lock) { lastContact = name }

    fun lastContact(): String? = synchronized(lock) { lastContact }

    fun setCall(snapshot: CallSnapshot) = synchronized(lock) {
        call = snapshot
        snapshot.contactName?.let { lastContact = it }
    }

    fun call(): CallSnapshot? = synchronized(lock) { call }

    fun setPending(p: Pending?) = synchronized(lock) { pending = p }

    fun hasPending(): Boolean = synchronized(lock) {
        val p = pending ?: return@synchronized false
        if (now() - p.createdAtMs > PENDING_TTL_MS) {
            pending = null
            false
        } else {
            true
        }
    }

    /** Tira a pergunta pendente (se ainda valer). */
    fun takePending(): Pending? = synchronized(lock) {
        val p = pending ?: return@synchronized null
        pending = null
        if (now() - p.createdAtMs > PENDING_TTL_MS) null else p
    }

    fun pendingLabels(): List<String>? = synchronized(lock) { (pending as? Pending.Choice)?.labels }

    fun clearPending() = synchronized(lock) { pending = null }

    fun newConfirm(prompt: String, onYes: () -> ActionResult, onNo: String): Pending.Confirm = Pending.Confirm(prompt, onYes, onNo, now())

    fun newChoice(prompt: String, labels: List<String>, onChoice: (Int) -> ActionResult): Pending.Choice = Pending.Choice(prompt, labels, onChoice, now())

    companion object {
        const val PENDING_TTL_MS = 45_000L
    }
}
