package com.kupa.assistant.ai

import org.json.JSONObject

enum class AiMode(val wire: String) { CHAT("chat"), SEARCH("search"), SCREEN("screen"), GAMER("gamer") }

data class AiMessage(val role: String, val text: String)

data class AiOptions(
    val mode: AiMode,
    val allowWebSearch: Boolean,
    val enabledTools: List<String>,
    val brief: Boolean,
    val gameContext: String,
    val language: String,
    val timeZone: String,
    /** "general" ou uma tarefa de conteúdo (niche_survey, hooks, script, optimize, analyze_text). */
    val task: String = "general",
    val niche: Map<String, String> = emptyMap(),
    val modeName: String = "",
    val modeInstructions: String = "",
    val modeNotes: String = "",
    val proactivity: String = "OFF",
    val verbosity: Int = 0,
    val modelClass: String = "",
    /** auto, openai, anthropic ou gemini. */
    val provider: String = "auto",
    /** O usuário autorizou usar outro provedor se o escolhido falhar? (padrão: não) */
    val fallbackAllowed: Boolean = false,
    val assistantName: String = "",
    /** Estilo descontraído ligado? Desligado = respostas neutras. */
    val casual: Boolean = true,
)

data class AiToolCall(val callId: String, val name: String, val arguments: JSONObject)

data class AiToolResult(val callId: String, val text: String?, val error: String?, val imageDataUrl: String?)

data class AiSource(val title: String, val url: String)

enum class AiErrorKind { NO_INTERNET, BACKEND_NOT_CONFIGURED, BACKEND_UNREACHABLE, BACKEND_AUTH, BACKEND_CONFIG, PROVIDER, SESSION_EXPIRED, INVALID_RESPONSE, CANCELLED, OTHER }

data class AiError(val kind: AiErrorKind, val code: String, val message: String)

sealed class AiResult {
    data class Final(val text: String, val sources: List<AiSource>, val webSearchUsed: Boolean, val model: String?) : AiResult()
    data class ToolCalls(val sessionId: String, val calls: List<AiToolCall>) : AiResult()
    data class Failure(val error: AiError) : AiResult()
}

/** Resultado do que o app executou no aparelho a pedido da IA (texto e/ou imagem, ou erro). */
class ToolOutput private constructor(val text: String?, val error: String?, val imageDataUrl: String?, val awaitUser: String?) {
    companion object {
        fun text(value: String) = ToolOutput(value, null, null, null)
        fun image(text: String, dataUrl: String) = ToolOutput(text, null, dataUrl, null)
        fun error(message: String) = ToolOutput(null, message, null, null)

        /** A ação precisa de uma resposta do USUÁRIO (confirmar/escolher). A IA não responde por ele: o app faz a pergunta. */
        fun awaitUser(prompt: String) = ToolOutput("AGUARDANDO O USUÁRIO: $prompt", null, null, prompt)
    }
}
