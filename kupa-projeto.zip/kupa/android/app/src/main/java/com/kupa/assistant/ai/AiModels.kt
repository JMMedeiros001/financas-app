package com.kupa.assistant.ai

import org.json.JSONObject

enum class AiMode(val wire: String) { CHAT("chat"), SEARCH("search"), SCREEN("screen"), GAMER("gamer") }

data class AiMessage(val role: String, val text: String)

data class AiOptions(
    val mode: AiMode,
    val allowWebSearch: Boolean,
    val enabledTools: List<String>,
    val brief: Boolean,
    val gameContext: String,
    val language: String,
    val timeZone: String,
)

data class AiToolCall(val callId: String, val name: String, val arguments: JSONObject)

data class AiToolResult(val callId: String, val text: String?, val error: String?, val imageDataUrl: String?)

data class AiSource(val title: String, val url: String)

enum class AiErrorKind { NO_INTERNET, BACKEND_NOT_CONFIGURED, BACKEND_UNREACHABLE, BACKEND_AUTH, BACKEND_CONFIG, OPENAI, SESSION_EXPIRED, INVALID_RESPONSE, CANCELLED, OTHER }

data class AiError(val kind: AiErrorKind, val code: String, val message: String)

sealed class AiResult {
    data class Final(val text: String, val sources: List<AiSource>, val webSearchUsed: Boolean, val model: String?) : AiResult()
    data class ToolCalls(val sessionId: String, val calls: List<AiToolCall>) : AiResult()
    data class Failure(val error: AiError) : AiResult()
}

/** Resultado do que o app executou no aparelho a pedido da IA (texto e/ou imagem, ou erro). */
class ToolOutput private constructor(val text: String?, val error: String?, val imageDataUrl: String?) {
    companion object {
        fun text(value: String) = ToolOutput(value, null, null)
        fun image(text: String, dataUrl: String) = ToolOutput(text, null, dataUrl)
        fun error(message: String) = ToolOutput(null, message, null)
    }
}
