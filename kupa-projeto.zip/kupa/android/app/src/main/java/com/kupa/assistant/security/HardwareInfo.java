package com.kupa.assistant.security;

/** Informações REAIS do aparelho, coletadas pelo Android (valores desconhecidos ficam -1). Nada é inventado. */
public final class HardwareInfo {
    public final long totalRamMb;
    public final int cores;
    public final int smallestWidthDp;
    public final boolean lowRamDevice;
    public final int batteryPercent;
    public final boolean charging;
    /** PowerManager.THERMAL_STATUS_* (0 nenhum ... 6 desligamento) ou -1 se o Android não informa. */
    public final int thermalStatus;
    public final boolean powerSaveMode;

    public HardwareInfo(long totalRamMb, int cores, int smallestWidthDp, boolean lowRamDevice, int batteryPercent, boolean charging, int thermalStatus, boolean powerSaveMode) {
        this.totalRamMb = totalRamMb;
        this.cores = cores;
        this.smallestWidthDp = smallestWidthDp;
        this.lowRamDevice = lowRamDevice;
        this.batteryPercent = batteryPercent;
        this.charging = charging;
        this.thermalStatus = thermalStatus;
        this.powerSaveMode = powerSaveMode;
    }

    public boolean isTablet() { return smallestWidthDp >= 600; }
}
