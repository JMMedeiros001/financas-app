package com.kupa.assistant.ui

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.kupa.assistant.KupaApp
import com.kupa.assistant.content.NicheProfile
import com.kupa.assistant.core.KupaCore

/**
 * Inteligência de conteúdo (só TEXTO): perfil do nicho, levantamento do nicho (com pesquisa na web), hooks, roteiro,
 * otimização e análise de roteiro/texto. NÃO edita vídeo, NÃO analisa vídeo e NÃO acessa redes sociais (não há ferramenta real para isso).
 */
class ContentActivity : Activity(), KupaCore.Listener {
    private lateinit var app: KupaApp
    private lateinit var result: TextView
    private lateinit var input: EditText
    private val fields = LinkedHashMap<String, EditText>()
    private var waiting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        val column = Ui.screen(this, "Conteúdo")
        column.addView(
            Ui.text(
                this,
                "Só texto: o KUPA pesquisa, planeja e escreve. Ele não edita nem analisa vídeo e não acessa suas redes sociais. " +
                    "Não promete visualizações. Tendências só entram com fonte; sem fonte vira HIPÓTESE.",
                13f, Ui.MUTED,
            ),
        )

        val nicheSection = Ui.section(column, "Seu nicho")
        val saved = app.niche.get()
        for ((key, label) in NicheProfile.FIELDS) {
            nicheSection.addView(Ui.text(this, label, 13f, Ui.TEXT))
            val e = EditText(this)
            e.setText(saved[key].orEmpty())
            e.setTextColor(Ui.TEXT)
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            nicheSection.addView(e)
            fields[key] = e
        }
        Ui.button(nicheSection, "Salvar nicho") {
            app.niche.save(fields.mapValues { it.value.text.toString() })
            Toast.makeText(this, "Nicho salvo (cifrado no aparelho).", Toast.LENGTH_SHORT).show()
        }
        Ui.button(nicheSection, "Apagar nicho") {
            app.niche.clear()
            for (e in fields.values) e.setText("")
        }

        val tasks = Ui.section(column, "Tarefas")
        input = EditText(this)
        input.hint = "Tema, título, roteiro ou texto para a tarefa"
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.minLines = 3
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        tasks.addView(input)
        Ui.button(tasks, "Levantamento geral do nicho (pesquisa na web)", primary = true) { run("niche_survey", allowEmpty = true) }
        Ui.button(tasks, "Gerar 5 hooks para o tema") { run("hooks") }
        Ui.button(tasks, "Criar roteiro para o tema") { run("script") }
        Ui.button(tasks, "Otimizar título, legenda, hashtags e CTA") { run("optimize") }
        Ui.button(tasks, "Analisar o roteiro/texto colado") { run("analyze_text") }

        val out = Ui.section(column, "Resultado")
        result = Ui.text(this, "Nada ainda.", 14f, Ui.TEXT)
        result.setTextIsSelectable(true)
        out.addView(result)
    }

    private fun run(task: String, allowEmpty: Boolean = false) {
        // salva o nicho antes de usar, para a tarefa já considerar o que está na tela
        app.niche.save(fields.mapValues { it.value.text.toString() })
        if (!allowEmpty && input.text.isBlank()) {
            Toast.makeText(this, "Escreva o tema ou cole o texto primeiro.", Toast.LENGTH_SHORT).show()
            return
        }
        if (app.niche.get().isEmpty()) {
            Toast.makeText(this, "Dica: preencha o nicho para respostas mais úteis.", Toast.LENGTH_SHORT).show()
        }
        waiting = true
        result.setTextColor(Ui.MUTED)
        result.text = "Trabalhando… (isto usa a IA pelo backend)"
        app.core.submitContentTask(task, input.text.toString())
    }

    override fun onStart() {
        super.onStart()
        app.core.addListener(this)
    }

    override fun onStop() {
        app.core.removeListener(this)
        super.onStop()
    }

    override fun onExchange(exchange: KupaCore.Exchange) {
        if (!waiting) return
        waiting = false
        val sources = if (exchange.sources.isEmpty()) "" else "\n\nFontes:\n" + exchange.sources.joinToString("\n") { "- " + it.title.ifEmpty { it.url } + " " + it.url }
        result.setTextColor(Ui.TEXT)
        result.text = exchange.answer + sources
    }

    override fun onProblem(message: String) {
        if (!waiting) return
        waiting = false
        result.setTextColor(Ui.BAD)
        result.text = message
    }

    override fun onBubble(text: String?, isError: Boolean) {}
}
