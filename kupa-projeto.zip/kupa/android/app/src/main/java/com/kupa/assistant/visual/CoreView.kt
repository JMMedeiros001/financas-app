package com.kupa.assistant.visual

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import com.kupa.assistant.core.CoreSignals

/**
 * Núcleo temporal do KUPA. Desenha [CoreScene] com o modo vindo de [modeProvider] (fatos reais) e os sinais reais de [CoreSignals].
 *
 * Economia e acessibilidade:
 *  - modos sem movimento (desligado, sem permissão, erro) desenham UM quadro e só reavaliam o modo a cada ~0,7 s;
 *  - com "remover animações" do Android (ou a opção do KUPA desligada) o quadro é estático, mas o estado continua legível;
 *  - os quadros por segundo respeitam o perfil de desempenho (e no repouso nunca passam de 20);
 *  - para de animar quando a tela não está visível.
 */
class CoreView(context: Context) : View(context) {
    /** Modo atual (lido a cada quadro, então nunca fica desatualizado). */
    var modeProvider: (() -> CoreMode)? = null

    /** Quadros por segundo permitidos pelo perfil de desempenho. */
    var fpsProvider: (() -> Int)? = null

    /** O usuário permite animações no KUPA? */
    var animationsAllowed: (() -> Boolean)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val startMs = SystemClock.uptimeMillis()
    private var lastMode: CoreMode? = null
    private var scheduled = false

    private val tick = Runnable {
        scheduled = false
        invalidate()
    }

    private fun motionAllowed(): Boolean = ValueAnimator.areAnimatorsEnabled() && (animationsAllowed?.invoke() ?: true)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val wMode = MeasureSpec.getMode(widthMeasureSpec)
        val hMode = MeasureSpec.getMode(heightMeasureSpec)
        val fallback = (280 * resources.displayMetrics.density).toInt()
        val size = when {
            wMode != MeasureSpec.UNSPECIFIED && hMode != MeasureSpec.UNSPECIFIED -> minOf(w, h)
            wMode != MeasureSpec.UNSPECIFIED -> w
            hMode != MeasureSpec.UNSPECIFIED -> h
            else -> fallback
        }
        setMeasuredDimension(size, size)
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val mode = modeProvider?.invoke() ?: CoreMode.IDLE
        if (mode != lastMode) {
            lastMode = mode
            contentDescription = "Núcleo do KUPA: " + mode.title()
        }
        val animate = motionAllowed()
        val t = (now - startMs) / 1000f
        val prims = CoreScene.build(mode, t, CoreSignals.micLevel(now), CoreSignals.speechPulse(now), animate)
        val radius = minOf(width, height) * 0.47f
        PrimRenderer.draw(canvas, prims, width / 2f, height / 2f, radius, paint)
        schedule(mode, animate)
    }

    private fun schedule(mode: CoreMode, animate: Boolean) {
        if (scheduled || !isAttachedToWindow || windowVisibility != VISIBLE) return
        scheduled = true
        val moving = animate && mode.animated()
        val delay = if (moving) {
            val cap = fpsProvider?.invoke() ?: 30
            val fps = if (mode == CoreMode.IDLE || mode == CoreMode.CONFIRM) minOf(cap, 20) else minOf(cap, 30)
            (1000L / maxOf(1, fps))
        } else {
            700L // sem movimento: só reavalia o modo de vez em quando
        }
        postOnAnimationDelayed(tick, delay)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        scheduled = false
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) invalidate() else {
            removeCallbacks(tick)
            scheduled = false
        }
    }
}
