package com.kupa.assistant.ai

import com.kupa.assistant.BuildConfig
import com.kupa.assistant.settings.Settings

/**
 * De onde vem a URL do backend. Ordem:
 *  1) URL personalizada digitada pelo usuário no app (opcional, só neste aparelho);
 *  2) URL do APK (BuildConfig.KUPA_BACKEND_URL), definida em android/kupa.properties na hora de gerar o APK.
 * Nenhuma URL é inventada: se as duas estiverem vazias, o app diz isso claramente.
 */
object BackendConfig {
    enum class Source { USER_OVERRIDE, BUILD, NONE }

    val buildUrl: String get() = BuildConfig.KUPA_BACKEND_URL.trim().trimEnd('/')

    val buildUrlIsDev: Boolean get() = BuildConfig.KUPA_BACKEND_URL_IS_DEV

    fun effectiveUrl(settings: Settings): String {
        val custom = settings.backendUrl.trim().trimEnd('/')
        return if (custom.isNotEmpty()) custom else buildUrl
    }

    fun source(settings: Settings): Source = when {
        settings.backendUrl.isNotBlank() -> Source.USER_OVERRIDE
        buildUrl.isNotEmpty() -> Source.BUILD
        else -> Source.NONE
    }

    const val NOT_CONFIGURED_MESSAGE =
        "Este APK foi gerado sem a URL do backend e você ainda não informou uma. " +
            "Defina KUPA_BACKEND_URL em android/kupa.properties e gere o APK de novo, " +
            "ou digite a URL em Configurações > Diagnóstico da IA."
}
