package com.kupa.assistant.ai

/**
 * Contrato do provedor de IA. O resto do app só conhece esta interface (nunca o SDK/API da OpenAI).
 * Hoje há um provedor: KupaBackendProvider (backend KUPA -> API oficial da OpenAI).
 * Para adicionar outro provedor no futuro, basta implementar esta interface.
 * As chamadas são bloqueantes: rode fora da thread principal.
 */
interface AiProvider {
    val name: String

    fun respond(messages: List<AiMessage>, options: AiOptions, attachments: List<String>): AiResult

    fun continueWithTools(sessionId: String, results: List<AiToolResult>, options: AiOptions): AiResult
}
