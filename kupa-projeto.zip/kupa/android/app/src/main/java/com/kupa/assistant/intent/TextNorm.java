package com.kupa.assistant.intent;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Normalização de texto falado: minúsculas, sem acentos, sem pontuação. Lógica pura (sem Android). */
public final class TextNorm {
    private TextNorm() {}

    private static final Set<String> GREETINGS = new HashSet<>(Arrays.asList("oi", "ola", "ei", "hey", "hei", "ok", "okay", "e", "opa", "fala"));
    private static final Set<String> WAKE = new HashSet<>(Arrays.asList("kupa", "cupa", "culpa", "kuppa", "cuppa", "kupah"));

    /** Minúsculas e sem acentos. */
    public static String fold(String s) {
        if (s == null) return "";
        String d = Normalizer.normalize(s, Normalizer.Form.NFD);
        StringBuilder out = new StringBuilder(d.length());
        for (int i = 0; i < d.length(); i++) {
            char c = d.charAt(i);
            if (Character.getType(c) == Character.NON_SPACING_MARK) continue;
            out.append(Character.toLowerCase(c));
        }
        return out.toString();
    }

    /** fold + tudo que não é letra/número vira espaço + espaços colapsados. */
    public static String normalize(String s) {
        String f = fold(s);
        StringBuilder out = new StringBuilder(f.length());
        boolean space = true;
        for (int i = 0; i < f.length(); i++) {
            char c = f.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                out.append(c);
                space = false;
            } else if (!space) {
                out.append(' ');
                space = true;
            }
        }
        return out.toString().trim();
    }

    public static List<String> tokens(String normalized) {
        List<String> list = new ArrayList<>();
        if (normalized == null || normalized.isEmpty()) return list;
        for (String t : normalized.split(" ")) if (!t.isEmpty()) list.add(t);
        return list;
    }

    public static String join(List<String> tokens, int from, int to) {
        StringBuilder sb = new StringBuilder();
        for (int i = from; i < to && i < tokens.size(); i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(tokens.get(i));
        }
        return sb.toString();
    }

    /** Tira "oi/ei" e a palavra de ativação ("kupa", "cupa", "culpa") do começo, se houver. */
    public static String stripWake(String normalized) {
        List<String> t = tokens(normalized);
        int i = 0;
        while (i < t.size() && GREETINGS.contains(t.get(i)) && i + 1 < t.size() && (WAKE.contains(t.get(i + 1)) || GREETINGS.contains(t.get(i + 1)))) i++;
        boolean removedWake = false;
        while (i < t.size() && WAKE.contains(t.get(i))) {
            i++;
            removedWake = true;
        }
        if (!removedWake) return normalized;
        return join(t, i, t.size());
    }

    public static boolean startsWithWake(String normalized) {
        List<String> t = tokens(normalized);
        int i = 0;
        while (i < t.size() && GREETINGS.contains(t.get(i))) i++;
        return i < t.size() && WAKE.contains(t.get(i));
    }
}
