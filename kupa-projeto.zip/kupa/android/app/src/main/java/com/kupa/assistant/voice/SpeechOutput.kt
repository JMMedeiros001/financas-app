package com.kupa.assistant.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.settings.Settings
import java.util.Locale

/**
 * Resposta por voz usando o Text-to-Speech do próprio Android (voz sintética, nada de áudio do jogo).
 * A personalidade jovem/energética vem de tom e velocidade ajustáveis em Configurações.
 * Todos os callbacks chegam na thread principal.
 */
class SpeechOutput(context: Context, private val settings: Settings) {
    private val appContext = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val audio = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var tts: TextToSpeech? = null
    private var ready = false
    private var failedInit = false
    private var languageOk = true
    private val pending = ArrayList<Job>()
    private var focusRequest: AudioFocusRequest? = null
    private var counter = 0
    private val callbacks = HashMap<String, Job>()

    private class Job(val text: String, val volume: Float, val flush: Boolean, val onStart: (() -> Unit)?, val onDone: () -> Unit, val onError: (String) -> Unit)

    /** Cria o motor de voz (chame na thread principal). */
    fun ensureInit() {
        if (tts != null) return
        tts = TextToSpeech(appContext) { status ->
            main.post { onInit(status) }
        }
    }

    private fun onInit(status: Int) {
        val engine = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            failedInit = true
            KupaLog.e("voz", "TextToSpeech falhou ao iniciar (status=$status)")
            flushPendingWithError("A voz do aparelho não iniciou.")
            return
        }
        val result = engine.setLanguage(Locale("pt", "BR"))
        languageOk = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
        if (!languageOk) KupaLog.w("voz", "voz em português do Brasil não instalada (resultado=$result)")
        engine.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build(),
        )
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String) {
                main.post { callbacks[utteranceId]?.onStart?.invoke() }
            }

            override fun onDone(utteranceId: String) {
                main.post { finish(utteranceId, null) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String) {
                main.post { finish(utteranceId, "Falha ao falar.") }
            }

            override fun onError(utteranceId: String, errorCode: Int) {
                main.post { finish(utteranceId, "Falha ao falar (código $errorCode).") }
            }
        })
        ready = true
        applyVoiceSettings()
        val queued = ArrayList(pending)
        pending.clear()
        for (job in queued) start(job)
    }

    private fun applyVoiceSettings() {
        val engine = tts ?: return
        engine.setPitch(settings.pitchPercent / 100f)
        engine.setSpeechRate(settings.ratePercent / 100f)
        val wanted = settings.ttsVoiceName
        if (wanted.isNotEmpty()) {
            try {
                val voice = engine.voices?.firstOrNull { it.name == wanted }
                if (voice != null) engine.setVoice(voice)
            } catch (e: Exception) {
                KupaLog.w("voz", "não consegui aplicar a voz escolhida: ${e.message}")
            }
        }
    }

    /** Nomes das vozes em português instaladas (para a tela de configurações). */
    fun portugueseVoices(): List<String> {
        val engine = tts ?: return emptyList()
        return try {
            engine.voices?.filter { it.locale.language == "pt" }?.map { it.name }?.sorted() ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Fala o texto. [onDone] é chamado ao terminar (ou ao falhar, depois de [onError]); nunca fica sem retorno.
     * Com [flush] = true interrompe o que estiver sendo falado.
     */
    fun speak(
        text: String,
        volumePercent: Int,
        flush: Boolean = true,
        onStart: (() -> Unit)? = null,
        onError: (String) -> Unit = {},
        onDone: () -> Unit,
    ) {
        val clean = text.trim()
        if (clean.isEmpty()) {
            onDone()
            return
        }
        ensureInit()
        val job = Job(clean, (volumePercent.coerceIn(0, 100)) / 100f, flush, onStart, onDone, onError)
        when {
            failedInit -> {
                onError("A voz do aparelho não está disponível.")
                onDone()
            }
            !ready -> pending.add(job)
            else -> start(job)
        }
    }

    private fun start(job: Job) {
        val engine = tts
        if (engine == null || !languageOk) {
            job.onError(
                if (engine == null) "A voz do aparelho não está disponível." else "A voz em português não está instalada no aparelho.",
            )
            job.onDone()
            return
        }
        applyVoiceSettings()
        requestFocus()
        val chunks = splitForTts(job.text)
        var queueMode = if (job.flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        if (job.flush) dropCallbacks()
        for ((index, chunk) in chunks.withIndex()) {
            counter++
            val id = "kupa-$counter"
            val last = index == chunks.size - 1
            callbacks[id] = if (last) job else Job("", job.volume, false, if (index == 0) job.onStart else null, {}, {})
            val params = Bundle()
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, job.volume)
            val r = engine.speak(chunk, queueMode, params, id)
            if (r != TextToSpeech.SUCCESS) {
                callbacks.remove(id)
                abandonFocus()
                job.onError("Não consegui falar agora.")
                job.onDone()
                return
            }
            queueMode = TextToSpeech.QUEUE_ADD
        }
    }

    /** Descarta pendências da fala anterior (interrompida por flush) sem chamar seus callbacks. */
    private fun dropCallbacks() {
        callbacks.clear()
    }

    private fun finish(utteranceId: String, error: String?) {
        val job = callbacks.remove(utteranceId) ?: return
        if (job.text.isEmpty()) {
            if (error != null) KupaLog.w("voz", error)
            return
        }
        abandonFocus()
        if (error != null) job.onError(error)
        job.onDone()
    }

    private fun flushPendingWithError(message: String) {
        val queued = ArrayList(pending)
        pending.clear()
        for (job in queued) {
            job.onError(message)
            job.onDone()
        }
    }

    /** Para de falar imediatamente. Não chama onDone da fala interrompida. */
    fun stop() {
        pending.clear()
        callbacks.clear()
        try {
            tts?.stop()
        } catch (e: Exception) {
            KupaLog.w("voz", "erro ao parar: ${e.message}")
        }
        abandonFocus()
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            KupaLog.w("voz", "erro ao encerrar: ${e.message}")
        }
        tts = null
        ready = false
    }

    private fun requestFocus() {
        if (focusRequest != null) return
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            .build()
        focusRequest = request
        audio.requestAudioFocus(request)
    }

    private fun abandonFocus() {
        val request = focusRequest ?: return
        audio.abandonAudioFocusRequest(request)
        focusRequest = null
    }

    private fun splitForTts(text: String): List<String> {
        val limit = 3500
        if (text.length <= limit) return listOf(text)
        val out = ArrayList<String>()
        var rest = text
        while (rest.length > limit) {
            var cut = rest.lastIndexOf(". ", limit)
            if (cut < limit / 2) cut = rest.lastIndexOf(' ', limit)
            if (cut <= 0) cut = limit
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1).trim()
        }
        if (rest.isNotEmpty()) out.add(rest)
        return out
    }
}
