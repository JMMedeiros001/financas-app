package com.kupa.assistant.security;

/** Decisão da política de segurança para uma ação. */
public final class Verdict {
    public enum Kind {
        /** Pode executar. */
        ALLOW,
        /** Perguntar uma vez ("quer que eu faça?"). */
        CONFIRM,
        /** Explicar o risco, confirmar, explicar de novo e confirmar uma segunda vez. */
        CONFIRM_TWICE,
        /** Duas confirmações + autenticação nativa do Android (biometria/PIN). */
        NATIVE_AUTH,
        /** Não executar. */
        BLOCK
    }

    public final Kind kind;
    public final RiskLevel effectiveRisk;
    /** Motivo em português, pronto para o usuário ouvir. */
    public final String reason;

    Verdict(Kind kind, RiskLevel effectiveRisk, String reason) {
        this.kind = kind;
        this.effectiveRisk = effectiveRisk;
        this.reason = reason;
    }

    @Override public String toString() { return kind + "(" + effectiveRisk + "): " + reason; }
}
