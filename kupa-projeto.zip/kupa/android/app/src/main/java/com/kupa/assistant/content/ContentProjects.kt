package com.kupa.assistant.content

import android.content.Context
import com.kupa.assistant.actions.SecureJsonStore
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ContentProject(val id: String, val title: String, val task: String, val input: String, val output: String, val createdAtMs: Long)

/** Projetos de conteúdo salvos pelo usuário (texto). Cifrados no aparelho; sem envio a ninguém; apagáveis. */
class ContentProjects(context: Context) {
    private val store = SecureJsonStore(context, "projects")

    @Synchronized
    fun all(): List<ContentProject> {
        val arr = store.read().optJSONArray("projects") ?: return emptyList()
        val out = ArrayList<ContentProject>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(ContentProject(o.optString("id"), o.optString("title"), o.optString("task"), o.optString("input"), o.optString("output"), o.optLong("createdAtMs")))
        }
        return out.sortedByDescending { it.createdAtMs }
    }

    @Synchronized
    private fun persist(list: List<ContentProject>): Boolean {
        val arr = JSONArray()
        for (p in list) arr.put(JSONObject().put("id", p.id).put("title", p.title).put("task", p.task).put("input", p.input).put("output", p.output).put("createdAtMs", p.createdAtMs))
        return store.write(JSONObject().put("projects", arr))
    }

    fun add(title: String, task: String, input: String, output: String): Boolean {
        val p = ContentProject(UUID.randomUUID().toString(), title.trim().take(60).ifEmpty { "Projeto" }, task, input.take(4000), output.take(20000), System.currentTimeMillis())
        return persist(listOf(p) + all().take(49)) // guarda no máximo 50
    }

    fun delete(id: String) {
        persist(all().filter { it.id != id })
    }

    fun clear() = store.clear()
}
