package com.kupa.assistant.content

import android.content.Context
import com.kupa.assistant.actions.SecureJsonStore
import org.json.JSONObject

/** Nicho do usuário (tema, público, estilo...). Texto que o próprio usuário escreve; cifrado no aparelho. */
class NicheProfile(context: Context) {
    private val store = SecureJsonStore(context, "niche")

    @Synchronized
    fun get(): Map<String, String> {
        val o = store.read()
        val out = LinkedHashMap<String, String>()
        for (f in FIELDS) {
            val v = o.optString(f.first, "").trim()
            if (v.isNotEmpty()) out[f.first] = v
        }
        return out
    }

    @Synchronized
    fun save(values: Map<String, String>) {
        val o = JSONObject()
        for (f in FIELDS) {
            val v = (values[f.first] ?: "").trim().take(400)
            if (v.isNotEmpty()) o.put(f.first, v)
        }
        store.write(o)
    }

    @Synchronized
    fun clear() = store.clear()

    companion object {
        /** chave enviada ao backend -> rótulo mostrado na tela. As chaves são as aceitas pelo backend. */
        val FIELDS = listOf(
            Pair("tema", "Tema do nicho (ex.: marketing digital)"),
            Pair("subtopicos", "Subtópicos"),
            Pair("publico", "Público"),
            Pair("estilo", "Estilo (tom, ritmo)"),
            Pair("palavrasChave", "Palavras-chave"),
            Pair("referencias", "Referências (canais/perfis que você estuda)"),
            Pair("formatos", "Formatos (shorts, reels, vídeos longos…)"),
            Pair("preferencias", "Preferências e o que evitar"),
        )
    }
}
