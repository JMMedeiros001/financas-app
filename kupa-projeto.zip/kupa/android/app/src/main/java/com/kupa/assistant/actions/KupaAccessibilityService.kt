package com.kupa.assistant.actions

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.provider.Settings as AndroidSettings
import android.view.accessibility.AccessibilityEvent
import com.kupa.assistant.core.KupaLog

/**
 * Serviço de acessibilidade MÍNIMO e opcional. Ele só fica sabendo QUAL app veio para a frente (mudança de janela),
 * para o KUPA confirmar de verdade que abriu um aplicativo. Ele NÃO lê o conteúdo da tela, NÃO toca em nada e
 * NÃO executa ações. Também ajuda o Android a permitir que o KUPA abra apps em segundo plano.
 * O usuário ativa e desativa em Configurações do Android > Acessibilidade.
 */
class KupaAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        running = true
        KupaLog.i("acessibilidade", "serviço de acessibilidade conectado")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        ForegroundApp.set(pkg)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        running = false
        KupaLog.i("acessibilidade", "serviço de acessibilidade desligado")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    companion object {
        @Volatile
        var running: Boolean = false
            private set

        /** O usuário ligou o serviço nas configurações do Android? (vale mesmo antes de ele conectar) */
        fun isEnabled(context: Context): Boolean {
            val me = ComponentName(context, KupaAccessibilityService::class.java).flattenToString()
            val enabled = try {
                AndroidSettings.Secure.getInt(context.contentResolver, AndroidSettings.Secure.ACCESSIBILITY_ENABLED, 0) == 1
            } catch (e: Exception) {
                false
            }
            if (!enabled) return false
            val list = AndroidSettings.Secure.getString(context.contentResolver, AndroidSettings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }
}

/** Último app que apareceu na frente (informado pelo serviço de acessibilidade, se estiver ligado). */
object ForegroundApp {
    private val lock = java.lang.Object()

    @Volatile
    var current: String? = null
        private set

    fun set(pkg: String) {
        synchronized(lock) {
            current = pkg
            lock.notifyAll()
        }
    }

    /** Espera (bloqueando) até o pacote aparecer na frente. Só use fora da thread principal. */
    fun awaitPackage(pkg: String, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        var found = false
        synchronized(lock) {
            var giveUp = false
            while (!giveUp) {
                if (current == pkg) {
                    found = true
                    giveUp = true
                } else {
                    val remaining = deadline - System.currentTimeMillis()
                    if (remaining <= 0) {
                        giveUp = true
                    } else {
                        try {
                            lock.wait(remaining)
                        } catch (e: InterruptedException) {
                            giveUp = true
                        }
                    }
                }
            }
        }
        return found
    }
}
