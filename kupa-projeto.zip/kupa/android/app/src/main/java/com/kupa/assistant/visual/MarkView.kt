package com.kupa.assistant.visual

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Símbolo original do KUPA (cabeçalho, carregamento). Estático: não gasta bateria. */
class MarkView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prims = CoreScene.mark()

    init {
        contentDescription = "Símbolo do KUPA"
    }

    override fun onDraw(canvas: Canvas) {
        PrimRenderer.draw(canvas, prims, width / 2f, height / 2f, minOf(width, height) * 0.5f, paint)
    }
}
