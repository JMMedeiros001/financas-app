package com.kupa.assistant.actions

import android.content.Context
import android.content.Intent
import android.provider.Settings as AndroidSettings
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.intent.AppMatcher
import com.kupa.assistant.intent.ContactMatcher
import com.kupa.assistant.intent.KupaIntent
import com.kupa.assistant.intent.LearningPlanner
import com.kupa.assistant.overlay.Notifications
import com.kupa.assistant.settings.Settings

/**
 * EXECUTOR ANDROID: recebe intenções JÁ VALIDADAS e faz a ação real. Nunca recebe texto livre da IA.
 * Cada resultado diz só o que de fato aconteceu; sem permissão ou sem como confirmar, fala isso.
 */
class ActionExecutor(
    private val context: Context,
    private val settings: Settings,
    private val ctx: ConversationContext,
    private val apps: AppLauncher,
    private val contacts: ContactResolver,
    private val phone: PhoneActions,
    private val learned: LearnedStore,
    private val callTracker: CallStateTracker,
    private val isAppForeground: () -> Boolean,
) {
    /**
     * @param fromAi veio de uma ferramenta pedida pela IA (nesse caso ações sensíveis SEMPRE pedem confirmação)
     * @param forceConfirm exige confirmação mesmo com a configuração "executar direto" (ex.: voz sem dizer "Kupa")
     */
    fun execute(intent: KupaIntent, fromAi: Boolean, forceConfirm: Boolean): ActionResult = when (intent.kind) {
        KupaIntent.Kind.OPEN_APP -> openApp(intent.appName.orEmpty())
        KupaIntent.Kind.OPEN_CHAT -> openChat(intent, fromAi || forceConfirm)
        KupaIntent.Kind.CALL_CONTACT -> callContact(intent, fromAi || forceConfirm)
        KupaIntent.Kind.WHO_IS_CALLING -> whoIsCalling()
        KupaIntent.Kind.ANSWER_CALL -> answerCall()
        KupaIntent.Kind.REJECT_CALL -> endOrReject(end = false)
        KupaIntent.Kind.END_CALL -> endOrReject(end = true)
        KupaIntent.Kind.IGNORE_CALL -> ignoreCall()
        else -> ActionResult.Failed("Esse comando não é uma ação no celular.")
    }

    // ------------------------------------------------------------------ abrir apps

    private fun canStartFromBackground(): Boolean =
        isAppForeground() || AndroidSettings.canDrawOverlays(context) || KupaAccessibilityService.running

    private fun openApp(spoken: String): ActionResult {
        val name = LearningPlanner.aliasEntity(spoken, learned.all())
        apps.systemTarget(name)?.let { return launchSystem(it) }
        val entries = apps.listApps()
        if (entries.isEmpty()) return ActionResult.Failed("Não consegui listar os aplicativos instalados neste aparelho.")
        val match = AppMatcher.resolve(name, entries)
        if (match.ambiguous) {
            val labels = match.ranked.map { it.app.label }
            return ActionResult.AskChoice("Encontrei ${joinNames(labels)}. Qual deles?", labels) { idx -> launchApp(match.ranked[idx].app) }
        }
        val chosen = match.chosen ?: return ActionResult.Failed("Não encontrei esse aplicativo instalado.")
        return launchApp(chosen.app)
    }

    private fun launchSystem(target: AppLauncher.SystemTarget): ActionResult {
        if (target.intent.resolveActivity(context.packageManager) == null) {
            return ActionResult.Failed("Não encontrei ${target.label} neste aparelho.")
        }
        return startAndVerify(target.intent, target.label, null)
    }

    private fun launchApp(app: AppMatcher.AppEntry): ActionResult {
        val intent = apps.launchIntentFor(app.packageName)
            ?: return ActionResult.Failed("O Android não deixou abrir ${app.label}.")
        val result = startAndVerify(intent, app.label, app.packageName)
        if (result is ActionResult.Done) ctx.rememberApp(app.label, app.packageName)
        return result
    }

    private fun startAndVerify(intent: Intent, label: String, pkg: String?): ActionResult {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!canStartFromBackground()) {
            Notifications.postTapToOpen(context, label, intent)
            return ActionResult.Failed(
                "Não posso abrir aplicativos com o KUPA em segundo plano sem a permissão de sobreposição ou a acessibilidade ligada. " +
                    "Deixei uma notificação: toque nela para abrir $label.",
            )
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            KupaLog.e("acoes", "não consegui abrir $label", e)
            return ActionResult.Failed("O Android não deixou abrir $label.")
        }
        if (pkg != null && KupaAccessibilityService.running) {
            return if (ForegroundApp.awaitPackage(pkg, 3000)) {
                ActionResult.Done("Abri $label.", verified = true)
            } else {
                ActionResult.Done("Pedi ao Android para abrir $label, mas não consegui confirmar que abriu.")
            }
        }
        return ActionResult.Done("Abrindo $label.")
    }

    // ------------------------------------------------------------------ contatos (ligar e abrir conversa)

    private fun withContact(rawName: String, pronoun: Boolean, then: (Long, String, Boolean) -> ActionResult): ActionResult {
        var name = rawName
        if (pronoun) name = ctx.lastContact() ?: return ActionResult.Failed("Não sei de quem você está falando. Diga o nome do contato.")
        name = LearningPlanner.aliasEntity(name, learned.all())
        if (!contacts.hasPermission()) {
            return ActionResult.Failed("Preciso da permissão de Contatos para encontrar $name. Conceda em Configurações do KUPA, em Permissões.")
        }
        val entries = contacts.loadEntries()
        if (entries.isEmpty()) return ActionResult.Failed("Não encontrei nenhum contato neste aparelho.")
        val match = ContactMatcher.resolve(name, entries)
        if (match.ambiguous) {
            val labels = match.ranked.map { describeContact(it.id, it.displayName) }
            return ActionResult.AskChoice("Encontrei ${match.ranked.size} contatos parecidos com $name: ${joinNames(labels)}. Qual deles?", labels) { idx ->
                val c = match.ranked[idx]
                then(c.id, c.displayName, false)
            }
        }
        val chosen = match.chosen ?: return ActionResult.Failed("Não encontrei nenhum contato chamado $name.")
        return then(chosen.id, chosen.displayName, match.weak)
    }

    private fun describeContact(id: Long, display: String): String {
        val first = contacts.phonesFor(id).firstOrNull() ?: return display
        val tail = first.number.filter { it.isDigit() }.takeLast(4)
        return if (tail.isEmpty()) "$display (${first.typeLabel})" else "$display (${first.typeLabel}, final $tail)"
    }

    private fun callContact(intent: KupaIntent, mustConfirm: Boolean): ActionResult =
        withContact(intent.contactName.orEmpty(), intent.pronoun) { id, display, weak ->
            val phones = contacts.phonesFor(id)
            if (phones.isEmpty()) return@withContact ActionResult.Failed("O contato $display não tem número de telefone.")
            val pick = if (phones.size == 1) phones[0] else (phones.singleOrNull { it.isPrimary } ?: phones.singleOrNull { it.isMobile })
            if (pick != null) {
                confirmAndCall(display, pick, weak, mustConfirm)
            } else {
                val labels = phones.map { "${it.typeLabel}, final ${it.number.filter { c -> c.isDigit() }.takeLast(4)}" }
                ActionResult.AskChoice("O $display tem ${phones.size} números: ${joinNames(labels)}. Qual deles?", labels) { idx ->
                    confirmAndCall(display, phones[idx], weak, mustConfirm)
                }
            }
        }

    private fun confirmAndCall(display: String, phoneEntry: ContactResolver.Phone, weak: Boolean, mustConfirm: Boolean): ActionResult {
        val needConfirm = mustConfirm || settings.confirmSensitive || weak
        if (!needConfirm) return placeCall(display, phoneEntry.number)
        val prompt = if (weak) "Não achei exatamente esse nome. O mais parecido é $display. Quer que eu faça a ligação?" else "Encontrei $display. Quer que eu faça a ligação?"
        return ActionResult.AskConfirm(prompt, { placeCall(display, phoneEntry.number) }, "Ok, não vou ligar.")
    }

    private fun placeCall(display: String, number: String): ActionResult {
        return when (phone.placeCall(number)) {
            PhoneActions.CallOutcome.PLACED -> {
                ctx.rememberContact(display)
                if (phone.canSeeCallState()) {
                    if (callTracker.awaitState(CallState.OFFHOOK, 4000)) {
                        ActionResult.Done("Ligando para $display.", verified = true)
                    } else {
                        ActionResult.Done("Pedi ao Android para ligar para $display, mas não consegui confirmar que a chamada começou.")
                    }
                } else {
                    ActionResult.Done("Pedi ao Android para ligar para $display.")
                }
            }
            PhoneActions.CallOutcome.NO_PERMISSION -> {
                if (canStartFromBackground() && phone.openDialer(number)) {
                    ctx.rememberContact(display)
                    ActionResult.Done("Não tenho permissão para ligar sozinho. Abri o discador com o número de $display; falta só tocar em ligar.")
                } else {
                    ActionResult.Failed("Preciso da permissão de Ligações para ligar para $display. Conceda em Configurações do KUPA, em Permissões.")
                }
            }
            PhoneActions.CallOutcome.FAILED -> ActionResult.Failed("O Android não conseguiu iniciar a ligação para $display.")
        }
    }

    private fun openChat(intent: KupaIntent, mustConfirm: Boolean): ActionResult {
        val appName = intent.appName ?: ctx.lastApp()?.first
            ?: return ActionResult.Failed("Em qual aplicativo? Eu só sei abrir conversas no WhatsApp.")
        val match = AppMatcher.resolve(LearningPlanner.aliasEntity(appName, learned.all()), apps.listApps())
        val app = match.chosen?.app ?: return ActionResult.Failed("Não encontrei esse aplicativo instalado.")
        val mime = when (app.packageName) {
            "com.whatsapp" -> "vnd.android.cursor.item/vnd.com.whatsapp.profile"
            "com.whatsapp.w4b" -> "vnd.android.cursor.item/vnd.com.whatsapp.w4b.profile"
            else -> return ActionResult.Failed("Só sei abrir conversas direto no WhatsApp.")
        }
        return withContact(intent.contactName.orEmpty(), intent.pronoun) { id, display, weak ->
            val uri = contacts.chatDataUri(id, mime)
                ?: return@withContact ActionResult.Failed("Não encontrei uma conversa do WhatsApp para $display nos seus contatos.")
            val open = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).setPackage(app.packageName)
            val doOpen = {
                val r = startAndVerify(open, "a conversa com $display", app.packageName)
                if (r is ActionResult.Done) {
                    ctx.rememberContact(display)
                    ctx.rememberApp(app.label, app.packageName)
                }
                r
            }
            if (weak || mustConfirm && settings.confirmSensitive) {
                ActionResult.AskConfirm("Encontrei $display. Quer que eu abra a conversa?", doOpen, "Ok, não abri.")
            } else {
                doOpen()
            }
        }
    }

    // ------------------------------------------------------------------ chamadas recebidas

    private fun whoIsCalling(): ActionResult {
        if (!phone.canSeeCallState()) {
            return ActionResult.Failed("Preciso da permissão de Estado do telefone para saber das chamadas. Conceda em Configurações do KUPA, em Permissões.")
        }
        val snap = ctx.call()
            ?: return ActionResult.Done("Não há nenhuma ligação tocando agora.")
        return when (snap.state) {
            CallState.RINGING -> ActionResult.Done(describeCaller(snap))
            CallState.OFFHOOK -> ActionResult.Done(
                if (snap.contactName != null) "Você está em uma ligação com ${snap.contactName}." else "Você está em uma ligação.",
            )
            CallState.IDLE -> {
                val recent = snap.incoming && snap.updatedAtMs > 0 && (android.os.SystemClock.elapsedRealtime() - snap.updatedAtMs) < 120_000
                if (recent && (snap.contactName != null || snap.numberKnown)) {
                    ActionResult.Done("A última ligação que recebi foi de " + (snap.contactName ?: "um número terminado em ${snap.lastDigits()}") + ".")
                } else {
                    ActionResult.Done("Não há nenhuma ligação tocando agora.")
                }
            }
        }
    }

    private fun describeCaller(snap: CallSnapshot): String {
        snap.contactName?.let { return "É $it." }
        if (snap.numberKnown) {
            return if (!contacts.hasPermission()) {
                "Não tenho a permissão de Contatos para dizer o nome. O número termina em ${snap.lastDigits()}."
            } else {
                "É um número desconhecido, terminado em ${snap.lastDigits()}."
            }
        }
        return if (!phone.canSeeCallNumbers()) {
            "Tem uma ligação tocando, mas não tenho a permissão de Registro de chamadas para ver quem é."
        } else {
            "É um número desconhecido ou oculto."
        }
    }

    private fun answerCall(): ActionResult {
        if (!phone.canAnswerCalls()) {
            return ActionResult.Failed("Preciso da permissão de Atender chamadas para fazer isso. Conceda em Configurações do KUPA, em Permissões.")
        }
        val watching = phone.canSeeCallState()
        if (watching && ctx.call()?.state != CallState.RINGING) return ActionResult.Failed("Não há ligação tocando agora.")
        if (!phone.answerRinging()) return ActionResult.Failed("O Android não deixou atender a ligação.")
        if (!watching) return ActionResult.Done("Pedi ao Android para atender a ligação.")
        return if (callTracker.awaitState(CallState.OFFHOOK, 2500)) ActionResult.Done("Atendi.", verified = true)
        else ActionResult.Done("Pedi ao Android para atender, mas não consegui confirmar.")
    }

    private fun endOrReject(end: Boolean): ActionResult {
        if (!phone.canAnswerCalls()) {
            return ActionResult.Failed("Preciso da permissão de Atender chamadas para recusar ou desligar. Conceda em Configurações do KUPA, em Permissões.")
        }
        val watching = phone.canSeeCallState()
        val state = ctx.call()?.state
        if (watching) {
            if (!end && state != CallState.RINGING) return ActionResult.Failed("Não há ligação tocando agora.")
            if (end && state != CallState.OFFHOOK && state != CallState.RINGING) return ActionResult.Failed("Não há ligação em andamento.")
        }
        val ended = phone.endCall()
            ?: return ActionResult.Failed("Esta versão do Android não permite que um aplicativo recuse ou desligue chamadas.")
        if (!ended) return ActionResult.Failed("O Android não conseguiu encerrar a ligação.")
        val doneText = if (end) "Desliguei." else "Recusei a ligação."
        if (!watching) return ActionResult.Done("Pedi ao Android para encerrar a ligação.")
        return if (callTracker.awaitState(CallState.IDLE, 2500)) ActionResult.Done(doneText, verified = true)
        else ActionResult.Done("Pedi ao Android para encerrar a ligação, mas não consegui confirmar.")
    }

    private fun ignoreCall(): ActionResult {
        if (phone.canSeeCallState() && ctx.call()?.state != CallState.RINGING) return ActionResult.Done("Não há ligação tocando agora.")
        return ActionResult.Done("Certo, deixo tocar. Não vou atender.")
    }

    private fun joinNames(items: List<String>): String = when (items.size) {
        0 -> ""
        1 -> items[0]
        else -> items.dropLast(1).joinToString(", ") + " e " + items.last()
    }
}
