package com.kupa.assistant.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Ferramentas: atalhos para as áreas que já existem no KUPA (nenhum botão é decorativo). */
class ToolsActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val column = Ui.screen(this, "Ferramentas")
        val a = Ui.section(column, "Criação e pesquisa")
        Ui.button(a, "Conteúdo: nicho, hooks, roteiros e projetos") { startActivity(Intent(this, ContentActivity::class.java)) }
        Ui.button(a, "Pesquisa rápida na internet") { startActivity(Intent(this, QuickSearchActivity::class.java)) }
        val b = Ui.section(column, "Personalização")
        Ui.button(b, "Modos do assistente") { startActivity(Intent(this, ModesActivity::class.java)) }
        Ui.button(b, "Comandos aprendidos") { startActivity(Intent(this, LearnedCommandsActivity::class.java)) }
        val c = Ui.section(column, "Registro e diagnóstico")
        Ui.button(c, "Histórico") { startActivity(Intent(this, HistoryActivity::class.java)) }
        Ui.button(c, "Diagnóstico da IA e do backend") { startActivity(Intent(this, DiagnosticsActivity::class.java)) }
    }
}
