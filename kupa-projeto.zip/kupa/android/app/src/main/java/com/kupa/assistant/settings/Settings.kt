package com.kupa.assistant.settings

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

private class BoolPref(val prefs: SharedPreferences, val key: String, val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = prefs.getBoolean(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }
}

private class IntPref(val prefs: SharedPreferences, val key: String, val def: Int) : ReadWriteProperty<Any?, Int> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Int = prefs.getInt(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }
}

private class StrPref(val prefs: SharedPreferences, val key: String, val def: String) : ReadWriteProperty<Any?, String> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): String = prefs.getString(key, def) ?: def
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
        prefs.edit().putString(key, value).apply()
    }
}

/**
 * Segredo guardado CIFRADO (AES-GCM, chave no Android Keystore). Se a cifra falhar, o valor fica só na memória
 * (some ao fechar o app) em vez de ir para o disco em texto puro. Migra o valor antigo em texto puro, se existir.
 */
private class SecretPref(val prefs: SharedPreferences, val key: String) : ReadWriteProperty<Any?, String> {
    private var memory: String? = null

    override fun getValue(thisRef: Any?, property: KProperty<*>): String {
        memory?.let { return it }
        val encrypted = prefs.getString("${key}_enc", null)
        if (encrypted != null) {
            val plain = com.kupa.assistant.actions.SecureStore.decrypt(encrypted)
            if (plain != null) {
                memory = plain
                return plain
            }
        }
        val legacy = prefs.getString(key, null)
        if (!legacy.isNullOrEmpty()) { // versão antiga guardava em texto puro: cifra e apaga o antigo
            setValue(thisRef, property, legacy)
            return legacy
        }
        return ""
    }

    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
        memory = value
        val editor = prefs.edit().remove(key)
        val encrypted = if (value.isEmpty()) "" else com.kupa.assistant.actions.SecureStore.encrypt(value)
        if (value.isEmpty()) editor.remove("${key}_enc") else if (encrypted != null) editor.putString("${key}_enc", encrypted) else editor.remove("${key}_enc")
        editor.apply()
    }
}

/** Todas as configurações do app. A chave da OpenAI NUNCA fica aqui: ela vive só no backend. */
class Settings(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("kupa_settings", Context.MODE_PRIVATE)
    private val listeners = ArrayList<SharedPreferences.OnSharedPreferenceChangeListener>()

    // ---- escuta e ações no celular ----
    /** "wake" = ativação por "Kupa" (um comando por vez); "continuous" = escuta contínua. */
    var listenMode by StrPref(prefs, "listenMode", "wake")
    /** true: ações sensíveis (ligar) pedem confirmação; false: executa direto quando o Android permitir. */
    var confirmSensitive by BoolPref(prefs, "confirmSensitive", true)
    /** Modo contínuo: frases soltas (sem comando de celular) também vão para a IA. Desligado por padrão (privacidade e custo). */
    var continuousFreeText by BoolPref(prefs, "continuousFreeText", false)
    /** Modo contínuo: pausa sozinho depois de X minutos sem comandos (0 = nunca). */
    var continuousIdleMinutes by IntPref(prefs, "continuousIdleMinutes", 10)
    var pauseWhenScreenOff by BoolPref(prefs, "pauseWhenScreenOff", true)
    var preferOfflineRecognition by BoolPref(prefs, "preferOfflineRecognition", true)

    // ---- identidade do assistente (nome e palavra de ativação) ----
    /** Nome mostrado e enviado à IA. Vazio = KUPA. */
    var assistantName by StrPref(prefs, "assistantName", "")
    /** Palavra de ativação (uma palavra, sem acento). Vazio = kupa. */
    var activationName by StrPref(prefs, "activationName", "")
    var customVariants by StrPref(prefs, "customVariants", "")
    var learnedVariants by StrPref(prefs, "learnedVariants", "")
    var disabledVariants by StrPref(prefs, "disabledVariants", "")
    var variantCandidates by StrPref(prefs, "variantCandidates", "")
    var ignoredCandidates by StrPref(prefs, "ignoredCandidates", "")

    // ---- voz e bipe: controles INDEPENDENTES ----
    /** Silencia (por janelas curtas e seguras) o bipe do reconhecimento de voz. Não afeta as respostas faladas do KUPA. */
    var muteMicBeep by BoolPref(prefs, "muteMicBeep", false)
    /** Falar as respostas em voz alta. Desligado = o KUPA só mostra o texto, mas continua ouvindo. Independe do bipe. */
    var speakResponses by BoolPref(prefs, "speakResponses", true)
    /** Estilo descontraído (personalidade de Popol e Kupa). Desligado = respostas neutras e objetivas. */
    var casualStyle by BoolPref(prefs, "casualStyle", true)

    // ---- provedor de IA ----
    /** auto, openai, anthropic ou gemini. */
    var aiProvider by StrPref(prefs, "aiProvider", "auto")
    /** Só com autorização explícita o KUPA usa outro provedor quando o escolhido falha (padrão: desligado, por privacidade). */
    var aiFallbackAllowed by BoolPref(prefs, "aiFallbackAllowed", false)

    // ---- modos, proatividade, desempenho e privacidade ----
    var activeModeId by StrPref(prefs, "activeModeId", "")
    /** Proatividade global: OFF, LOW, MEDIUM ou HIGH. */
    var proactivity by StrPref(prefs, "proactivity", "OFF")
    /** Perfil de desempenho: AUTO ou um dos perfis do PerformanceProfile. */
    var performanceProfile by StrPref(prefs, "performanceProfile", "AUTO")
    /** Apps (um por linha) onde o KUPA não analisa a tela, além dos padrões (bancos, senhas, autenticadores...). */
    var privacyZones by StrPref(prefs, "privacyZones", "")

    // ---- voz ----
    /** VOZ ATIVADA/DESATIVADA: liga juntos microfone, reconhecimento de fala e resposta por voz. */
    var voiceEnabled by BoolPref(prefs, "voiceEnabled", true)
    var wakeListening by BoolPref(prefs, "wakeListening", true)
    var wakeAcceptVariants by BoolPref(prefs, "wakeAcceptVariants", true)
    var volumePercent by IntPref(prefs, "volumePercent", 80)
    var pitchPercent by IntPref(prefs, "pitchPercent", 115)
    var ratePercent by IntPref(prefs, "ratePercent", 105)
    var ttsVoiceName by StrPref(prefs, "ttsVoiceName", "")

    // ---- personagem / interface ----
    var overlayEnabled by BoolPref(prefs, "overlayEnabled", true)
    var sizeDp by IntPref(prefs, "sizeDp", 150)
    var alphaPercent by IntPref(prefs, "alphaPercent", 100)
    var alwaysOnTop by BoolPref(prefs, "alwaysOnTop", true)
    var autoPosition by BoolPref(prefs, "autoPosition", true)
    var showBubble by BoolPref(prefs, "showBubble", true)
    var animationsEnabled by BoolPref(prefs, "animationsEnabled", true)
    var posX by IntPref(prefs, "posX", -1)
    var posY by IntPref(prefs, "posY", -1)

    // ---- tela ----
    var screenAnalysisEnabled by BoolPref(prefs, "screenAnalysisEnabled", false)

    // ---- IA ----
    var backendUrl by StrPref(prefs, "backendUrl", "")
    var appToken by SecretPref(prefs, "appToken")
    var webSearchAllowed by BoolPref(prefs, "webSearchAllowed", true)

    // ---- modo gamer ----
    var gamerHideCharacter by BoolPref(prefs, "gamerHideCharacter", true)
    var gamerKeepVoice by BoolPref(prefs, "gamerKeepVoice", true)
    var gamerKeepSearch by BoolPref(prefs, "gamerKeepSearch", true)
    var gamerAllowScreen by BoolPref(prefs, "gamerAllowScreen", true)
    var gamerQuickAnswers by BoolPref(prefs, "gamerQuickAnswers", true)
    var gamerVolumePercent by IntPref(prefs, "gamerVolumePercent", 80)
    /** "continuous" = continua escutando "Kupa"; "paused" = microfone desligado até tocar em "Falar" na notificação. */
    var gamerMicMode by StrPref(prefs, "gamerMicMode", "continuous")
    var gamerRestorePosition by BoolPref(prefs, "gamerRestorePosition", true)
    var gamerShowBubble by BoolPref(prefs, "gamerShowBubble", false)
    var gamerNotify by BoolPref(prefs, "gamerNotify", true)
    var gamerSessionContext by BoolPref(prefs, "gamerSessionContext", true)

    // ---- guardado ao entrar no modo gamer, para restaurar ao sair ----
    var savedPosX by IntPref(prefs, "savedPosX", -1)
    var savedPosY by IntPref(prefs, "savedPosY", -1)
    var savedSizeDp by IntPref(prefs, "savedSizeDp", -1)
    var savedAlphaPercent by IntPref(prefs, "savedAlphaPercent", -1)

    /** Registra um ouvinte de mudanças. Devolve uma função que o REMOVE (chame ao encerrar quem registrou, para não vazar). */
    fun onChange(listener: () -> Unit): () -> Unit {
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> listener() }
        listeners.add(l) // referência forte: o Android só guarda fraca
        prefs.registerOnSharedPreferenceChangeListener(l)
        return {
            prefs.unregisterOnSharedPreferenceChangeListener(l)
            listeners.remove(l)
        }
    }
}
