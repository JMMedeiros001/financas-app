package com.kupa.assistant.settings

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

private class BoolPref(val prefs: SharedPreferences, val key: String, val def: Boolean) : ReadWriteProperty<Any?, Boolean> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = prefs.getBoolean(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }
}

private class IntPref(val prefs: SharedPreferences, val key: String, val def: Int) : ReadWriteProperty<Any?, Int> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): Int = prefs.getInt(key, def)
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }
}

private class StrPref(val prefs: SharedPreferences, val key: String, val def: String) : ReadWriteProperty<Any?, String> {
    override fun getValue(thisRef: Any?, property: KProperty<*>): String = prefs.getString(key, def) ?: def
    override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) {
        prefs.edit().putString(key, value).apply()
    }
}

/** Todas as configurações do app. A chave da OpenAI NUNCA fica aqui: ela vive só no backend. */
class Settings(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("kupa_settings", Context.MODE_PRIVATE)
    private val listeners = ArrayList<SharedPreferences.OnSharedPreferenceChangeListener>()

    // ---- voz ----
    /** VOZ ATIVADA/DESATIVADA: liga juntos microfone, reconhecimento de fala e resposta por voz. */
    var voiceEnabled by BoolPref(prefs, "voiceEnabled", true)
    var wakeListening by BoolPref(prefs, "wakeListening", true)
    var wakeAcceptVariants by BoolPref(prefs, "wakeAcceptVariants", true)
    var volumePercent by IntPref(prefs, "volumePercent", 80)
    var pitchPercent by IntPref(prefs, "pitchPercent", 115)
    var ratePercent by IntPref(prefs, "ratePercent", 105)
    var ttsVoiceName by StrPref(prefs, "ttsVoiceName", "")

    // ---- personagem / interface ----
    var overlayEnabled by BoolPref(prefs, "overlayEnabled", true)
    var sizeDp by IntPref(prefs, "sizeDp", 150)
    var alphaPercent by IntPref(prefs, "alphaPercent", 100)
    var alwaysOnTop by BoolPref(prefs, "alwaysOnTop", true)
    var autoPosition by BoolPref(prefs, "autoPosition", true)
    var showBubble by BoolPref(prefs, "showBubble", true)
    var animationsEnabled by BoolPref(prefs, "animationsEnabled", true)
    var posX by IntPref(prefs, "posX", -1)
    var posY by IntPref(prefs, "posY", -1)

    // ---- tela ----
    var screenAnalysisEnabled by BoolPref(prefs, "screenAnalysisEnabled", false)

    // ---- IA ----
    var backendUrl by StrPref(prefs, "backendUrl", "")
    var appToken by StrPref(prefs, "appToken", "")
    var webSearchAllowed by BoolPref(prefs, "webSearchAllowed", true)

    // ---- modo gamer ----
    var gamerHideCharacter by BoolPref(prefs, "gamerHideCharacter", true)
    var gamerKeepVoice by BoolPref(prefs, "gamerKeepVoice", true)
    var gamerKeepSearch by BoolPref(prefs, "gamerKeepSearch", true)
    var gamerAllowScreen by BoolPref(prefs, "gamerAllowScreen", true)
    var gamerQuickAnswers by BoolPref(prefs, "gamerQuickAnswers", true)
    var gamerVolumePercent by IntPref(prefs, "gamerVolumePercent", 80)
    /** "continuous" = continua escutando "Kupa"; "paused" = microfone desligado até tocar em "Falar" na notificação. */
    var gamerMicMode by StrPref(prefs, "gamerMicMode", "continuous")
    var gamerRestorePosition by BoolPref(prefs, "gamerRestorePosition", true)
    var gamerShowBubble by BoolPref(prefs, "gamerShowBubble", false)
    var gamerNotify by BoolPref(prefs, "gamerNotify", true)
    var gamerSessionContext by BoolPref(prefs, "gamerSessionContext", true)

    // ---- guardado ao entrar no modo gamer, para restaurar ao sair ----
    var savedPosX by IntPref(prefs, "savedPosX", -1)
    var savedPosY by IntPref(prefs, "savedPosY", -1)
    var savedSizeDp by IntPref(prefs, "savedSizeDp", -1)
    var savedAlphaPercent by IntPref(prefs, "savedAlphaPercent", -1)

    fun onChange(listener: () -> Unit) {
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> listener() }
        listeners.add(l) // referência forte: o Android só guarda fraca
        prefs.registerOnSharedPreferenceChangeListener(l)
    }
}
