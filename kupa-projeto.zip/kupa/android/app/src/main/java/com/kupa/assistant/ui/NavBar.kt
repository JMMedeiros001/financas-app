package com.kupa.assistant.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import com.kupa.assistant.visual.Palette

/** Navegação inferior: Início, Conversas, Pesquisa, Ferramentas, Configurações (as telas que já existem; nada decorativo). */
object NavBar {
    enum class Tab(val label: String) {
        HOME("Início"), CHAT("Conversas"), SEARCH("Pesquisa"), TOOLS("Ferramentas"), SETTINGS("Configurações")
    }

    fun currentFor(activity: Activity): Tab = when (activity) {
        is MainActivity -> Tab.HOME
        is ChatActivity -> Tab.CHAT
        is QuickSearchActivity -> Tab.SEARCH
        is SettingsActivity, is DiagnosticsActivity -> Tab.SETTINGS
        else -> Tab.TOOLS // Ferramentas, Modos, Conteúdo, Histórico, Comandos aprendidos
    }

    private fun target(tab: Tab): Class<out Activity> = when (tab) {
        Tab.HOME -> MainActivity::class.java
        Tab.CHAT -> ChatActivity::class.java
        Tab.SEARCH -> QuickSearchActivity::class.java
        Tab.TOOLS -> ToolsActivity::class.java
        Tab.SETTINGS -> SettingsActivity::class.java
    }

    fun go(activity: Activity, tab: Tab) {
        if (tab == currentFor(activity)) return
        val intent = Intent(activity, target(tab))
        if (tab == Tab.HOME) intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        activity.startActivity(intent)
    }

    fun build(activity: Activity): View {
        val ctx: Context = activity
        val current = currentFor(activity)
        val bar = LinearLayout(ctx)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.background = Ui.rounded(ctx, Palette.DEEP_BLUE, 0, Ui.EDGE)
        bar.setPadding(Ui.dp(ctx, 4), Ui.dp(ctx, 6), Ui.dp(ctx, 4), Ui.dp(ctx, 6))
        for (tab in Tab.values()) {
            val selected = tab == current
            val item = LinearLayout(ctx)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER
            item.minimumHeight = Ui.dp(ctx, 56)
            item.contentDescription = tab.label + if (selected) ", tela atual" else ""
            val icon = NavIconView(ctx, tab, if (selected) Palette.CYAN else Palette.MUTED)
            item.addView(icon, LinearLayout.LayoutParams(Ui.dp(ctx, 26), Ui.dp(ctx, 26)))
            val label = TextView(ctx)
            label.text = tab.label
            label.textSize = 10.5f
            label.gravity = Gravity.CENTER
            label.maxLines = 1
            label.setTextColor(if (selected) Palette.CYAN else Palette.MUTED)
            item.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            item.setOnClickListener { go(activity, tab) }
            bar.addView(item, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        Ui.padBottomForSystemBars(bar)
        return bar
    }
}

/** Ícones vetoriais simples e consistentes (traço de 2 dp), desenhados no Canvas. */
class NavIconView(context: Context, private val tab: NavBar.Tab, private val color: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO // o rótulo do item já descreve
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.STROKE
        paint.color = color
        paint.strokeWidth = 2f * resources.displayMetrics.density
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        when (tab) {
            NavBar.Tab.HOME -> {
                path.reset()
                path.moveTo(w * 0.12f, h * 0.50f)
                path.lineTo(w * 0.50f, h * 0.14f)
                path.lineTo(w * 0.88f, h * 0.50f)
                path.moveTo(w * 0.22f, h * 0.44f)
                path.lineTo(w * 0.22f, h * 0.86f)
                path.lineTo(w * 0.78f, h * 0.86f)
                path.lineTo(w * 0.78f, h * 0.44f)
                canvas.drawPath(path, paint)
            }
            NavBar.Tab.CHAT -> {
                rect.set(w * 0.10f, h * 0.16f, w * 0.90f, h * 0.68f)
                canvas.drawRoundRect(rect, w * 0.12f, w * 0.12f, paint)
                path.reset()
                path.moveTo(w * 0.32f, h * 0.68f)
                path.lineTo(w * 0.28f, h * 0.88f)
                path.lineTo(w * 0.52f, h * 0.68f)
                canvas.drawPath(path, paint)
            }
            NavBar.Tab.SEARCH -> {
                canvas.drawCircle(w * 0.44f, h * 0.44f, w * 0.27f, paint)
                canvas.drawLine(w * 0.64f, h * 0.64f, w * 0.88f, h * 0.88f, paint)
            }
            NavBar.Tab.TOOLS -> {
                val s = w * 0.34f
                val g = w * 0.10f
                for (i in 0..1) for (j in 0..1) {
                    val x = w * 0.12f + i * (s + g)
                    val y = h * 0.12f + j * (s + g)
                    rect.set(x, y, x + s, y + s)
                    canvas.drawRoundRect(rect, w * 0.06f, w * 0.06f, paint)
                }
            }
            NavBar.Tab.SETTINGS -> {
                canvas.drawCircle(w * 0.5f, h * 0.5f, w * 0.16f, paint)
                for (k in 0 until 8) {
                    val a = Math.toRadians(k * 45.0)
                    val c = Math.cos(a).toFloat()
                    val s2 = Math.sin(a).toFloat()
                    canvas.drawLine(w * 0.5f + c * w * 0.28f, h * 0.5f + s2 * h * 0.28f, w * 0.5f + c * w * 0.40f, h * 0.5f + s2 * h * 0.40f, paint)
                }
            }
        }
    }
}
