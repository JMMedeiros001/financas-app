package com.kupa.assistant.ai

import com.kupa.assistant.BuildConfig

/**
 * Regra de segurança da URL do backend (a lógica fica em [BackendUrlValidator], testada em Java puro).
 * Produção: só HTTPS e só endereço remoto real. Build DEBUG: HTTP apenas para rede local explícita.
 * Erros de certificado TLS NUNCA são ignorados.
 */
object BackendUrlPolicy {
    fun check(url: String): BackendUrlValidator.Result = BackendUrlValidator.validate(url, BuildConfig.DEBUG)

    fun isAllowed(url: String): Boolean = check(url).ok()
}
