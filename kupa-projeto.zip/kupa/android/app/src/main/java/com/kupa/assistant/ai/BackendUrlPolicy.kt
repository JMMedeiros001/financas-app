package com.kupa.assistant.ai

import java.net.URI

/**
 * Regra de segurança: HTTPS vale para qualquer endereço; HTTP puro só para rede local/privada
 * (para o token e as perguntas não trafegarem sem criptografia pela internet).
 */
object BackendUrlPolicy {
    fun isAllowed(url: String): Boolean {
        val uri = try {
            URI(url.trim())
        } catch (e: Exception) {
            return false
        }
        val scheme = uri.scheme?.lowercase() ?: return false
        val host = uri.host?.lowercase() ?: return false
        if (scheme == "https") return true
        if (scheme != "http") return false
        return isPrivateHost(host)
    }

    private fun isPrivateHost(host: String): Boolean {
        if (host == "localhost" || host == "10.0.2.2" || host.endsWith(".local")) return true
        val parts = host.split('.')
        if (parts.size != 4) return false
        val nums = ArrayList<Int>()
        for (p in parts) {
            val n = p.toIntOrNull()
            if (n == null || n < 0 || n > 255) return false
            nums.add(n)
        }
        val a = nums[0]
        val b = nums[1]
        return a == 10 || a == 127 || (a == 192 && b == 168) || (a == 172 && b in 16..31) || (a == 100 && b in 64..127)
    }

    const val REJECTED_MESSAGE =
        "Use HTTPS, ou HTTP apenas com um endereço da rede local (ex.: http://192.168.0.10:8787)."
}
