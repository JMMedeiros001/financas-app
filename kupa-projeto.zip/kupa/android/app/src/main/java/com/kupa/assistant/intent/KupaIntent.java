package com.kupa.assistant.intent;

/** Intenção estruturada: o que o usuário pediu, já validado. A IA/voz INTERPRETA; só o executor Android AGE. */
public final class KupaIntent {
    public enum Kind {
        OPEN_APP, OPEN_CHAT, CALL_CONTACT, WHO_IS_CALLING, ANSWER_CALL, REJECT_CALL, END_CALL, IGNORE_CALL,
        LEARN, FORGET, LIST_LEARNED
    }

    public final Kind kind;
    /** App pedido (OPEN_APP) ou app da conversa (OPEN_CHAT, pode ser null). */
    public final String appName;
    /** Contato pedido (CALL_CONTACT, OPEN_CHAT). */
    public final String contactName;
    /** true quando o usuário disse "ele/ela" (resolver pelo contexto). */
    public final boolean pronoun;
    /** LEARN: frase gatilho; FORGET: gatilho a esquecer. */
    public final String trigger;
    /** LEARN: significado dito pelo usuário. */
    public final String meaning;

    private KupaIntent(Kind kind, String appName, String contactName, boolean pronoun, String trigger, String meaning) {
        this.kind = kind;
        this.appName = appName;
        this.contactName = contactName;
        this.pronoun = pronoun;
        this.trigger = trigger;
        this.meaning = meaning;
    }

    public static KupaIntent openApp(String app) { return new KupaIntent(Kind.OPEN_APP, app, null, false, null, null); }
    public static KupaIntent openChat(String contact, boolean pronoun, String app) { return new KupaIntent(Kind.OPEN_CHAT, app, contact, pronoun, null, null); }
    public static KupaIntent callContact(String contact, boolean pronoun) { return new KupaIntent(Kind.CALL_CONTACT, null, contact, pronoun, null, null); }
    public static KupaIntent simple(Kind kind) { return new KupaIntent(kind, null, null, false, null, null); }
    public static KupaIntent learn(String trigger, String meaning) { return new KupaIntent(Kind.LEARN, null, null, false, trigger, meaning); }
    public static KupaIntent forget(String trigger) { return new KupaIntent(Kind.FORGET, null, null, false, trigger, null); }

    public KupaIntent withApp(String app) { return new KupaIntent(kind, app, contactName, pronoun, trigger, meaning); }
    public KupaIntent withContact(String contact, boolean isPronoun) { return new KupaIntent(kind, appName, contact, isPronoun, trigger, meaning); }

    /** Ações que mexem com o mundo real e pedem confirmação quando a configuração exige. */
    public boolean isSensitive() { return kind == Kind.CALL_CONTACT; }

    /** Comandos padrão que o aprendizado NÃO pode redefinir. */
    public boolean isProtected() {
        switch (kind) {
            case OPEN_APP:
            case OPEN_CHAT:
            case CALL_CONTACT:
                return false;
            default:
                return true;
        }
    }

    @Override public String toString() {
        return kind + "(app=" + appName + ", contact=" + contactName + (pronoun ? ", pronome" : "") + (trigger != null ? ", gatilho=" + trigger : "") + (meaning != null ? ", significado=" + meaning : "") + ")";
    }

    @Override public boolean equals(Object o) {
        if (!(o instanceof KupaIntent)) return false;
        KupaIntent k = (KupaIntent) o;
        return kind == k.kind && eq(appName, k.appName) && eq(contactName, k.contactName) && pronoun == k.pronoun && eq(trigger, k.trigger) && eq(meaning, k.meaning);
    }

    @Override public int hashCode() { return toString().hashCode(); }

    private static boolean eq(String a, String b) { return a == null ? b == null : a.equals(b); }
}
