package com.kupa.assistant.actions

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.intent.ContactMatcher

/** Consulta os contatos do aparelho (precisa da permissão Contatos). Nunca inventa nome nem número. */
class ContactResolver(private val context: Context) {
    class Phone(val number: String, val typeLabel: String, val isMobile: Boolean, val isPrimary: Boolean)

    fun hasPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    /** Só id e nome (leve). Os números são buscados depois, apenas do contato escolhido. */
    fun loadEntries(): List<ContactMatcher.ContactEntry> {
        if (!hasPermission()) return emptyList()
        val out = ArrayList<ContactMatcher.ContactEntry>()
        try {
            context.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY),
                null, null, null,
            )?.use { c ->
                val idIdx = c.getColumnIndex(ContactsContract.Contacts._ID)
                val nameIdx = c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME_PRIMARY)
                while (c.moveToNext()) {
                    val name = c.getString(nameIdx)?.trim().orEmpty()
                    if (name.isNotEmpty()) out.add(ContactMatcher.ContactEntry(c.getLong(idIdx), name))
                }
            }
        } catch (e: Exception) {
            KupaLog.e("contatos", "falha ao ler contatos", e)
        }
        return out
    }

    fun phonesFor(contactId: Long): List<Phone> {
        if (!hasPermission()) return emptyList()
        val out = ArrayList<Phone>()
        val seen = HashSet<String>()
        try {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.NUMBER,
                    ContactsContract.CommonDataKinds.Phone.TYPE,
                    ContactsContract.CommonDataKinds.Phone.LABEL,
                    ContactsContract.CommonDataKinds.Phone.IS_PRIMARY,
                ),
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?", arrayOf(contactId.toString()), null,
            )?.use { c ->
                while (c.moveToNext()) {
                    val number = c.getString(0)?.trim().orEmpty()
                    if (number.isEmpty()) continue
                    val digits = number.filter { it.isDigit() }
                    if (!seen.add(digits)) continue
                    val type = c.getInt(1)
                    val custom = c.getString(2)
                    val label = ContactsContract.CommonDataKinds.Phone.getTypeLabel(context.resources, type, custom)?.toString().orEmpty()
                    out.add(Phone(number, label.ifEmpty { "telefone" }, type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE, c.getInt(3) != 0))
                }
            }
        } catch (e: Exception) {
            KupaLog.e("contatos", "falha ao ler telefones", e)
        }
        return out
    }

    /** Linha de dados do WhatsApp (mimetype ...profile) do contato, usada para abrir a conversa. null se não existir. */
    fun chatDataUri(contactId: Long, mimeType: String): Uri? {
        if (!hasPermission()) return null
        try {
            context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                arrayOf(ContactsContract.Data._ID),
                ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?",
                arrayOf(contactId.toString(), mimeType), null,
            )?.use { c ->
                if (c.moveToFirst()) return ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, c.getLong(0))
            }
        } catch (e: Exception) {
            KupaLog.e("contatos", "falha ao procurar conversa", e)
        }
        return null
    }

    /** Nome do contato dono de um número (para dizer quem está ligando). */
    fun nameForNumber(number: String): String? {
        if (!hasPermission() || number.isEmpty()) return null
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            context.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)?.trim()?.ifEmpty { null }
            }
        } catch (e: Exception) {
            KupaLog.e("contatos", "falha ao procurar o número", e)
        }
        return null
    }
}
