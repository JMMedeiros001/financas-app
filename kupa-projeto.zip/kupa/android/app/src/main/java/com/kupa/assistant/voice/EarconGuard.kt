package com.kupa.assistant.voice

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.settings.Settings

/**
 * Botão "Silenciar bipe do microfone".
 *
 * O bipe do reconhecimento de voz é tocado pelo serviço de reconhecimento do aparelho (não pelo KUPA) e o Android não tem opção
 * oficial para desligá-lo. A alternativa segura implementada: silenciar por uma JANELA CURTA o canal de mídia em volta do início/fim
 * da escuta (a lógica e as proteções estão em [EarconGuardCore], testada): só com a preferência ligada, nunca com outro app tocando
 * mídia, sem mexer no nível de volume, sem permissões especiais e sempre desfeito (antes de o KUPA falar e ao encerrar).
 * LIMITE: se o seu aparelho toca o bipe por outro canal (notificação/sistema) o botão não consegue silenciá-lo sem uma permissão especial.
 */
class EarconGuard(context: Context, private val settings: Settings) {
    private val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val prefs = context.getSharedPreferences("kupa_earcon", Context.MODE_PRIVATE)
    private val main = Handler(Looper.getMainLooper())

    private val logic = EarconGuardCore(
        object : EarconGuardCore.Audio {
            override fun isMusicActive(): Boolean = audio.isMusicActive

            override fun isMusicMuted(): Boolean = audio.isStreamMute(AudioManager.STREAM_MUSIC)

            override fun muteMusic(): Boolean {
                return try {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                    true
                } catch (e: Exception) {
                    KupaLog.w("bipe", "o Android recusou silenciar a mídia: ${e.message}")
                    false
                }
            }

            override fun unmuteMusic() {
                try {
                    audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e: Exception) {
                    KupaLog.w("bipe", "não consegui desfazer o mudo: ${e.message}")
                }
            }
        },
        object : EarconGuardCore.Store {
            override fun mutedByUs(): Boolean = prefs.getBoolean(KEY, false)

            override fun setMutedByUs(value: Boolean) {
                prefs.edit().putBoolean(KEY, value).commit() // síncrono: a marca precisa existir ANTES do mudo
            }
        },
    )

    /** Silencia o canal de mídia por [durationMs] (se a preferência estiver ligada e for seguro). Chame na thread principal. */
    fun muteWindow(durationMs: Long) {
        val w = logic.request(settings.muteMicBeep, durationMs)
        if (w.muting) {
            val epoch = w.epoch
            main.postDelayed({ logic.onWindowEnd(epoch) }, w.durationMs)
        }
    }

    /** Desfaz o mudo AGORA (antes de o KUPA falar e ao encerrar). */
    fun release() {
        logic.release()
    }

    /** Ao iniciar o app: desfaz um mudo que o KUPA deixou para trás se o processo morreu no meio de uma janela. */
    fun recoverAfterCrash() {
        logic.recoverAfterCrash()
    }

    companion object {
        private const val KEY = "mutedByUs"

        /** Antes de abrir o reconhecedor (cobre o bipe de início). */
        const val START_MS = 1500L

        /** Quando o reconhecedor avisa que está pronto. */
        const val READY_MS = 700L

        /** No fim da fala, no resultado ou no erro (cobre o bipe de fim). */
        const val END_MS = 900L
    }
}
