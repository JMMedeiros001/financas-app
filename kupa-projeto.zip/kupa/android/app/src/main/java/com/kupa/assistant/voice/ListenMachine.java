package com.kupa.assistant.voice;

/**
 * Máquina de estados da escuta (palavra-chave e comando). Lógica PURA, sem Android: o VoiceController só executa os passos que ela manda.
 * É a ÚNICA autoridade sobre "pode iniciar o microfone agora?".
 *
 * Garantias (testadas em tools/jvmtests/ListenMachineTests.java):
 *  - no máximo UM reconhecedor válido por vez (cada início ganha um token novo; callbacks e temporizadores de tokens antigos são IGNORADOS);
 *  - desativar invalida tudo na mesma chamada: nenhum callback ou temporizador antigo consegue reiniciar a escuta;
 *  - pedidos repetidos de início são idempotentes;
 *  - falhas recuperáveis têm limite (MAX_RECOVERABLE_FAILURES): depois disso o estado é ERROR e só uma ação do usuário reinicia;
 *  - preferência do usuário vence qualquer recuperação.
 */
public final class ListenMachine {
    public enum State { DISABLED, WAITING_PERMISSION, STARTING, LISTENING, COMMAND, STOPPING, SUSPENDED, ERROR, UNAVAILABLE }

    public enum Cmd { NONE, START_WAKE, START_COMMAND, STOP, RESTART_LATER }

    /** Como um ciclo do reconhecedor terminou. */
    public enum Outcome { NO_SPEECH, HEARD_NO_WAKE, FAIL_RECOVERABLE, FAIL_PERMISSION, FAIL_UNAVAILABLE }

    public static final int MAX_RECOVERABLE_FAILURES = 5;
    public static final long NORMAL_RESTART_MS = 200L;
    private static final long[] BACKOFF_MS = {400L, 1000L, 2500L, 5000L, 8000L};

    /** O que o Android deve fazer agora. */
    public static final class Step {
        public final Cmd cmd;
        /** START_*: token do reconhecedor a iniciar. RESTART_LATER: token do temporizador a agendar. */
        public final long token;
        public final long delayMs;
        /** O Android deve cancelar qualquer temporizador de reinício pendente. */
        public final boolean cancelTimer;
        /** O evento era de uma sessão antiga e foi ignorado. */
        public final boolean stale;
        public final State previous;
        public final State state;
        public final String reason;

        Step(Cmd cmd, long token, long delayMs, boolean cancelTimer, boolean stale, State previous, State state, String reason) {
            this.cmd = cmd;
            this.token = token;
            this.delayMs = delayMs;
            this.cancelTimer = cancelTimer;
            this.stale = stale;
            this.previous = previous;
            this.state = state;
            this.reason = reason;
        }

        public boolean stateChanged() { return previous != state; }
    }

    private State state = State.DISABLED;
    private String reason = "desativada";
    private long token = 0L;          // reconhecedor da palavra-chave VÁLIDO (0 = nenhum)
    private long commandToken = 0L;   // reconhecedor de comando VÁLIDO (0 = nenhum)
    private long pendingTimer = 0L;   // temporizador de reinício VÁLIDO (0 = nenhum)
    private long nextToken = 1L;
    private int failures = 0;
    private boolean lastWanted = false;

    // ------------------------------------------------------------------ consultas

    public synchronized State state() { return state; }

    public synchronized String reason() { return reason; }

    public synchronized int failures() { return failures; }

    /** O microfone está REALMENTE em uso (o reconhecedor avisou que está pronto, ou um comando está sendo ouvido). */
    public synchronized boolean micOpen() { return state == State.LISTENING || state == State.COMMAND; }

    public synchronized boolean isCurrentWake(long t) { return t != 0L && t == token; }

    public synchronized boolean isCurrentCommand(long t) { return t != 0L && t == commandToken && state == State.COMMAND; }

    public synchronized boolean hasValidSession() { return token != 0L || commandToken != 0L; }

    public synchronized boolean hasPendingTimer() { return pendingTimer != 0L; }

    // ------------------------------------------------------------------ reconciliação com o mundo real

    /**
     * Compara o que o usuário quer com o que é possível agora e devolve UM passo. Idempotente: chamar várias vezes seguidas com as
     * mesmas entradas não cria uma segunda sessão.
     *
     * @param wanted     preferência do usuário: palavra-chave habilitada, voz ligada, escuta não pausada
     * @param permission permissão de microfone concedida
     * @param available  o reconhecimento de fala existe neste aparelho
     * @param allowedNow condições momentâneas (tela, jogo, estado do assistente) permitem escutar
     */
    public synchronized Step reconcile(boolean wanted, boolean permission, boolean available, boolean allowedNow) {
        boolean enableEdge = wanted && !lastWanted;
        lastWanted = wanted;
        if (state == State.COMMAND) return noop("comando em andamento");
        if (!wanted) return stopTo(State.DISABLED, "desativada pelo usuário");
        if (enableEdge) failures = 0; // o usuário (re)ativou: recomeça a política de recuperação
        if (!permission) return stopTo(State.WAITING_PERMISSION, "falta a permissão do microfone");
        if (!available) return stopTo(State.UNAVAILABLE, "o reconhecimento de voz não está disponível");
        if (state == State.ERROR && !enableEdge) return noop(reason);
        if (!allowedNow) return stopTo(State.SUSPENDED, "pausada por uma condição momentânea");
        if (state == State.STARTING || state == State.LISTENING) return noop(reason);
        State prev = state;
        token = nextToken++;
        pendingTimer = 0L;
        state = State.STARTING;
        reason = "iniciando";
        return new Step(Cmd.START_WAKE, token, 0L, false, false, prev, state, reason);
    }

    /** O reconhecedor avisou que está pronto para ouvir. */
    public synchronized Step onReady(long t) {
        if (!isCurrentWake(t)) return stale();
        if (state == State.STARTING) {
            State prev = state;
            state = State.LISTENING;
            reason = "ouvindo";
            return new Step(Cmd.NONE, 0L, 0L, false, false, prev, state, reason);
        }
        return noop(reason);
    }

    /** A palavra de ativação foi detectada (ou o comando contínuo foi aceito): o reconhecedor entrega o microfone. */
    public synchronized Step onWakeDetected(long t) {
        if (!isCurrentWake(t)) return stale();
        return stopTo(State.SUSPENDED, "aguardando o comando");
    }

    /** Um ciclo do reconhecedor terminou. */
    public synchronized Step onCycleEnd(long t, Outcome outcome) {
        if (!isCurrentWake(t)) return stale();
        State prev = state;
        token = 0L; // este ciclo acabou: callbacks dele não valem mais
        switch (outcome) {
            case NO_SPEECH:
            case HEARD_NO_WAKE:
                failures = 0;
                return scheduleRestart(prev, NORMAL_RESTART_MS);
            case FAIL_PERMISSION:
                state = State.WAITING_PERMISSION;
                reason = "falta a permissão do microfone";
                return new Step(Cmd.NONE, 0L, 0L, false, false, prev, state, reason);
            case FAIL_UNAVAILABLE:
                state = State.UNAVAILABLE;
                reason = "o reconhecimento de voz não está disponível";
                return new Step(Cmd.NONE, 0L, 0L, false, false, prev, state, reason);
            default: // FAIL_RECOVERABLE
                failures++;
                if (failures > MAX_RECOVERABLE_FAILURES) {
                    state = State.ERROR;
                    reason = "o microfone falhou " + MAX_RECOVERABLE_FAILURES + " vezes seguidas";
                    return new Step(Cmd.NONE, 0L, 0L, false, false, prev, state, reason);
                }
                return scheduleRestart(prev, BACKOFF_MS[Math.min(failures - 1, BACKOFF_MS.length - 1)]);
        }
    }

    private Step scheduleRestart(State prev, long delay) {
        pendingTimer = nextToken++;
        state = State.STARTING; // "rearmando": nenhum reconhecedor roda agora, mas outro início NÃO é permitido
        reason = "reiniciando a escuta";
        return new Step(Cmd.RESTART_LATER, pendingTimer, delay, false, false, prev, state, reason);
    }

    /** O temporizador de reinício disparou: só vale se ainda for o temporizador atual; as condições são reavaliadas na hora. */
    public synchronized Step onRestartTimer(long timer, boolean wanted, boolean permission, boolean available, boolean allowedNow) {
        if (timer == 0L || timer != pendingTimer) return stale();
        pendingTimer = 0L;
        if (state == State.STARTING) state = State.SUSPENDED; // sem reconhecedor ativo: libera o reconcile para decidir
        return reconcile(wanted, permission, available, allowedNow);
    }

    // ------------------------------------------------------------------ comando (uma frase)

    /** Abre o microfone para ouvir UM comando. Substitui a escuta da palavra-chave; nunca coexiste com ela. */
    public synchronized Step beginCommand(boolean permission, boolean voiceEnabled) {
        if (!voiceEnabled) return noop("a voz está desativada");
        if (!permission) return noop("falta a permissão do microfone");
        State prev = state;
        boolean hadTimer = pendingTimer != 0L;
        token = 0L;
        pendingTimer = 0L;
        commandToken = nextToken++;
        state = State.COMMAND;
        reason = "ouvindo um comando";
        return new Step(Cmd.START_COMMAND, commandToken, 0L, hadTimer, false, prev, state, reason);
    }

    /** O comando terminou (resultado ou falha). Depois disso chame reconcile(): ele decide se a palavra-chave volta. */
    public synchronized Step onCommandEnd(long t) {
        if (!isCurrentCommand(t)) return stale();
        State prev = state;
        commandToken = 0L;
        state = State.SUSPENDED;
        reason = "comando concluído";
        return new Step(Cmd.NONE, 0L, 0L, false, false, prev, state, reason);
    }

    // ------------------------------------------------------------------ controle externo

    /** Para qualquer reconhecedor e temporizador AGORA, sem mudar a preferência (usado pelo "parar tudo" do núcleo). */
    public synchronized Step suspend(String why) {
        if (!hasValidSession() && !hasPendingTimer() && state != State.COMMAND) return noop(reason);
        return stopTo(State.SUSPENDED, why);
    }

    /** Ação manual "tentar de novo": tira do ERROR e reavalia. */
    public synchronized Step manualRetry(boolean wanted, boolean permission, boolean available, boolean allowedNow) {
        if (state == State.ERROR) {
            failures = 0;
            state = State.SUSPENDED;
            reason = "nova tentativa manual";
        }
        return reconcile(wanted, permission, available, allowedNow);
    }

    // ------------------------------------------------------------------ internos

    private Step stopTo(State target, String why) {
        State prev = state;
        boolean hadRecognizer = token != 0L || commandToken != 0L;
        boolean hadTimer = pendingTimer != 0L;
        // invalida TUDO na mesma chamada: nenhum callback ou temporizador antigo consegue agir depois
        token = 0L;
        commandToken = 0L;
        pendingTimer = 0L;
        state = target;
        reason = why;
        return new Step(hadRecognizer ? Cmd.STOP : Cmd.NONE, 0L, 0L, hadTimer, false, prev, state, reason);
    }

    private Step noop(String why) {
        return new Step(Cmd.NONE, 0L, 0L, false, false, state, state, why);
    }

    private Step stale() {
        return new Step(Cmd.NONE, 0L, 0L, false, true, state, state, "evento de uma sessão antiga ignorado");
    }
}
