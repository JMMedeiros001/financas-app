package com.kupa.assistant.perf

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.security.HardwareInfo
import com.kupa.assistant.security.PerfParams
import com.kupa.assistant.security.PerformanceProfile
import com.kupa.assistant.security.PerformanceSelector
import com.kupa.assistant.settings.Settings
import java.util.concurrent.CopyOnWriteArrayList

/**
 * TabletPerformanceEngine (o mesmo para celular e tablet: é um único KUPA). Lê o hardware REAL pelo Android e escolhe parâmetros
 * (quadros do Popol, cache de imagens, qualidade da captura). Dado que o Android não informa fica "desconhecido": nada é inventado.
 */
class PerformanceEngine(private val context: Context, private val settings: Settings) {
    @Volatile
    var hardware: HardwareInfo = collect()
        private set

    @Volatile
    var resolved: PerformanceProfile = PerformanceProfile.BALANCED
        private set

    @Volatile
    var params: PerfParams = PerformanceSelector.paramsFor(PerformanceProfile.BALANCED, hardware)
        private set

    private val listeners = CopyOnWriteArrayList<(PerfParams) -> Unit>()

    fun addListener(l: (PerfParams) -> Unit) {
        listeners.add(l)
        l(params)
    }

    fun requestedProfile(): PerformanceProfile = try {
        PerformanceProfile.valueOf(settings.performanceProfile)
    } catch (e: IllegalArgumentException) {
        PerformanceProfile.AUTO
    }

    fun start() {
        refresh()
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                pm.addThermalStatusListener(context.mainExecutor) { _ -> refresh() }
            } catch (e: Exception) {
                KupaLog.w("desempenho", "sem aviso térmico do Android: ${e.message}")
            }
        }
    }

    /** Relê o hardware e reaplica. Barato; pode ser chamado a cada minuto e quando as configurações mudam. */
    fun refresh() {
        hardware = collect()
        val requested = requestedProfile()
        resolved = if (requested == PerformanceProfile.AUTO) PerformanceSelector.resolveAuto(hardware) else requested
        val next = PerformanceSelector.paramsFor(requested, hardware)
        if (next.toString() != params.toString()) {
            params = next
            KupaLog.i("desempenho", "perfil ${resolved.name}: $next")
            for (l in listeners) l(next)
        }
    }

    fun category(): PerformanceSelector.Category = PerformanceSelector.categorize(hardware)

    /** Resumo legível para a tela de configurações (somente dados reais; desconhecido aparece como tal). */
    fun describe(): String {
        val h = hardware
        val thermal = when (h.thermalStatus) {
            -1 -> "indisponível neste aparelho"
            0 -> "normal"
            1 -> "leve"
            2 -> "moderado"
            3 -> "severo"
            else -> "crítico"
        }
        val battery = if (h.batteryPercent < 0) "desconhecida" else "${h.batteryPercent}%" + if (h.charging) " (carregando)" else ""
        return "Memória: ${h.totalRamMb} MB · Núcleos: ${h.cores} · Menor largura da tela: ${h.smallestWidthDp} dp (${if (h.isTablet()) "tablet" else "celular"}) · " +
            "Térmico: $thermal · Bateria: $battery" + (if (h.powerSaveMode) " · economia de energia ligada" else "") +
            "\nCategoria (heurística por memória e núcleos, não é benchmark): ${category().name}\nPerfil em uso: ${resolved.name} → $params"
    }

    private fun collect(): HardwareInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        val battery: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val thermal = if (Build.VERSION.SDK_INT >= 29) pm.currentThermalStatus else -1
        return HardwareInfo(
            mem.totalMem / (1024 * 1024), Runtime.getRuntime().availableProcessors(), context.resources.configuration.smallestScreenWidthDp,
            am.isLowRamDevice, percent, charging, thermal, pm.isPowerSaveMode,
        )
    }
}
