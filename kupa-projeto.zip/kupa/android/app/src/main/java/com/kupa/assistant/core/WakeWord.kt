package com.kupa.assistant.core

import java.text.Normalizer

/** Remove acentos e põe em minúsculas SEM mudar o tamanho do texto (os índices continuam valendo no original). */
fun foldText(text: String): String {
    val out = StringBuilder(text.length)
    for (ch in text) {
        val decomposed = Normalizer.normalize(ch.toString(), Normalizer.Form.NFD)
        var base = ch
        for (d in decomposed) {
            if (Character.getType(d) != Character.NON_SPACING_MARK.toInt()) {
                base = d
                break
            }
        }
        out.append(base.lowercaseChar())
    }
    return out.toString()
}

/**
 * Detecta a palavra de ativação "Kupa" em frases do reconhecedor de voz.
 * "kupa" é aceita em qualquer ponto da frase inicial. As variações "cupa"/"culpa" (erros comuns do reconhecimento)
 * só são aceitas quando a chance de o usuário ter dito "Kupa" é alta: no começo da frase ou depois de um chamado
 * ("oi", "ei", "fala"...). Assim "a culpa é minha" NÃO ativa o assistente.
 */
object WakeWord {
    data class Match(val command: String, val exact: Boolean)

    private val exactWords = setOf("kupa", "kupá")
    private val variantWords = setOf("cupa", "culpa", "kuppa", "cuppa", "kupah")
    private val greetings = setOf("oi", "ei", "ola", "e", "ai", "fala", "opa", "hey", "hei", "ok", "okay", "alo")

    private data class Token(val word: String, val start: Int, val end: Int)

    private fun tokenize(text: String): List<Token> {
        val tokens = ArrayList<Token>()
        val folded = foldText(text)
        var i = 0
        while (i < folded.length) {
            if (folded[i].isLetterOrDigit()) {
                var j = i
                while (j < folded.length && folded[j].isLetterOrDigit()) j++
                tokens.add(Token(folded.substring(i, j), i, j))
                i = j
            } else {
                i++
            }
        }
        return tokens
    }

    /** @return o comando que veio junto na mesma frase (pode ser vazio) ou null se não houve ativação. */
    fun match(text: String, acceptVariants: Boolean = true): Match? {
        val tokens = tokenize(text)
        if (tokens.isEmpty()) return null
        val limit = minOf(tokens.size, 4)
        for (index in 0 until limit) {
            val word = tokens[index].word
            val isExact = word in exactWords
            val isVariant = acceptVariants && word in variantWords
            if (!isExact && !isVariant) continue
            // Variações só valem no começo da frase ou depois de um chamado ("oi cupa").
            if (isVariant) {
                val onlyGreetingsBefore = (0 until index).all { tokens[it].word in greetings }
                if (!onlyGreetingsBefore) continue
            } else {
                val onlyGreetingsBefore = (0 until index).all { tokens[it].word in greetings }
                if (!onlyGreetingsBefore && index > 2) continue
            }
            val rest = text.substring(tokens[index].end).trim().trimStart(',', '.', '!', '?', ':', ';', '-', ' ')
            return Match(rest.trim(), isExact)
        }
        return null
    }
}
