package com.kupa.assistant.core

import com.kupa.assistant.voice.ActivationNameEngine
import java.text.Normalizer

/** Remove acentos e põe em minúsculas SEM mudar o tamanho do texto (os índices continuam valendo no original). */
fun foldText(text: String): String {
    val out = StringBuilder(text.length)
    for (ch in text) {
        val decomposed = Normalizer.normalize(ch.toString(), Normalizer.Form.NFD)
        var base = ch
        for (d in decomposed) {
            if (Character.getType(d) != Character.NON_SPACING_MARK.toInt()) {
                base = d
                break
            }
        }
        out.append(base.lowercaseChar())
    }
    return out.toString()
}

/**
 * Detecta a palavra de ativação em frases do reconhecedor de voz. A lógica fica em [ActivationNameEngine] (Java puro, testado);
 * o nome e as variantes vêm de [com.kupa.assistant.identity.AssistantIdentity] e podem ser mudados pelo usuário.
 * A palavra de ativação só INICIA uma interação: não identifica quem falou e não autoriza nada.
 */
object WakeWord {
    data class Match(val command: String, val exact: Boolean)

    @Volatile
    private var engine: ActivationNameEngine = ActivationNameEngine(ActivationNameEngine.DEFAULT_NAME, ActivationNameEngine.DEFAULT_PHONETIC_VARIANTS)

    /** Chamado com uma frase que NÃO ativou (para sugerir variantes; a frase não é guardada). */
    @Volatile
    var onMiss: ((String) -> Unit)? = null

    fun install(newEngine: ActivationNameEngine) {
        engine = newEngine
    }

    /** @return o comando que veio junto na mesma frase (pode ser vazio) ou null se não houve ativação. */
    fun match(text: String, acceptVariants: Boolean = true): Match? {
        val m = engine.match(text, acceptVariants) ?: return null
        return Match(m.command, m.exact)
    }

    fun noteMiss(text: String) {
        onMiss?.invoke(text)
    }
}
