package com.kupa.assistant.visual;

/**
 * Modo visual do núcleo. É derivado SOMENTE de fatos reais (microfone aberto, serviço rodando, estado do assistente...):
 * a animação nunca simula escuta, processamento ou conexão que não estejam acontecendo.
 */
public enum CoreMode {
    /** Serviço do KUPA parado: núcleo apagado e estático. */
    OFF,
    /** Falta a permissão do microfone: âmbar, estático. */
    NEEDS_PERMISSION,
    /** Em espera. */
    IDLE,
    /** O KUPA pediu a escuta, mas o microfone AINDA não está aberto. */
    STARTING,
    /** Microfone realmente aberto, ouvindo a palavra de ativação. */
    LISTENING,
    /** Microfone realmente aberto, ouvindo um comando. */
    COMMAND,
    /** Pensando, pesquisando, analisando a tela ou executando. */
    PROCESSING,
    /** Falando a resposta. */
    SPEAKING,
    /** Há uma ação esperando a sua confirmação. */
    CONFIRM,
    /** Erro ou modo seguro. */
    ERROR;

    /** Modos que têm movimento. Os outros ficam parados (nada de atividade fingida). */
    public boolean animated() {
        return this != OFF && this != NEEDS_PERMISSION && this != ERROR;
    }

    /** Título curto do estado (também lido por leitores de tela). */
    public String title() {
        switch (this) {
            case OFF: return "desligado";
            case NEEDS_PERMISSION: return "falta a permissão do microfone";
            case STARTING: return "iniciando a escuta";
            case LISTENING: return "ouvindo";
            case COMMAND: return "ouvindo o comando";
            case PROCESSING: return "processando";
            case SPEAKING: return "falando";
            case CONFIRM: return "aguardando sua confirmação";
            case ERROR: return "algo deu errado";
            default: return "em espera";
        }
    }

    /** Orientação curta para o usuário neste estado. */
    public String hint(String callName) {
        switch (this) {
            case OFF: return "Toque em Iniciar KUPA para ativar o assistente.";
            case NEEDS_PERMISSION: return "Conceda o microfone para eu ouvir você.";
            case STARTING: return "Abrindo o microfone…";
            case LISTENING: return "Diga \"" + callName + "\" para me chamar.";
            case COMMAND: return "Pode falar.";
            case PROCESSING: return "Um instante…";
            case SPEAKING: return "Toque em Parar se quiser me interromper.";
            case CONFIRM: return "Responda sim ou não.";
            case ERROR: return "Veja o estado da escuta e da IA abaixo.";
            default: return "Diga \"" + callName + "\" ou toque em Falar.";
        }
    }

    public boolean usesMicLevel() { return this == LISTENING || this == COMMAND; }

    /**
     * Decide o modo a partir de fatos. Prioridade: erro > confirmação > falando > processando > microfone > permissão > desligado > espera.
     *
     * @param assistantState nome do estado visual do assistente (SPEAKING, THINKING, SEARCHING, LISTENING, ERROR...)
     */
    public static CoreMode resolve(boolean serviceRunning, boolean micPermission, boolean micOpen, boolean commandOpen,
                                   String assistantState, boolean confirmationPending, boolean safeShutdown) {
        String s = assistantState == null ? "" : assistantState;
        if (safeShutdown || s.equals("ERROR")) return ERROR;
        if (confirmationPending) return CONFIRM;
        if (s.equals("SPEAKING")) return SPEAKING;
        if (s.equals("THINKING") || s.equals("SEARCHING") || s.equals("SCREEN_ANALYSIS") || s.equals("EXECUTING")
            || s.equals("TRANSLATING") || s.equals("READING")) return PROCESSING;
        if (micOpen) return commandOpen ? COMMAND : LISTENING;
        if (s.equals("LISTENING") || s.equals("ACTIVATED")) return STARTING; // quer ouvir, mas o microfone ainda não abriu
        if (!micPermission) return NEEDS_PERMISSION;
        if (!serviceRunning) return OFF;
        return IDLE;
    }
}
