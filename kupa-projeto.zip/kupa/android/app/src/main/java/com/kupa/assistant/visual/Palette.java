package com.kupa.assistant.visual;

/** Paleta única do KUPA — TEMPORAL INTELLIGENCE SYSTEM (valores ARGB). O app inteiro lê as cores daqui. */
public final class Palette {
    private Palette() {}

    public static final int TARDIS_BLUE = 0xFF0756A5;
    public static final int DEEP_BLUE = 0xFF061426;
    public static final int SPACE = 0xFF030811;
    public static final int TECH_BLUE = 0xFF167DDB;
    public static final int CYAN = 0xFF50E6FF;
    public static final int COLD_WHITE = 0xFFEAF7FF;
    public static final int PANEL = 0xFF10253C;
    public static final int OK_GREEN = 0xFF42DDAA;
    public static final int AMBER = 0xFFFFBF69;
    /** Erro: vermelho suave, usado só em estados de falha. */
    public static final int ERROR_RED = 0xFFFF6B6B;
    /** Texto secundário com contraste alto sobre o painel. */
    public static final int MUTED = 0xFF8FB4CF;
    /** Sistema desligado/inativo. */
    public static final int DORMANT = 0xFF2B4A66;

    public static int withAlpha(int argb, float alpha) {
        int a = Math.round(Math.max(0f, Math.min(1f, alpha)) * 255f);
        return (a << 24) | (argb & 0x00FFFFFF);
    }

    public static int mix(int a, int b, float t) {
        float k = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | (Math.round(ar + (br - ar) * k) << 16) | (Math.round(ag + (bg - ag) * k) << 8) | Math.round(ab + (bb - ab) * k);
    }

    /** Luminância relativa (WCAG), para conferir contraste em testes. */
    public static double luminance(int argb) {
        double[] c = {(argb >> 16 & 255) / 255.0, (argb >> 8 & 255) / 255.0, (argb & 255) / 255.0};
        for (int i = 0; i < 3; i++) c[i] = c[i] <= 0.03928 ? c[i] / 12.92 : Math.pow((c[i] + 0.055) / 1.055, 2.4);
        return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
    }

    public static double contrast(int fg, int bg) {
        double l1 = luminance(fg), l2 = luminance(bg);
        double hi = Math.max(l1, l2), lo = Math.min(l1, l2);
        return (hi + 0.05) / (lo + 0.05);
    }
}
