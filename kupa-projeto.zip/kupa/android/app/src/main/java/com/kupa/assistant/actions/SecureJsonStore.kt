package com.kupa.assistant.actions

import android.content.Context
import com.kupa.assistant.core.KupaLog
import org.json.JSONObject

/** Guarda um JSON CIFRADO (Android Keystore) em SharedPreferences. Se não conseguir cifrar, NÃO grava (nada em texto puro). */
class SecureJsonStore(context: Context, name: String) {
    private val prefs = context.applicationContext.getSharedPreferences("kupa_secure_$name", Context.MODE_PRIVATE)

    @Synchronized
    fun read(): JSONObject {
        val stored = prefs.getString("data", null) ?: return JSONObject()
        val plain = SecureStore.decrypt(stored) ?: run {
            KupaLog.w("armazenamento", "dados cifrados ilegíveis; começando vazio")
            return JSONObject()
        }
        return try {
            JSONObject(plain)
        } catch (e: Exception) {
            KupaLog.e("armazenamento", "JSON inválido", e)
            JSONObject()
        }
    }

    @Synchronized
    fun write(json: JSONObject): Boolean {
        val encrypted = SecureStore.encrypt(json.toString())
        if (encrypted == null) {
            KupaLog.e("armazenamento", "não consegui cifrar; nada foi gravado")
            return false
        }
        prefs.edit().putString("data", encrypted).apply()
        return true
    }

    @Synchronized
    fun clear() {
        prefs.edit().remove("data").apply()
    }
}
