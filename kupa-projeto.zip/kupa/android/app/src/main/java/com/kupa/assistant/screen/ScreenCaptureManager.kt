package com.kupa.assistant.screen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Base64
import android.view.WindowManager
import com.kupa.assistant.core.KupaLog
import java.io.ByteArrayOutputStream

/**
 * Captura de tela AUTORIZADA pelo usuário, só com o mecanismo oficial do Android (MediaProjection).
 * Não tenta burlar proteção nenhuma: se um jogo/app bloquear a captura (FLAG_SECURE), o quadro vem preto
 * e isso é detectado e informado, sem fingir que "viu" a tela.
 */
class ScreenCaptureManager(private val context: Context) {
    private val lock = java.lang.Object()
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var capW = 0
    private var capH = 0
    private var dpi = 0

    @Volatile private var latest: Bitmap? = null
    @Volatile private var latestAt = 0L
    @Volatile private var wantFresh = false

    /** Avisado quando o usuário (ou o sistema) encerra o compartilhamento de tela. */
    @Volatile var onStopped: (() -> Unit)? = null

    val isActive: Boolean get() = projection != null

    private class Dims(val w: Int, val h: Int, val dpi: Int)

    private fun screenDims(): Dims {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val density = context.resources.configuration.densityDpi
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            return scaled(b.width(), b.height(), density)
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return scaled(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    /** Reduz para no máximo 1280 px no lado maior (economiza memória, rede e custo da IA). */
    private fun scaled(w: Int, h: Int, density: Int): Dims {
        val factor = minOf(1f, 1280f / maxOf(w, h).toFloat())
        val sw = maxOf(2, ((w * factor).toInt() / 2) * 2)
        val sh = maxOf(2, ((h * factor).toInt() / 2) * 2)
        return Dims(sw, sh, maxOf(1, (density * factor).toInt()))
    }

    @Synchronized
    fun start(p: MediaProjection) {
        stopInternal()
        val t = HandlerThread("kupa-capture")
        t.start()
        val h = Handler(t.looper)
        thread = t
        handler = h
        // Android 14+: o callback precisa existir antes de criar o VirtualDisplay.
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                KupaLog.i("tela", "compartilhamento encerrado pelo sistema/usuário")
                synchronized(this@ScreenCaptureManager) { stopInternal() }
                onStopped?.invoke()
            }
        }, h)
        val d = screenDims()
        capW = d.w
        capH = d.h
        dpi = d.dpi
        val r = newReader(capW, capH, h)
        reader = r
        virtualDisplay = p.createVirtualDisplay(
            "KupaCapture", capW, capH, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, h,
        )
        projection = p
        KupaLog.i("tela", "captura iniciada ${capW}x$capH")
    }

    private fun newReader(w: Int, h: Int, handler: Handler): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ ir -> onImage(ir) }, handler)
        return r
    }

    private fun onImage(r: ImageReader) {
        var image: Image? = null
        try {
            image = r.acquireLatestImage() ?: return
            val now = SystemClock.uptimeMillis()
            // limita a ~2 conversões por segundo (jogos mudam a tela 60x/s)
            if (!wantFresh && now - latestAt < 500) return
            val bmp = toBitmap(image)
            synchronized(lock) {
                latest = bmp
                latestAt = now
                wantFresh = false
                lock.notifyAll()
            }
        } catch (e: Exception) {
            KupaLog.e("tela", "falha ao converter quadro", e)
        } finally {
            image?.close()
        }
    }

    private fun toBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        if (rowPadding == 0) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    /** Se a tela girou (ex.: jogo em paisagem), refaz o leitor/tela virtual no novo tamanho. */
    @Synchronized
    private fun adaptToRotation() {
        val vd = virtualDisplay ?: return
        val h = handler ?: return
        val d = screenDims()
        if (d.w == capW && d.h == capH) return
        KupaLog.i("tela", "orientação mudou: ${capW}x$capH -> ${d.w}x${d.h}")
        val oldReader = reader
        val newReader = newReader(d.w, d.h, h)
        vd.resize(d.w, d.h, d.dpi)
        vd.surface = newReader.surface
        reader = newReader
        oldReader?.close()
        capW = d.w
        capH = d.h
        dpi = d.dpi
        synchronized(lock) { latest = null; latestAt = 0L }
    }

    /**
     * Devolve uma cópia do quadro mais recente. Com [fresh] = true espera um quadro novo (útil depois de esconder
     * o personagem); se não vier a tempo, usa o último quadro válido. Bloqueante: chame fora da thread principal.
     */
    fun captureFrame(fresh: Boolean, timeoutMs: Long): Bitmap? {
        if (!isActive) return null
        adaptToRotation()
        val requestedAt = SystemClock.uptimeMillis()
        val deadline = requestedAt + timeoutMs
        var result: Bitmap? = null
        synchronized(lock) {
            if (fresh) wantFresh = true
            var done = false
            while (!done) {
                val b = latest
                if (b != null && (!fresh || latestAt >= requestedAt)) {
                    result = copy(b)
                    done = true
                } else {
                    val remaining = deadline - SystemClock.uptimeMillis()
                    if (remaining <= 0) {
                        done = true
                    } else {
                        try {
                            lock.wait(remaining)
                        } catch (e: InterruptedException) {
                            done = true
                        }
                    }
                }
            }
            wantFresh = false
            if (result == null) {
                val last = latest
                if (last != null) result = copy(last)
            }
        }
        return result
    }

    private fun copy(b: Bitmap): Bitmap? = try {
        b.copy(Bitmap.Config.ARGB_8888, false)
    } catch (e: OutOfMemoryError) {
        null
    }

    @Synchronized
    fun stop() {
        stopInternal()
    }

    private fun stopInternal() {
        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
            KupaLog.w("tela", "release virtualDisplay: ${e.message}")
        }
        virtualDisplay = null
        try {
            reader?.close()
        } catch (e: Exception) {
            KupaLog.w("tela", "close reader: ${e.message}")
        }
        reader = null
        try {
            projection?.stop()
        } catch (e: Exception) {
            KupaLog.w("tela", "stop projection: ${e.message}")
        }
        projection = null
        thread?.quitSafely()
        thread = null
        handler = null
        synchronized(lock) {
            latest = null
            latestAt = 0L
            lock.notifyAll()
        }
    }

    companion object {
        /** Quadro (quase) todo preto = captura bloqueada pelo app/jogo ou nada desenhado ainda. */
        fun looksBlank(bmp: Bitmap): Boolean {
            val stepX = maxOf(1, bmp.width / 24)
            val stepY = maxOf(1, bmp.height / 24)
            var total = 0
            var dark = 0
            var y = 0
            while (y < bmp.height) {
                var x = 0
                while (x < bmp.width) {
                    val c = bmp.getPixel(x, y)
                    val sum = ((c shr 16) and 0xFF) + ((c shr 8) and 0xFF) + (c and 0xFF)
                    total++
                    if (sum < 12) dark++
                    x += stepX
                }
                y += stepY
            }
            return total > 0 && dark * 100 / total >= 99
        }

        /** JPEG reduzido (lado maior <= 1280, qualidade 70) em data URL, pronto para enviar à IA. */
        fun toJpegDataUrl(bmp: Bitmap): String {
            val maxSide = 1280
            val scale = minOf(1f, maxSide.toFloat() / maxOf(bmp.width, bmp.height).toFloat())
            val out = if (scale < 1f) {
                Bitmap.createScaledBitmap(bmp, maxOf(1, (bmp.width * scale).toInt()), maxOf(1, (bmp.height * scale).toInt()), true)
            } else {
                bmp
            }
            val bytes = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 70, bytes)
            if (out !== bmp) out.recycle()
            return "data:image/jpeg;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
        }
    }
}
