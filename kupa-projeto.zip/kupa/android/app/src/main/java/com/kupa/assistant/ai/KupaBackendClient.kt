package com.kupa.assistant.ai

import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.settings.Settings
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException

/** Cliente HTTP do backend KUPA (HttpURLConnection, sem bibliotecas). Chamadas bloqueantes. */
class KupaBackendClient(private val settings: Settings) {

    class Http(val status: Int, val body: String)

    class Failure(val error: AiError) : Exception(error.message)

    data class HealthResult(val ok: Boolean, val message: String, val version: String?)
    data class ConfigResult(
        val ok: Boolean,
        val message: String,
        val provider: String?,
        val model: String?,
        val apiKeyConfigured: Boolean,
        val modelConfigured: Boolean,
        val webSearchEnabled: Boolean,
    )
    data class TestResult(val ok: Boolean, val message: String, val model: String?, val latencyMs: Long, val reply: String?)

    private fun baseUrl(): String {
        val url = settings.backendUrl.trim().trimEnd('/')
        if (url.isEmpty()) {
            throw Failure(AiError(AiErrorKind.BACKEND_NOT_CONFIGURED, "backend_not_configured", "O endereço do backend ainda não foi configurado."))
        }
        if (!BackendUrlPolicy.isAllowed(url)) {
            throw Failure(AiError(AiErrorKind.BACKEND_NOT_CONFIGURED, "backend_url_rejected", BackendUrlPolicy.REJECTED_MESSAGE))
        }
        return url
    }

    /** Faz a requisição. Lança Failure para problemas de rede; devolve Http para qualquer resposta do servidor. */
    fun request(method: String, path: String, body: String?, auth: Boolean, readTimeoutMs: Int): Http {
        val connection = URL(baseUrl() + path).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = 6000
            connection.readTimeout = readTimeoutMs
            connection.setRequestProperty("Accept", "application/json")
            if (auth) connection.setRequestProperty("Authorization", "Bearer " + settings.appToken)
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Http(status, text)
        } catch (e: SocketTimeoutException) {
            throw Failure(AiError(AiErrorKind.BACKEND_UNREACHABLE, "timeout", "O backend demorou demais para responder."))
        } catch (e: UnknownHostException) {
            throw Failure(AiError(AiErrorKind.BACKEND_UNREACHABLE, "unknown_host", "Não encontrei o endereço do backend. Confira a URL."))
        } catch (e: IOException) {
            KupaLog.w("backend", "falha de rede: ${e.javaClass.simpleName}")
            throw Failure(AiError(AiErrorKind.BACKEND_UNREACHABLE, "io_error", "Não consegui conectar ao backend. Ele está ligado e na mesma rede?"))
        } finally {
            connection.disconnect()
        }
    }

    /** Converte uma resposta de erro do backend em AiError com mensagem compreensível. */
    fun errorFrom(http: Http): AiError {
        var code = "http_${http.status}"
        var message = "O backend respondeu com erro (${http.status})."
        try {
            val err = JSONObject(http.body).optJSONObject("error")
            if (err != null) {
                code = err.optString("code", code)
                val m = err.optString("message", "")
                if (m.isNotEmpty()) message = m
            }
        } catch (e: Exception) {
            // corpo não era JSON: mantém a mensagem genérica
        }
        val kind = when {
            http.status == 401 || code == "unauthorized" -> AiErrorKind.BACKEND_AUTH
            code == "auth_not_configured" || code == "api_key_missing" || code == "model_not_configured" -> AiErrorKind.BACKEND_CONFIG
            code == "session_expired" -> AiErrorKind.SESSION_EXPIRED
            code.startsWith("openai_") || code == "tool_not_allowed" -> AiErrorKind.OPENAI
            else -> AiErrorKind.OTHER
        }
        val finalMessage = if (kind == AiErrorKind.BACKEND_AUTH) "O backend recusou o token. Confira o token em Configurações." else message
        return AiError(kind, code, finalMessage)
    }

    fun health(): HealthResult {
        return try {
            val http = request("GET", "/health", null, false, 5000)
            if (http.status == 200) {
                val json = JSONObject(http.body)
                if (json.optBoolean("ok", false) && json.optString("service") == "kupa-backend") {
                    HealthResult(true, "Backend respondeu.", json.optString("version", ""))
                } else {
                    HealthResult(false, "O endereço respondeu, mas não parece ser o backend do KUPA.", null)
                }
            } else {
                HealthResult(false, "O backend respondeu com erro (${http.status}).", null)
            }
        } catch (f: Failure) {
            HealthResult(false, f.error.message, null)
        } catch (e: Exception) {
            HealthResult(false, "Resposta inesperada do backend.", null)
        }
    }

    fun config(): ConfigResult {
        return try {
            val http = request("GET", "/v1/config", null, true, 8000)
            if (http.status != 200) {
                ConfigResult(false, errorFrom(http).message, null, null, false, false, false)
            } else {
                val j = JSONObject(http.body)
                ConfigResult(
                    true, "ok", j.optString("provider", ""), if (j.isNull("model")) null else j.optString("model"),
                    j.optBoolean("apiKeyConfigured", false), j.optBoolean("modelConfigured", false), j.optBoolean("webSearchEnabled", false),
                )
            }
        } catch (f: Failure) {
            ConfigResult(false, f.error.message, null, null, false, false, false)
        } catch (e: Exception) {
            ConfigResult(false, "Resposta inesperada do backend.", null, null, false, false, false)
        }
    }

    /** Teste REAL: o backend faz uma chamada de verdade à OpenAI. */
    fun testAi(): TestResult {
        return try {
            val http = request("POST", "/v1/ai/test", "{}", true, 45000)
            if (http.status != 200) {
                TestResult(false, errorFrom(http).message, null, 0, null)
            } else {
                val j = JSONObject(http.body)
                TestResult(j.optBoolean("ok", false), "ok", j.optString("model", ""), j.optLong("latencyMs", 0), j.optString("reply", ""))
            }
        } catch (f: Failure) {
            TestResult(false, f.error.message, null, 0, null)
        } catch (e: Exception) {
            TestResult(false, "Resposta inesperada do backend.", null, 0, null)
        }
    }
}
