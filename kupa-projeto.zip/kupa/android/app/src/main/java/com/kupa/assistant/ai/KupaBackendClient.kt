package com.kupa.assistant.ai

import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.settings.Settings
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Cliente HTTP do backend KUPA (HttpURLConnection, sem bibliotecas). Chamadas bloqueantes. */
class KupaBackendClient(private val settings: Settings) {

    class Http(val status: Int, val body: String)

    class Failure(val error: AiError) : Exception(error.message)

    data class HealthResult(val ok: Boolean, val message: String, val version: String?, val code: String? = null)
    data class ProviderInfo(val name: String, val label: String, val configured: Boolean, val apiKeyConfigured: Boolean, val modelConfigured: Boolean, val model: String?)
    data class ConfigResult(
        val ok: Boolean,
        val message: String,
        val provider: String?,
        val model: String?,
        val apiKeyConfigured: Boolean,
        val modelConfigured: Boolean,
        val webSearchEnabled: Boolean,
        val providers: List<ProviderInfo> = emptyList(),
    )
    data class TestResult(val ok: Boolean, val message: String, val model: String?, val latencyMs: Long, val reply: String?, val code: String? = null)

    private fun baseUrl(): String {
        val check = BackendConfig.check(settings)
        if (check.problem == BackendUrlValidator.Problem.EMPTY) {
            throw Failure(AiError(AiErrorKind.BACKEND_NOT_CONFIGURED, "backend_not_configured", BackendConfig.NOT_CONFIGURED_MESSAGE))
        }
        if (!check.ok()) {
            throw Failure(AiError(AiErrorKind.BACKEND_NOT_CONFIGURED, "backend_url_invalid", "URL do backend inválida: " + check.message))
        }
        return check.normalized
    }

    /** Faz a requisição. Lança Failure para problemas de rede; devolve Http para qualquer resposta do servidor. */
    fun request(method: String, path: String, body: String?, auth: Boolean, readTimeoutMs: Int): Http {
        val connection = URL(baseUrl() + path).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = method
            connection.connectTimeout = if (readTimeoutMs >= 30_000) 25_000 else 8_000
            connection.readTimeout = readTimeoutMs
            connection.setRequestProperty("Accept", "application/json")
            if (auth) connection.setRequestProperty("Authorization", "Bearer " + settings.appToken)
            if (body != null) {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Http(status, text)
        } catch (e: IOException) {
            // classifica DNS, TLS (certificado), conexão recusada, timeout... em mensagens que o usuário entende
            val info = BackendFailure.fromException(e)
            KupaLog.w("backend", "falha: ${info.code} (${e.javaClass.simpleName})")
            throw Failure(AiError(AiErrorKind.BACKEND_UNREACHABLE, info.code, info.message))
        } finally {
            connection.disconnect()
        }
    }

    /** Converte uma resposta de erro do backend em AiError com mensagem compreensível. */
    fun errorFrom(http: Http): AiError {
        var code = "http_${http.status}"
        var message = "O backend respondeu com erro (${http.status})."
        try {
            val err = JSONObject(http.body).optJSONObject("error")
            if (err != null) {
                code = err.optString("code", code)
                val m = err.optString("message", "")
                if (m.isNotEmpty()) message = m
            }
        } catch (e: Exception) {
            // corpo não era JSON: mantém a mensagem genérica
        }
        val kind = when {
            http.status == 401 || code == "unauthorized" -> AiErrorKind.BACKEND_AUTH
            code == "auth_not_configured" || code == "api_key_missing" || code == "model_not_configured" ||
                code == "provider_not_available" || code == "no_provider_available" || code == "provider_unknown" -> AiErrorKind.BACKEND_CONFIG
            code == "session_expired" -> AiErrorKind.SESSION_EXPIRED
            code.startsWith("openai_") || code.startsWith("anthropic_") || code.startsWith("gemini_") ||
                code == "tool_not_allowed" || code == "tool_invalid_args" -> AiErrorKind.PROVIDER
            else -> AiErrorKind.OTHER
        }
        val finalMessage = if (kind == AiErrorKind.BACKEND_AUTH) "O backend recusou o token. Confira o token em Configurações." else message
        return AiError(kind, code, finalMessage)
    }

    fun health(): HealthResult {
        return try {
            val http = request("GET", "/health", null, false, 5000)
            if (http.status == 200) {
                val json = try { JSONObject(http.body) } catch (e: Exception) { null }
                if (json != null && (json.optString("status") == "ok" || json.optBoolean("ok", false)) && json.optString("service") == "kupa-backend") {
                    HealthResult(true, "Backend respondeu.", json.optString("version", ""))
                } else {
                    val info = BackendFailure.invalidResponse()
                    HealthResult(false, info.message, null, info.code)
                }
            } else {
                val info = BackendFailure.fromHttpStatus(http.status, true)
                HealthResult(false, info.message, null, info.code)
            }
        } catch (f: Failure) {
            HealthResult(false, f.error.message, null, f.error.code)
        } catch (e: Exception) {
            HealthResult(false, "Resposta inesperada do backend.", null, "unexpected")
        }
    }

    fun config(): ConfigResult {
        return try {
            val http = request("GET", "/v1/config", null, true, 8000)
            if (http.status != 200) {
                ConfigResult(false, errorFrom(http).message, null, null, false, false, false)
            } else {
                val j = JSONObject(http.body)
                val list = ArrayList<ProviderInfo>()
                val arr = j.optJSONArray("providers")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val p = arr.optJSONObject(i) ?: continue
                        list.add(
                            ProviderInfo(
                                p.optString("name"), p.optString("label", p.optString("name")), p.optBoolean("configured", false),
                                p.optBoolean("apiKeyConfigured", false), p.optBoolean("modelConfigured", false), if (p.isNull("model")) null else p.optString("model"),
                            ),
                        )
                    }
                }
                ConfigResult(
                    true, "ok", j.optString("provider", ""), if (j.isNull("model")) null else j.optString("model"),
                    j.optBoolean("apiKeyConfigured", false), j.optBoolean("modelConfigured", false), j.optBoolean("webSearchEnabled", false), list,
                )
            }
        } catch (f: Failure) {
            ConfigResult(false, f.error.message, null, null, false, false, false)
        } catch (e: Exception) {
            ConfigResult(false, "Resposta inesperada do backend.", null, null, false, false, false)
        }
    }

    /** Teste REAL: o backend faz uma chamada de verdade ao provedor pedido (ou ao padrão). */
    fun testAi(provider: String? = null): TestResult {
        return try {
            val body = JSONObject().apply { if (provider != null) put("provider", provider) }.toString()
            val http = request("POST", "/v1/ai/test", body, true, 45000)
            if (http.status != 200) {
                val err = errorFrom(http)
                TestResult(false, err.message, null, 0, null, err.code)
            } else {
                val j = JSONObject(http.body)
                TestResult(j.optBoolean("ok", false), "ok", j.optString("model", ""), j.optLong("latencyMs", 0), j.optString("reply", ""))
            }
        } catch (f: Failure) {
            TestResult(false, f.error.message, null, 0, null, f.error.code)
        } catch (e: Exception) {
            TestResult(false, "Resposta inesperada do backend.", null, 0, null, "unexpected")
        }
    }
}
