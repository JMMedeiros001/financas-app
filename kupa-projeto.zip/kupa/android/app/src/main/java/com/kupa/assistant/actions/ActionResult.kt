package com.kupa.assistant.actions

/**
 * Resultado REAL de uma ação no celular. Mensagens são faladas ao usuário, então só dizem o que de fato aconteceu:
 * "Abrindo..." (pedido enviado ao Android) ou "Abri..." (confirmado), nunca "pronto" sem saber.
 */
sealed class ActionResult {
    class Done(val message: String, val verified: Boolean = false) : ActionResult()
    class Failed(val message: String) : ActionResult()

    /** Precisa de um sim/não do usuário antes de agir. */
    class AskConfirm(val prompt: String, val onYes: () -> ActionResult, val onNoMessage: String = "Ok, cancelei.") : ActionResult()

    /** Mais de uma possibilidade: o usuário escolhe ("o primeiro", "o do trabalho"). */
    class AskChoice(val prompt: String, val labels: List<String>, val onChoice: (Int) -> ActionResult) : ActionResult()

    /** Não entendi a resposta: repete a pergunta uma vez. */
    class Reask(val prompt: String) : ActionResult()
}
