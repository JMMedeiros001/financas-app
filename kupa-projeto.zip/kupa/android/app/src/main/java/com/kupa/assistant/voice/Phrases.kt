package com.kupa.assistant.voice

import kotlin.random.Random

/** Falas curtas automáticas, usadas com moderação (só nos momentos pedidos). */
object Phrases {
    private val activated = listOf("Sim?", "Pode falar.", "Estou ouvindo.")
    private val searching = listOf("Vou pesquisar.", "Deixa eu verificar.")
    private val problem = listOf("Hum... tive um problema.", "Não consegui fazer isso.")

    fun activated(): String = activated[Random.nextInt(activated.size)]
    fun searching(): String = searching[Random.nextInt(searching.size)]
    fun problem(): String = problem[Random.nextInt(problem.size)]
    const val DIDNT_UNDERSTAND = "Não entendi."
}
