package com.kupa.assistant.game

import com.kupa.assistant.core.KupaLog

/**
 * Contexto TEMPORÁRIO da sessão de jogo (só em memória, nada vai para o disco).
 * O KUPA não presume qual jogo está aberto: só usa o que o usuário disse (ou o que a tela mostrou na hora).
 */
class GameContextService {
    @Volatile private var game: String = ""
    @Volatile private var hero: String = ""
    @Volatile private var updatedAtMs: Long = 0L

    val isEmpty: Boolean get() = game.isEmpty() && hero.isEmpty()

    @Synchronized
    fun setGame(value: String) {
        game = value.trim().take(60)
        updatedAtMs = System.currentTimeMillis()
        KupaLog.i("jogo", "contexto: jogo definido")
    }

    @Synchronized
    fun setHero(value: String) {
        hero = value.trim().take(60)
        updatedAtMs = System.currentTimeMillis()
        KupaLog.i("jogo", "contexto: personagem definido")
    }

    @Synchronized
    fun clear() {
        game = ""
        hero = ""
        updatedAtMs = 0L
        KupaLog.i("jogo", "contexto apagado")
    }

    /** Texto enviado à IA junto com a pergunta (vazio se não houver contexto). */
    @Synchronized
    fun asPromptText(): String {
        val parts = ArrayList<String>()
        if (game.isNotEmpty()) parts.add("jogo: $game")
        if (hero.isNotEmpty()) parts.add("personagem/herói do usuário: $hero")
        return parts.joinToString("; ")
    }

    @Synchronized
    fun summaryForUser(): String {
        if (isEmpty) return "Nenhum contexto de jogo guardado."
        return asPromptText()
    }
}
