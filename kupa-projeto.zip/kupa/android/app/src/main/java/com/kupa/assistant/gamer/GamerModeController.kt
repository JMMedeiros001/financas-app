package com.kupa.assistant.gamer

import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.settings.Settings
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Estado do MODO GAMER (gamerMode), separado do resto.
 * Ligar o modo gamer só muda a APRESENTAÇÃO (esconde Popol e Kupa): o KUPA CORE, a IA, o microfone
 * (se permitido pelo Android) e as ferramentas continuam funcionando. Nada é destruído.
 */
class GamerModeController(private val settings: Settings) {
    fun interface Listener {
        fun onGamerModeChanged(active: Boolean)
    }

    private val listeners = CopyOnWriteArrayList<Listener>()

    @Volatile
    var active: Boolean = false
        private set

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    /** Personagem fica invisível sobre o jogo? */
    val characterHidden: Boolean get() = active && settings.gamerHideCharacter

    fun enable() {
        if (active) return
        // guarda a apresentação atual para restaurar ao sair
        settings.savedPosX = settings.posX
        settings.savedPosY = settings.posY
        settings.savedSizeDp = settings.sizeDp
        settings.savedAlphaPercent = settings.alphaPercent
        active = true
        KupaLog.i("gamer", "modo gamer LIGADO (personagem oculto=${settings.gamerHideCharacter})")
        for (l in listeners) l.onGamerModeChanged(true)
    }

    fun disable() {
        if (!active) return
        active = false
        if (settings.gamerRestorePosition) {
            if (settings.savedPosX != -1 || settings.savedPosY != -1) {
                settings.posX = settings.savedPosX
                settings.posY = settings.savedPosY
            }
            if (settings.savedSizeDp > 0) settings.sizeDp = settings.savedSizeDp
            if (settings.savedAlphaPercent > 0) settings.alphaPercent = settings.savedAlphaPercent
        }
        KupaLog.i("gamer", "modo gamer DESLIGADO (posição/tamanho/transparência restaurados=${settings.gamerRestorePosition})")
        for (l in listeners) l.onGamerModeChanged(false)
    }
}
