package com.kupa.assistant.security;

/**
 * Escolhe categoria de hardware e perfil de desempenho a partir de dados REAIS do aparelho.
 * A categoria é uma heurística simples (memória e núcleos) e diz isso: não é um benchmark.
 */
public final class PerformanceSelector {
    private PerformanceSelector() {}

    public enum Category { LOW, MEDIUM, HIGH, ULTRA }

    public static Category categorize(HardwareInfo h) {
        if (h.lowRamDevice || h.totalRamMb < 3000) return Category.LOW;
        Category c = h.totalRamMb < 6000 ? Category.MEDIUM : h.totalRamMb < 10000 ? Category.HIGH : Category.ULTRA;
        if (h.cores > 0 && h.cores <= 4 && c != Category.LOW) c = Category.values()[c.ordinal() - 1];
        return c;
    }

    /** Resolve o perfil AUTO: térmico e bateria vêm primeiro; depois a capacidade do aparelho. */
    public static PerformanceProfile resolveAuto(HardwareInfo h) {
        if (h.thermalStatus >= 3) return PerformanceProfile.THERMAL_SAFE;
        boolean lowBattery = h.batteryPercent >= 0 && h.batteryPercent <= 15 && !h.charging;
        if (lowBattery || h.powerSaveMode) return PerformanceProfile.BATTERY_SAVER;
        if (h.thermalStatus == 2) return PerformanceProfile.BALANCED;
        switch (categorize(h)) {
            case ULTRA:
            case HIGH:
                return PerformanceProfile.PERFORMANCE_MAX;
            case MEDIUM:
                return PerformanceProfile.BALANCED;
            default:
                return PerformanceProfile.BATTERY_SAVER;
        }
    }

    public static PerfParams paramsFor(PerformanceProfile profile, HardwareInfo h) {
        PerformanceProfile p = profile == PerformanceProfile.AUTO ? resolveAuto(h) : profile;
        PerfParams base;
        switch (p) {
            case PERFORMANCE_MAX: base = new PerfParams(60, 24, 130, 1600, 80); break;
            case ANIMATION_MAX: base = new PerfParams(60, 32, 160, 1280, 70); break;
            case BATTERY_SAVER: base = new PerfParams(20, 6, 0, 1024, 60); break;
            case THERMAL_SAFE: base = new PerfParams(15, 6, 0, 960, 55); break;
            case AI_HEAVY: base = new PerfParams(30, 12, 100, 1280, 70); break;
            case SCREEN_ANALYSIS: base = new PerfParams(30, 8, 100, 1600, 80); break;
            case VOICE_LOW_LATENCY: base = new PerfParams(30, 8, 100, 1024, 60); break;
            default: base = new PerfParams(45, 12, 130, 1280, 70); break; // BALANCED
        }
        if (categorize(h) == Category.LOW) {
            return new PerfParams(Math.min(base.animationFps, 30), Math.min(base.spriteCacheMb, 8), base.crossfadeMs, Math.min(base.captureMaxSidePx, 1280), base.jpegQuality);
        }
        return base;
    }
}
