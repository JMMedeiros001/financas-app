package com.kupa.assistant.ui

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.kupa.assistant.visual.MarkView
import com.kupa.assistant.visual.Palette
import kotlin.math.roundToInt

/**
 * Kit de telas feitas em código (sem XML e sem bibliotecas) na identidade "KUPA — TEMPORAL INTELLIGENCE SYSTEM".
 * TODAS as cores, bordas e raios saem daqui (e as cores, de [Palette]); trocar o visual do app inteiro é mexer neste arquivo.
 */
object Ui {
    val BG = Palette.SPACE
    val CARD = Palette.PANEL
    val TEXT = Palette.COLD_WHITE
    val MUTED = Palette.MUTED
    val ACCENT = Palette.CYAN
    val OK = Palette.OK_GREEN
    val BAD = Palette.ERROR_RED
    val WARN = Palette.AMBER
    val BLUE = Palette.TARDIS_BLUE
    val TECH = Palette.TECH_BLUE

    /** Borda fina em ciano translúcido dos painéis holográficos. */
    val EDGE = Palette.withAlpha(Palette.CYAN, 0.30f)

    /** Fundo de botão secundário e de campo. */
    val CHIP = Palette.mix(Palette.DEEP_BLUE, Palette.PANEL, 0.55f)

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).roundToInt()

    fun rounded(context: Context, color: Int, radiusDp: Int = 14, strokeColor: Int? = null): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(context, radiusDp).toFloat()
        if (strokeColor != null) d.setStroke(dp(context, 1), strokeColor)
        return d
    }

    /** Soma a altura da barra de status ao topo de [view] (necessário no modo de tela inteira do Android 15). */
    @Suppress("DEPRECATION")
    fun padTopForSystemBars(view: View) {
        val base = view.paddingTop
        view.setOnApplyWindowInsetsListener { v, insets ->
            val top = if (Build.VERSION.SDK_INT >= 30) insets.getInsets(WindowInsets.Type.systemBars()).top else insets.systemWindowInsetTop
            v.setPadding(v.paddingLeft, base + top, v.paddingRight, v.paddingBottom)
            insets
        }
    }

    /** Soma a altura da barra de navegação do sistema à base de [view]. */
    @Suppress("DEPRECATION")
    fun padBottomForSystemBars(view: View) {
        val base = view.paddingBottom
        view.setOnApplyWindowInsetsListener { v, insets ->
            val bottom = if (Build.VERSION.SDK_INT >= 30) insets.getInsets(WindowInsets.Type.systemBars()).bottom else insets.systemWindowInsetBottom
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, base + bottom)
            insets
        }
    }

    /** Cabeçalho de tela: símbolo do KUPA + título. */
    fun header(context: Context, title: String): LinearLayout {
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val mark = MarkView(context)
        row.addView(mark, LinearLayout.LayoutParams(dp(context, 34), dp(context, 34)))
        val t = text(context, title, 22f, TEXT, bold = true)
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.marginStart = dp(context, 12)
        row.addView(t, lp)
        return row
    }

    /** Tela com cabeçalho, rolagem, coluna vertical e a navegação inferior. Devolve a coluna para adicionar conteúdo. */
    fun screen(activity: Activity, title: String): LinearLayout {
        val root = LinearLayout(activity)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(BG)
        val scroll = ScrollView(activity)
        scroll.setBackgroundColor(BG)
        scroll.isFillViewport = true
        val column = LinearLayout(activity)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(activity, 16), dp(activity, 16), dp(activity, 16), dp(activity, 24))
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(NavBar.build(activity), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        padTopForSystemBars(root)
        activity.setContentView(root)
        column.addView(header(activity, title))
        return column
    }

    fun text(context: Context, value: String, sizeSp: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView {
        val tv = TextView(context)
        tv.text = value
        tv.textSize = sizeSp
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return tv
    }

    fun section(parent: LinearLayout, title: String): LinearLayout {
        val context = parent.context
        val header = text(context, title.uppercase(), 12f, ACCENT, bold = true)
        header.letterSpacing = 0.08f
        val hp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hp.topMargin = dp(context, 22)
        header.layoutParams = hp
        parent.addView(header)
        val card = LinearLayout(context)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(context, CARD, 16, EDGE) // painel azul com borda fina ciano
        card.setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 10))
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = dp(context, 6)
        parent.addView(card, cp)
        return card
    }

    private fun rowParams(context: Context): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(context, 6)
        p.bottomMargin = dp(context, 6)
        return p
    }

    fun switchRow(parent: LinearLayout, label: String, description: String?, get: () -> Boolean, set: (Boolean) -> Unit): Switch {
        val context = parent.context
        val sw = Switch(context)
        sw.text = label
        sw.textSize = 15f
        sw.setTextColor(TEXT)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(ACCENT, MUTED))
        sw.trackTintList = ColorStateList(states, intArrayOf(Palette.withAlpha(ACCENT, 0.45f), Palette.withAlpha(MUTED, 0.30f)))
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, checked -> set(checked) }
        sw.minHeight = dp(context, 48)
        parent.addView(sw, rowParams(context))
        if (description != null) parent.addView(text(context, description, 12f, MUTED))
        return sw
    }

    fun sliderRow(parent: LinearLayout, label: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit, format: (Int) -> String = { it.toString() }) {
        val context = parent.context
        val title = text(context, "$label: ${format(get())}", 15f, TEXT)
        parent.addView(title, rowParams(context))
        val bar = SeekBar(context)
        bar.max = max - min
        bar.progress = (get() - min).coerceIn(0, max - min)
        bar.progressTintList = ColorStateList.valueOf(ACCENT)
        bar.thumbTintList = ColorStateList.valueOf(ACCENT)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val value = progress + min
                title.text = "$label: ${format(value)}"
                if (fromUser) set(value)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        parent.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun inputRow(parent: LinearLayout, label: String, hint: String, get: () -> String, set: (String) -> Unit, secret: Boolean = false): EditText {
        val context = parent.context
        parent.addView(text(context, label, 15f, TEXT), rowParams(context))
        val edit = EditText(context)
        edit.setText(get())
        edit.hint = hint
        edit.setTextColor(TEXT)
        edit.setHintTextColor(MUTED)
        edit.setSingleLine(true)
        edit.background = rounded(context, CHIP, 10, EDGE)
        edit.setPadding(dp(context, 12), dp(context, 10), dp(context, 12), dp(context, 10))
        edit.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        edit.setOnFocusChangeListener { _, focused -> if (!focused) set(edit.text.toString().trim()) }
        parent.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return edit
    }

    /**
     * Escolha entre poucas opções (cada uma vira um botão; a atual fica destacada).
     * Até 3 opções ficam numa linha; 4 ou mais quebram em linhas de 2, para o texto NUNCA ser cortado nem partido no meio da palavra.
     */
    fun choiceRow(parent: LinearLayout, label: String, options: List<Pair<String, String>>, get: () -> String, set: (String) -> Unit) {
        val context = parent.context
        parent.addView(text(context, label, 15f, TEXT), rowParams(context))
        val buttons = ArrayList<Pair<Button, String>>()
        fun refresh() {
            for ((b, value) in buttons) {
                val selected = get() == value
                b.background = rounded(context, if (selected) BLUE else CHIP, 10, if (selected) ACCENT else EDGE)
                b.setTextColor(if (selected) Palette.COLD_WHITE else TEXT)
            }
        }
        val perRow = if (options.size <= 3) options.size else 2
        var row: LinearLayout? = null
        for ((index, option) in options.withIndex()) {
            if (index % perRow == 0) {
                val r = LinearLayout(context)
                r.orientation = LinearLayout.HORIZONTAL
                val rp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                rp.bottomMargin = dp(context, 6)
                parent.addView(r, rp)
                row = r
            }
            val b = Button(context)
            b.text = option.first
            b.isAllCaps = false
            b.setSingleLine(true)
            b.minimumHeight = dp(context, 48)
            val value = option.second
            b.setOnClickListener {
                set(value)
                refresh()
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = dp(context, 6)
            row?.addView(b, lp)
            buttons.add(Pair(b, value))
        }
        refresh()
    }

    fun button(parent: LinearLayout, label: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val context = parent.context
        val b = Button(context)
        b.text = label
        b.isAllCaps = false
        b.minimumHeight = dp(context, 48)
        b.setTextColor(TEXT)
        b.background = if (primary) rounded(context, BLUE, 12, ACCENT) else rounded(context, CHIP, 12, EDGE)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(context, 8)
        parent.addView(b, lp)
        return b
    }

    fun statusLine(parent: LinearLayout, label: String): Pair<TextView, TextView> {
        val context = parent.context
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val name = text(context, label, 14f, MUTED)
        val value = text(context, "…", 14f, TEXT, bold = true)
        value.gravity = Gravity.END
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(value, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f))
        parent.addView(row, rowParams(context))
        return Pair(name, value)
    }

    fun note(parent: LinearLayout, message: String, color: Int = MUTED): TextView {
        val tv = text(parent.context, message, 12f, color)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(parent.context, 4)
        parent.addView(tv, lp)
        return tv
    }

    fun show(v: View, visible: Boolean) {
        v.visibility = if (visible) View.VISIBLE else View.GONE
    }
}
