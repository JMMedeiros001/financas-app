package com.kupa.assistant.ui

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.roundToInt

/** Pequeno kit de telas feitas em código (sem XML e sem bibliotecas), no visual escuro do KUPA. */
object Ui {
    val BG = Color.parseColor("#14162B")
    val CARD = Color.parseColor("#1E2140")
    val TEXT = Color.parseColor("#EDEFFA")
    val MUTED = Color.parseColor("#9AA0C8")
    val ACCENT = Color.parseColor("#7C8CFF")
    val OK = Color.parseColor("#6FE3A5")
    val BAD = Color.parseColor("#FF7B8A")
    val WARN = Color.parseColor("#FFD27A")

    fun dp(context: Context, value: Int): Int = (value * context.resources.displayMetrics.density).roundToInt()

    fun rounded(context: Context, color: Int, radiusDp: Int = 14, strokeColor: Int? = null): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(context, radiusDp).toFloat()
        if (strokeColor != null) d.setStroke(dp(context, 1), strokeColor)
        return d
    }

    /** Tela com rolagem e coluna vertical. Devolve a coluna para adicionar conteúdo. */
    fun screen(activity: Activity, title: String): LinearLayout {
        val scroll = ScrollView(activity)
        scroll.setBackgroundColor(BG)
        scroll.isFillViewport = true
        val column = LinearLayout(activity)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(activity, 16), dp(activity, 24), dp(activity, 16), dp(activity, 32))
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        activity.setContentView(scroll)
        column.addView(text(activity, title, 24f, TEXT, bold = true))
        return column
    }

    fun text(context: Context, value: String, sizeSp: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView {
        val tv = TextView(context)
        tv.text = value
        tv.textSize = sizeSp
        tv.setTextColor(color)
        if (bold) tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        return tv
    }

    fun section(parent: LinearLayout, title: String): LinearLayout {
        val context = parent.context
        val header = text(context, title.uppercase(), 12f, ACCENT, bold = true)
        val hp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hp.topMargin = dp(context, 22)
        header.layoutParams = hp
        parent.addView(header)
        val card = LinearLayout(context)
        card.orientation = LinearLayout.VERTICAL
        card.background = rounded(context, CARD)
        card.setPadding(dp(context, 14), dp(context, 8), dp(context, 14), dp(context, 8))
        val cp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        cp.topMargin = dp(context, 6)
        parent.addView(card, cp)
        return card
    }

    private fun rowParams(context: Context): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(context, 6)
        p.bottomMargin = dp(context, 6)
        return p
    }

    fun switchRow(parent: LinearLayout, label: String, description: String?, get: () -> Boolean, set: (Boolean) -> Unit): Switch {
        val context = parent.context
        val sw = Switch(context)
        sw.text = label
        sw.textSize = 15f
        sw.setTextColor(TEXT)
        sw.isChecked = get()
        sw.setOnCheckedChangeListener { _, checked -> set(checked) }
        parent.addView(sw, rowParams(context))
        if (description != null) parent.addView(text(context, description, 12f, MUTED))
        return sw
    }

    fun sliderRow(parent: LinearLayout, label: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit, format: (Int) -> String = { it.toString() }) {
        val context = parent.context
        val title = text(context, "$label: ${format(get())}", 15f, TEXT)
        parent.addView(title, rowParams(context))
        val bar = SeekBar(context)
        bar.max = max - min
        bar.progress = (get() - min).coerceIn(0, max - min)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                val value = progress + min
                title.text = "$label: ${format(value)}"
                if (fromUser) set(value)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        parent.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun inputRow(parent: LinearLayout, label: String, hint: String, get: () -> String, set: (String) -> Unit, secret: Boolean = false): EditText {
        val context = parent.context
        parent.addView(text(context, label, 15f, TEXT), rowParams(context))
        val edit = EditText(context)
        edit.setText(get())
        edit.hint = hint
        edit.setTextColor(TEXT)
        edit.setHintTextColor(MUTED)
        edit.setSingleLine(true)
        edit.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        edit.setOnFocusChangeListener { _, focused -> if (!focused) set(edit.text.toString().trim()) }
        parent.addView(edit, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return edit
    }

    /** Escolha entre poucas opções (cada uma vira um botão; a atual fica destacada). */
    fun choiceRow(parent: LinearLayout, label: String, options: List<Pair<String, String>>, get: () -> String, set: (String) -> Unit) {
        val context = parent.context
        parent.addView(text(context, label, 15f, TEXT), rowParams(context))
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val buttons = ArrayList<Pair<Button, String>>()
        fun refresh() {
            for ((b, value) in buttons) {
                val selected = get() == value
                b.background = rounded(context, if (selected) ACCENT else Color.parseColor("#2A2E57"), 10)
                b.setTextColor(if (selected) Color.BLACK else TEXT)
            }
        }
        for ((labelText, value) in options) {
            val b = Button(context)
            b.text = labelText
            b.isAllCaps = false
            b.setOnClickListener {
                set(value)
                refresh()
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.marginEnd = dp(context, 6)
            row.addView(b, lp)
            buttons.add(Pair(b, value))
        }
        refresh()
        parent.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun button(parent: LinearLayout, label: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val context = parent.context
        val b = Button(context)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(if (primary) Color.BLACK else TEXT)
        b.background = rounded(context, if (primary) ACCENT else Color.parseColor("#2A2E57"), 12)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(context, 8)
        parent.addView(b, lp)
        return b
    }

    fun statusLine(parent: LinearLayout, label: String): Pair<TextView, TextView> {
        val context = parent.context
        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val name = text(context, label, 14f, MUTED)
        val value = text(context, "…", 14f, TEXT, bold = true)
        value.gravity = Gravity.END
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(value, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f))
        parent.addView(row, rowParams(context))
        return Pair(name, value)
    }

    fun note(parent: LinearLayout, message: String, color: Int = MUTED): TextView {
        val tv = text(parent.context, message, 12f, color)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(parent.context, 4)
        parent.addView(tv, lp)
        return tv
    }

    fun show(v: View, visible: Boolean) {
        v.visibility = if (visible) View.VISIBLE else View.GONE
    }
}
