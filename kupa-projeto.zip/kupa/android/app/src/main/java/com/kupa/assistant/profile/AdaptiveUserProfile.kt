package com.kupa.assistant.profile

import android.content.Context
import com.kupa.assistant.actions.SecureJsonStore
import org.json.JSONObject

enum class Feedback { UP, DOWN, SHORTER, LONGER, NO_SUGGESTIONS }

/**
 * Perfil adaptativo, SÓ com o que o usuário mostra de forma explícita (botões de feedback) e uso simples (apps abertos).
 * Não aprende senhas, tokens, chaves nem conteúdo sensível. Cifrado no aparelho e apagável a qualquer momento.
 */
class AdaptiveUserProfile(context: Context) {
    private val store = SecureJsonStore(context, "profile")
    private var data: JSONObject = store.read()

    private val levels = listOf("OFF", "LOW", "MEDIUM", "HIGH")

    @Synchronized
    private fun save() {
        store.write(data)
    }

    /** -1 = respostas bem curtas, 0 = normal, 1 = mais detalhadas. */
    @Synchronized
    fun verbosity(): Int = data.optInt("verbosity", 0)

    /** Proatividade efetiva: o que o usuário ajustou com feedback > padrão do modo > padrão global. */
    @Synchronized
    fun proactivity(modeId: String, modeDefault: String?, globalDefault: String): String {
        val key = if (modeId.isEmpty()) "geral" else modeId
        val override = data.optJSONObject("proactivity")?.optString(key, "")
        return if (!override.isNullOrEmpty()) override else (modeDefault ?: globalDefault)
    }

    @Synchronized
    fun record(feedback: Feedback, modeId: String, currentProactivity: String) {
        val key = if (modeId.isEmpty()) "geral" else modeId
        val streaks = data.optJSONObject("downStreak") ?: JSONObject().also { data.put("downStreak", it) }
        val overrides = data.optJSONObject("proactivity") ?: JSONObject().also { data.put("proactivity", it) }
        when (feedback) {
            Feedback.UP -> {
                streaks.put(key, 0)
                data.put("likes", data.optInt("likes", 0) + 1)
            }
            Feedback.DOWN -> {
                val s = streaks.optInt(key, 0) + 1
                data.put("dislikes", data.optInt("dislikes", 0) + 1)
                if (s >= 3) { // 3 "não útil" seguidos: o KUPA sugere menos neste modo
                    val idx = levels.indexOf(currentProactivity.uppercase()).coerceAtLeast(0)
                    overrides.put(key, levels[maxOf(0, idx - 1)])
                    streaks.put(key, 0)
                } else {
                    streaks.put(key, s)
                }
            }
            Feedback.SHORTER -> data.put("verbosity", maxOf(-1, verbosity() - 1))
            Feedback.LONGER -> data.put("verbosity", minOf(1, verbosity() + 1))
            Feedback.NO_SUGGESTIONS -> overrides.put(key, "OFF")
        }
        save()
    }

    @Synchronized
    fun noteAppOpened(label: String) {
        val apps = data.optJSONObject("apps") ?: JSONObject().also { data.put("apps", it) }
        apps.put(label.take(60), apps.optInt(label.take(60), 0) + 1)
        save()
    }

    @Synchronized
    fun topApps(n: Int): List<Pair<String, Int>> {
        val apps = data.optJSONObject("apps") ?: return emptyList()
        val out = ArrayList<Pair<String, Int>>()
        for (k in apps.keys()) out.add(Pair(k, apps.optInt(k)))
        return out.sortedByDescending { it.second }.take(n)
    }

    @Synchronized
    fun summary(): String {
        val likes = data.optInt("likes", 0)
        val dislikes = data.optInt("dislikes", 0)
        val verb = when (verbosity()) {
            -1 -> "respostas bem curtas"
            1 -> "respostas mais detalhadas"
            else -> "respostas normais"
        }
        val apps = topApps(3).joinToString(", ") { "${it.first} (${it.second}x)" }
        return "Feedback: $likes úteis, $dislikes não úteis. Estilo preferido: $verb." + if (apps.isNotEmpty()) " Apps que você mais pede: $apps." else ""
    }

    @Synchronized
    fun clear() {
        data = JSONObject()
        store.clear()
    }
}
