package com.kupa.assistant.ui

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.kupa.assistant.KupaApp
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.history.HistoryType

/** Conversa por texto com o KUPA (usa o mesmo núcleo, com ou sem voz). */
class ChatActivity : Activity(), KupaCore.Listener {
    private lateinit var app: KupaApp
    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var input: EditText
    private val stateListener = StateManager.Listener { _, current -> status.text = "Popol: ${current.label}" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 12))

        root.addView(Ui.text(this, "Conversar", 22f, Ui.TEXT, bold = true))
        status = Ui.text(this, "Popol: ${app.states.current.label}", 12f, Ui.MUTED)
        root.addView(status)

        scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "Pergunte qualquer coisa…"
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.maxLines = 4
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }
        bar.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendButton = Button(this)
        sendButton.text = "Enviar"
        sendButton.isAllCaps = false
        sendButton.setOnClickListener { send() }
        bar.addView(sendButton)
        val mic = Button(this)
        mic.text = "Falar"
        mic.isAllCaps = false
        mic.setOnClickListener { app.core.listenNow() }
        bar.addView(mic)
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        for (e in app.core.sessionExchanges) addExchange(e)
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        app.core.submitText(text, HistoryType.TEXT)
    }

    override fun onStart() {
        super.onStart()
        app.core.addListener(this)
        app.states.addListener(stateListener)
    }

    override fun onStop() {
        app.core.removeListener(this)
        app.states.removeListener(stateListener)
        super.onStop()
    }

    private fun bubble(text: String, mine: Boolean, error: Boolean = false): TextView {
        val tv = Ui.text(this, text, 15f, if (error) Ui.BAD else Ui.TEXT)
        tv.background = Ui.rounded(this, if (mine) Color.parseColor("#2A2E57") else Ui.CARD, 14)
        val pad = Ui.dp(this, 10)
        tv.setPadding(pad, pad, pad, pad)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 8)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.marginStart = if (mine) Ui.dp(this, 40) else 0
        lp.marginEnd = if (mine) 0 else Ui.dp(this, 40)
        tv.layoutParams = lp
        tv.setTextIsSelectable(true)
        return tv
    }

    private fun addExchange(e: KupaCore.Exchange) {
        list.addView(bubble(e.question, true))
        val sources = if (e.sources.isEmpty()) "" else "\n\nFontes: " + e.sources.joinToString(", ") { it.title.ifEmpty { it.url } }
        list.addView(bubble(e.answer + sources, false))
        scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onExchange(exchange: KupaCore.Exchange) = addExchange(exchange)

    override fun onProblem(message: String) {
        list.addView(bubble(message, false, error = true))
        scroll.post { scroll.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    override fun onBubble(text: String?, isError: Boolean) {}
}
