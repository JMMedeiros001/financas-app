package com.kupa.assistant.ui

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import com.kupa.assistant.KupaApp

/** Conversa por texto com o KUPA (tela cheia no celular). No tablet o mesmo painel fica dentro da tela inicial. */
class ChatActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = KupaApp.from(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 8))
        body.addView(Ui.header(this, "Conversas"))
        body.addView(ChatPanel(this, app), LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(body, LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(NavBar.build(this), LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT))
        Ui.padTopForSystemBars(root)
        setContentView(root)
    }
}
