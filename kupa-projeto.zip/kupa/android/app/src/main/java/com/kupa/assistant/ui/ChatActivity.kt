package com.kupa.assistant.ui

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import com.kupa.assistant.KupaApp

/** Conversa por texto com o KUPA (tela cheia no celular). No tablet o mesmo painel fica dentro da tela inicial. */
class ChatActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = KupaApp.from(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 12))
        root.addView(Ui.text(this, "Conversar", 22f, Ui.TEXT, bold = true))
        root.addView(ChatPanel(this, app), LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }
}
