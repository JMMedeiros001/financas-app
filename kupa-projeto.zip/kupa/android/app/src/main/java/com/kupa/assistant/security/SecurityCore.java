package com.kupa.assistant.security;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Núcleo de segurança: máquina de estados + registro mínimo de eventos (sem conteúdo, sem segredos).
 * Reações: BLOCK -> ALERT -> LOG -> STOP -> SAFE_SHUTDOWN para tentativa séria de burlar as regras.
 * Lógica pura (sem Android) para poder ser testada de verdade.
 */
public final class SecurityCore {
    public enum Signal {
        /** A IA pediu uma ferramenta que não existe/não está autorizada. */
        AI_TOOL_NOT_ALLOWED,
        /** Argumentos inválidos numa chamada de ferramenta. */
        AI_INVALID_ARGS,
        /** Texto com instruções para burlar as regras (prompt injection). */
        INJECTION_SUSPECTED,
        /** Algo tentou desativar/alterar o SecurityCore ou as políticas. */
        POLICY_BYPASS_ATTEMPT,
        /** Algo tentou pular uma confirmação. */
        CONFIRMATION_BYPASS,
        /** Sinal FRACO de integridade (depurador, chave de teste...). Não prova comprometimento. */
        INTEGRITY_WEAK_SIGNAL,
        /** Evidência CONFIÁVEL de comprometimento (só use com prova real). */
        COMPROMISE_EVIDENCE
    }

    public static final class Event {
        public final long timeMs;
        public final String code;
        public final SecurityState state;

        Event(long timeMs, String code, SecurityState state) {
            this.timeMs = timeMs;
            this.code = code;
            this.state = state;
        }
    }

    /** O que o app deve fazer depois de um sinal. */
    public static final class Reaction {
        public final SecurityState state;
        public final boolean blockCurrentAction;
        public final boolean alertUser;
        public final boolean safeShutdown;
        public final String message;

        Reaction(SecurityState state, boolean block, boolean alert, boolean shutdown, String message) {
            this.state = state;
            this.blockCurrentAction = block;
            this.alertUser = alert;
            this.safeShutdown = shutdown;
            this.message = message;
        }
    }

    private static final long WINDOW_MS = 10 * 60_000L;
    private static final long WARNING_DECAY_MS = 15 * 60_000L;
    private static final long SUSPICIOUS_DECAY_MS = 30 * 60_000L;
    private static final int MAX_EVENTS = 100;

    private SecurityState state = SecurityState.NORMAL;
    private long lastRaisedAt = 0L;
    private final Deque<Event> events = new ArrayDeque<>();
    private final List<Long> aiViolations = new ArrayList<>();
    private final List<Long> injections = new ArrayList<>();

    public synchronized SecurityState state(long nowMs) {
        decay(nowMs);
        return state;
    }

    public synchronized List<Event> events() {
        return new ArrayList<>(events);
    }

    public synchronized Reaction report(Signal signal, long nowMs) {
        decay(nowMs);
        switch (signal) {
            case POLICY_BYPASS_ATTEMPT:
            case CONFIRMATION_BYPASS:
                move(SecurityState.SAFE_SHUTDOWN, signal, nowMs);
                return new Reaction(state, true, true, true, "Detectei uma tentativa de burlar as regras de segurança. Bloqueei, parei tudo e entrei em modo seguro.");
            case COMPROMISE_EVIDENCE:
                move(SecurityState.COMPROMISED, signal, nowMs);
                return new Reaction(state, true, true, true, "Há evidência de comprometimento. Bloqueei ações sensíveis e parei. Use as ferramentas oficiais do Android para verificar o aparelho.");
            case INJECTION_SUSPECTED:
                prune(injections, nowMs);
                injections.add(nowMs);
                if (injections.size() >= 3) {
                    move(SecurityState.SUSPICIOUS, signal, nowMs);
                    return new Reaction(state, true, true, false, "Vi várias tentativas de me dar ordens escondidas em conteúdo. Bloqueei ações sensíveis por precaução.");
                }
                move(SecurityState.WARNING, signal, nowMs);
                return new Reaction(state, true, true, false, "Esse conteúdo parecia conter ordens para eu burlar minhas regras. Ignorei e bloqueei o pedido.");
            case AI_TOOL_NOT_ALLOWED:
            case AI_INVALID_ARGS:
                prune(aiViolations, nowMs);
                aiViolations.add(nowMs);
                if (aiViolations.size() >= 3) {
                    move(SecurityState.SUSPICIOUS, signal, nowMs);
                    return new Reaction(state, true, true, false, "A IA pediu ações não autorizadas várias vezes. Bloqueei ações sensíveis por precaução.");
                }
                move(SecurityState.WARNING, signal, nowMs);
                return new Reaction(state, true, false, false, "A IA pediu algo que não está autorizado. Bloqueei.");
            case INTEGRITY_WEAK_SIGNAL:
                move(SecurityState.WARNING, signal, nowMs);
                return new Reaction(state, false, false, false, "Vi um sinal fraco que pode indicar um problema de integridade, mas não consigo confirmar a origem.");
            default:
                return new Reaction(state, false, false, false, "");
        }
    }

    /** Voltar de COMPROMISED/SAFE_SHUTDOWN só com ação explícita e segura do usuário (autenticação feita). */
    public synchronized boolean rearm(boolean userAuthenticated, long nowMs) {
        if (!state.blocksActions()) return true;
        if (!userAuthenticated) return false;
        state = SecurityState.NORMAL;
        aiViolations.clear();
        injections.clear();
        log("REARM", nowMs);
        return true;
    }

    private void move(SecurityState target, Signal signal, long nowMs) {
        // só sobe de gravidade; nunca desce por causa de um novo sinal
        if (target.ordinal() > state.ordinal()) state = target;
        lastRaisedAt = nowMs;
        log(signal.name(), nowMs);
    }

    private void log(String code, long nowMs) {
        if (events.size() >= MAX_EVENTS) events.removeFirst();
        events.addLast(new Event(nowMs, code, state));
    }

    private void prune(List<Long> list, long nowMs) {
        for (int i = list.size() - 1; i >= 0; i--) if (nowMs - list.get(i) > WINDOW_MS) list.remove(i);
    }

    private void decay(long nowMs) {
        if (state == SecurityState.WARNING && nowMs - lastRaisedAt > WARNING_DECAY_MS) state = SecurityState.NORMAL;
        else if (state == SecurityState.SUSPICIOUS && nowMs - lastRaisedAt > SUSPICIOUS_DECAY_MS) {
            state = SecurityState.WARNING;
            lastRaisedAt = nowMs;
        }
    }
}
