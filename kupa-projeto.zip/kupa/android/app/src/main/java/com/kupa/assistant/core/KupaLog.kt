package com.kupa.assistant.core

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Log de desenvolvimento: vai para o Logcat e para um buffer em memória (tela de diagnóstico). Nunca grava segredos. */
object KupaLog {
    private const val TAG = "KUPA"
    private const val MAX_LINES = 300
    private val lines = ArrayDeque<String>()
    private val format = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val keyRegex = Regex("sk-[A-Za-z0-9_-]{8,}")
    private val bearerRegex = Regex("(?i)(bearer\\s+)[A-Za-z0-9._~+/=-]{8,}")
    private val dataUrlRegex = Regex("data:image/[a-z]+;base64,[A-Za-z0-9+/=]{20,}")

    private fun clean(message: String): String = message
        .replace(keyRegex, "sk-[REDACTED]")
        .replace(bearerRegex, "\$1[REDACTED]")
        .replace(dataUrlRegex, "data:image/...[omitido]")

    @Synchronized
    private fun add(level: String, tag: String, message: String) {
        val line = "${format.format(Date())} $level/$tag: ${clean(message)}"
        if (lines.size >= MAX_LINES) lines.removeFirst()
        lines.addLast(line)
    }

    fun d(tag: String, message: String) {
        add("D", tag, message)
        Log.d(TAG, "[$tag] ${clean(message)}")
    }

    fun i(tag: String, message: String) {
        add("I", tag, message)
        Log.i(TAG, "[$tag] ${clean(message)}")
    }

    fun w(tag: String, message: String) {
        add("W", tag, message)
        Log.w(TAG, "[$tag] ${clean(message)}")
    }

    fun e(tag: String, message: String, error: Throwable? = null) {
        val full = if (error != null) "$message (${error.javaClass.simpleName}: ${error.message})" else message
        add("E", tag, full)
        Log.e(TAG, "[$tag] ${clean(full)}")
    }

    @Synchronized
    fun snapshot(): List<String> = lines.toList()
}
