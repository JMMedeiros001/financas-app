package com.kupa.assistant.ai;

import java.net.URI;
import java.util.Locale;

/**
 * Valida a URL do backend ANTES de qualquer conexão. Lógica pura (testada).
 * Produção: só HTTPS e só um endereço remoto de verdade. Desenvolvimento (debug): HTTP apenas para rede local explícita.
 */
public final class BackendUrlValidator {
    private BackendUrlValidator() {}

    public enum Problem {
        NONE, EMPTY, MALFORMED, UNSUPPORTED_SCHEME, INSECURE_REMOTE, LOOPBACK, PLACEHOLDER, HAS_CREDENTIALS, HAS_QUERY_OR_FRAGMENT, BAD_PORT
    }

    public static final class Result {
        public final Problem problem;
        /** URL normalizada (sem barra final) quando válida; vazia caso contrário. */
        public final String normalized;
        /** Explicação em português, pronta para mostrar ao usuário. */
        public final String message;

        Result(Problem problem, String normalized, String message) {
            this.problem = problem;
            this.normalized = normalized;
            this.message = message;
        }

        public boolean ok() { return problem == Problem.NONE; }
    }

    private static final String[] PLACEHOLDER_MARKERS = {
        "exemplo", "example", "seu-", "sua-", "seudominio", "seu_dominio", "nome-do-seu", "meu-backend-aqui", "xxxx", "<", ">", "...", "sualink", "suaurl",
    };

    public static Result validate(String raw, boolean allowCleartextLocal) {
        String text = raw == null ? "" : raw.trim();
        if (text.isEmpty()) {
            return new Result(Problem.EMPTY, "", "A URL do backend não foi informada.");
        }
        String lower = text.toLowerCase(Locale.ROOT);
        for (String marker : PLACEHOLDER_MARKERS) {
            if (lower.contains(marker)) {
                return new Result(Problem.PLACEHOLDER, "", "Isto parece um exemplo, não um endereço real. Use o endereço público que a hospedagem do backend te deu.");
            }
        }
        URI uri;
        try {
            uri = new URI(text);
        } catch (Exception e) {
            return new Result(Problem.MALFORMED, "", "O endereço não é uma URL válida. Ele deve começar com https:// e ter o formato https://endereco.com");
        }
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
        String host = uri.getHost();
        if (scheme.isEmpty() || host == null || host.isEmpty()) {
            return new Result(Problem.MALFORMED, "", "O endereço está incompleto. Ele deve começar com https:// e ter o formato https://endereco.com");
        }
        if (!scheme.equals("https") && !scheme.equals("http")) {
            return new Result(Problem.UNSUPPORTED_SCHEME, "", "Só endereços https:// são aceitos.");
        }
        if (uri.getRawUserInfo() != null) {
            return new Result(Problem.HAS_CREDENTIALS, "", "Não coloque usuário ou senha dentro da URL. O token é digitado à parte e fica cifrado no aparelho.");
        }
        if (uri.getRawQuery() != null || uri.getRawFragment() != null) {
            return new Result(Problem.HAS_QUERY_OR_FRAGMENT, "", "A URL não deve ter ? nem #. Use só o endereço base do backend.");
        }
        int port = uri.getPort();
        if (port != -1 && (port < 1 || port > 65535)) {
            return new Result(Problem.BAD_PORT, "", "A porta informada é inválida.");
        }
        boolean loopback = isLoopback(host);
        boolean local = isPrivateOrLocal(host);
        if (scheme.equals("http")) {
            if (!allowCleartextLocal) {
                return new Result(Problem.INSECURE_REMOTE, "", "Este APK só aceita HTTPS (conexão criptografada). Hospede o backend com HTTPS; as plataformas de hospedagem já fornecem isso.");
            }
            if (!(local || loopback)) {
                return new Result(Problem.INSECURE_REMOTE, "", "HTTP só é aceito em builds de teste e só para um endereço da sua rede local. Para um servidor remoto use HTTPS.");
            }
        }
        if (loopback && !allowCleartextLocal) {
            return new Result(Problem.LOOPBACK, "", "localhost no celular é o próprio celular, não o seu computador nem a internet. Use o endereço público do backend.");
        }
        if (!scheme.equals("https") && loopback) {
            // dev: só funciona com "adb reverse"; avisa mas aceita
            return new Result(Problem.NONE, normalize(uri, scheme, host, port), "Aceito para teste: localhost só funciona no aparelho com 'adb reverse'.");
        }
        return new Result(Problem.NONE, normalize(uri, scheme, host, port), "URL válida.");
    }

    private static String normalize(URI uri, String scheme, String host, int port) {
        String path = uri.getRawPath() == null ? "" : uri.getRawPath();
        while (path.endsWith("/")) path = path.substring(0, path.length() - 1);
        String h = host.contains(":") && !host.startsWith("[") ? "[" + host + "]" : host;
        return scheme + "://" + h.toLowerCase(Locale.ROOT) + (port == -1 ? "" : ":" + port) + path;
    }

    static boolean isLoopback(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("localhost") || h.equals("0.0.0.0") || h.equals("::1") || h.equals("[::1]") || h.startsWith("127.");
    }

    static boolean isPrivateOrLocal(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("10.0.2.2") || h.endsWith(".local")) return true; // emulador Android / mDNS
        String[] p = h.split("\\.");
        if (p.length != 4) return false;
        try {
            int a = Integer.parseInt(p[0]);
            int b = Integer.parseInt(p[1]);
            return a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31);
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
