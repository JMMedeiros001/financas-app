package com.kupa.assistant.actions

import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.intent.CommandInterpreter
import com.kupa.assistant.intent.KupaIntent
import com.kupa.assistant.intent.LearnedCommand
import com.kupa.assistant.intent.LearningPlanner
import com.kupa.assistant.intent.ReplyParser
import com.kupa.assistant.intent.TextNorm
import com.kupa.assistant.modes.ModeManager
import com.kupa.assistant.security.SecurityGuard

/**
 * Camada de intenções: texto falado -> INTENÇÕES estruturadas -> executor Android.
 * Cuida de comandos aprendidos, sequências ("abra X e depois Y"), perguntas pendentes (sim/não, escolhas)
 * e dos comandos de aprender/esquecer. A IA NUNCA executa nada direto: passa por aqui e pelo ActionExecutor.
 * Métodos podem bloquear (contatos, espera de confirmação do Android): chame fora da thread principal.
 */
class CommandCenter(
    private val ctx: ConversationContext,
    private val executor: ActionExecutor,
    private val learned: LearnedStore,
    private val modes: ModeManager,
    private val security: SecurityGuard,
    private val onStop: () -> Unit,
) {
    sealed class Decision {
        class Executed(val result: ActionResult) : Decision()
        object NotCommand : Decision()
        object Ignored : Decision()
    }

    private val interpreter = CommandInterpreter()

    fun hasPending(): Boolean = ctx.hasPending()

    fun cancelPending() = ctx.clearPending()

    /** Rápido e sem I/O de contatos: a frase (ou um atalho aprendido) é um comando de celular? */
    fun looksLikeCommand(text: String): Boolean {
        val expanded = LearningPlanner.expandPhrase(text, learned.all()) ?: text
        return !interpreter.interpret(expanded).isEmpty
    }

    /**
     * Decide o que fazer com a frase.
     * @param addressed a pessoa chamou o KUPA ("Kupa, ...") ou veio de um botão/modo por palavra-chave
     * @param continuous modo de escuta contínua (frases soltas sem comando são ignoradas, nunca vão à IA sem querer)
     */
    fun decide(text: String, continuous: Boolean, addressed: Boolean, fromVoice: Boolean): Decision {
        if (ctx.hasPending()) {
            val answered = answerPending(text, fromVoice)
            if (answered != null) return Decision.Executed(answered)
        }
        val expanded = LearningPlanner.expandPhrase(text, learned.all()) ?: text
        val interpretation = interpreter.interpret(expanded)
        if (interpretation.isEmpty) return if (continuous && !addressed) Decision.Ignored else Decision.NotCommand
        val forceConfirm = continuous && !addressed // voz solta pode ser TV/conversa: ações sensíveis sempre perguntam
        return Decision.Executed(register(runFrom(interpretation.intents, 0, emptyList(), false, forceConfirm, fromVoice)))
    }

    /** Usado pelas ferramentas da IA (open_app, call_contact, incoming_call). Sensíveis sempre pedem confirmação. */
    fun runFromAi(intents: List<KupaIntent>): ActionResult = register(runFrom(intents, 0, emptyList(), true, true, false))

    // ------------------------------------------------------------------ perguntas pendentes

    private fun answerPending(text: String, fromVoice: Boolean): ActionResult? {
        val labels = ctx.pendingLabels()
        val pending = ctx.takePending() ?: return null
        val reply = ReplyParser.parse(text, labels)
        val asCommand = interpreter.interpret(LearningPlanner.expandPhrase(text, learned.all()) ?: text)
        val tokens = TextNorm.tokens(TextNorm.normalize(text)).size

        // a pessoa mudou de assunto com um comando novo e claro: descarta a pergunta e deixa o comando seguir
        val looksLikeNewCommand = !asCommand.isEmpty && (reply.type == ReplyParser.Type.UNKNOWN || (reply.type == ReplyParser.Type.YES && tokens > 2))
        if (looksLikeNewCommand) return null

        return when (pending) {
            is Pending.Confirm -> when (reply.type) {
                ReplyParser.Type.YES -> register(pending.onYes())
                ReplyParser.Type.NO -> ActionResult.Done(pending.onNoMessage)
                else -> reask(pending, "Responda sim ou não. ${pending.prompt}")
            }
            is Pending.Choice -> when (reply.type) {
                ReplyParser.Type.CHOICE -> register(pending.onChoice(reply.index))
                ReplyParser.Type.NO -> ActionResult.Done("Ok, cancelei.")
                else -> reask(pending, "Não entendi qual. ${pending.prompt}")
            }
        }
    }

    private fun reask(pending: Pending, prompt: String): ActionResult {
        if (pending.attempts >= 1) return ActionResult.Done("Ok, deixei pra lá.")
        pending.attempts += 1
        ctx.setPending(pending)
        return ActionResult.Reask(prompt)
    }

    /** Guarda a pergunta pendente quando o resultado é uma pergunta. Chamado só nos pontos de saída. */
    private fun register(result: ActionResult): ActionResult {
        when (result) {
            is ActionResult.AskConfirm -> ctx.setPending(ctx.newConfirm(result.prompt, result.onYes, result.onNoMessage))
            is ActionResult.AskChoice -> ctx.setPending(ctx.newChoice(result.prompt, result.labels, result.onChoice))
            else -> {}
        }
        return result
    }

    // ------------------------------------------------------------------ sequências

    private fun runFrom(intents: List<KupaIntent>, start: Int, prior: List<String>, fromAi: Boolean, forceConfirm: Boolean, fromVoice: Boolean): ActionResult {
        val messages = ArrayList(prior)
        var i = start
        while (i < intents.size) {
            val r = executeOne(intents[i], fromAi, forceConfirm, fromVoice)
            when (r) {
                is ActionResult.Done -> {
                    messages.add(r.message)
                    i++
                }
                is ActionResult.Failed -> {
                    messages.add(r.message)
                    if (i < intents.size - 1) messages.add("Parei a sequência por aqui.")
                    return ActionResult.Failed(messages.joinToString(" "))
                }
                is ActionResult.AskConfirm -> {
                    val next = i + 1
                    val before = ArrayList(messages)
                    return ActionResult.AskConfirm(
                        (before + r.prompt).joinToString(" "),
                        { continueAfter(r.onYes(), intents, next, before, fromAi, forceConfirm, fromVoice) },
                        r.onNoMessage,
                    )
                }
                is ActionResult.AskChoice -> {
                    val next = i + 1
                    val before = ArrayList(messages)
                    return ActionResult.AskChoice(
                        (before + r.prompt).joinToString(" "), r.labels,
                        { idx -> continueAfter(r.onChoice(idx), intents, next, before, fromAi, forceConfirm, fromVoice) },
                    )
                }
                is ActionResult.Reask -> return r
            }
        }
        return ActionResult.Done(messages.joinToString(" "))
    }

    private fun continueAfter(result: ActionResult, intents: List<KupaIntent>, next: Int, before: List<String>, fromAi: Boolean, forceConfirm: Boolean, fromVoice: Boolean): ActionResult {
        return when (result) {
            is ActionResult.Done -> {
                if (next >= intents.size) ActionResult.Done((before + result.message).joinToString(" "), result.verified)
                else runFrom(intents, next, before + result.message, fromAi, forceConfirm, fromVoice)
            }
            is ActionResult.Failed -> ActionResult.Failed((before + result.message).joinToString(" "))
            else -> result
        }
    }

    private fun executeOne(intent: KupaIntent, fromAi: Boolean, forceConfirm: Boolean, fromVoice: Boolean): ActionResult {
        // "parar tudo" nunca é bloqueado (é o botão de emergência); o resto respeita o estado de segurança
        if (intent.kind == KupaIntent.Kind.STOP_KUPA) {
            onStop()
            return ActionResult.Done("Parei tudo.")
        }
        if (security.state().blocksActions() && intent.kind != KupaIntent.Kind.LIST_LEARNED && intent.kind != KupaIntent.Kind.LIST_MODES) {
            return ActionResult.Failed("O KUPA está em modo seguro e não executa comandos. Reative em Configurações, com a confirmação do aparelho.")
        }
        return when (intent.kind) {
            KupaIntent.Kind.LEARN -> learn(intent)
            KupaIntent.Kind.FORGET -> forget(intent)
            KupaIntent.Kind.LIST_LEARNED -> listLearned()
            KupaIntent.Kind.ACTIVATE_MODE -> activateMode(intent)
            KupaIntent.Kind.EXIT_MODE -> exitMode()
            KupaIntent.Kind.LIST_MODES -> listModes()
            else -> executor.execute(intent, fromAi, forceConfirm, fromVoice)
        }
    }

    // ------------------------------------------------------------------ modos

    private fun activateMode(intent: KupaIntent): ActionResult {
        val name = intent.trigger.orEmpty()
        val mode = modes.findByName(name)
            ?: return ActionResult.Failed("Não encontrei um modo chamado $name. Crie em Configurações, em Modos.")
        modes.activate(mode.id)
        return ActionResult.Done("Modo ${mode.name} ativado. As regras de segurança continuam as mesmas.")
    }

    private fun exitMode(): ActionResult {
        val active = modes.active() ?: return ActionResult.Done("Nenhum modo personalizado estava ativo.")
        modes.exit()
        return ActionResult.Done("Saí do modo ${active.name}.")
    }

    private fun listModes(): ActionResult {
        val all = modes.all()
        if (all.isEmpty()) return ActionResult.Done("Você ainda não criou nenhum modo. Crie em Configurações, em Modos.")
        val active = modes.active()?.name
        return ActionResult.Done("Seus modos: " + all.joinToString(", ") { it.name } + (if (active != null) ". Ativo agora: $active." else "."))
    }

    // ------------------------------------------------------------------ aprender / esquecer / listar

    private fun learn(intent: KupaIntent): ActionResult {
        val plan = LearningPlanner.plan(intent.trigger.orEmpty(), intent.meaning.orEmpty(), interpreter)
        if (!plan.ok) return ActionResult.Failed(plan.error ?: "Não consegui aprender isso.")
        val existing = learned.findByTrigger(plan.trigger)
        val prompt = if (existing != null) {
            "Já existe um comando para \"${plan.trigger}\". Quer substituir? Agora seria: ${plan.description}."
        } else {
            "Entendi: ${plan.description}. Posso salvar?"
        }
        // Aprender SEMPRE pede confirmação: nada muda em silêncio.
        return ActionResult.AskConfirm(prompt, {
            learned.put(plan.kind ?: LearnedCommand.Kind.PHRASE, plan.trigger, plan.expansion)
            KupaLog.i("aprendizado", "novo comando salvo")
            ActionResult.Done("Salvei. Quando você disser \"${plan.trigger}\", eu vou ${plan.description.substringAfter("vou ")}.")
        }, "Ok, não salvei nada.")
    }

    private fun forget(intent: KupaIntent): ActionResult {
        val trigger = intent.trigger.orEmpty()
        return if (learned.removeByTrigger(trigger)) ActionResult.Done("Esqueci o comando \"$trigger\".")
        else ActionResult.Failed("Não achei nenhum comando aprendido chamado \"$trigger\".")
    }

    private fun listLearned(): ActionResult {
        val all = learned.all()
        if (all.isEmpty()) return ActionResult.Done("Você ainda não me ensinou nenhum comando.")
        val names = all.take(3).joinToString(", ") { "\"${it.trigger}\"" }
        val more = if (all.size > 3) " e mais ${all.size - 3}" else ""
        return ActionResult.Done("Você me ensinou ${all.size} " + (if (all.size == 1) "comando" else "comandos") + ": $names$more. Veja todos em Configurações, em Comandos aprendidos.")
    }
}
