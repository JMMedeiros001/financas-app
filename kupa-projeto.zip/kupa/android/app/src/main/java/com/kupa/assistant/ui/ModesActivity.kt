package com.kupa.assistant.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import com.kupa.assistant.KupaApp
import com.kupa.assistant.modes.ModeManager
import com.kupa.assistant.modes.ModeProfile

/**
 * Modos personalizados. Um modo orienta o estilo e pode RESTRINGIR recursos (tela, pesquisa); ele NUNCA desativa a segurança
 * nem libera algo que as configurações globais proíbem. Por voz: "ativar modo X", "sair do modo", "quais modos".
 */
class ModesActivity : Activity() {
    private lateinit var app: KupaApp
    private lateinit var column: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        column = Ui.screen(this, "Modos")
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        while (column.childCount > 1) column.removeViewAt(1)
        column.addView(
            Ui.text(
                this,
                "Um modo muda o foco e o estilo das respostas e pode restringir recursos. Nenhum modo desativa a segurança do KUPA. " +
                    "Criar um modo por voz ainda não está disponível: use esta tela. Para usar por voz: \"Kupa, ativar modo estudo\" e \"Kupa, sair do modo\".",
                13f, Ui.MUTED,
            ),
        )
        val active = app.modes.active()
        column.addView(Ui.text(this, if (active != null) "Modo ativo: ${active.name}" else "Nenhum modo ativo (padrão).", 15f, Ui.TEXT, bold = true))
        Ui.button(column, "Criar modo", primary = true) { showEditor(null) }
        Ui.button(column, "Criar modelo \"Método Dark\" (conteúdo digital)") {
            if (app.modes.findByName("Método Dark") != null) {
                Toast.makeText(this, "Esse modelo já foi criado.", Toast.LENGTH_SHORT).show()
            } else {
                app.modes.save(ModeManager.metodoDarkTemplate(app.modes.newId()))
                render()
            }
        }
        val all = app.modes.all().sortedBy { it.name.lowercase() }
        if (all.isEmpty()) column.addView(Ui.text(this, "Você ainda não criou nenhum modo.", 14f, Ui.MUTED))
        for (m in all) addRow(m, active?.id == m.id)
    }

    private fun addRow(m: ModeProfile, isActive: Boolean) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.rounded(this, Ui.CARD)
        val pad = Ui.dp(this, 12)
        card.setPadding(pad, pad, pad, pad)
        card.addView(Ui.text(this, m.name + if (isActive) "  ·  ATIVO" else "", 16f, if (isActive) Ui.OK else Ui.TEXT, bold = true))
        if (m.description.isNotBlank()) card.addView(Ui.text(this, m.description, 13f, Ui.MUTED))
        card.addView(
            Ui.text(
                this,
                "Proatividade: ${m.proactivity} · Tela: ${if (m.allowScreen) "permitida" else "bloqueada"} · Pesquisa: ${if (m.allowWeb) "permitida" else "bloqueada"}" +
                    if (m.modelClass.isNotEmpty()) " · Modelo: ${m.modelClass}" else "",
                12f, Ui.MUTED,
            ),
        )
        Ui.button(card, if (isActive) "Sair deste modo" else "Ativar") {
            if (isActive) app.modes.exit() else app.modes.activate(m.id)
            render()
        }
        Ui.button(card, "Editar") { showEditor(m) }
        Ui.button(card, "Apagar") {
            AlertDialog.Builder(this)
                .setMessage("Apagar o modo \"${m.name}\" e as notas dele?")
                .setPositiveButton("Apagar") { _, _ ->
                    app.modes.delete(m.id)
                    render()
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 10)
        column.addView(card, lp)
    }

    private fun field(form: LinearLayout, hint: String, value: String, lines: Int): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.inputType = if (lines > 1) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE else InputType.TYPE_CLASS_TEXT
        e.minLines = lines
        form.addView(e)
        return e
    }

    private fun showEditor(existing: ModeProfile?) {
        val form = LinearLayout(this)
        form.orientation = LinearLayout.VERTICAL
        val pad = Ui.dp(this, 16)
        form.setPadding(pad, pad, pad, 0)
        form.addView(TextView(this).apply { text = "O modo só orienta o estilo e pode restringir recursos. Ele nunca desativa a segurança." })
        val name = field(form, "Nome (ex.: Estudo)", existing?.name.orEmpty(), 1)
        val description = field(form, "Objetivo (opcional)", existing?.description.orEmpty(), 1)
        val instructions = field(form, "Instruções de foco e estilo", existing?.instructions.orEmpty(), 3)
        val notes = field(form, "Memória deste modo (preferências, tom, formato). Nunca coloque senhas.", existing?.notes.orEmpty(), 2)
        val levels = listOf("OFF", "LOW", "MEDIUM", "HIGH")
        val proactivity = Spinner(this)
        proactivity.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, levels.map { "Proatividade: $it" })
        proactivity.setSelection(levels.indexOf(existing?.proactivity ?: "OFF").coerceAtLeast(0))
        form.addView(proactivity)
        val classes = listOf("", "fast", "reasoning")
        val modelClass = Spinner(this)
        modelClass.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Modelo: padrão", "Modelo: rápido", "Modelo: raciocínio"))
        modelClass.setSelection(classes.indexOf(existing?.modelClass ?: "").coerceAtLeast(0))
        form.addView(modelClass)
        val allowScreen = CheckBox(this).apply { text = "Permitir análise de tela neste modo"; isChecked = existing?.allowScreen ?: true }
        val allowWeb = CheckBox(this).apply { text = "Permitir pesquisa na internet neste modo"; isChecked = existing?.allowWeb ?: true }
        form.addView(allowScreen)
        form.addView(allowWeb)
        AlertDialog.Builder(this)
            .setTitle(if (existing == null) "Novo modo" else "Editar modo")
            .setView(form)
            .setPositiveButton("Salvar") { _, _ ->
                val n = name.text.toString().trim()
                if (n.isEmpty()) {
                    Toast.makeText(this, "Dê um nome ao modo.", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val ok = app.modes.save(
                    ModeProfile(
                        existing?.id ?: app.modes.newId(), n, description.text.toString().trim(), instructions.text.toString(), notes.text.toString(),
                        levels[proactivity.selectedItemPosition], allowScreen.isChecked, allowWeb.isChecked, classes[modelClass.selectedItemPosition],
                    ),
                )
                if (!ok) Toast.makeText(this, "Não consegui salvar com segurança (cifra do aparelho indisponível).", Toast.LENGTH_LONG).show()
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
