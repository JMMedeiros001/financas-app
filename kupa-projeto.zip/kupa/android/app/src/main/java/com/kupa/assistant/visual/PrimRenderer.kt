package com.kupa.assistant.visual

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/** Desenha as primitivas de [CoreScene] num Canvas do Android. A geometria é a mesma testada em Java e usada nas prévias. */
object PrimRenderer {
    private val rect = RectF()

    fun draw(canvas: Canvas, prims: List<CoreScene.Prim>, cx: Float, cy: Float, radius: Float, paint: Paint) {
        for (p in prims) {
            paint.color = p.argb
            when (p.kind) {
                CoreScene.ARC -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeCap = Paint.Cap.ROUND
                    paint.strokeWidth = p.w * radius
                    val r = p.r * radius
                    val x = cx + p.x * radius
                    val y = cy + p.y * radius
                    rect.set(x - r, y - r, x + r, y + r)
                    canvas.drawArc(rect, p.a0, p.sweep, false, paint)
                }
                CoreScene.LINE -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeCap = Paint.Cap.ROUND
                    paint.strokeWidth = p.w * radius
                    canvas.drawLine(cx + p.x * radius, cy + p.y * radius, cx + p.x2 * radius, cy + p.y2 * radius, paint)
                }
                CoreScene.CIRCLE -> {
                    paint.style = Paint.Style.STROKE
                    paint.strokeCap = Paint.Cap.BUTT
                    paint.strokeWidth = p.w * radius
                    canvas.drawCircle(cx + p.x * radius, cy + p.y * radius, p.r * radius, paint)
                }
                else -> {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx + p.x * radius, cy + p.y * radius, p.r * radius, paint)
                }
            }
        }
    }
}
