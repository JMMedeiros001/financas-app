package com.kupa.assistant.ui

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import com.kupa.assistant.KupaApp
import com.kupa.assistant.history.HistoryEntry
import com.kupa.assistant.history.HistoryType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Histórico completo (só no aparelho): pergunta, resposta, data, hora e tipo. Dá para apagar um item ou tudo. */
class HistoryActivity : Activity() {
    private lateinit var app: KupaApp
    private lateinit var column: LinearLayout
    private val format = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        app = KupaApp.from(this)
        column = Ui.screen(this, "Histórico")
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun typeLabel(type: HistoryType): String = when (type) {
        HistoryType.VOICE -> "VOZ"
        HistoryType.TEXT -> "TEXTO"
        HistoryType.SEARCH -> "PESQUISA"
        HistoryType.SCREEN_ANALYSIS -> "ANÁLISE DE TELA"
        HistoryType.GAMER -> "GAMER"
    }

    private fun render() {
        while (column.childCount > 1) column.removeViewAt(1)
        val entries = app.history.list()
        if (entries.isEmpty()) {
            column.addView(Ui.text(this, "Nada por aqui ainda. Suas conversas com o KUPA ficam salvas só neste aparelho.", 14f, Ui.MUTED))
            return
        }
        Ui.button(column, "Apagar todo o histórico") { confirmClear() }
        for (e in entries) addRow(e)
    }

    private fun addRow(e: HistoryEntry) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = Ui.rounded(this, Ui.CARD)
        val pad = Ui.dp(this, 12)
        card.setPadding(pad, pad, pad, pad)
        card.addView(Ui.text(this, "${format.format(Date(e.timestampMs))}  ·  ${typeLabel(e.type)}", 11f, Ui.ACCENT, bold = true))
        card.addView(Ui.text(this, "Você: ${e.question}", 14f, Ui.TEXT))
        card.addView(Ui.text(this, "KUPA: ${e.answer}", 14f, Ui.MUTED))
        card.setOnLongClickListener {
            AlertDialog.Builder(this)
                .setMessage("Apagar este item do histórico?")
                .setPositiveButton("Apagar") { _, _ ->
                    app.history.delete(e.id)
                    render()
                }
                .setNegativeButton("Cancelar", null)
                .show()
            true
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 10)
        column.addView(card, lp)
    }

    private fun confirmClear() {
        AlertDialog.Builder(this)
            .setMessage("Apagar TODO o histórico? Isso não pode ser desfeito.")
            .setPositiveButton("Apagar tudo") { _, _ ->
                app.history.clear()
                app.core.clearConversation()
                render()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
