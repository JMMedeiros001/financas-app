package com.kupa.assistant.security;

import com.kupa.assistant.intent.TextNorm;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

/** Apps em que o KUPA NÃO analisa a tela (bancos, carteiras, senhas, autenticadores, saúde) + o que o usuário definir. */
public final class PrivacyZones {
    private PrivacyZones() {}

    private static final List<String> LABEL_WORDS = Arrays.asList(
        "banco", "bank", "nubank", "itau", "bradesco", "santander", "caixa", "picpay", "paypal", "pix", "carteira", "wallet",
        "authenticator", "autenticador", "bitwarden", "1password", "lastpass", "keepass", "dashlane", "keeper", "senhas", "passwords",
        "saude", "health", "receita", "inter", "c6", "neon", "next", "xp", "rico", "nuinvest", "binance", "mercado pago", "gov br", "meu inss", "fgts");
    private static final List<String> PACKAGE_PARTS = Arrays.asList(
        "nubank", "com.nu.", "itau", "bradesco", "santander", "caixa", "mercadopago", "picpay", "paypal", "authenticator", "bitwarden",
        "1password", "lastpass", "keepass", "dashlane", "wallet", "carteira", "banco", "bank", "binance", "gov.br", "receita", "fgts", "inss");

    public static boolean isSensitive(String label, String packageName, Collection<String> userEntries) {
        String l = TextNorm.normalize(label == null ? "" : label);
        String p = packageName == null ? "" : packageName.toLowerCase();
        List<String> tokens = TextNorm.tokens(l);
        for (String w : LABEL_WORDS) {
            if (w.contains(" ") ? l.contains(w) : tokens.contains(w)) return true;
        }
        for (String part : PACKAGE_PARTS) if (p.contains(part)) return true;
        if (userEntries != null) {
            for (String e : userEntries) {
                String n = TextNorm.normalize(e);
                if (n.isEmpty()) continue;
                if (l.equals(n) || l.contains(n) || (!p.isEmpty() && p.contains(e.toLowerCase().trim()))) return true;
            }
        }
        return false;
    }
}
