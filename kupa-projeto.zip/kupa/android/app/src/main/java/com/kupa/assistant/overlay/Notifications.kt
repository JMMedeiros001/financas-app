package com.kupa.assistant.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import com.kupa.assistant.R
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.ui.MainActivity

object Notifications {
    const val CHANNEL_SERVICE = "kupa_service"
    const val CHANNEL_ANSWERS = "kupa_answers"
    const val ID_SERVICE = 1001
    const val ID_ANSWER = 1002

    fun ensureChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val service = NotificationChannel(CHANNEL_SERVICE, "KUPA em execução", NotificationManager.IMPORTANCE_LOW)
        service.description = "Mantém o KUPA ativo para ouvir você e mostrar o Popol."
        service.setShowBadge(false)
        nm.createNotificationChannel(service)
        // importância baixa de propósito: sem som nem aviso por cima do jogo
        val answers = NotificationChannel(CHANNEL_ANSWERS, "Respostas do KUPA", NotificationManager.IMPORTANCE_LOW)
        answers.description = "Respostas curtas, sem som, quando o Modo Gamer está ligado."
        answers.setShowBadge(false)
        nm.createNotificationChannel(answers)
    }

    private fun pending(context: Context, requestCode: Int, intent: Intent, service: Boolean = false): PendingIntent {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        return if (service) PendingIntent.getService(context, requestCode, intent, flags) else PendingIntent.getActivity(context, requestCode, intent, flags)
    }

    fun serviceNotification(context: Context, gamerActive: Boolean): Notification {
        ensureChannels(context)
        val open = pending(context, 1, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
        val listen = pending(context, 2, Intent(context, KupaService::class.java).setAction(KupaService.ACTION_LISTEN_NOW), service = true)
        val stop = pending(context, 3, Intent(context, KupaService::class.java).setAction(KupaService.ACTION_STOP), service = true)
        val icon = Icon.createWithResource(context, R.drawable.ic_launcher)
        val builder = Notification.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("KUPA ativo")
            .setContentText(if (gamerActive) "Modo gamer ligado. Diga \"Kupa\" quando precisar." else "Diga \"Kupa\" para chamar.")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(icon, "Falar", listen).build())
            .addAction(Notification.Action.Builder(icon, "Parar", stop).build())
        return builder.build()
    }

    /** Resposta curta em notificação silenciosa (Modo Gamer). Só aparece se a permissão de notificações foi dada. */
    fun postAnswer(context: Context, text: String) {
        try {
            ensureChannels(context)
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val n = Notification.Builder(context, CHANNEL_ANSWERS)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("KUPA")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setTimeoutAfter(30_000)
                .setOnlyAlertOnce(true)
                .build()
            nm.notify(ID_ANSWER, n)
        } catch (e: Exception) {
            KupaLog.w("notificacao", "não consegui mostrar a notificação: ${e.message}")
        }
    }
}
