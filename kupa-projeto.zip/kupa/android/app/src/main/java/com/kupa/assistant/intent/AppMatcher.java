package com.kupa.assistant.intent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Acha, entre os aplicativos instalados, o que o usuário quis abrir. Sem boa correspondência, devolve nada. */
public final class AppMatcher {
    private AppMatcher() {}

    public static final class AppEntry {
        public final String packageName;
        public final String label;
        final String norm;
        final List<String> tokens;
        final String pkgTail;

        public AppEntry(String packageName, String label) {
            this.packageName = packageName;
            this.label = label;
            this.norm = TextNorm.normalize(label);
            this.tokens = TextNorm.tokens(this.norm);
            String tail = packageName == null ? "" : packageName.substring(packageName.lastIndexOf('.') + 1);
            this.pkgTail = TextNorm.normalize(tail);
        }
    }

    public static final class Scored {
        public final AppEntry app;
        public final int score;

        Scored(AppEntry app, int score) {
            this.app = app;
            this.score = score;
        }

        @Override public String toString() { return app.label + "(" + score + ")"; }
    }

    public static final class Result {
        public final List<Scored> ranked;
        public final Scored chosen;
        public final boolean ambiguous;
        /** Correspondência só aproximada: avisar o usuário do que foi aberto. */
        public final boolean weak;

        Result(List<Scored> ranked, Scored chosen, boolean ambiguous) {
            this.ranked = ranked;
            this.chosen = chosen;
            this.ambiguous = ambiguous;
            this.weak = chosen != null && chosen.score < 75;
        }
    }

    private static final Set<String> NOISE = new HashSet<>(Arrays.asList("o", "a", "os", "as", "app", "aplicativo", "do", "da"));
    private static final int MIN_SCORE = 55;
    private static final int MARGIN = 10;

    public static Result resolve(String query, List<AppEntry> apps) {
        List<String> q = new ArrayList<>(TextNorm.tokens(TextNorm.normalize(query)));
        while (q.size() > 1 && NOISE.contains(q.get(0))) q.remove(0);
        if (q.isEmpty()) return new Result(Collections.<Scored>emptyList(), null, false);
        String qn = TextNorm.join(q, 0, q.size());

        List<Scored> ranked = new ArrayList<>();
        for (AppEntry a : apps) {
            int s = score(q, qn, a);
            if (s >= MIN_SCORE) ranked.add(new Scored(a, s));
        }
        Collections.sort(ranked, new Comparator<Scored>() {
            @Override public int compare(Scored x, Scored y) {
                if (x.score != y.score) return y.score - x.score;
                return x.app.label.compareToIgnoreCase(y.app.label);
            }
        });
        if (ranked.isEmpty()) return new Result(ranked, null, false);
        if (ranked.size() == 1) return new Result(ranked, ranked.get(0), false);
        if (ranked.get(0).score - ranked.get(1).score >= MARGIN) return new Result(ranked, ranked.get(0), false);
        List<Scored> close = new ArrayList<>();
        for (Scored s : ranked) if (ranked.get(0).score - s.score < MARGIN && close.size() < 5) close.add(s);
        return new Result(close, null, true);
    }

    static int score(List<String> q, String qn, AppEntry a) {
        if (a.norm.equals(qn)) return 100;
        if (a.norm.startsWith(qn + " ")) return 80;
        boolean allWhole = true;
        for (String w : q) allWhole &= a.tokens.contains(w);
        if (allWhole) return 75;
        if (a.pkgTail.equals(qn.replace(" ", ""))) return 70;
        if (a.norm.contains(qn) && qn.length() >= 4) return 58;
        if (q.size() == 1) {
            String w = q.get(0);
            if (a.pkgTail.contains(w) && w.length() >= 4) return 60;
            for (String t : a.tokens) if (Fuzzy.withinOne(w, t, 5)) return 56;
        }
        return 0;
    }
}
