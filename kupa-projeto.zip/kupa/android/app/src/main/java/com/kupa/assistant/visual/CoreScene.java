package com.kupa.assistant.visual;

import java.util.ArrayList;
import java.util.List;

/**
 * Geometria do núcleo temporal e do símbolo do KUPA em Java PURO (sem Android): o app só DESENHA estas primitivas e os testes e as
 * prévias usam exatamente o mesmo código. Coordenadas no círculo unitário (centro 0,0; raio 1; y para baixo); ângulos em graus,
 * 0° = 3 horas, positivo = sentido horário.
 *
 * Original do KUPA: anéis de segmentos com rotação independente, escala de instrumentos, mostrador temporal com ponteiro,
 * pulsos luminosos e ondas — sem copiar logotipos de nenhuma franquia.
 */
public final class CoreScene {
    private CoreScene() {}

    public static final int ARC = 0;     // traço em arco: (x,y)=centro, r, a0, sweep, w
    public static final int LINE = 1;    // traço: (x,y)->(x2,y2), w
    public static final int CIRCLE = 2;  // círculo só com borda: (x,y), r, w
    public static final int DISC = 3;    // círculo cheio: (x,y), r

    public static final class Prim {
        public final int kind;
        public final float x, y, r, a0, sweep, x2, y2, w;
        public final int argb;

        Prim(int kind, float x, float y, float r, float a0, float sweep, float x2, float y2, float w, int argb) {
            this.kind = kind;
            this.x = x;
            this.y = y;
            this.r = r;
            this.a0 = a0;
            this.sweep = sweep;
            this.x2 = x2;
            this.y2 = y2;
            this.w = w;
            this.argb = argb;
        }
    }

    private static float clamp01(float v) { return v < 0f ? 0f : Math.min(v, 1f); }

    private static Prim arc(float r, float a0, float sweep, float w, int argb) { return new Prim(ARC, 0, 0, r, a0, sweep, 0, 0, w, argb); }

    private static Prim circle(float r, float w, int argb) { return new Prim(CIRCLE, 0, 0, r, 0, 0, 0, 0, w, argb); }

    private static Prim disc(float x, float y, float r, int argb) { return new Prim(DISC, x, y, r, 0, 0, 0, 0, 0, argb); }

    private static Prim line(float x1, float y1, float x2, float y2, float w, int argb) { return new Prim(LINE, x1, y1, 0, 0, 0, x2, y2, w, argb); }

    private static Prim radial(float r1, float r2, float deg, float w, int argb) {
        double a = Math.toRadians(deg);
        return line((float) (Math.cos(a) * r1), (float) (Math.sin(a) * r1), (float) (Math.cos(a) * r2), (float) (Math.sin(a) * r2), w, argb);
    }

    private static float pos(float v) { return ((v % 360f) + 360f) % 360f; }

    /**
     * Quadro do núcleo.
     *
     * @param t       tempo em segundos (ignorado se !animate ou se o modo não tem movimento)
     * @param level   nível REAL do microfone 0..1 (só usado em LISTENING/COMMAND)
     * @param pulse   pulso REAL da fala 0..1 (só usado em SPEAKING)
     * @param animate false = movimento reduzido: quadro estático, mas o estado continua legível pelas cores e formas
     */
    public static List<Prim> build(CoreMode mode, float t, float level, float pulse, boolean animate) {
        float tt = animate && mode.animated() ? t : 0f;
        float lvl = animate && mode.usesMicLevel() ? clamp01(level) : 0f;
        float pls = animate && mode == CoreMode.SPEAKING ? clamp01(pulse) : 0f;

        int primary;
        int accent;
        float wOuter, wA, wB, needle, glow;
        float align = 0.25f;
        switch (mode) {
            case OFF:
                primary = Palette.DORMANT; accent = Palette.DORMANT; wOuter = wA = wB = needle = 0; glow = 0.04f; break;
            case NEEDS_PERMISSION:
                primary = Palette.withAlpha(Palette.AMBER, 0.55f); accent = Palette.AMBER; wOuter = wA = wB = needle = 0; glow = 0.08f; break;
            case ERROR:
                primary = Palette.withAlpha(Palette.ERROR_RED, 0.75f); accent = Palette.ERROR_RED; wOuter = wA = wB = needle = 0; glow = 0.12f; break;
            case STARTING:
                primary = Palette.withAlpha(Palette.CYAN, 0.7f); accent = Palette.CYAN; wOuter = 3; wA = 14; wB = -18; needle = 30; glow = 0.18f; break;
            case LISTENING:
                primary = Palette.CYAN; accent = Palette.COLD_WHITE; wOuter = 3; wA = 12; wB = -16; needle = 20; glow = 0.26f + 0.24f * lvl; break;
            case COMMAND:
                primary = Palette.CYAN; accent = Palette.COLD_WHITE; wOuter = 5; wA = 22; wB = -28; needle = 40; glow = 0.30f + 0.26f * lvl; break;
            case PROCESSING:
                primary = Palette.TECH_BLUE; accent = Palette.CYAN; wOuter = 6; wA = 70; wB = -110; needle = 140; glow = 0.30f;
                align = 0.5f + 0.5f * (float) Math.sin(2 * Math.PI * tt / 1.6); break;
            case SPEAKING:
                primary = Palette.CYAN; accent = Palette.COLD_WHITE; wOuter = 2; wA = 10; wB = -14; needle = 12;
                glow = 0.20f + 0.20f * pls + 0.05f * (float) Math.sin(2 * Math.PI * tt * 1.2); break;
            case CONFIRM:
                primary = Palette.TECH_BLUE; accent = Palette.AMBER; wOuter = 1; wA = 3; wB = -4; needle = 4;
                glow = 0.20f + 0.05f * (float) Math.sin(2 * Math.PI * tt / 3.0); break;
            default: // IDLE
                primary = Palette.TECH_BLUE; accent = Palette.CYAN; wOuter = 2; wA = 6; wB = -9; needle = 6;
                glow = 0.15f + 0.04f * (float) Math.sin(2 * Math.PI * tt / 4.0); break;
        }
        int glowColor = mode == CoreMode.CONFIRM ? Palette.mix(Palette.TECH_BLUE, Palette.AMBER, 0.45f)
            : mode == CoreMode.ERROR ? Palette.ERROR_RED
            : mode == CoreMode.NEEDS_PERMISSION ? Palette.AMBER
            : primary | 0xFF000000;

        List<Prim> out = new ArrayList<>(190);

        // 1) halo (iluminação que parece vir de dentro)
        // 10 camadas finas = degradê suave (sem disco chapado); o raio máximo fica DENTRO da escala externa (0,97)
        for (int i = 0; i < 10; i++) {
            out.add(disc(0, 0, 0.99f - 0.045f * i, Palette.withAlpha(glowColor, glow * 0.14f * (1f - i / 10f))));
        }

        // 2) escala externa de instrumentos
        float angO = wOuter * tt;
        out.add(circle(0.97f, 0.008f, Palette.withAlpha(primary | 0xFF000000, 0.35f)));
        for (int i = 0; i < 72; i++) {
            boolean major = i % 6 == 0;
            out.add(radial(major ? 0.915f : 0.935f, 0.955f, pos(angO + i * 5f), major ? 0.012f : 0.006f, Palette.withAlpha(primary | 0xFF000000, major ? 0.8f : 0.38f)));
        }

        // 3) anel A: 6 segmentos (nível do microfone engrossa os segmentos)
        float angA = wA * tt;
        for (int i = 0; i < 6; i++) {
            float w = 0.055f + 0.035f * lvl * (0.5f + 0.5f * (float) Math.sin(i * 1.7 + tt * 6.0));
            out.add(arc(0.85f, pos(angA + i * 60f), 48f, w, Palette.withAlpha(primary | 0xFF000000, mode == CoreMode.OFF ? 0.9f : 0.9f)));
        }

        // 4) anel B: 9 segmentos que se alinham no processamento
        float angB = wB * tt;
        float sweepB = 28f + 12f * align * (mode == CoreMode.PROCESSING ? 0.95f : 0f);
        for (int i = 0; i < 9; i++) {
            int c = mode == CoreMode.CONFIRM && i % 3 == 0 ? Palette.AMBER : (mode == CoreMode.PROCESSING ? Palette.mix(Palette.TECH_BLUE, Palette.CYAN, 0.55f) : accent);
            if (mode == CoreMode.ERROR && i % 3 == 1) continue; // anel quebrado: falha visível
            out.add(arc(0.73f, pos(angB + i * 40f), sweepB, 0.035f, Palette.withAlpha(c | 0xFF000000, 0.85f)));
        }

        // 5) linhas radiais de instrumentação
        float angR = angB * 0.3f;
        for (int i = 0; i < 36; i++) {
            boolean big = i % 3 == 0;
            out.add(radial(big ? 0.58f : 0.60f, big ? 0.68f : 0.66f, pos(angR + i * 10f), 0.007f, Palette.withAlpha(primary | 0xFF000000, 0.42f)));
        }

        // 6) mostrador temporal: 12 marcas e um ponteiro
        out.add(circle(0.56f, 0.010f, Palette.withAlpha(primary | 0xFF000000, 0.6f)));
        for (int i = 0; i < 12; i++) {
            double a = Math.toRadians(i * 30.0 - 90.0);
            out.add(disc((float) (Math.cos(a) * 0.56), (float) (Math.sin(a) * 0.56), i % 3 == 0 ? 0.020f : 0.012f, Palette.withAlpha(accent | 0xFF000000, 0.85f)));
        }
        float angN = pos(needle * tt - 90f);
        out.add(radial(0.42f, 0.54f, angN, 0.014f, Palette.withAlpha(accent | 0xFF000000, 0.95f)));
        out.add(new Prim(DISC, (float) (Math.cos(Math.toRadians(angN)) * 0.54), (float) (Math.sin(Math.toRadians(angN)) * 0.54), 0.024f, 0, 0, 0, 0, 0, Palette.withAlpha(accent | 0xFF000000, 1f)));

        // 7) pulsos luminosos atravessando os anéis (só no processamento: atividade REAL)
        if (mode == CoreMode.PROCESSING) {
            float[] radii = {0.85f, 0.73f, 0.56f};
            float[] speeds = {160f, -210f, 300f};
            for (int k = 0; k < 3; k++) {
                float head = pos(tt * speeds[k] + k * 120f);
                int dir = speeds[k] < 0 ? -1 : 1;
                for (int s = 1; s <= 3; s++) {
                    out.add(arc(radii[k], pos(head - dir * s * 9f - (dir > 0 ? 9f : 0f)), 9f, 0.03f, Palette.withAlpha(Palette.CYAN, 0.5f - 0.13f * s)));
                }
                double a = Math.toRadians(head);
                out.add(disc((float) (Math.cos(a) * radii[k]), (float) (Math.sin(a) * radii[k]), 0.032f, Palette.COLD_WHITE));
            }
        }

        // 8) ondas de voz: reagem ao microfone (escuta) ou à fala
        if (mode == CoreMode.LISTENING || mode == CoreMode.COMMAND || mode == CoreMode.SPEAKING) {
            float amp = mode == CoreMode.SPEAKING ? 0.06f * pls + 0.008f * (float) Math.sin(2 * Math.PI * tt * 2.0) : 0.07f * lvl;
            for (int i = 0; i < 3; i++) {
                out.add(circle(0.445f + 0.032f * i + amp * (i + 1) * 0.6f, 0.010f, Palette.withAlpha(Palette.CYAN, 0.58f - 0.16f * i)));
            }
        }

        // 9) cavidade central (onde o Popol aparece)
        out.add(disc(0, 0, 0.40f, Palette.withAlpha(Palette.DEEP_BLUE, 0.92f)));
        out.add(circle(0.40f, 0.012f, Palette.withAlpha(primary | 0xFF000000, 0.85f)));
        return out;
    }

    /** Símbolo original do KUPA: núcleo (K de nós holográficos) dentro de um mecanismo circular temporal com um marcador orbital. */
    public static List<Prim> mark() {
        List<Prim> out = new ArrayList<>();
        out.add(disc(0, 0, 1.0f, Palette.withAlpha(Palette.DEEP_BLUE, 0.96f)));
        for (int i = 0; i < 3; i++) out.add(arc(0.86f, -100f + i * 120f, 92f, 0.09f, Palette.TECH_BLUE));
        out.add(circle(0.62f, 0.035f, Palette.withAlpha(Palette.TECH_BLUE, 0.55f)));
        double o = Math.toRadians(20.0);
        out.add(disc((float) (Math.cos(o) * 0.86), (float) (Math.sin(o) * 0.86), 0.075f, Palette.CYAN));
        out.add(line(-0.22f, -0.38f, -0.22f, 0.38f, 0.095f, Palette.COLD_WHITE));
        out.add(line(-0.22f, 0.02f, 0.30f, -0.38f, 0.095f, Palette.COLD_WHITE));
        out.add(line(-0.22f, 0.02f, 0.30f, 0.38f, 0.095f, Palette.COLD_WHITE));
        out.add(disc(0.30f, -0.38f, 0.078f, Palette.CYAN));
        out.add(disc(0.30f, 0.38f, 0.078f, Palette.CYAN));
        out.add(disc(-0.22f, -0.38f, 0.06f, Palette.COLD_WHITE));
        out.add(disc(-0.22f, 0.38f, 0.06f, Palette.COLD_WHITE));
        return out;
    }
}
