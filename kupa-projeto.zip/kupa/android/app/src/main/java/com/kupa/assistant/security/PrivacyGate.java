package com.kupa.assistant.security;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Porteiro de privacidade: tudo que sai do aparelho passa por aqui. Remove credenciais e identificadores financeiros
 * (chaves, tokens, senhas, cartão com Luhn válido, CPF válido, CVV) e diz O QUE foi removido (nunca o valor).
 * Faz minimização, não é uma garantia absoluta: dados pessoais comuns (nome, endereço) não são detectáveis com segurança.
 */
public final class PrivacyGate {
    private PrivacyGate() {}

    public static final class Result {
        public final String sanitized;
        public final List<String> redactions;

        Result(String sanitized, List<String> redactions) {
            this.sanitized = sanitized;
            this.redactions = redactions;
        }

        public boolean changed() { return !redactions.isEmpty(); }
    }

    private static final Pattern API_KEY = Pattern.compile("\\b(?:sk-[A-Za-z0-9_-]{16,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_-]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|xox[abp]-[A-Za-z0-9-]{10,})");
    private static final Pattern BEARER = Pattern.compile("(?i)\\bbearer\\s+[A-Za-z0-9._~+/=-]{16,}");
    private static final Pattern PASSWORD = Pattern.compile("(?i)\\b(senha|password|passcode|pin)\\b(\\s*(?:é|e|eh|:|=|is)?\\s*)[\"']?([^\\s\"',;]{4,})");
    private static final Pattern CVV = Pattern.compile("(?i)\\b(cvv|cvc|codigo de seguranca)\\b(\\s*[:=]?\\s*)\\d{3,4}\\b");
    private static final Pattern CARD = Pattern.compile("\\b(?:\\d[ -]?){13,19}\\b");
    private static final Pattern CPF = Pattern.compile("\\b\\d{3}\\.?\\d{3}\\.?\\d{3}-?\\d{2}\\b");

    public static Result scrubOutgoing(String text) {
        if (text == null || text.isEmpty()) return new Result("", new ArrayList<String>());
        Set<String> kinds = new LinkedHashSet<>();
        String s = text;

        s = replaceAll(API_KEY, s, "[REMOVIDO:chave]", kinds, "chave de API");
        s = replaceAll(BEARER, s, "[REMOVIDO:token]", kinds, "token de acesso");

        Matcher m = PASSWORD.matcher(s);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            kinds.add("senha");
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + m.group(2) + "[REMOVIDO:senha]"));
        }
        m.appendTail(sb);
        s = sb.toString();

        m = CVV.matcher(s);
        sb = new StringBuffer();
        while (m.find()) {
            kinds.add("código de segurança do cartão");
            m.appendReplacement(sb, Matcher.quoteReplacement(m.group(1) + m.group(2) + "[REMOVIDO:cvv]"));
        }
        m.appendTail(sb);
        s = sb.toString();

        m = CARD.matcher(s);
        sb = new StringBuffer();
        while (m.find()) {
            String digits = m.group().replaceAll("[^0-9]", "");
            if (digits.length() >= 13 && digits.length() <= 19 && luhn(digits)) {
                kinds.add("número de cartão");
                m.appendReplacement(sb, "[REMOVIDO:cartão]");
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group()));
            }
        }
        m.appendTail(sb);
        s = sb.toString();

        m = CPF.matcher(s);
        sb = new StringBuffer();
        while (m.find()) {
            String digits = m.group().replaceAll("[^0-9]", "");
            if (validCpf(digits)) {
                kinds.add("CPF");
                m.appendReplacement(sb, "[REMOVIDO:cpf]");
            } else {
                m.appendReplacement(sb, Matcher.quoteReplacement(m.group()));
            }
        }
        m.appendTail(sb);
        return new Result(sb.toString(), new ArrayList<>(kinds));
    }

    private static String replaceAll(Pattern p, String s, String replacement, Set<String> kinds, String kind) {
        Matcher m = p.matcher(s);
        if (!m.find()) return s;
        kinds.add(kind);
        return m.replaceAll(Matcher.quoteReplacement(replacement));
    }

    static boolean luhn(String digits) {
        int sum = 0;
        boolean alt = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int d = digits.charAt(i) - '0';
            if (alt) {
                d *= 2;
                if (d > 9) d -= 9;
            }
            sum += d;
            alt = !alt;
        }
        return sum % 10 == 0;
    }

    static boolean validCpf(String d) {
        if (d.length() != 11) return false;
        boolean same = true;
        for (int i = 1; i < 11; i++) if (d.charAt(i) != d.charAt(0)) same = false;
        if (same) return false;
        for (int len = 9; len <= 10; len++) {
            int sum = 0;
            for (int i = 0; i < len; i++) sum += (d.charAt(i) - '0') * (len + 1 - i);
            int check = (sum * 10) % 11;
            if (check == 10) check = 0;
            if (check != d.charAt(len) - '0') return false;
        }
        return true;
    }
}
