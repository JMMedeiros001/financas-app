package com.kupa.assistant.intent;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Interpretador de comandos em português (voz/texto -> intenções estruturadas).
 * Só reconhece comandos CLAROS; se qualquer parte da frase não for entendida, devolve vazio e a frase segue para a IA.
 * Não executa nada: quem executa é o executor Android, depois de validar.
 */
public final class CommandInterpreter {
    private static final int MAX_SEGMENTS = 4;

    private static final Pattern LEAD_FILLERS = Pattern.compile(
        "^(?:(?:agora|entao|ai|tambem|primeiro|por favor|por gentileza|pode|poderia|podia|consegue|conseguiria|quero|queria|preciso|gostaria de|gostaria|vou querer|da pra|bora|vamos)\\s+)+");
    private static final Pattern TRAIL_FILLERS = Pattern.compile(
        "(?:\\s+(?:por favor|por gentileza|pra mim|para mim|ai|agora|pfv|valeu|obrigado|obrigada|rapidinho|rapido))+$");

    private static final String OPEN_VERBS = "abre|abra|abrir|abri|inicia|inicie|iniciar|executa|execute|executar|lanca|lance|lancar";
    private static final String CMD_VERBS = OPEN_VERBS + "|liga|ligue|ligar|chama|chame|chamar|atende|atenda|recusa|recuse|desliga|desligue|telefona|telefone|disca";

    private static final Pattern SEQUENCE_SPLIT = Pattern.compile(
        "\\s+(?:e\\s+depois(?:\\s+disso)?|e\\s+em\\s+seguida|e\\s+logo\\s+depois|e\\s+entao|depois|em\\s+seguida|logo\\s+depois)\\s+"
            + "|\\s+e\\s+(?=(?:" + CMD_VERBS + ")\\b)"
            + "|\\s+e\\s+(?=(?:o|a|os|as)\\s)");

    private static final Pattern LEARN_WHEN = Pattern.compile(
        "^(?:quando|toda vez que|sempre que) eu (?:disser|falar|digo|falo|dizer) (.+?) (?:eu )?"
            + "(?:quero dizer|quer dizer|significa|estou falando|to falando|estou me referindo|me refiro)"
            + "(?: que| de| do| da| dos| das| para| pra| a| o| as| os| em)* (.+)$");
    private static final Pattern LEARN_VERB = Pattern.compile(
        "^(?:aprenda|aprende|memorize|memoriza|lembre|lembra) que (.+?) (?:significa|quer dizer|quero dizer)(?: que| de| do| da| para| pra| a| o)* (.+)$");
    private static final Pattern FORGET = Pattern.compile(
        "^(?:esquece|esqueca|apaga|apague|remove|remova|remover|exclui|exclua|deleta|delete) (?:o |a )?(?:comando|atalho|apelido)(?: que eu ensinei)? (.+)$");
    private static final Pattern LIST_LEARNED = Pattern.compile(
        "^(?:quais|lista|liste|mostra|mostre|me mostra|fala|diga)(?: me)? (?:os )?(?:meus )?comandos(?: que eu ensinei| aprendidos| personalizados| ensinados)?$|^quais comandos eu ensinei$");

    private static final Pattern MODE_ON = Pattern.compile(
        "^(?:ativa|ative|ativar|entra|entre|entrar|muda|mude|mudar|coloca|coloque|colocar)\\s+(?:no\\s+|para\\s+o\\s+|pro\\s+|o\\s+|para\\s+|em\\s+)?modo\\s+(.+)$");
    private static final Pattern MODE_OFF = Pattern.compile(
        "^(?:sai|saia|sair|desativa|desative|desativar|encerra|encerre|encerrar|tira|tire|tirar|volta|volte|voltar)\\s+(?:do\\s+|de\\s+|o\\s+|para\\s+o\\s+)?modo(?:\\s+(.+))?$");
    private static final Pattern MODE_LIST = Pattern.compile(
        "^(?:quais|lista|liste|mostra|mostre)\\s+(?:os\\s+|meus\\s+)?modos(?:\\s+que\\s+eu\\s+criei|\\s+eu\\s+criei|\\s+eu\\s+tenho|\\s+disponiveis)?$");
    private static final Set<String> STOP_FILL = new HashSet<>(Arrays.asList("tudo", "o", "kupa", "de", "ouvir", "a", "escuta", "agora", "ja"));

    private static final Pattern CHAT = Pattern.compile(
        "^(?:" + OPEN_VERBS + ")\\s+(?:a\\s+|o\\s+)?(?:conversa|chat)\\s+(?:com|do|da|de)\\s+(?:o\\s+|a\\s+)?(.+?)(?:\\s+(?:no|na|pelo|pela|em)\\s+(?:o\\s+|a\\s+)?(.+))?$");
    private static final Pattern CALL_LIGAR = Pattern.compile(
        "^(?:liga|ligue|ligar|telefona|telefone|telefonar|disca|disque|discar)(?:\\s+ai)?\\s+(?:para|pra|pro|ao|a)\\s+(?:o\\s+|a\\s+)?(.+)$");
    private static final Pattern CALL_FAZER = Pattern.compile(
        "^(?:faz|faca|fazer|realiza|realize|realizar|da|de|dar)\\s+(?:uma\\s+)?(?:ligacao|chamada|ligadinha|toque)\\s+(?:para|pra|pro|ao|a)\\s+(?:o\\s+|a\\s+)?(.+)$");
    private static final Pattern CALL_CHAMAR = Pattern.compile("^(?:chama|chame|chamar)\\s+(?:o\\s+|a\\s+)?(.+)$");
    private static final Pattern OPEN = Pattern.compile("^(?:" + OPEN_VERBS + ")(?:\\s+ai)?\\s+(.+)$");

    private static final Set<String> PRONOUNS = new HashSet<>(Arrays.asList("ele", "ela", "la", "esse", "essa", "ele ai", "ela ai"));
    private static final Set<String> POSSESSIVES = new HashSet<>(Arrays.asList("meu", "minha", "seu", "sua", "o", "a"));
    private static final Set<String> OPEN_NOISE = new HashSet<>(Arrays.asList("o", "a", "os", "as", "app", "aplicativo", "aplicacao", "programa", "do", "da", "de", "no", "na", "pra", "para", "ai"));
    private static final Set<String> CALL_FILL = new HashSet<>(Arrays.asList("a", "o", "ligacao", "chamada", "telefone", "ai", "agora", "essa", "esta", "pra", "mim", "por", "favor", "la", "ligando"));

    public Interpretation interpret(String raw) {
        String n = TextNorm.normalize(raw);
        n = TextNorm.stripWake(n);
        n = stripFillers(n);
        List<KupaIntent> out = new ArrayList<>();
        if (n.isEmpty()) return new Interpretation(out, n);

        KupaIntent special = parseManagement(n);
        if (special != null) {
            out.add(special);
            return new Interpretation(out, n);
        }

        String[] segs = SEQUENCE_SPLIT.split(n);
        if (segs.length > MAX_SEGMENTS) return new Interpretation(new ArrayList<KupaIntent>(), n);
        KupaIntent prev = null;
        for (int i = 0; i < segs.length; i++) {
            String seg = stripFillers(segs[i].trim());
            KupaIntent it = parseSegment(seg, i > 0 ? prev : null);
            if (it == null) return new Interpretation(new ArrayList<KupaIntent>(), n);
            out.add(it);
            prev = it;
        }
        return new Interpretation(out, n);
    }

    private static String stripFillers(String n) {
        String s = n;
        for (int guard = 0; guard < 4; guard++) {
            String before = s;
            s = LEAD_FILLERS.matcher(s).replaceFirst("").trim();
            s = TRAIL_FILLERS.matcher(s).replaceFirst("").trim();
            if (s.equals(before)) break;
        }
        return s;
    }

    // ------------------------------------------------------------------ aprender / esquecer / listar

    private KupaIntent parseManagement(String n) {
        Matcher m = LEARN_WHEN.matcher(n);
        if (m.matches()) return KupaIntent.learn(m.group(1).trim(), m.group(2).trim());
        m = LEARN_VERB.matcher(n);
        if (m.matches()) return KupaIntent.learn(m.group(1).trim(), m.group(2).trim());
        m = FORGET.matcher(n);
        if (m.matches()) return KupaIntent.forget(m.group(1).trim());
        if (LIST_LEARNED.matcher(n).matches()) return KupaIntent.simple(KupaIntent.Kind.LIST_LEARNED);
        if (MODE_LIST.matcher(n).matches()) return KupaIntent.simple(KupaIntent.Kind.LIST_MODES);
        m = MODE_ON.matcher(n);
        if (m.matches() && !isGamerName(m.group(1))) return KupaIntent.activateMode(m.group(1).trim());
        m = MODE_OFF.matcher(n);
        if (m.matches() && (m.group(1) == null || !isGamerName(m.group(1)))) return KupaIntent.simple(KupaIntent.Kind.EXIT_MODE);
        List<String> t = TextNorm.tokens(n);
        if (t.size() >= 2 && t.size() <= 4 && (t.get(0).equals("para") || t.get(0).equals("pare") || t.get(0).equals("parar"))
            && (t.contains("tudo") || t.contains("kupa")) && onlyIn(t, 1, STOP_FILL)) {
            return KupaIntent.simple(KupaIntent.Kind.STOP_KUPA);
        }
        return null;
    }

    // ------------------------------------------------------------------ um comando

    private KupaIntent parseSegment(String seg, KupaIntent previous) {
        if (seg.isEmpty()) return null;
        KupaIntent it = parseCallControl(seg);
        if (it != null) return it;
        it = parseChat(seg);
        if (it != null) return it;
        it = parseCall(seg);
        if (it != null) return it;
        it = parseOpen(seg);
        if (it != null) return it;
        return parseInherited(seg, previous);
    }

    private KupaIntent parseCallControl(String seg) {
        List<String> t = TextNorm.tokens(seg);
        if (t.isEmpty()) return null;
        String first = t.get(0);

        // quem está ligando?
        if (first.equals("quem") && t.size() <= 8 && !containsAny(t, "tv", "televisao", "radio", "luz", "wifi", "computador", "pc", "notebook", "ventilador", "som", "carro")) {
            boolean ringing = containsAny(t, "ligando", "chamando", "telefonando", "linha", "ligacao", "chamada");
            boolean toMe = t.contains("me") && containsAny(t, "liga", "ligou", "chama", "chamou");
            boolean justWho = t.size() == 2 && (t.get(1).equals("ligou") || t.get(1).equals("chamou"));
            if (ringing || toMe || justWho) return KupaIntent.simple(KupaIntent.Kind.WHO_IS_CALLING);
        }
        if (seg.startsWith("de quem e") && containsAny(t, "ligacao", "chamada")) return KupaIntent.simple(KupaIntent.Kind.WHO_IS_CALLING);

        // não atende = deixar tocar
        if (first.equals("nao") && t.size() <= 4 && t.size() >= 2) {
            String second = t.get(1);
            boolean answerWord = second.equals("atende") || second.equals("atenda") || second.equals("atender");
            boolean wantWord = (second.equals("quero") || second.equals("vou")) && t.size() >= 3 && t.get(2).equals("atender");
            if (answerWord || wantWord) return KupaIntent.simple(KupaIntent.Kind.IGNORE_CALL);
            return null;
        }
        // deixa tocar / chamar até cair
        if ((first.equals("deixa") || first.equals("deixe") || first.equals("deixar")) && containsAny(t, "tocar", "tocando", "chamar", "chamando", "cair")
            && allIn(t, IGNORE_OK)) {
            return KupaIntent.simple(KupaIntent.Kind.IGNORE_CALL);
        }
        if ((first.equals("ignora") || first.equals("ignore") || first.equals("ignorar")) && onlyFill(t, 1)) {
            return KupaIntent.simple(KupaIntent.Kind.IGNORE_CALL);
        }
        // atender
        if ((first.equals("atende") || first.equals("atenda") || first.equals("atender")) && onlyFill(t, 1)) {
            return KupaIntent.simple(KupaIntent.Kind.ANSWER_CALL);
        }
        if ((first.equals("pega") || first.equals("pegue")) && t.size() >= 2 && containsAny(t, "ligacao", "chamada", "telefone") && onlyFill(t, 1)) {
            return KupaIntent.simple(KupaIntent.Kind.ANSWER_CALL);
        }
        // recusar
        if ((first.equals("recusa") || first.equals("recuse") || first.equals("recusar") || first.equals("rejeita") || first.equals("rejeite") || first.equals("rejeitar")) && onlyFill(t, 1)) {
            return KupaIntent.simple(KupaIntent.Kind.REJECT_CALL);
        }
        // desligar a chamada em andamento (exige dizer "ligação" ou "chamada")
        if ((first.equals("desliga") || first.equals("desligue") || first.equals("desligar") || first.equals("encerra") || first.equals("encerre") || first.equals("encerrar"))
            && containsAny(t, "ligacao", "chamada") && onlyFill(t, 1)) {
            return KupaIntent.simple(KupaIntent.Kind.END_CALL);
        }
        return null;
    }

    private static final Set<String> IGNORE_OK = new HashSet<>(Arrays.asList(
        "deixa", "deixe", "deixar", "tocar", "tocando", "chamar", "chamando", "cair", "ate", "que", "ela", "a", "o", "ligacao", "chamada", "telefone", "pode", "assim", "la", "ai", "toque"));

    private static final Set<String> LEADERS = new HashSet<>(Arrays.asList("o", "a", "os", "as", "para", "pra", "pro", "ao", "do", "da", "de", "no", "na"));

    /** "modo gamer" tem tratamento próprio no app. */
    private static boolean isGamerName(String name) {
        String n = name.trim();
        return n.equals("gamer") || n.equals("game") || n.startsWith("gamer ");
    }

    private static boolean onlyIn(List<String> t, int from, Set<String> allowed) {
        for (int i = from; i < t.size(); i++) if (!allowed.contains(t.get(i))) return false;
        return true;
    }

    private static boolean allIn(List<String> t, Set<String> allowed) {
        for (String w : t) if (!allowed.contains(w)) return false;
        return true;
    }

    private static boolean containsAny(List<String> t, String... words) {
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }

    private static boolean onlyFill(List<String> t, int from) {
        for (int i = from; i < t.size(); i++) if (!CALL_FILL.contains(t.get(i))) return false;
        return true;
    }

    private KupaIntent parseChat(String seg) {
        Matcher m = CHAT.matcher(seg);
        if (!m.matches()) return null;
        String contact = m.group(1).trim();
        String app = m.group(2) == null ? null : m.group(2).trim();
        if (contact.isEmpty()) return null;
        boolean pronoun = PRONOUNS.contains(contact);
        return KupaIntent.openChat(pronoun ? "ele" : cleanName(contact), pronoun, app);
    }

    private KupaIntent parseCall(String seg) {
        String name = null;
        Matcher m = CALL_LIGAR.matcher(seg);
        if (m.matches()) name = m.group(1);
        if (name == null) {
            m = CALL_FAZER.matcher(seg);
            if (m.matches()) name = m.group(1);
        }
        if (name == null) {
            m = CALL_CHAMAR.matcher(seg);
            if (m.matches()) name = m.group(1);
        }
        if (name == null) return null;
        name = name.trim();
        if (name.isEmpty()) return null;
        // ligação por WhatsApp/vídeo não é suportada: melhor não entender do que ligar para a pessoa errada
        if (name.contains("whatsapp") || name.contains("video") || name.contains("zap")) return null;
        if (PRONOUNS.contains(name)) return KupaIntent.callContact("ele", true);
        String cleaned = cleanName(name);
        if (cleaned.isEmpty() || TextNorm.tokens(cleaned).size() > 4 || TextNorm.tokens(cleaned).contains("e")) return null;
        return KupaIntent.callContact(cleaned, false);
    }

    private KupaIntent parseOpen(String seg) {
        Matcher m = OPEN.matcher(seg);
        if (!m.matches()) return null;
        String name = stripOpenNoise(m.group(1).trim());
        if (name.isEmpty() || TextNorm.tokens(name).size() > 5) return null;
        if (TextNorm.tokens(name).contains("e")) return null; // "whatsapp e conte uma piada": parte não entendida, melhor não agir
        return KupaIntent.openApp(name);
    }

    private KupaIntent parseInherited(String seg, KupaIntent previous) {
        if (previous == null) return null;
        List<String> t = TextNorm.tokens(seg);
        if (t.isEmpty() || t.size() > 5) return null;
        // só herda o verbo quando o trecho é um complemento ("o jogo", "para maria"), nunca uma frase solta
        if (!LEADERS.contains(t.get(0))) return null;
        if (previous.kind == KupaIntent.Kind.OPEN_APP) {
            String name = stripOpenNoise(seg);
            return (name.isEmpty() || TextNorm.tokens(name).contains("e")) ? null : KupaIntent.openApp(name);
        }
        if (previous.kind == KupaIntent.Kind.CALL_CONTACT) {
            String name = stripLeading(seg, "o", "a", "para", "pra", "pro", "ao", "de", "do", "da");
            if (name.isEmpty()) return null;
            if (PRONOUNS.contains(name)) return KupaIntent.callContact("ele", true);
            return KupaIntent.callContact(cleanName(name), false);
        }
        return null;
    }

    private static String stripOpenNoise(String s) {
        List<String> t = TextNorm.tokens(s);
        int i = 0;
        while (i < t.size() - 1 && i < 3 && OPEN_NOISE.contains(t.get(i))) i++;
        return TextNorm.join(t, i, t.size());
    }

    private static String stripLeading(String s, String... words) {
        List<String> t = TextNorm.tokens(s);
        Set<String> set = new HashSet<>(Arrays.asList(words));
        int i = 0;
        while (i < t.size() - 1 && set.contains(t.get(i))) i++;
        return TextNorm.join(t, i, t.size());
    }

    /** Tira "meu/minha/o/a" do começo e "agora/no celular" do fim do nome de um contato. */
    private static String cleanName(String name) {
        List<String> t = new ArrayList<>(TextNorm.tokens(name));
        while (t.size() > 1 && POSSESSIVES.contains(t.get(0))) t.remove(0);
        String joined = TextNorm.join(t, 0, t.size());
        for (String tail : new String[] {" no celular", " pelo celular", " do celular", " agora", " ai"}) {
            if (joined.endsWith(tail)) joined = joined.substring(0, joined.length() - tail.length());
        }
        return joined.trim();
    }
}
