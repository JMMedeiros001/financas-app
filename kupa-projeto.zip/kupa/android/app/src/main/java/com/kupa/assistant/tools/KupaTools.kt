package com.kupa.assistant.tools

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.kupa.assistant.ai.AiToolCall
import com.kupa.assistant.ai.ToolOutput
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.screen.ScreenCaptureManager
import com.kupa.assistant.settings.Settings
import org.json.JSONObject

/** Ferramentas que a IA pode PEDIR. Quem decide se executa é o KUPA CORE (via este registro), nunca a IA. */
class ToolRegistry(
    private val context: Context,
    private val settings: Settings,
    private val screen: ScreenCaptureManager,
    private val prepareForCapture: () -> Unit,
    private val restoreAfterCapture: () -> Unit,
) {
    /** Ferramentas que o usuário autorizou neste momento (enviadas ao backend a cada pergunta). */
    fun enabledNames(gamerActive: Boolean): List<String> {
        val names = ArrayList<String>()
        val screenAllowed = settings.screenAnalysisEnabled && (!gamerActive || settings.gamerAllowScreen)
        if (screenAllowed) names.add(ANALYZE_SCREEN)
        names.add(START_TIMER)
        return names
    }

    fun execute(call: AiToolCall, gamerActive: Boolean): ToolOutput {
        if (call.name !in enabledNames(gamerActive)) {
            KupaLog.w("ferramentas", "ferramenta não autorizada: ${call.name}")
            return ToolOutput.error("Esta ferramenta não está autorizada agora.")
        }
        return try {
            when (call.name) {
                ANALYZE_SCREEN -> analyzeScreen()
                START_TIMER -> startTimer(call.arguments)
                else -> ToolOutput.error("Ferramenta desconhecida.")
            }
        } catch (e: Exception) {
            KupaLog.e("ferramentas", "erro em ${call.name}", e)
            ToolOutput.error("Falhou ao executar a ferramenta.")
        }
    }

    private fun analyzeScreen(): ToolOutput {
        if (!screen.isActive) {
            return ToolOutput.error(
                "A captura de tela não está ativa. O usuário precisa iniciar a captura em Configurações > Tela e autorizar no aviso do Android.",
            )
        }
        prepareForCapture() // esconde o personagem para ele não aparecer na foto
        var captured: android.graphics.Bitmap? = null
        try {
            Thread.sleep(160)
            captured = screen.captureFrame(fresh = true, timeoutMs = 1200)
        } finally {
            restoreAfterCapture()
        }
        val frame = captured ?: return ToolOutput.error("Não consegui capturar a tela agora.")
        if (ScreenCaptureManager.looksBlank(frame)) {
            frame.recycle()
            return ToolOutput.error(
                "A captura de tela veio em branco: este app ou jogo provavelmente bloqueia capturas. A análise visual não está disponível aqui.",
            )
        }
        val dataUrl = ScreenCaptureManager.toJpegDataUrl(frame)
        frame.recycle()
        return ToolOutput.image("Captura da tela do usuário neste momento.", dataUrl)
    }

    private fun startTimer(args: JSONObject): ToolOutput {
        val seconds = args.optInt("seconds", 0)
        if (seconds < 1 || seconds > 86400) return ToolOutput.error("Duração inválida para o temporizador.")
        val label = args.optString("label", "KUPA").take(60)
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (intent.resolveActivity(context.packageManager) == null) {
            return ToolOutput.error("Não encontrei um app de relógio para criar o temporizador.")
        }
        context.startActivity(intent)
        return ToolOutput.text("Pedido de temporizador de $seconds segundos enviado ao app de relógio do aparelho.")
    }

    companion object {
        const val ANALYZE_SCREEN = "analyze_screen"
        const val START_TIMER = "start_timer"
    }
}
