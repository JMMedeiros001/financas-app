package com.kupa.assistant.core

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.kupa.assistant.ai.AiError
import com.kupa.assistant.ai.AiErrorKind
import com.kupa.assistant.ai.AiMessage
import com.kupa.assistant.ai.AiMode
import com.kupa.assistant.ai.AiOptions
import com.kupa.assistant.ai.AiOrchestrator
import com.kupa.assistant.ai.AiResult
import com.kupa.assistant.ai.AiSource
import com.kupa.assistant.ai.KupaBackendClient
import com.kupa.assistant.ai.KupaBackendProvider
import com.kupa.assistant.ai.NetworkChecker
import com.kupa.assistant.game.GameContextService
import com.kupa.assistant.gamer.GamerModeController
import com.kupa.assistant.history.HistoryDb
import com.kupa.assistant.history.HistoryType
import com.kupa.assistant.overlay.Notifications
import com.kupa.assistant.screen.ScreenCaptureManager
import com.kupa.assistant.settings.Settings
import com.kupa.assistant.tools.ToolRegistry
import com.kupa.assistant.voice.Phrases
import com.kupa.assistant.voice.SpeechInput
import com.kupa.assistant.voice.SpeechOutput
import java.util.TimeZone
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** Quem controla o microfone (implementado pelo VoiceController, dentro do serviço). */
interface VoiceControl {
    fun startCommandListening()
    fun refresh()
    fun stopAll()
}

/** Quem consegue esconder o personagem por um instante (para ele não aparecer na captura de tela). */
interface OverlayHider {
    fun hideForCapture()
    fun restoreAfterCapture()
}

/**
 * KUPA CORE: o cérebro do app. Recebe o que o usuário pediu (voz, texto, pesquisa rápida), decide o que é
 * comando local e o que vai para a IA, controla as ferramentas autorizadas, conduz os estados do Popol e
 * entrega a resposta (balão, voz, histórico). Os métodos públicos devem ser chamados na thread principal.
 */
class KupaCore(
    private val app: Application,
    val settings: Settings,
    val history: HistoryDb,
    val states: StateManager,
    val gameContext: GameContextService,
    val gamer: GamerModeController,
    val screen: ScreenCaptureManager,
) {
    interface Listener {
        fun onBubble(text: String?, isError: Boolean)
        fun onExchange(exchange: Exchange)
        fun onProblem(message: String)
    }

    data class Exchange(val question: String, val answer: String, val type: HistoryType, val timestampMs: Long, val sources: List<AiSource>)

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val listeners = CopyOnWriteArrayList<Listener>()

    val client = KupaBackendClient(settings)
    private val provider = KupaBackendProvider(client)
    private val tools = ToolRegistry(app, settings, screen, { hideForCapture() }, { restoreAfterCapture() })
    private val orchestrator = AiOrchestrator(provider, tools)
    val speech = SpeechOutput(app, settings)

    @Volatile var voiceControl: VoiceControl? = null
    @Volatile var overlayHider: OverlayHider? = null

    private var generation = 0
    private var bubbleToken = 0
    private val convo = ArrayList<AiMessage>()
    private var lastExchangeAt = 0L
    val sessionExchanges = ArrayList<Exchange>()

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    // ------------------------------------------------------------------ entrada

    /** Palavra de ativação detectada. [inlineCommand] é o que veio junto na mesma frase ("Kupa, o que é DNA?"). */
    fun onWake(inlineCommand: String) {
        if (states.current != KupaState.IDLE) return
        KupaLog.i("core", "ativado por voz (comando junto=${inlineCommand.isNotBlank()})")
        states.set(KupaState.ACTIVATED)
        if (inlineCommand.isNotBlank()) {
            main.postDelayed({ process(inlineCommand, HistoryType.VOICE, false) }, 250)
            return
        }
        if (gamer.active) {
            vibrateTick()
            beginListening()
        } else if (settings.voiceEnabled) {
            speech.speak(Phrases.activated(), settings.volumePercent, flush = true, onError = {}, onDone = { beginListening() })
        } else {
            beginListening()
        }
    }

    /** "Falar" (botão/notificação): abre o microfone direto, sem precisar dizer "Kupa". */
    fun listenNow() {
        if (states.current != KupaState.IDLE) cancelInternal(goIdle = true)
        states.set(KupaState.ACTIVATED)
        vibrateTick()
        beginListening()
    }

    private fun beginListening() {
        if (states.current != KupaState.ACTIVATED) return
        states.set(KupaState.LISTENING)
        val vc = voiceControl
        if (vc == null) {
            onListenFailed(SpeechInput.Failure.NOT_AVAILABLE, "O microfone só funciona com o KUPA em execução. Toque em Iniciar KUPA.")
        } else {
            vc.startCommandListening()
        }
    }

    fun onCommandHeard(text: String) {
        if (states.current != KupaState.LISTENING) return
        process(text, HistoryType.VOICE, false)
    }

    fun onListenFailed(failure: SpeechInput.Failure, message: String?) {
        when (failure) {
            SpeechInput.Failure.NO_MATCH, SpeechInput.Failure.TIMEOUT -> {
                states.set(KupaState.CONFUSED)
                if (settings.voiceEnabled && !gamer.active) {
                    speech.speak(Phrases.DIDNT_UNDERSTAND, settings.volumePercent, flush = true, onDone = {})
                }
                scheduleIdle(1600, KupaState.CONFUSED)
            }
            SpeechInput.Failure.PERMISSION -> showError(message ?: "Preciso da permissão do microfone.", speak = false)
            SpeechInput.Failure.NOT_AVAILABLE -> showError(message ?: "O reconhecimento de voz não está disponível.", speak = false)
            SpeechInput.Failure.NETWORK -> showError(message ?: "O reconhecimento de voz precisa de internet e não conseguiu conectar.", speak = false)
            else -> showError(message ?: "Não consegui ouvir agora.", speak = false)
        }
    }

    /** Texto digitado (conversa), pesquisa rápida ou pedidos vindos do menu. */
    fun submitText(text: String, type: HistoryType = HistoryType.TEXT, forceSearch: Boolean = false) {
        if (text.isBlank()) return
        if (states.current != KupaState.IDLE) cancelInternal(goIdle = false)
        process(text.trim(), type, forceSearch)
    }

    fun cancel() {
        cancelInternal(goIdle = true)
    }

    private fun cancelInternal(goIdle: Boolean) {
        generation++
        bubbleToken++
        speech.stop()
        voiceControl?.stopAll()
        if (goIdle) {
            states.set(KupaState.IDLE)
            voiceControl?.refresh()
        }
    }

    /** Mensagens de problema vindas de fora do fluxo normal (ex.: microfone sem permissão). */
    fun reportProblem(message: String) {
        showError(message, speak = false)
    }

    // ------------------------------------------------------------------ processamento

    private fun process(text: String, type: HistoryType, forceSearch: Boolean) {
        val local = CommandRouter.route(text)
        if (local != null) {
            handleLocal(local, text, type)
        } else {
            runAi(text, type, forceSearch)
        }
    }

    private fun handleLocal(command: LocalCommand, question: String, type: HistoryType) {
        generation++
        when (command) {
            LocalCommand.GamerOn -> {
                val already = gamer.active
                finishWithText(question, if (already) "O modo gamer já está ligado." else "Modo gamer ligado. Pode me chamar quando precisar.", HistoryType.GAMER, emptyList(), forceSpeak = true)
                if (!already) main.postDelayed({ gamer.enable() }, 200)
            }
            LocalCommand.GamerOff -> {
                val was = gamer.active
                gamer.disable()
                finishWithText(question, if (was) "Modo gamer desligado." else "O modo gamer já estava desligado.", HistoryType.GAMER, emptyList(), forceSpeak = true)
            }
            LocalCommand.Cancel -> {
                cancelInternal(goIdle = true)
            }
            LocalCommand.ClearGameContext -> {
                gameContext.clear()
                finishWithText(question, "Pronto, apaguei o contexto do jogo.", typeFor(type), emptyList())
            }
            is LocalCommand.SetGame -> {
                gameContext.setGame(command.game)
                finishWithText(question, "Beleza, anotei: você está jogando ${command.game}.", typeFor(type), emptyList())
            }
            is LocalCommand.SetHero -> {
                gameContext.setHero(command.hero)
                finishWithText(question, "Certo, anotei: você está de ${command.hero}.", typeFor(type), emptyList())
            }
        }
    }

    private fun typeFor(type: HistoryType): HistoryType = if (gamer.active) HistoryType.GAMER else type

    private fun runAi(text: String, type: HistoryType, forceSearch: Boolean) {
        val myGen = ++generation
        val gamerOn = gamer.active

        if (!NetworkChecker.hasAnyNetwork(app)) {
            showError("Estou sem internet agora, então não consigo consultar a IA nem pesquisar. Os recursos locais continuam funcionando.", speak = true)
            return
        }

        val searchLikely = forceSearch || type == HistoryType.SEARCH || VisualIntent.looksLikeSearch(text)
        val visual = VisualIntent.stateWhileThinking(text, searchLikely)
        states.set(KupaState.THINKING)
        if (visual != KupaState.THINKING) {
            main.postDelayed({
                if (generation == myGen && states.current == KupaState.THINKING) states.set(visual)
            }, 650)
        }
        if (searchLikely && settings.voiceEnabled && !gamerOn && Random.nextInt(100) < 35) {
            speech.speak(Phrases.searching(), settings.volumePercent, flush = true, onDone = {})
        }

        val now = System.currentTimeMillis()
        if (now - lastExchangeAt > 10 * 60 * 1000L) convo.clear()
        val messages = ArrayList<AiMessage>(convo.takeLast(8))
        messages.add(AiMessage("user", text))

        val options = AiOptions(
            mode = when {
                gamerOn -> AiMode.GAMER
                forceSearch || type == HistoryType.SEARCH -> AiMode.SEARCH
                else -> AiMode.CHAT
            },
            allowWebSearch = settings.webSearchAllowed && (!gamerOn || settings.gamerKeepSearch),
            enabledTools = tools.enabledNames(gamerOn),
            brief = gamerOn && settings.gamerQuickAnswers,
            gameContext = if (settings.gamerSessionContext) gameContext.asPromptText() else "",
            language = "pt-BR",
            timeZone = TimeZone.getDefault().id,
        )

        val progress = object : AiOrchestrator.Progress {
            override fun isCancelled(): Boolean = generation != myGen

            override fun onToolStarted(name: String) {
                main.post {
                    if (generation != myGen) return@post
                    states.set(if (name == ToolRegistry.ANALYZE_SCREEN) KupaState.SCREEN_ANALYSIS else KupaState.EXECUTING)
                }
            }

            override fun onToolFinished(name: String) {
                main.post {
                    if (generation != myGen) return@post
                    if (states.current == KupaState.SCREEN_ANALYSIS || states.current == KupaState.EXECUTING) states.set(KupaState.THINKING)
                }
            }
        }

        worker.execute {
            val outcome = try {
                orchestrator.run(messages, options, gamerOn, progress)
            } catch (e: Exception) {
                KupaLog.e("core", "erro inesperado na IA", e)
                AiOrchestrator.Outcome(AiResult.Failure(AiError(AiErrorKind.OTHER, "unexpected", "Algo deu errado ao consultar a IA.")), false)
            }
            main.post { onAiOutcome(myGen, text, type, outcome, gamerOn) }
        }
    }

    private fun onAiOutcome(myGen: Int, question: String, type: HistoryType, outcome: AiOrchestrator.Outcome, gamerOn: Boolean) {
        if (generation != myGen) return
        when (val result = outcome.result) {
            is AiResult.Final -> {
                convo.add(AiMessage("user", question))
                convo.add(AiMessage("assistant", result.text))
                while (convo.size > 12) convo.removeAt(0)
                lastExchangeAt = System.currentTimeMillis()
                val historyType = when {
                    gamerOn -> HistoryType.GAMER
                    outcome.usedScreen -> HistoryType.SCREEN_ANALYSIS
                    result.webSearchUsed && type != HistoryType.VOICE -> HistoryType.SEARCH
                    else -> type
                }
                finishWithText(question, result.text, historyType, result.sources)
            }
            is AiResult.Failure -> {
                if (result.error.kind == AiErrorKind.CANCELLED) return
                KupaLog.w("core", "IA falhou: ${result.error.code}")
                showError(result.error.message, speak = true)
            }
            is AiResult.ToolCalls -> showError("A IA pediu mais ferramentas do que posso usar agora.", speak = true)
        }
    }

    // ------------------------------------------------------------------ saída

    private fun finishWithText(question: String, answer: String, type: HistoryType, sources: List<AiSource>, forceSpeak: Boolean = false) {
        val now = System.currentTimeMillis()
        history.add(question, answer, type, now)
        val exchange = Exchange(question, answer, type, now, sources)
        sessionExchanges.add(exchange)
        if (sessionExchanges.size > 50) sessionExchanges.removeAt(0)
        for (l in listeners) l.onExchange(exchange)

        val gamerOn = gamer.active
        if (!gamerOn && settings.showBubble || gamerOn && settings.gamerShowBubble) emitBubble(answer, false, answer.length)
        if (gamerOn && settings.gamerNotify) Notifications.postAnswer(app, answer)

        val speakIt = settings.voiceEnabled && (!gamerOn || settings.gamerKeepVoice || forceSpeak)
        val volume = if (gamerOn) settings.gamerVolumePercent else settings.volumePercent
        val myGen = generation
        states.set(KupaState.SPEAKING)
        if (speakIt) {
            speech.speak(
                answer, volume, flush = true,
                onError = { message -> KupaLog.w("core", "voz: $message"); for (l in listeners) l.onProblem(message) },
                onDone = { if (generation == myGen) complete() },
            )
        } else {
            main.postDelayed({ if (generation == myGen) complete() }, readingTimeMs(answer))
        }
    }

    private fun readingTimeMs(text: String): Long = (1500L + 45L * text.length).coerceIn(1500L, 7000L)

    private fun complete() {
        states.set(KupaState.COMPLETED)
        scheduleIdle(900, KupaState.COMPLETED)
    }

    private fun scheduleIdle(delayMs: Long, expected: KupaState) {
        val myGen = generation
        main.postDelayed({
            if (generation == myGen && states.current == expected) {
                states.set(KupaState.IDLE)
                voiceControl?.refresh()
            }
        }, delayMs)
    }

    private fun showError(message: String, speak: Boolean) {
        generation++
        val myGen = generation
        KupaLog.w("core", "erro mostrado: $message")
        speech.stop()
        states.set(KupaState.ERROR)
        for (l in listeners) l.onProblem(message)
        val gamerOn = gamer.active
        if (!gamerOn && settings.showBubble || gamerOn && settings.gamerShowBubble) emitBubble(message, true, message.length)
        if (gamerOn && settings.gamerNotify) Notifications.postAnswer(app, message)
        val speakIt = speak && settings.voiceEnabled && (!gamerOn || settings.gamerKeepVoice)
        if (speakIt) {
            speech.speak(Phrases.problem(), if (gamerOn) settings.gamerVolumePercent else settings.volumePercent, flush = true, onDone = {})
        }
        main.postDelayed({
            if (generation == myGen && states.current == KupaState.ERROR) {
                states.set(KupaState.IDLE)
                voiceControl?.refresh()
            }
        }, 3800)
    }

    private fun emitBubble(text: String, isError: Boolean, length: Int) {
        val token = ++bubbleToken
        for (l in listeners) l.onBubble(text, isError)
        val visibleMs = (4000L + 60L * length).coerceIn(4000L, 20000L)
        main.postDelayed({
            if (token == bubbleToken) for (l in listeners) l.onBubble(null, false)
        }, visibleMs)
    }

    fun hideBubbleNow() {
        bubbleToken++
        for (l in listeners) l.onBubble(null, false)
    }

    // ------------------------------------------------------------------ ajustes que mexem no fluxo

    fun setVoiceEnabled(enabled: Boolean) {
        settings.voiceEnabled = enabled
        if (!enabled) {
            speech.stop()
            voiceControl?.stopAll()
        } else {
            voiceControl?.refresh()
        }
    }

    fun clearConversation() {
        convo.clear()
        sessionExchanges.clear()
    }

    // ------------------------------------------------------------------ captura de tela

    private fun hideForCapture() {
        runOnMainBlocking(500) { overlayHider?.hideForCapture() }
    }

    private fun restoreAfterCapture() {
        runOnMainBlocking(500) { overlayHider?.restoreAfterCapture() }
    }

    private fun runOnMainBlocking(timeoutMs: Long, block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        latch.await(timeoutMs, TimeUnit.MILLISECONDS)
    }

    private fun vibrateTick() {
        if (!gamer.active) return
        try {
            @Suppress("DEPRECATION")
            val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            KupaLog.w("core", "vibração indisponível: ${e.message}")
        }
    }
}
