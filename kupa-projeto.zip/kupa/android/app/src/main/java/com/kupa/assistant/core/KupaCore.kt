package com.kupa.assistant.core

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import com.kupa.assistant.actions.ActionResult
import com.kupa.assistant.actions.CommandCenter
import com.kupa.assistant.actions.ConversationContext
import com.kupa.assistant.actions.PhoneActions
import com.kupa.assistant.ai.AiError
import com.kupa.assistant.ai.AiErrorKind
import com.kupa.assistant.ai.AiMessage
import com.kupa.assistant.ai.AiMode
import com.kupa.assistant.ai.AiOptions
import com.kupa.assistant.ai.AiOrchestrator
import com.kupa.assistant.ai.AiResult
import com.kupa.assistant.ai.AiSource
import com.kupa.assistant.ai.KupaBackendClient
import com.kupa.assistant.ai.KupaBackendProvider
import com.kupa.assistant.ai.NetworkChecker
import com.kupa.assistant.game.GameContextService
import com.kupa.assistant.gamer.GamerModeController
import com.kupa.assistant.history.HistoryDb
import com.kupa.assistant.history.HistoryType
import com.kupa.assistant.content.NicheProfile
import com.kupa.assistant.modes.ModeManager
import com.kupa.assistant.overlay.Notifications
import com.kupa.assistant.perf.PerformanceEngine
import com.kupa.assistant.profile.AdaptiveUserProfile
import com.kupa.assistant.security.InjectionDetector
import com.kupa.assistant.security.PrivacyGate
import com.kupa.assistant.security.ResultVerifier
import com.kupa.assistant.security.SecurityCore
import com.kupa.assistant.security.SecurityGuard
import com.kupa.assistant.screen.ScreenCaptureManager
import com.kupa.assistant.settings.Settings
import com.kupa.assistant.tools.ToolRegistry
import com.kupa.assistant.voice.Phrases
import com.kupa.assistant.voice.SpeechInput
import com.kupa.assistant.voice.SpeechOutput
import java.util.TimeZone
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** Quem controla o microfone (implementado pelo VoiceController, dentro do serviço). */
interface VoiceControl {
    fun startCommandListening()
    fun refresh()
    fun stopAll()

    /** Houve um comando de verdade (zera o relógio de inatividade da escuta contínua). */
    fun noteActivity()

    /** O microfone está aberto agora? (indicador de privacidade) */
    fun isMicOpen(): Boolean

    fun pauseListening()

    fun resumeListening()
}

/** Quem consegue esconder o personagem por um instante (para ele não aparecer na captura de tela). */
interface OverlayHider {
    fun hideForCapture()
    fun restoreAfterCapture()
}

/**
 * KUPA CORE: o cérebro do app. Recebe o que o usuário pediu (voz, texto, pesquisa rápida), decide o que é
 * comando local, comando do celular (camada de intenções) ou conversa com a IA, controla as ferramentas autorizadas,
 * conduz os estados do Popol e entrega a resposta (balão, voz, histórico). Métodos públicos: thread principal.
 */
class KupaCore(
    private val app: Application,
    val settings: Settings,
    val history: HistoryDb,
    val states: StateManager,
    val gameContext: GameContextService,
    val gamer: GamerModeController,
    val screen: ScreenCaptureManager,
    val commands: CommandCenter,
    phone: PhoneActions,
    conversation: ConversationContext,
    val security: SecurityGuard,
    val modes: ModeManager,
    val profile: AdaptiveUserProfile,
    val niche: NicheProfile,
    val performance: PerformanceEngine,
) {
    interface Listener {
        fun onBubble(text: String?, isError: Boolean)
        fun onExchange(exchange: Exchange)
        fun onProblem(message: String)
    }

    data class Exchange(val question: String, val answer: String, val type: HistoryType, val timestampMs: Long, val sources: List<AiSource>)

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val listeners = CopyOnWriteArrayList<Listener>()

    val client = KupaBackendClient(settings)
    private val provider = KupaBackendProvider(client)
    private val tools = ToolRegistry(app, settings, screen, { hideForCapture() }, { restoreAfterCapture() }, commands, phone, security, conversation, performance, modes)
    private val orchestrator = AiOrchestrator(provider, tools)
    val speech = SpeechOutput(app, settings)

    @Volatile var voiceControl: VoiceControl? = null
    @Volatile var overlayHider: OverlayHider? = null

    @Volatile var sendingToBackend = false
        private set

    private var generation = 0
    private var bubbleToken = 0
    private val convo = ArrayList<AiMessage>()
    private var lastExchangeAt = 0L
    val sessionExchanges = ArrayList<Exchange>()

    init {
        // o SecurityCore manda: qualquer alerta chega aqui, nunca o contrário
        security.reactor = { reaction -> main.post { onSecurityReaction(reaction) } }
    }

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    // ------------------------------------------------------------------ entrada

    /** Modo "Kupa": palavra de ativação detectada. [inlineCommand] é o que veio junto ("Kupa, abra o WhatsApp"). */
    fun onWake(inlineCommand: String) {
        if (states.current != KupaState.IDLE) return
        if (security.state().blocksActions()) return
        KupaLog.i("core", "ativado por voz (comando junto=${inlineCommand.isNotBlank()})")
        states.set(KupaState.ACTIVATED)
        if (inlineCommand.isNotBlank()) {
            main.postDelayed({ process(inlineCommand, HistoryType.VOICE, forceSearch = false, continuous = false, addressed = true) }, 250)
            return
        }
        if (gamer.active) {
            vibrateTick()
            beginListening()
        } else if (settings.voiceEnabled) {
            speech.speak(Phrases.activated(), settings.volumePercent, flush = true, onError = {}, onDone = { beginListening() })
        } else {
            beginListening()
        }
    }

    /** "Falar" (botão/notificação): abre o microfone direto, sem precisar dizer "Kupa". */
    fun listenNow() {
        if (security.state().blocksActions()) {
            announceSafeMode()
            return
        }
        if (states.current != KupaState.IDLE) cancelInternal(goIdle = true)
        states.set(KupaState.ACTIVATED)
        vibrateTick()
        beginListening()
    }

    private fun beginListening() {
        if (states.current != KupaState.ACTIVATED) return
        states.set(KupaState.LISTENING)
        val vc = voiceControl
        if (vc == null) {
            onListenFailed(SpeechInput.Failure.NOT_AVAILABLE, "O microfone só funciona com o KUPA em execução. Toque em Iniciar KUPA.")
        } else {
            vc.startCommandListening()
        }
    }

    /** Comando ouvido depois de "Kupa" (ou de uma pergunta do KUPA). Escolhe a alternativa que parece um comando de celular. */
    fun onCommandHeard(alternatives: List<String>) {
        if (states.current != KupaState.LISTENING || alternatives.isEmpty()) return
        val text = if (commands.hasPending()) alternatives[0] else (alternatives.firstOrNull { commands.looksLikeCommand(it) } ?: alternatives[0])
        process(text, HistoryType.VOICE, forceSearch = false, continuous = false, addressed = true)
    }

    /**
     * Modo contínuo: o microfone ouviu uma frase sem "Kupa" na frente.
     * Só vira ação se for um comando de celular reconhecido (ou resposta a uma pergunta do KUPA, ou "Kupa, ...").
     * Conversa solta NÃO vai para a IA, a menos que o usuário ligue essa opção. Devolve true se tratou a frase.
     */
    fun onContinuousSpeech(alternatives: List<String>): Boolean {
        if (states.current != KupaState.IDLE || alternatives.isEmpty()) return false
        if (commands.hasPending()) {
            process(alternatives[0], HistoryType.VOICE, forceSearch = false, continuous = true, addressed = true)
            return true
        }
        var chosen: String? = null
        var addressed = false
        for (alt in alternatives) {
            val wake = WakeWord.match(alt, settings.wakeAcceptVariants)
            val text = wake?.command ?: alt
            if (wake != null) addressed = true
            if (text.isNotBlank() && commands.looksLikeCommand(text)) {
                chosen = text
                addressed = wake != null
                break
            }
        }
        if (chosen == null) {
            val wake = WakeWord.match(alternatives[0], settings.wakeAcceptVariants)
            if (wake != null) {
                if (wake.command.isBlank()) {
                    onWake("")
                    return true
                }
                chosen = wake.command
                addressed = true
            } else if (settings.continuousFreeText) {
                chosen = alternatives[0]
                addressed = true
            }
        }
        val text = chosen ?: return false
        process(text, HistoryType.VOICE, forceSearch = false, continuous = true, addressed = addressed)
        return true
    }

    fun onListenFailed(failure: SpeechInput.Failure, message: String?) {
        if (commands.hasPending()) {
            commands.cancelPending()
            KupaLog.i("core", "pergunta pendente cancelada: sem resposta")
            states.set(KupaState.CONFUSED)
            emitBubble("Não ouvi sua resposta, então cancelei.", false, 40)
            scheduleIdle(1600, KupaState.CONFUSED)
            return
        }
        when (failure) {
            SpeechInput.Failure.NO_MATCH, SpeechInput.Failure.TIMEOUT -> {
                states.set(KupaState.CONFUSED)
                if (settings.voiceEnabled && !gamer.active) {
                    speech.speak(Phrases.DIDNT_UNDERSTAND, settings.volumePercent, flush = true, onDone = {})
                }
                scheduleIdle(1600, KupaState.CONFUSED)
            }
            SpeechInput.Failure.PERMISSION -> showError(message ?: "Preciso da permissão do microfone.", speak = false)
            SpeechInput.Failure.NOT_AVAILABLE -> showError(message ?: "O reconhecimento de voz não está disponível.", speak = false)
            SpeechInput.Failure.NETWORK -> showError(message ?: "O reconhecimento de voz precisa de internet e não conseguiu conectar.", speak = false)
            else -> showError(message ?: "Não consegui ouvir agora.", speak = false)
        }
    }

    /** Texto digitado (conversa), pesquisa rápida ou pedidos vindos do menu. */
    fun submitText(text: String, type: HistoryType = HistoryType.TEXT, forceSearch: Boolean = false) {
        if (text.isBlank()) return
        if (states.current != KupaState.IDLE) cancelInternal(goIdle = false)
        process(text.trim(), type, forceSearch, continuous = false, addressed = true)
    }

    fun cancel() {
        commands.cancelPending()
        cancelInternal(goIdle = true)
    }

    private fun cancelInternal(goIdle: Boolean) {
        generation++
        bubbleToken++
        speech.stop()
        voiceControl?.stopAll()
        if (goIdle) {
            states.set(KupaState.IDLE)
            voiceControl?.refresh()
        }
    }

    /** Aviso informativo no balão (sem mudar o estado do Popol). */
    fun announce(message: String) {
        if (gamer.active && !settings.gamerShowBubble) return
        emitBubble(message, false, message.length)
    }

    /** Mensagens de problema vindas de fora do fluxo normal (ex.: microfone sem permissão). */
    fun reportProblem(message: String) {
        showError(message, speak = false)
    }

    // ------------------------------------------------------------------ processamento

    private fun process(text: String, type: HistoryType, forceSearch: Boolean, continuous: Boolean, addressed: Boolean) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        if (security.state().blocksActions()) {
            // modo seguro: só "parar" é aceito; o resto é recusado com clareza
            if (CommandRouter.route(clean) != LocalCommand.Cancel && !isStopPhrase(clean)) {
                announceSafeMode()
                return
            }
        }
        if (!commands.hasPending()) {
            val local = CommandRouter.route(clean)
            if (local != null) {
                handleLocal(local, clean, type)
                return
            }
        }
        val myGen = ++generation
        if (!continuous) states.set(KupaState.THINKING)
        worker.execute {
            val decision = try {
                commands.decide(clean, continuous, addressed, type == HistoryType.VOICE)
            } catch (e: Exception) {
                KupaLog.e("core", "erro ao interpretar o comando", e)
                CommandCenter.Decision.NotCommand
            }
            main.post { onDecision(myGen, clean, type, forceSearch, decision) }
        }
    }

    private fun onDecision(myGen: Int, text: String, type: HistoryType, forceSearch: Boolean, decision: CommandCenter.Decision) {
        if (generation != myGen) return
        when (decision) {
            is CommandCenter.Decision.Executed -> {
                voiceControl?.noteActivity()
                deliverAction(text, decision.result, myGen)
            }
            CommandCenter.Decision.NotCommand -> runAi(text, type, forceSearch)
            CommandCenter.Decision.Ignored -> {
                KupaLog.d("core", "frase solta ignorada (modo contínuo)")
                if (states.current == KupaState.THINKING) states.set(KupaState.IDLE)
                voiceControl?.refresh()
            }
        }
    }

    private fun handleLocal(command: LocalCommand, question: String, type: HistoryType) {
        generation++
        when (command) {
            LocalCommand.GamerOn -> {
                val already = gamer.active
                finishWithText(question, if (already) "O modo gamer já está ligado." else "Modo gamer ligado. Pode me chamar quando precisar.", HistoryType.GAMER, emptyList(), forceSpeak = true)
                if (!already) main.postDelayed({ gamer.enable() }, 200)
            }
            LocalCommand.GamerOff -> {
                val was = gamer.active
                gamer.disable()
                finishWithText(question, if (was) "Modo gamer desligado." else "O modo gamer já estava desligado.", HistoryType.GAMER, emptyList(), forceSpeak = true)
            }
            LocalCommand.Cancel -> {
                commands.cancelPending()
                cancelInternal(goIdle = true)
            }
            LocalCommand.ClearGameContext -> {
                gameContext.clear()
                finishWithText(question, "Pronto, apaguei o contexto do jogo.", typeFor(type), emptyList())
            }
            is LocalCommand.SetGame -> {
                gameContext.setGame(command.game)
                finishWithText(question, "Beleza, anotei: você está jogando ${command.game}.", typeFor(type), emptyList())
            }
            is LocalCommand.SetHero -> {
                gameContext.setHero(command.hero)
                finishWithText(question, "Certo, anotei: você está de ${command.hero}.", typeFor(type), emptyList())
            }
        }
    }

    private fun typeFor(type: HistoryType): HistoryType = if (gamer.active) HistoryType.GAMER else type

    // ------------------------------------------------------------------ ações no celular

    private fun deliverAction(question: String, result: ActionResult, myGen: Int) {
        when (result) {
            is ActionResult.Done -> {
                states.set(KupaState.EXECUTING)
                finishWithText(question, result.message, HistoryType.ACTION, emptyList(), forceSpeak = false)
            }
            is ActionResult.Failed -> {
                history.add(question, result.message, HistoryType.ACTION)
                showError(result.message, speak = true, speakMessage = true)
            }
            is ActionResult.AskConfirm -> deliverPrompt(result.prompt, myGen)
            is ActionResult.AskChoice -> deliverPrompt(result.prompt, myGen)
            is ActionResult.Reask -> deliverPrompt(result.prompt, myGen)
        }
    }

    /** Pergunta ao usuário (confirmar/escolher) e depois escuta a resposta. */
    private fun deliverPrompt(prompt: String, myGen: Int) {
        val gamerOn = gamer.active
        if (!gamerOn && settings.showBubble || gamerOn && settings.gamerShowBubble) emitBubble(prompt, false, prompt.length + 80)
        if (gamerOn && settings.gamerNotify) Notifications.postAnswer(app, prompt)
        val sessionExchange = Exchange("", prompt, HistoryType.ACTION, System.currentTimeMillis(), emptyList())
        for (l in listeners) l.onExchange(sessionExchange)
        val speakIt = settings.voiceEnabled && (!gamerOn || settings.gamerKeepVoice)
        states.set(KupaState.SPEAKING)
        if (speakIt) {
            speech.speak(
                prompt, if (gamerOn) settings.gamerVolumePercent else settings.volumePercent, flush = true,
                onError = { m -> KupaLog.w("core", "voz: $m") },
                onDone = { if (generation == myGen) awaitReply() },
            )
        } else {
            main.postDelayed({ if (generation == myGen) awaitReply() }, readingTimeMs(prompt))
        }
    }

    /** Depois de uma pergunta: no modo por palavra-chave abre o microfone uma vez; no contínuo a escuta já segue sozinha. */
    private fun awaitReply() {
        if (!settings.voiceEnabled || settings.listenMode == "continuous") {
            states.set(KupaState.IDLE)
            voiceControl?.refresh()
            return
        }
        states.set(KupaState.ACTIVATED)
        beginListening()
    }

    /**
     * @param contentTask tarefa de inteligência de conteúdo (niche_survey, hooks, script, optimize, analyze_text) ou null para conversa normal.
     */
    private fun runAi(rawText: String, type: HistoryType, forceSearch: Boolean, contentTask: String? = null) {
        val myGen = ++generation
        val gamerOn = gamer.active

        // PRIVACY GATE: nada sai do aparelho sem passar por aqui (credenciais e dados financeiros são removidos antes do envio)
        val gate = PrivacyGate.scrubOutgoing(rawText)
        val text = gate.sanitized
        if (gate.changed()) {
            KupaLog.i("privacidade", "removido antes do envio: ${gate.redactions.joinToString()}")
            announce("Removi " + gate.redactions.joinToString(", ") + " do que você disse antes de enviar à IA.")
        }

        if (!NetworkChecker.hasAnyNetwork(app)) {
            showError("Estou sem internet agora, então não consigo consultar a IA nem pesquisar. Os recursos locais continuam funcionando.", speak = true)
            return
        }

        val searchLikely = forceSearch || type == HistoryType.SEARCH || VisualIntent.looksLikeSearch(text)
        val visual = VisualIntent.stateWhileThinking(text, searchLikely)
        states.set(KupaState.THINKING)
        if (visual != KupaState.THINKING) {
            main.postDelayed({
                if (generation == myGen && states.current == KupaState.THINKING) states.set(visual)
            }, 650)
        }
        if (searchLikely && settings.voiceEnabled && !gamerOn && Random.nextInt(100) < 35) {
            speech.speak(Phrases.searching(), settings.volumePercent, flush = true, onDone = {})
        }

        val now = System.currentTimeMillis()
        if (now - lastExchangeAt > 10 * 60 * 1000L) convo.clear()
        val messages = ArrayList<AiMessage>(convo.takeLast(8))
        messages.add(AiMessage("user", text))

        // o modo ativo só pode RESTRINGIR (E lógico com as configurações globais) e nunca altera a segurança
        val activeMode = modes.active()
        val scrub = { value: String -> PrivacyGate.scrubOutgoing(value).sanitized }
        val options = AiOptions(
            mode = when {
                gamerOn -> AiMode.GAMER
                forceSearch || type == HistoryType.SEARCH -> AiMode.SEARCH
                else -> AiMode.CHAT
            },
            allowWebSearch = settings.webSearchAllowed && (!gamerOn || settings.gamerKeepSearch) && (activeMode?.allowWeb != false),
            enabledTools = if (contentTask != null) emptyList() else tools.enabledNames(gamerOn),
            brief = contentTask == null && gamerOn && settings.gamerQuickAnswers,
            gameContext = if (settings.gamerSessionContext) scrub(gameContext.asPromptText()) else "",
            language = "pt-BR",
            timeZone = TimeZone.getDefault().id,
            task = contentTask ?: "general",
            niche = if (contentTask != null) niche.get().mapValues { scrub(it.value) } else emptyMap(),
            modeName = activeMode?.name ?: "",
            modeInstructions = scrub(activeMode?.instructions ?: ""),
            modeNotes = scrub(activeMode?.notes ?: ""),
            proactivity = profile.proactivity(activeMode?.id ?: "", activeMode?.proactivity, settings.proactivity),
            verbosity = profile.verbosity(),
            modelClass = activeMode?.modelClass ?: "",
        )

        val progress = object : AiOrchestrator.Progress {
            override fun isCancelled(): Boolean = generation != myGen

            override fun onToolStarted(name: String) {
                main.post {
                    if (generation != myGen) return@post
                    states.set(if (name == ToolRegistry.ANALYZE_SCREEN) KupaState.SCREEN_ANALYSIS else KupaState.EXECUTING)
                }
            }

            override fun onToolFinished(name: String) {
                main.post {
                    if (generation != myGen) return@post
                    if (states.current == KupaState.SCREEN_ANALYSIS || states.current == KupaState.EXECUTING) states.set(KupaState.THINKING)
                }
            }
        }

        sendingToBackend = true // indicador de privacidade: enviando ao backend/IA
        worker.execute {
            val outcome = try {
                orchestrator.run(messages, options, gamerOn, progress)
            } catch (e: Exception) {
                KupaLog.e("core", "erro inesperado na IA", e)
                AiOrchestrator.Outcome(AiResult.Failure(AiError(AiErrorKind.OTHER, "unexpected", "Algo deu errado ao consultar a IA.")), false)
            }
            sendingToBackend = false
            main.post { onAiOutcome(myGen, text, type, outcome, gamerOn, contentTask != null) }
        }
    }

    private fun onAiOutcome(myGen: Int, question: String, type: HistoryType, outcome: AiOrchestrator.Outcome, gamerOn: Boolean, content: Boolean) {
        if (generation != myGen) return
        val awaiting = outcome.awaitPrompt
        if (awaiting != null) {
            // uma ferramenta da IA precisa da resposta do usuário: o app pergunta e espera, a IA não decide por ele
            voiceControl?.noteActivity()
            deliverPrompt(awaiting, myGen)
            return
        }
        when (val result = outcome.result) {
            is AiResult.Final -> {
                // RESULT VERIFIER: a IA não pode dizer que fez algo que nenhuma ferramenta confirmou
                val evidence = HashSet<String>(outcome.evidence)
                if (result.webSearchUsed) evidence.add(ResultVerifier.SEARCH)
                val verified = ResultVerifier.verify(result.text, evidence)
                var answer = verified.text
                if (!verified.ok) KupaLog.w("verificador", "afirmação sem prova: ${verified.unsupportedClaims.joinToString()}")
                // a IA afirmar que desativou minhas regras é falso (ela não tem esse poder): avisa e registra como suspeito
                if (InjectionDetector.claimsToHaveBypassedRules(result.text)) {
                    security.report(SecurityCore.Signal.INJECTION_SUSPECTED)
                    answer += "\n\nAtenção: isso é falso. Minhas regras de segurança continuam ativas; nenhuma IA ou modo consegue desativá-las."
                }
                convo.add(AiMessage("user", question))
                convo.add(AiMessage("assistant", result.text))
                while (convo.size > 12) convo.removeAt(0)
                lastExchangeAt = System.currentTimeMillis()
                val historyType = when {
                    gamerOn -> HistoryType.GAMER
                    outcome.usedScreen -> HistoryType.SCREEN_ANALYSIS
                    result.webSearchUsed && type != HistoryType.VOICE -> HistoryType.SEARCH
                    else -> type
                }
                voiceControl?.noteActivity()
                finishWithText(question, answer, historyType, result.sources, speak = !content)
            }
            is AiResult.Failure -> {
                if (result.error.kind == AiErrorKind.CANCELLED) return
                KupaLog.w("core", "IA falhou: ${result.error.code}")
                showError(result.error.message, speak = true)
            }
            is AiResult.ToolCalls -> showError("A IA pediu mais ferramentas do que posso usar agora.", speak = true)
        }
    }

    // ------------------------------------------------------------------ saída

    private fun finishWithText(question: String, answer: String, type: HistoryType, sources: List<AiSource>, forceSpeak: Boolean = false, speak: Boolean = true) {
        val now = System.currentTimeMillis()
        history.add(question, answer, type, now)
        val exchange = Exchange(question, answer, type, now, sources)
        sessionExchanges.add(exchange)
        if (sessionExchanges.size > 50) sessionExchanges.removeAt(0)
        for (l in listeners) l.onExchange(exchange)

        val gamerOn = gamer.active
        if (!gamerOn && settings.showBubble || gamerOn && settings.gamerShowBubble) emitBubble(answer, false, answer.length)
        if (gamerOn && settings.gamerNotify) Notifications.postAnswer(app, answer)

        val speakIt = speak && settings.voiceEnabled && (!gamerOn || settings.gamerKeepVoice || forceSpeak)
        val volume = if (gamerOn) settings.gamerVolumePercent else settings.volumePercent
        val myGen = generation
        states.set(KupaState.SPEAKING)
        if (speakIt) {
            speech.speak(
                answer, volume, flush = true,
                onError = { message -> KupaLog.w("core", "voz: $message"); for (l in listeners) l.onProblem(message) },
                onDone = { if (generation == myGen) complete() },
            )
        } else {
            main.postDelayed({ if (generation == myGen) complete() }, readingTimeMs(answer))
        }
    }

    private fun readingTimeMs(text: String): Long = (1500L + 45L * text.length).coerceIn(1500L, 7000L)

    private fun complete() {
        states.set(KupaState.COMPLETED)
        scheduleIdle(900, KupaState.COMPLETED)
    }

    private fun scheduleIdle(delayMs: Long, expected: KupaState) {
        val myGen = generation
        main.postDelayed({
            if (generation == myGen && states.current == expected) {
                states.set(KupaState.IDLE)
                voiceControl?.refresh()
            }
        }, delayMs)
    }

    /** @param speakMessage fala o próprio texto do erro (ex.: "Não encontrei esse aplicativo instalado."), em vez de só "tive um problema". */
    private fun showError(message: String, speak: Boolean, speakMessage: Boolean = false) {
        generation++
        val myGen = generation
        KupaLog.w("core", "erro mostrado: $message")
        speech.stop()
        states.set(KupaState.ERROR)
        for (l in listeners) l.onProblem(message)
        val gamerOn = gamer.active
        if (!gamerOn && settings.showBubble || gamerOn && settings.gamerShowBubble) emitBubble(message, true, message.length)
        if (gamerOn && settings.gamerNotify) Notifications.postAnswer(app, message)
        val speakIt = speak && settings.voiceEnabled && (!gamerOn || settings.gamerKeepVoice)
        var hold = 3800L
        if (speakIt) {
            val toSay = if (speakMessage) message else Phrases.problem()
            if (speakMessage) hold = readingTimeMs(message) + 1200L
            speech.speak(toSay, if (gamerOn) settings.gamerVolumePercent else settings.volumePercent, flush = true, onDone = {})
        }
        main.postDelayed({
            if (generation == myGen && states.current == KupaState.ERROR) {
                states.set(KupaState.IDLE)
                voiceControl?.refresh()
            }
        }, hold)
    }

    private fun emitBubble(text: String, isError: Boolean, length: Int) {
        val token = ++bubbleToken
        for (l in listeners) l.onBubble(text, isError)
        val visibleMs = (4000L + 60L * length).coerceIn(4000L, 20000L)
        main.postDelayed({
            if (token == bubbleToken) for (l in listeners) l.onBubble(null, false)
        }, visibleMs)
    }

    fun hideBubbleNow() {
        bubbleToken++
        for (l in listeners) l.onBubble(null, false)
    }

    // ------------------------------------------------------------------ conteúdo, segurança e indicadores

    /** Tarefa de inteligência de conteúdo (só texto). A resposta aparece na tela de Conteúdo; não é falada. */
    fun submitContentTask(task: String, input: String) {
        if (security.state().blocksActions()) {
            announceSafeMode()
            return
        }
        if (input.isBlank() && task != "niche_survey") return
        if (states.current != KupaState.IDLE) cancelInternal(goIdle = false)
        val prompt = if (input.isBlank()) "Faça o levantamento do meu nicho." else input.trim()
        runAi(prompt, HistoryType.TEXT, forceSearch = task == "niche_survey", contentTask = task)
    }

    private fun isStopPhrase(text: String): Boolean = commands.looksLikeCommand(text) && com.kupa.assistant.intent.CommandInterpreter().interpret(text).intents.let {
        it.size == 1 && it[0].kind == com.kupa.assistant.intent.KupaIntent.Kind.STOP_KUPA
    }

    private fun announceSafeMode() {
        val msg = "O KUPA está em modo seguro e não executa comandos. Reative em Configurações, com a confirmação do aparelho."
        emitBubble(msg, true, msg.length)
        for (l in listeners) l.onProblem(msg)
    }

    /**
     * PARAR KUPA: interrompe IA, voz, análise de tela, automação e perguntas pendentes, pausa a escuta e sai do modo atual.
     * Não encerra o serviço (para isso existe "Parar" na notificação).
     */
    fun stopEverything() {
        commands.cancelPending()
        cancelInternal(goIdle = false)
        screen.stop()
        voiceControl?.pauseListening()
        modes.exit()
        states.set(KupaState.IDLE)
        KupaLog.i("core", "PARAR KUPA acionado")
        emitBubble("KUPA parado. A escuta está pausada; toque em Retomar para voltar.", false, 60)
    }

    /** Reação do SecurityCore: alerta o usuário e, se for o caso, para tudo e entra em SAFE_SHUTDOWN. */
    private fun onSecurityReaction(r: SecurityCore.Reaction) {
        KupaLog.w("core", "reação de segurança: ${r.state.name}")
        if (r.message.isNotEmpty()) {
            emitBubble(r.message, true, r.message.length)
            for (l in listeners) l.onProblem(r.message)
            if (r.alertUser) Notifications.postAnswer(app, r.message)
        }
        if (r.safeShutdown) safeShutdown()
    }

    /** SAFE_SHUTDOWN: bloqueia, cancela, para a captura e a escuta; só volta com ação explícita e autenticada do usuário. */
    private fun safeShutdown() {
        commands.cancelPending()
        cancelInternal(goIdle = false)
        screen.stop()
        voiceControl?.pauseListening()
        modes.exit()
        states.set(KupaState.ERROR) // fica em ERRO de propósito: nada volta ao normal sozinho
    }

    /** Sai do modo seguro com a autenticação do aparelho. */
    fun rearm(onDone: (Boolean) -> Unit) {
        security.rearm { ok ->
            if (ok) {
                states.set(KupaState.IDLE)
                voiceControl?.resumeListening()
                emitBubble("KUPA reativado.", false, 20)
            }
            onDone(ok)
        }
    }

    /** O que o KUPA está fazendo AGORA com microfone, tela e rede (indicadores de privacidade). */
    fun indicators(): List<String> {
        val out = ArrayList<String>()
        if (voiceControl?.isMicOpen() == true) out.add("🎤 microfone ouvindo")
        if (screen.isActive) out.add("🖥 captura de tela autorizada ativa")
        if (sendingToBackend) out.add("☁ enviando ao backend/IA")
        if (states.current == KupaState.EXECUTING) out.add("⚙ executando uma ação")
        return out
    }

    // ------------------------------------------------------------------ ajustes que mexem no fluxo

    fun setVoiceEnabled(enabled: Boolean) {
        settings.voiceEnabled = enabled
        if (!enabled) {
            speech.stop()
            voiceControl?.stopAll()
        } else {
            voiceControl?.refresh()
        }
    }

    fun clearConversation() {
        convo.clear()
        sessionExchanges.clear()
    }

    // ------------------------------------------------------------------ captura de tela

    private fun hideForCapture() {
        runOnMainBlocking(500) { overlayHider?.hideForCapture() }
    }

    private fun restoreAfterCapture() {
        runOnMainBlocking(500) { overlayHider?.restoreAfterCapture() }
    }

    private fun runOnMainBlocking(timeoutMs: Long, block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
            return
        }
        val latch = CountDownLatch(1)
        main.post {
            try {
                block()
            } finally {
                latch.countDown()
            }
        }
        latch.await(timeoutMs, TimeUnit.MILLISECONDS)
    }

    private fun vibrateTick() {
        if (!gamer.active) return
        try {
            @Suppress("DEPRECATION")
            val vibrator = app.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            KupaLog.w("core", "vibração indisponível: ${e.message}")
        }
    }
}
