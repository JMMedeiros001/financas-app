package com.kupa.assistant.screen

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.overlay.KupaService

/** Activity transparente que mostra o pedido OFICIAL de permissão de gravação/captura de tela do Android. */
class ScreenPermissionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
        } catch (e: Exception) {
            KupaLog.e("tela", "não consegui abrir o pedido de captura", e)
            Toast.makeText(this, "Não consegui abrir o pedido de permissão de tela.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("API simples e estável; sem dependências extras")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                KupaService.deliverProjection(this, resultCode, data)
            } else {
                Toast.makeText(this, "Captura de tela não autorizada.", Toast.LENGTH_LONG).show()
            }
        }
        finish()
    }

    companion object {
        private const val REQUEST_CAPTURE = 4711
    }
}
