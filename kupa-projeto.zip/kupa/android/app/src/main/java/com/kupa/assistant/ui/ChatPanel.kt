package com.kupa.assistant.ui

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.kupa.assistant.KupaApp
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.StateManager
import com.kupa.assistant.history.HistoryType
import com.kupa.assistant.profile.Feedback

/**
 * Conversa com o KUPA, reutilizável: ocupa a tela inteira no celular e fica ao lado do Popol no tablet
 * (é a MESMA tela, só muda a disposição). Cada resposta da IA tem botões de feedback que o perfil adaptativo usa.
 */
class ChatPanel(context: Context, private val app: KupaApp) : LinearLayout(context), KupaCore.Listener {
    private val list = LinearLayout(context)
    private val scroll = ScrollView(context)
    private val status: TextView = Ui.text(context, "Popol: ${app.states.current.label}", 12f, Ui.MUTED)
    private val input = EditText(context)
    private val stateListener = StateManager.Listener { _, current -> status.text = "Popol: ${current.label}" }

    init {
        orientation = VERTICAL
        addView(status)

        list.orientation = VERTICAL
        scroll.addView(list, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(scroll, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val bar = LinearLayout(context)
        bar.orientation = HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        input.hint = "Pergunte qualquer coisa…"
        input.setHintTextColor(Ui.MUTED)
        input.setTextColor(Ui.TEXT)
        input.maxLines = 4
        input.imeOptions = EditorInfo.IME_ACTION_SEND
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                send()
                true
            } else {
                false
            }
        }
        bar.addView(input, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendButton = Button(context)
        sendButton.text = "Enviar"
        sendButton.isAllCaps = false
        sendButton.setOnClickListener { send() }
        bar.addView(sendButton)
        val mic = Button(context)
        mic.text = "Falar"
        mic.isAllCaps = false
        mic.setOnClickListener { app.core.listenNow() }
        bar.addView(mic)
        addView(bar, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        for (e in app.core.sessionExchanges) addExchange(e)
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        app.core.submitText(text, HistoryType.TEXT)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        app.core.addListener(this)
        app.states.addListener(stateListener)
    }

    override fun onDetachedFromWindow() {
        app.core.removeListener(this)
        app.states.removeListener(stateListener)
        super.onDetachedFromWindow()
    }

    private fun bubble(text: String, mine: Boolean, error: Boolean = false): TextView {
        val tv = Ui.text(context, text, 15f, if (error) Ui.BAD else Ui.TEXT)
        tv.background = Ui.rounded(context, if (mine) com.kupa.assistant.visual.Palette.mix(com.kupa.assistant.visual.Palette.TARDIS_BLUE, com.kupa.assistant.visual.Palette.DEEP_BLUE, 0.45f) else Ui.CARD, 14, if (mine) Ui.ACCENT.let { com.kupa.assistant.visual.Palette.withAlpha(it, 0.45f) } else Ui.EDGE)
        val pad = Ui.dp(context, 10)
        tv.setPadding(pad, pad, pad, pad)
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(context, 8)
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lp.marginStart = if (mine) Ui.dp(context, 40) else 0
        lp.marginEnd = if (mine) 0 else Ui.dp(context, 40)
        tv.layoutParams = lp
        tv.setTextIsSelectable(true)
        return tv
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val tv = Ui.text(context, label, 12f, Ui.TEXT)
        tv.background = Ui.rounded(context, Ui.CHIP, 10, Ui.EDGE)
        val p = Ui.dp(context, 8)
        tv.setPadding(p, Ui.dp(context, 4), p, Ui.dp(context, 4))
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.marginEnd = Ui.dp(context, 6)
        tv.layoutParams = lp
        tv.setOnClickListener { onClick() }
        return tv
    }

    /** Botões de feedback depois de uma resposta da IA: o perfil adaptativo aprende só com o que o usuário aperta. */
    private fun feedbackRow(): LinearLayout {
        val row = LinearLayout(context)
        row.orientation = HORIZONTAL
        val mode = app.modes.active()
        fun send(f: Feedback, message: String) {
            val current = app.profile.proactivity(mode?.id ?: "", mode?.proactivity, app.settings.proactivity)
            app.profile.record(f, mode?.id ?: "", current)
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }
        row.addView(chip("👍 útil") { send(Feedback.UP, "Anotado.") })
        row.addView(chip("👎 não útil") { send(Feedback.DOWN, "Anotado. Se isso se repetir, vou sugerir menos.") })
        row.addView(chip("mais curto") { send(Feedback.SHORTER, "Vou responder mais curto.") })
        row.addView(chip("mais detalhado") { send(Feedback.LONGER, "Vou detalhar mais.") })
        row.addView(chip("sem sugestões") { send(Feedback.NO_SUGGESTIONS, "Não vou mais sugerir nada neste modo.") })
        val lp = LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(context, 4)
        row.layoutParams = lp
        return row
    }

    private fun addExchange(e: KupaCore.Exchange) {
        if (e.question.isNotBlank()) list.addView(bubble(e.question, true))
        val sources = if (e.sources.isEmpty()) "" else "\n\nFontes: " + e.sources.joinToString(", ") { it.title.ifEmpty { it.url } }
        list.addView(bubble(e.answer + sources, false))
        if (e.question.isNotBlank() && e.type != HistoryType.ACTION && e.type != HistoryType.GAMER) list.addView(feedbackRow())
        scroll.post { scroll.fullScroll(FOCUS_DOWN) }
    }

    override fun onExchange(exchange: KupaCore.Exchange) = addExchange(exchange)

    override fun onProblem(message: String) {
        list.addView(bubble(message, false, error = true))
        scroll.post { scroll.fullScroll(FOCUS_DOWN) }
    }

    override fun onBubble(text: String?, isError: Boolean) {}
}
