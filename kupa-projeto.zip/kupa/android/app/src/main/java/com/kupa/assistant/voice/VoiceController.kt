package com.kupa.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.KupaState
import com.kupa.assistant.core.VoiceControl
import com.kupa.assistant.core.WakeWord
import com.kupa.assistant.settings.Settings

/**
 * Decide quando o microfone fica aberto e o que fazer com o que foi ouvido. DOIS MODOS:
 *  - "wake" (ativação por "Kupa"): escuta só a palavra de ativação; depois de "Kupa" ouve UM comando e volta a aguardar.
 *  - "continuous" (escuta contínua): cada frase é avaliada; vira ação só se for comando de celular reconhecido.
 * Cuidados com bateria e privacidade: só escuta quando o KUPA está em espera, pausa com a tela desligada (opcional),
 * pausa sozinho depois de um tempo sem comandos (modo contínuo) e pode ser pausado a qualquer momento.
 * Nunca finge que está ouvindo: se o Android não permitir, avisa o núcleo. Nenhum áudio vai ao backend do KUPA.
 */
class VoiceController(
    private val context: Context,
    private val settings: Settings,
    private val core: KupaCore,
) : VoiceControl {
    private enum class Mode { OFF, LISTEN, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private val input = SpeechInput(context)
    private var mode = Mode.OFF
    private var consecutiveFailures = 0
    private var restartScheduled = false
    private var unavailableReported = false
    private var destroyed = false
    private var paused = false
    private var screenOn = true
    private var offlineBroken = false
    private var lastActivityAt = SystemClock.elapsedRealtime()

    /** Avisado quando pausa/retoma (para atualizar a notificação). */
    var onStateChanged: (() -> Unit)? = null

    val isPaused: Boolean get() = paused
    val isContinuousMode: Boolean get() = settings.listenMode == "continuous"
    val isListeningLoop: Boolean get() = mode == Mode.LISTEN

    private fun hasMicPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun listenAllowed(): Boolean {
        if (destroyed || !settings.voiceEnabled || !settings.wakeListening || paused) return false
        if (settings.pauseWhenScreenOff && !screenOn) return false
        if (core.gamer.active && settings.gamerMicMode != "continuous") return false
        return core.states.current == KupaState.IDLE
    }

    private fun preferOffline(): Boolean = settings.preferOfflineRecognition && !offlineBroken

    // ------------------------------------------------------------------ controle externo

    /** Reavalia se deve estar escutando. Chame sempre que algo relevante mudar. */
    override fun refresh() {
        main.post { refreshNow() }
    }

    override fun noteActivity() {
        lastActivityAt = SystemClock.elapsedRealtime()
    }

    override fun isMicOpen(): Boolean = mode != Mode.OFF

    override fun pauseListening() = pause()

    override fun resumeListening() = resume()

    fun pause() {
        main.post {
            if (paused) return@post
            paused = true
            stopListening()
            KupaLog.i("voz", "escuta pausada")
            onStateChanged?.invoke()
        }
    }

    fun resume() {
        main.post {
            if (!paused) return@post
            paused = false
            lastActivityAt = SystemClock.elapsedRealtime()
            KupaLog.i("voz", "escuta retomada")
            onStateChanged?.invoke()
            refreshNow()
        }
    }

    fun togglePause() {
        if (paused) resume() else pause()
    }

    fun setScreenOn(on: Boolean) {
        main.post {
            screenOn = on
            if (!on && settings.pauseWhenScreenOff) stopListening() else refreshNow()
        }
    }

    private fun refreshNow() {
        if (destroyed) return
        if (mode == Mode.COMMAND) return
        if (!listenAllowed()) {
            if (mode == Mode.LISTEN) stopListening()
            return
        }
        if (!hasMicPermission()) {
            stopListening()
            return
        }
        if (mode != Mode.LISTEN) {
            mode = Mode.LISTEN
            consecutiveFailures = 0
            beginListenCycle()
        }
    }

    // ------------------------------------------------------------------ escuta contínua / por palavra-chave

    private fun idleExpired(): Boolean {
        if (!isContinuousMode) return false
        val limit = settings.continuousIdleMinutes
        if (limit <= 0) return false
        return SystemClock.elapsedRealtime() - lastActivityAt > limit * 60_000L
    }

    private fun beginListenCycle() {
        if (mode != Mode.LISTEN || destroyed) return
        if (idleExpired()) {
            paused = true
            stopListening()
            KupaLog.i("voz", "escuta contínua pausada por inatividade")
            core.announce("Pausei a escuta contínua para poupar bateria. Toque em Retomar na notificação do KUPA.")
            onStateChanged?.invoke()
            return
        }
        input.start(object : SpeechInput.Listener {
            override fun onReady() {}

            // Só o resultado final conta: assim sabemos se o comando veio junto ("Kupa, abra o WhatsApp").
            override fun onPartial(text: String) {}

            override fun onResult(alternatives: List<String>) {
                if (mode != Mode.LISTEN) return
                consecutiveFailures = 0
                if (isContinuousMode) {
                    val consumed = core.onContinuousSpeech(alternatives)
                    if (consumed) {
                        input.cancel()
                        mode = Mode.OFF
                    } else {
                        scheduleRestart(120)
                    }
                    return
                }
                for (alt in alternatives) {
                    val match = WakeWord.match(alt, settings.wakeAcceptVariants)
                    if (match != null) {
                        KupaLog.i("voz", "palavra de ativação detectada")
                        stopListening()
                        core.onWake(match.command)
                        return
                    }
                }
                scheduleRestart(150)
            }

            override fun onFailure(failure: SpeechInput.Failure) {
                if (mode != Mode.LISTEN) return
                when (failure) {
                    SpeechInput.Failure.NO_MATCH, SpeechInput.Failure.TIMEOUT -> {
                        consecutiveFailures = 0
                        scheduleRestart(200)
                    }
                    SpeechInput.Failure.LANGUAGE_UNAVAILABLE -> {
                        // o pacote de voz offline em português não está instalado: usa o reconhecimento normal do Android
                        offlineBroken = true
                        KupaLog.w("voz", "reconhecimento no aparelho indisponível; usando o padrão do Android")
                        scheduleRestart(200)
                    }
                    SpeechInput.Failure.PERMISSION -> {
                        stopListening()
                        core.reportProblem("Preciso da permissão do microfone para ouvir você.")
                    }
                    SpeechInput.Failure.NOT_AVAILABLE -> {
                        stopListening()
                        if (!unavailableReported) {
                            unavailableReported = true
                            core.reportProblem("O reconhecimento de voz não está disponível neste aparelho.")
                        }
                    }
                    else -> {
                        consecutiveFailures++
                        scheduleRestart(minOf(8000L, 600L * consecutiveFailures * consecutiveFailures))
                    }
                }
            }
        }, preferOffline())
    }

    private fun scheduleRestart(delayMs: Long) {
        if (restartScheduled) return
        restartScheduled = true
        main.postDelayed({
            restartScheduled = false
            if (mode == Mode.LISTEN && listenAllowed()) beginListenCycle() else if (mode == Mode.LISTEN) stopListening()
        }, delayMs)
    }

    // ------------------------------------------------------------------ um comando (depois de "Kupa", do botão Falar ou de uma pergunta)

    /** Abre o microfone para ouvir UM comando. */
    override fun startCommandListening() {
        main.post { startCommandNow() }
    }

    private fun startCommandNow() {
        if (destroyed) return
        stopListening()
        if (!settings.voiceEnabled) {
            core.onListenFailed(SpeechInput.Failure.NOT_AVAILABLE, "A voz está desativada. Ative a voz para falar comigo.")
            return
        }
        if (!hasMicPermission()) {
            core.onListenFailed(SpeechInput.Failure.PERMISSION, "Preciso da permissão do microfone.")
            return
        }
        mode = Mode.COMMAND
        input.start(object : SpeechInput.Listener {
            override fun onReady() {}
            override fun onPartial(text: String) {}

            override fun onResult(alternatives: List<String>) {
                if (mode != Mode.COMMAND) return
                mode = Mode.OFF
                // se o usuário repetiu "Kupa" no começo do comando, tira
                val cleaned = alternatives.map { alt ->
                    val again = WakeWord.match(alt, settings.wakeAcceptVariants)
                    if (again != null && again.command.isNotEmpty()) again.command else alt
                }
                core.onCommandHeard(cleaned)
            }

            override fun onFailure(failure: SpeechInput.Failure) {
                if (mode != Mode.COMMAND) return
                if (failure == SpeechInput.Failure.LANGUAGE_UNAVAILABLE) {
                    offlineBroken = true
                    startCommandNow()
                    return
                }
                mode = Mode.OFF
                core.onListenFailed(failure, null)
            }
        }, preferOffline())
    }

    private fun stopListening() {
        input.cancel()
        mode = Mode.OFF
    }

    override fun stopAll() {
        main.post { stopListening() }
    }

    fun destroy() {
        destroyed = true
        main.removeCallbacksAndMessages(null)
        stopListening()
    }
}
