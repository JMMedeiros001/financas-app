package com.kupa.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.KupaState
import com.kupa.assistant.core.VoiceControl
import com.kupa.assistant.core.WakeWord
import com.kupa.assistant.settings.Settings

/**
 * Decide quando o microfone fica aberto e o que fazer com o que foi ouvido:
 * - escuta contínua pela palavra "Kupa" (só quando o app está em espera e a voz está ativada);
 * - escuta do comando depois da ativação (ou ao tocar em "Falar").
 * Nunca finge que está ouvindo: se o Android não permitir, avisa o núcleo.
 */
class VoiceController(
    private val context: Context,
    private val settings: Settings,
    private val core: KupaCore,
) : VoiceControl {
    private enum class Mode { OFF, WAKE, COMMAND }

    private val main = Handler(Looper.getMainLooper())
    private val input = SpeechInput(context)
    private var mode = Mode.OFF
    private var consecutiveFailures = 0
    private var restartScheduled = false
    private var wakeUnavailableReported = false
    private var destroyed = false

    val isWakeActive: Boolean get() = mode == Mode.WAKE

    private fun hasMicPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun wakeAllowed(): Boolean {
        if (destroyed || !settings.voiceEnabled || !settings.wakeListening) return false
        if (core.gamer.active && settings.gamerMicMode != "continuous") return false
        return core.states.current == KupaState.IDLE
    }

    /** Reavalia se deve estar escutando a palavra de ativação. Chame sempre que algo relevante mudar. */
    override fun refresh() {
        main.post { refreshNow() }
    }

    private fun refreshNow() {
        if (destroyed) return
        if (mode == Mode.COMMAND) return
        if (!wakeAllowed()) {
            if (mode == Mode.WAKE) stopListening()
            return
        }
        if (!hasMicPermission()) {
            stopListening()
            return
        }
        if (mode != Mode.WAKE) {
            mode = Mode.WAKE
            consecutiveFailures = 0
            beginWakeCycle()
        }
    }

    private fun beginWakeCycle() {
        if (mode != Mode.WAKE || destroyed) return
        input.start(object : SpeechInput.Listener {
            override fun onReady() {}
            // Só o resultado final conta: assim sabemos se o comando veio junto ("Kupa, o que é DNA?").
            override fun onPartial(text: String) {}

            override fun onResult(alternatives: List<String>) {
                if (mode != Mode.WAKE) return
                consecutiveFailures = 0
                for (alt in alternatives) {
                    val match = WakeWord.match(alt, settings.wakeAcceptVariants)
                    if (match != null) {
                        KupaLog.i("voz", "palavra de ativação detectada")
                        stopListening()
                        core.onWake(match.command)
                        return
                    }
                }
                scheduleWakeRestart(150)
            }

            override fun onFailure(failure: SpeechInput.Failure) {
                if (mode != Mode.WAKE) return
                when (failure) {
                    SpeechInput.Failure.NO_MATCH, SpeechInput.Failure.TIMEOUT -> {
                        consecutiveFailures = 0
                        scheduleWakeRestart(200)
                    }
                    SpeechInput.Failure.PERMISSION -> {
                        stopListening()
                        core.reportProblem("Preciso da permissão do microfone para ouvir você.")
                    }
                    SpeechInput.Failure.NOT_AVAILABLE -> {
                        stopListening()
                        if (!wakeUnavailableReported) {
                            wakeUnavailableReported = true
                            core.reportProblem("O reconhecimento de voz não está disponível neste aparelho.")
                        }
                    }
                    else -> {
                        consecutiveFailures++
                        scheduleWakeRestart(minOf(8000L, 600L * consecutiveFailures * consecutiveFailures))
                    }
                }
            }
        })
    }

    private fun scheduleWakeRestart(delayMs: Long) {
        if (restartScheduled) return
        restartScheduled = true
        main.postDelayed({
            restartScheduled = false
            if (mode == Mode.WAKE && wakeAllowed()) beginWakeCycle() else if (mode == Mode.WAKE) stopListening()
        }, delayMs)
    }

    /** Abre o microfone para ouvir UM comando (depois de "Kupa" ou ao tocar em "Falar"). */
    override fun startCommandListening() {
        main.post { startCommandNow() }
    }

    private fun startCommandNow() {
        if (destroyed) return
        stopListening()
        if (!settings.voiceEnabled) {
            core.onListenFailed(SpeechInput.Failure.NOT_AVAILABLE, "A voz está desativada. Ative a voz para falar comigo.")
            return
        }
        if (!hasMicPermission()) {
            core.onListenFailed(SpeechInput.Failure.PERMISSION, "Preciso da permissão do microfone.")
            return
        }
        mode = Mode.COMMAND
        input.start(object : SpeechInput.Listener {
            override fun onReady() {}
            override fun onPartial(text: String) {}

            override fun onResult(alternatives: List<String>) {
                if (mode != Mode.COMMAND) return
                mode = Mode.OFF
                var text = alternatives[0]
                // se o usuário repetiu "Kupa" no começo do comando, tira
                val again = WakeWord.match(text, settings.wakeAcceptVariants)
                if (again != null && again.command.isNotEmpty()) text = again.command
                core.onCommandHeard(text)
            }

            override fun onFailure(failure: SpeechInput.Failure) {
                if (mode != Mode.COMMAND) return
                mode = Mode.OFF
                core.onListenFailed(failure, null)
            }
        })
    }

    private fun stopListening() {
        input.cancel()
        mode = Mode.OFF
    }

    override fun stopAll() {
        main.post { stopListening() }
    }

    fun destroy() {
        destroyed = true
        main.removeCallbacksAndMessages(null)
        stopListening()
    }
}
