package com.kupa.assistant.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.kupa.assistant.core.KupaCore
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.KupaState
import com.kupa.assistant.core.VoiceControl
import com.kupa.assistant.core.WakeWord
import com.kupa.assistant.settings.Settings

/**
 * Executa o que a [ListenMachine] manda. A máquina é a ÚNICA autoridade sobre "pode abrir o microfone agora?":
 * este controlador não decide nada sozinho, só traduz os passos dela em chamadas ao [SpeechInput].
 *
 * Por que isso existe (causas reais do "microfone ativando repetidamente", achadas no código anterior):
 *  1. Os erros BUSY/REDE/OUTRO reiniciavam a escuta PARA SEMPRE (espera de até 8 s, sem limite): agora há limite e estado ERROR.
 *  2. Callbacks e o temporizador de reinício só olhavam o "modo": um callback ou temporizador ANTIGO podia agir na sessão NOVA depois de
 *     desligar e ligar a palavra-chave. Agora cada início tem um token; tudo que não for do token atual é ignorado.
 *  3. O botão "Falar" com LANGUAGE_UNAVAILABLE reiniciava o comando sem limite: agora há uma única nova tentativa.
 *
 * DOIS MODOS de escuta:
 *  - "wake": escuta só a palavra de ativação; depois dela ouve UM comando e volta a aguardar.
 *  - "continuous": cada frase é avaliada; vira ação só se for comando de celular reconhecido.
 * Nenhum áudio vai ao backend do KUPA. Pausa com a tela desligada (opcional) e por inatividade (modo contínuo).
 */
class VoiceController(
    private val context: Context,
    private val settings: Settings,
    private val core: KupaCore,
) : VoiceControl {
    private val main = Handler(Looper.getMainLooper())
    private val input = SpeechInput(context)
    private val machine = ListenMachine()
    private var restartRunnable: Runnable? = null
    private var unavailableReported = false
    private var recognizerUnavailable = false
    private var errorReported = false
    private var destroyed = false
    private var paused = false
    private var screenOn = true
    private var offlineBroken = false
    private var lastWantedSeen = false
    private var lastActivityAt = SystemClock.elapsedRealtime()

    init {
        input.earcon = com.kupa.assistant.KupaApp.from(context).earcon
    }

    /** Avisado quando o estado da escuta muda (para atualizar notificação e telas). */
    var onStateChanged: (() -> Unit)? = null

    val isPaused: Boolean get() = paused
    val isContinuousMode: Boolean get() = settings.listenMode == "continuous"
    val isListeningLoop: Boolean get() = machine.state() == ListenMachine.State.LISTENING
    fun listenState(): ListenMachine.State = machine.state()

    private fun hasMicPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /** O que o USUÁRIO quer: voz ligada, palavra-chave habilitada e escuta não pausada. Vence qualquer recuperação. */
    private fun wanted(): Boolean = !destroyed && settings.voiceEnabled && settings.wakeListening && !paused

    /** Condições MOMENTÂNEAS (tela, jogo, assistente ocupado). Resolvidas, a escuta volta se a preferência continuar. */
    private fun allowedNow(): Boolean {
        if (settings.pauseWhenScreenOff && !screenOn) return false
        if (core.gamer.active && settings.gamerMicMode != "continuous") return false
        return core.states.current == KupaState.IDLE
    }

    private fun preferOffline(): Boolean = settings.preferOfflineRecognition && !offlineBroken

    // ------------------------------------------------------------------ o único caminho para mexer no microfone

    private fun reconcile() {
        if (destroyed) return
        val w = wanted()
        if (w && !lastWantedSeen) { // o usuário (re)ativou: erros antigos não valem mais
            recognizerUnavailable = false
            errorReported = false
            unavailableReported = false
        }
        lastWantedSeen = w
        perform(machine.reconcile(w, hasMicPermission(), !recognizerUnavailable, allowedNow()))
    }

    private fun perform(step: ListenMachine.Step) {
        if (step.cancelTimer) cancelTimer()
        when (step.cmd) {
            ListenMachine.Cmd.STOP -> input.cancel()
            ListenMachine.Cmd.START_WAKE -> startWakeCycle(step.token)
            ListenMachine.Cmd.START_COMMAND -> startCommandCycle(step.token)
            ListenMachine.Cmd.RESTART_LATER -> scheduleTimer(step.token, step.delayMs)
            else -> Unit
        }
        if (step.stateChanged()) {
            KupaLog.i("voz", "escuta: ${step.previous.name} -> ${step.state.name} (${step.reason})")
            onStateChanged?.invoke()
            if (step.state == ListenMachine.State.ERROR && !errorReported) {
                errorReported = true
                core.reportProblem("O microfone falhou várias vezes seguidas e eu parei de tentar. Toque em \"Tentar de novo\" na tela inicial.")
            }
        }
    }

    private fun cancelTimer() {
        restartRunnable?.let { main.removeCallbacks(it) }
        restartRunnable = null
    }

    private fun scheduleTimer(timerToken: Long, delayMs: Long) {
        cancelTimer()
        val r = Runnable {
            restartRunnable = null
            if (destroyed) return@Runnable
            perform(machine.onRestartTimer(timerToken, wanted(), hasMicPermission(), !recognizerUnavailable, allowedNow()))
        }
        restartRunnable = r
        main.postDelayed(r, delayMs)
    }

    // ------------------------------------------------------------------ controle externo

    /** Reavalia se deve estar escutando. Seguro chamar quantas vezes quiser: a máquina é idempotente. */
    override fun refresh() {
        main.post { reconcile() }
    }

    override fun noteActivity() {
        lastActivityAt = SystemClock.elapsedRealtime()
    }

    /** Verdadeiro SÓ quando o reconhecedor avisou que está ouvindo (ou um comando está sendo ouvido). */
    override fun isMicOpen(): Boolean = machine.micOpen()

    override fun pauseListening() = pause()

    override fun resumeListening() = resume()

    fun pause() {
        main.post {
            if (paused) return@post
            paused = true
            KupaLog.i("voz", "escuta pausada")
            reconcile()
            onStateChanged?.invoke()
        }
    }

    fun resume() {
        main.post {
            if (!paused) return@post
            paused = false
            lastActivityAt = SystemClock.elapsedRealtime()
            recognizerUnavailable = false
            KupaLog.i("voz", "escuta retomada")
            reconcile()
            onStateChanged?.invoke()
        }
    }

    fun togglePause() {
        if (paused) resume() else pause()
    }

    fun setScreenOn(on: Boolean) {
        main.post {
            screenOn = on
            reconcile()
        }
    }

    /** "Tentar de novo": ação MANUAL depois de um erro. Zera as falhas e cria no máximo uma nova sessão. */
    override fun retryNow() {
        main.post {
            if (destroyed) return@post
            recognizerUnavailable = false
            errorReported = false
            unavailableReported = false
            lastWantedSeen = wanted()
            perform(machine.manualRetry(wanted(), hasMicPermission(), !recognizerUnavailable, allowedNow()))
        }
    }

    override fun needsRetry(): Boolean {
        val s = machine.state()
        return wanted() && (s == ListenMachine.State.ERROR || s == ListenMachine.State.UNAVAILABLE)
    }

    /** Texto curto e VERDADEIRO sobre a escuta (preferência, permissão e uso real do microfone são coisas diferentes). */
    override fun statusText(): String {
        val s = machine.state()
        if (s == ListenMachine.State.COMMAND) return "Ouvindo um comando agora."
        if (!settings.voiceEnabled) return "A voz está desativada nas configurações."
        if (!settings.wakeListening) return "Palavra-chave DESATIVADA. Microfone fechado. O botão Falar continua disponível."
        if (paused) return "Escuta PAUSADA por você. Toque em Retomar."
        return when (s) {
            ListenMachine.State.LISTENING -> "Ouvindo a palavra de ativação (microfone em uso)."
            ListenMachine.State.STARTING -> "Iniciando a escuta…"
            ListenMachine.State.WAITING_PERMISSION -> "Palavra-chave ligada, mas falta a permissão do microfone."
            ListenMachine.State.UNAVAILABLE -> "Reconhecimento de voz indisponível neste aparelho."
            ListenMachine.State.SUSPENDED -> "Escuta suspensa por enquanto (${machine.reason()}). Volta sozinha quando der."
            ListenMachine.State.ERROR -> "A escuta falhou várias vezes e parou. Toque em Tentar de novo."
            ListenMachine.State.STOPPING -> "Encerrando a escuta…"
            else -> "Palavra-chave ligada; aguardando para iniciar."
        }
    }

    // ------------------------------------------------------------------ escuta contínua / por palavra-chave

    private fun idleExpired(): Boolean {
        if (!isContinuousMode) return false
        val limit = settings.continuousIdleMinutes
        if (limit <= 0) return false
        return SystemClock.elapsedRealtime() - lastActivityAt > limit * 60_000L
    }

    private fun startWakeCycle(token: Long) {
        if (idleExpired()) {
            paused = true
            KupaLog.i("voz", "escuta contínua pausada por inatividade")
            core.announce("Pausei a escuta contínua para poupar bateria. Toque em Retomar na notificação do KUPA.")
            reconcile() // agora wanted() é falso: a máquina para tudo
            onStateChanged?.invoke()
            return
        }
        input.start(object : SpeechInput.Listener {
            override fun onReady() {
                perform(machine.onReady(token))
            }

            // Só o resultado final conta: assim sabemos se o comando veio junto ("Kupa, abra o WhatsApp").
            override fun onPartial(text: String) {}

            override fun onResult(alternatives: List<String>) {
                if (!machine.isCurrentWake(token)) return // callback de uma sessão antiga: ignorado
                if (isContinuousMode) {
                    val consumed = core.onContinuousSpeech(alternatives)
                    if (consumed) {
                        perform(machine.onWakeDetected(token))
                    } else {
                        perform(machine.onCycleEnd(token, ListenMachine.Outcome.HEARD_NO_WAKE))
                    }
                    return
                }
                for (alt in alternatives) {
                    val match = WakeWord.match(alt, settings.wakeAcceptVariants)
                    if (match != null) {
                        KupaLog.i("voz", "palavra de ativação detectada")
                        perform(machine.onWakeDetected(token)) // o detector entrega o microfone antes do comando
                        core.onWake(match.command)
                        return
                    }
                }
                alternatives.firstOrNull()?.let { WakeWord.noteMiss(it) } // só pode virar SUGESTÃO; nada é salvo sem você confirmar
                perform(machine.onCycleEnd(token, ListenMachine.Outcome.HEARD_NO_WAKE))
            }

            override fun onFailure(failure: SpeechInput.Failure) {
                if (!machine.isCurrentWake(token)) return // erro de uma sessão antiga NÃO reinicia nada
                val outcome = when (failure) {
                    SpeechInput.Failure.NO_MATCH, SpeechInput.Failure.TIMEOUT -> ListenMachine.Outcome.NO_SPEECH
                    SpeechInput.Failure.LANGUAGE_UNAVAILABLE -> {
                        if (!offlineBroken) {
                            // o pacote de voz offline em português não está instalado: usa o reconhecimento normal do Android
                            offlineBroken = true
                            KupaLog.w("voz", "reconhecimento no aparelho indisponível; usando o padrão do Android")
                            ListenMachine.Outcome.NO_SPEECH
                        } else {
                            ListenMachine.Outcome.FAIL_RECOVERABLE
                        }
                    }
                    SpeechInput.Failure.PERMISSION -> {
                        core.reportProblem("Preciso da permissão do microfone para ouvir você.")
                        ListenMachine.Outcome.FAIL_PERMISSION
                    }
                    SpeechInput.Failure.NOT_AVAILABLE -> {
                        recognizerUnavailable = true
                        if (!unavailableReported) {
                            unavailableReported = true
                            core.reportProblem("O reconhecimento de voz não está disponível neste aparelho.")
                        }
                        ListenMachine.Outcome.FAIL_UNAVAILABLE
                    }
                    else -> ListenMachine.Outcome.FAIL_RECOVERABLE // ocupado, rede ou outro: recuperação LIMITADA pela máquina
                }
                perform(machine.onCycleEnd(token, outcome))
            }
        }, preferOffline())
    }

    // ------------------------------------------------------------------ um comando (depois da palavra, do botão Falar ou de uma pergunta)

    /** Abre o microfone para ouvir UM comando. Substitui a escuta da palavra-chave; nunca coexiste com ela. */
    override fun startCommandListening() {
        main.post { startCommandNow() }
    }

    private fun startCommandNow() {
        if (destroyed) return
        if (!settings.voiceEnabled) {
            core.onListenFailed(SpeechInput.Failure.NOT_AVAILABLE, "A voz está desativada. Ative a voz para falar comigo.")
            return
        }
        if (!hasMicPermission()) {
            core.onListenFailed(SpeechInput.Failure.PERMISSION, "Preciso da permissão do microfone.")
            return
        }
        perform(machine.beginCommand(true, true))
    }

    private fun startCommandCycle(token: Long) {
        input.start(object : SpeechInput.Listener {
            override fun onReady() {}
            override fun onPartial(text: String) {}

            override fun onResult(alternatives: List<String>) {
                if (!machine.isCurrentCommand(token)) return
                perform(machine.onCommandEnd(token))
                // se o usuário repetiu a palavra de ativação no começo do comando, tira
                val cleaned = alternatives.map { alt ->
                    val again = WakeWord.match(alt, settings.wakeAcceptVariants)
                    if (again != null && again.command.isNotEmpty()) again.command else alt
                }
                core.onCommandHeard(cleaned)
                refresh() // se a palavra-chave continuar habilitada e o assistente voltar ao repouso, a escuta retoma
            }

            override fun onFailure(failure: SpeechInput.Failure) {
                if (!machine.isCurrentCommand(token)) return
                if (failure == SpeechInput.Failure.LANGUAGE_UNAVAILABLE && !offlineBroken) {
                    // UMA nova tentativa sem o reconhecimento no aparelho (antes isto podia repetir para sempre)
                    offlineBroken = true
                    perform(machine.onCommandEnd(token))
                    perform(machine.beginCommand(true, true))
                    return
                }
                perform(machine.onCommandEnd(token))
                core.onListenFailed(failure, null)
                refresh()
            }
        }, preferOffline())
    }

    /** Para qualquer escuta e invalida callbacks e temporizadores, SEM mudar a preferência (usado pelo "parar tudo"). */
    override fun stopAll() {
        main.post { perform(machine.suspend("parada pelo assistente")) }
    }

    fun destroy() {
        destroyed = true
        onStateChanged = null
        main.removeCallbacksAndMessages(null)
        restartRunnable = null
        perform(machine.suspend("encerrando"))
        perform(machine.reconcile(false, false, false, false)) // wanted=false: DISABLED, sessão e temporizador invalidados
        input.cancel()
        com.kupa.assistant.KupaApp.from(context).earcon.release() // nunca deixa o canal de mídia mudo ao encerrar
    }
}
