package com.kupa.assistant.core

/**
 * Só decide qual estado VISUAL mostrar enquanto a IA pensa (o app não recebe eventos em tempo real da busca).
 * A funcionalidade em si (buscar, traduzir, ler) é decidida pela IA e pelas ferramentas, não por esta lista.
 */
object VisualIntent {
    fun stateWhileThinking(text: String, searchLikely: Boolean): KupaState {
        val t = foldText(text)
        if (t.contains("traduz") || t.contains("traducao") || t.contains("em ingles") || t.contains("em portugues")) return KupaState.TRANSLATING
        if (t.contains("leia") || t.contains("ler ") || t.contains("le isso") || t.contains("o que esta escrito") || t.contains("o que ta escrito")) return KupaState.READING
        if (searchLikely) return KupaState.SEARCHING
        return KupaState.THINKING
    }

    fun looksLikeSearch(text: String): Boolean {
        val t = foldText(text)
        val hints = listOf("pesquis", "procur", "busca", "noticia", "hoje", "agora", "quanto custa", "preco", "ultima", "atual", "quem ganhou", "resultado")
        return hints.any { t.contains(it) }
    }
}
