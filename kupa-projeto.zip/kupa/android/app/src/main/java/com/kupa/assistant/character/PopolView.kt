package com.kupa.assistant.character

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import com.kupa.assistant.core.KupaLog
import com.kupa.assistant.core.KupaState
import com.kupa.assistant.core.StateManager

/**
 * Personagem na tela: POPOL_CHARACTER + KUPA_WOLF como camadas separadas, cada uma com seu controlador.
 * Hoje os sprites trazem Popol e Kupa juntos, então só a camada do Popol aparece e anima o conjunto.
 * Quando existirem os arquivos popol_* e kupa_* (ver SpriteRepository), a camada do Kupa liga sozinha.
 */
class PopolView(context: Context, private val sprites: SpriteRepository) : FrameLayout(context) {
    private val stage = FrameLayout(context)
    private val imageA = newImage()
    private val imageB = newImage()
    private val kupaView = newImage()
    private var frontIsA = true
    private var shown: KupaState? = null
    private var animationsEnabled = true
    private var running = false
    private var boundStates: StateManager? = null

    val popolAnimator = PopolAnimationController()
    val kupaAnimator = KupaAnimationController()

    /** Avisado quando nenhum visual pôde ser carregado (erro de carregamento do Popol). */
    var onLoadError: (() -> Unit)? = null

    private val stateListener = StateManager.Listener { _, current -> show(current) }

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            popolAnimator.tick(now)
            if (kupaView.visibility == View.VISIBLE) kupaAnimator.tick(now)
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    init {
        clipChildren = false
        clipToPadding = false
        stage.clipChildren = false
        stage.addView(imageB, matchParent())
        stage.addView(imageA, matchParent())
        addView(stage, matchParent())
        kupaView.visibility = View.GONE
        addView(kupaView, matchParent())
        popolAnimator.attach(stage)
        kupaAnimator.attach(kupaView)
    }

    private fun newImage(): ImageView {
        val v = ImageView(context)
        v.scaleType = ImageView.ScaleType.FIT_CENTER
        v.isClickable = false
        return v
    }

    private fun matchParent() = LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    /** Liga o personagem ao StateManager: ele passa a acompanhar os estados sozinho. */
    fun bindTo(states: StateManager) {
        boundStates?.removeListener(stateListener)
        boundStates = states
        states.addListener(stateListener)
        show(states.current)
    }

    fun setAnimationsEnabled(enabled: Boolean) {
        animationsEnabled = enabled
        popolAnimator.setEnabled(enabled)
        kupaAnimator.setEnabled(enabled)
        updateRunning()
    }

    /** Mostra o estado: troca o visual (com fade curto) e manda cada controlador tocar sua animação. */
    fun show(state: KupaState) {
        val loaded = sprites.forState(state)
        if (loaded == null) {
            showFallback()
            onLoadError?.invoke()
            return
        }
        val first = shown == null
        shown = state
        swapPopol(loaded.popol, animate = animationsEnabled && !first)
        if (loaded.kupa != null) {
            kupaView.setImageBitmap(loaded.kupa)
            kupaView.visibility = View.VISIBLE
        } else {
            kupaView.visibility = View.GONE
        }
        val anim = StateAnimations.forState(state)
        popolAnimator.play(anim.popol)
        if (loaded.kupa != null) kupaAnimator.play(anim.kupa)
    }

    private fun swapPopol(bitmap: Bitmap, animate: Boolean) {
        val incoming = if (frontIsA) imageB else imageA
        val outgoing = if (frontIsA) imageA else imageB
        incoming.animate().cancel()
        outgoing.animate().cancel()
        incoming.setImageBitmap(bitmap)
        stage.bringChildToFront(incoming)
        frontIsA = !frontIsA
        if (animate) {
            incoming.alpha = 0f
            incoming.animate().alpha(1f).setDuration(130).withEndAction {
                outgoing.setImageDrawable(null)
            }.start()
        } else {
            incoming.alpha = 1f
            outgoing.setImageDrawable(null)
        }
    }

    private fun showFallback() {
        val circle = GradientDrawable()
        circle.shape = GradientDrawable.OVAL
        circle.setColor(0xFF7C8CFF.toInt())
        imageA.setImageDrawable(circle)
        imageA.alpha = 1f
        imageB.setImageDrawable(null)
        kupaView.visibility = View.GONE
        KupaLog.e("sprites", "nenhum visual do Popol pôde ser carregado")
    }

    // ------------------------------------------------------------------ ciclo de vida da animação

    private fun updateRunning() {
        val shouldRun = animationsEnabled && isAttachedToWindow && windowVisibility == View.VISIBLE && visibility == View.VISIBLE
        if (shouldRun && !running) {
            running = true
            Choreographer.getInstance().postFrameCallback(frameCallback)
        } else if (!shouldRun && running) {
            running = false
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        boundStates?.let {
            it.removeListener(stateListener)
            it.addListener(stateListener)
            show(it.current)
        }
        updateRunning()
    }

    override fun onDetachedFromWindow() {
        boundStates?.removeListener(stateListener)
        running = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        updateRunning()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (changedView === this) updateRunning()
    }

    companion object {
        /** Proporção dos sprites padronizados (640 x 720). */
        const val ASPECT_HEIGHT_OVER_WIDTH = 720f / 640f
    }
}
