package com.kupa.assistant.voice;

/**
 * Arquitetura PREPARATÓRIA para reconhecimento de falante. HOJE NÃO EXISTE mecanismo real integrado: o Android não oferece
 * verificação de falante nas APIs oficiais e nenhum modelo foi embarcado. Por isso a única implementação é {@link UnavailableSpeakerVerifier}.
 * Nenhum resultado desta camada concede permissão: a política de segurança trata voz como NÃO verificada em qualquer caso.
 */
public final class VoiceVerification {
    private VoiceVerification() {}

    /** Resultados possíveis, sem falsa certeza. */
    public enum Result {
        /** Há um mecanismo real e a voz provavelmente é de um perfil cadastrado (nunca certeza, nunca autenticação). */
        PROBABLE_MATCH,
        NOT_RECOGNIZED,
        INSUFFICIENT_SAMPLE,
        INCONCLUSIVE,
        /** Não há mecanismo real de verificação neste aparelho/app. */
        UNAVAILABLE,
        TECHNICAL_FAILURE
    }

    public interface SpeakerVerifier {
        /** O mecanismo é real e está pronto? */
        boolean isAvailable();

        /** Explica o estado em português (por que está indisponível, ou qual tecnologia é usada). */
        String describe();

        /** Compara uma amostra de voz com os perfis cadastrados. Nunca devolve certeza. */
        Result verify(byte[] pcm16Mono16k);
    }

    /** Estado real hoje: indisponível. Sempre diz isso; nunca finge reconhecer ninguém. */
    public static final class UnavailableSpeakerVerifier implements SpeakerVerifier {
        @Override public boolean isAvailable() { return false; }

        @Override public String describe() {
            return "Reconhecimento de falante INDISPONÍVEL: o Android não tem API oficial para isso e nenhum modelo de verificação de falante foi integrado. "
                + "O reconhecimento de fala (texto) funciona, mas ele não identifica quem está falando. Veja docs/AVALIACAO_RECONHECIMENTO_DE_FALANTE.md.";
        }

        @Override public Result verify(byte[] pcm16Mono16k) { return Result.UNAVAILABLE; }
    }

    /**
     * Regra fixa de segurança: o que a verificação de voz PODE influenciar. Hoje nada concede permissão.
     * Mesmo com um mecanismo real no futuro, só PROBABLE_MATCH com mecanismo disponível poderia ser um sinal ADICIONAL;
     * jamais substitui confirmação, autenticação do aparelho nem o bloqueio de ações HIGH/CRITICAL.
     */
    public static boolean grantsAnyPermission(Result r) {
        return false;
    }

    /** Resultado que o app mostra/registra quando alguém tenta usar a voz como autorização. */
    public static String explain(Result r) {
        switch (r) {
            case PROBABLE_MATCH: return "Voz provavelmente de um perfil cadastrado (isto não é autenticação).";
            case NOT_RECOGNIZED: return "Voz não reconhecida.";
            case INSUFFICIENT_SAMPLE: return "Amostra de voz insuficiente.";
            case INCONCLUSIVE: return "Verificação inconclusiva.";
            case TECHNICAL_FAILURE: return "Falha técnica na verificação.";
            default: return "Verificação de falante indisponível.";
        }
    }
}
