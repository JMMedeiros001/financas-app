package com.kupa.assistant.security;

import com.kupa.assistant.intent.TextNorm;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Procura, em texto NÃO confiável, ordens do tipo "ignore suas regras". Ajuda a bloquear; não é a única defesa. */
public final class InjectionDetector {
    private InjectionDetector() {}

    private static final String[][] RULES = {
        {"ignorar_regras", "(ignore|ignora|ignorar|esqueca|esqueça|desconsidere|desconsidera|desobedeca|desobedeça) (todas )?(as |suas |tuas |seus |teus |os |todos os )?(regras|instrucoes|instruções|politicas|políticas|restricoes|restrições|limites)"},
        {"ignore_prev", "(ignore|disregard|forget) (all |any |the )?(previous|prior|above|your|system) (instructions|rules|prompts?)"},
        {"desativar_seguranca", "(desativ|desligu|desabilit|burl|contorn)[a-z]* (a |o |as |os )?(seguranca|segurança|protecao|proteção|confirmacao|confirmação|filtros?|regras)"},
        {"disable_security", "(disable|turn off|bypass|override) (the |your )?(security|safety|guardrails|rules|filters|confirmation)"},
        {"novo_papel", "(voce|você) (agora )?(e|é|sera|será) (um |uma )?(outro|outra|novo|nova|sem restric|dan\\b)"},
        {"revelar_prompt", "(revele|mostre|exiba|reveal|show|print) (o |seu |sua |your |the )?(system )?(prompt|instrucoes|instruções) (do sistema|inicial|secreto)?"},
        {"pedir_credencial", "(envie|mande|diga|digite|passe|send|give|tell) (me |nos )?((a|o|sua|seu|minha|meu|the|your) )*(senha|password|token|api ?key|chave secreta|codigo de verificacao|código de verificação|cvv)"},
        {"executar_sem_confirmar", "\\bsem (pedir |solicitar |perguntar|precisar de )?((a|sua|qualquer) )?(confirmacao|confirmação|permissao|permissão|autorizacao|autorização|perguntar)"},
        {"modo_dev", "(modo|mode) (desenvolvedor|developer|deus|god|sem restric)"},
    };

    private static final List<Pattern> COMPILED = new ArrayList<>();
    private static final List<String> NAMES = new ArrayList<>();

    static {
        for (String[] r : RULES) {
            NAMES.add(r[0]);
            COMPILED.add(Pattern.compile(r[1], Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE));
        }
    }

    public static final class Result {
        public final boolean suspected;
        public final List<String> patterns;

        Result(List<String> patterns) {
            this.patterns = patterns;
            this.suspected = !patterns.isEmpty();
        }
    }

    private static final Pattern COMPLIANCE = Pattern.compile(
        "(desativei|desliguei|ignorei|contornei|burlei|removi|apaguei) (a |as |minha |minhas |todas as |todos os )?(seguranca|segurança|regras|protecao|proteção|confirmacao|confirmação|restricoes|restrições|limites)"
            + "|modo (desenvolvedor|deus|sem restricoes|sem restrições) (ativado|ligado|liberado)",
        Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    /** A RESPOSTA da IA diz que desativou/ignorou as regras? (Ela não tem esse poder: é falso e o usuário precisa saber.) */
    public static boolean claimsToHaveBypassedRules(String answer) {
        if (answer == null || answer.isEmpty()) return false;
        return COMPLIANCE.matcher(answer).find() || COMPLIANCE.matcher(TextNorm.fold(answer)).find();
    }

    public static Result scan(String text) {
        List<String> found = new ArrayList<>();
        if (text == null || text.isEmpty()) return new Result(found);
        String folded = TextNorm.fold(text);
        for (int i = 0; i < COMPILED.size(); i++) {
            if (COMPILED.get(i).matcher(text).find() || COMPILED.get(i).matcher(folded).find()) found.add(NAMES.get(i));
        }
        return new Result(found);
    }
}
