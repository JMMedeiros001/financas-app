package com.kupa.assistant.security;

/** Gravidade possível de uma ação (da menos para a mais perigosa; a ordem importa). */
public enum RiskLevel {
    NONE, LOW, MEDIUM, HIGH, CRITICAL;

    public RiskLevel raised() {
        return this == CRITICAL ? CRITICAL : values()[ordinal() + 1];
    }

    public boolean atLeast(RiskLevel other) {
        return ordinal() >= other.ordinal();
    }

    public static RiskLevel max(RiskLevel a, RiskLevel b) {
        return a.ordinal() >= b.ordinal() ? a : b;
    }
}
