# Regras R8 do RELEASE do KUPA.
# O app não usa reflexão nem bibliotecas de terceiros. Os visuais são carregados por NOME (resources.getIdentifier),
# por isso os recursos drawable são mantidos em res/raw/keep.xml.
-keep class com.kupa.assistant.BuildConfig { *; }
-dontwarn javax.annotation.**
