import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ---------------------------------------------------------------------------------------------
// URL do backend (público, NÃO é segredo). Ordem de prioridade:
//   1) -PKUPA_BACKEND_URL=...   2) variável de ambiente KUPA_BACKEND_URL   3) android/kupa.properties
// Só para desenvolvimento local (debug), e sem ir para o GitHub:
//   KUPA_BACKEND_URL_DEV em android/kupa.local.properties (ou variável de ambiente).
// NUNCA coloque a chave da OpenAI aqui.
// ---------------------------------------------------------------------------------------------
fun readProps(file: File): Properties {
    val p = Properties()
    if (file.exists()) file.inputStream().use { p.load(it) }
    return p
}

fun configValue(name: String, vararg files: File): String {
    val fromGradle = (project.findProperty(name) as String?)?.trim().orEmpty()
    if (fromGradle.isNotEmpty()) return fromGradle
    val fromEnv = System.getenv(name)?.trim().orEmpty()
    if (fromEnv.isNotEmpty()) return fromEnv
    for (f in files) {
        val v = readProps(f).getProperty(name)?.trim().orEmpty()
        if (v.isNotEmpty()) return v
    }
    return ""
}

fun checkedUrl(name: String, value: String): String {
    val url = value.trim().trimEnd('/')
    if (url.isEmpty()) return ""
    val ok = (url.startsWith("https://") || url.startsWith("http://")) && url.length > 9 && !url.contains(" ") && !url.contains("SEU-")
    if (!ok) {
        throw GradleException("$name inválida: \"$value\". Use uma URL completa começando com https:// (veja README_BACKEND.md).")
    }
    return url
}

val kupaProdUrl = checkedUrl("KUPA_BACKEND_URL", configValue("KUPA_BACKEND_URL", rootProject.file("kupa.properties")))
val kupaDevUrl = checkedUrl("KUPA_BACKEND_URL_DEV", configValue("KUPA_BACKEND_URL_DEV", rootProject.file("kupa.local.properties")))
if (kupaProdUrl.isEmpty()) {
    logger.warn("KUPA: KUPA_BACKEND_URL não está definida. O APK será gerado SEM URL do backend e o app avisará isso. Defina em android/kupa.properties (veja README_BACKEND.md).")
}

android {
    namespace = "com.kupa.assistant"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.kupa.assistant"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        buildConfigField("String", "KUPA_BACKEND_URL", "\"$kupaProdUrl\"")
        buildConfigField("boolean", "KUPA_BACKEND_URL_IS_DEV", "false")
    }

    buildFeatures {
        buildConfig = true
    }

    // Assinatura do RELEASE: SÓ por variáveis de ambiente (nada de chave/senha no repositório).
    //   KUPA_KEYSTORE_PATH, KUPA_KEYSTORE_PASSWORD, KUPA_KEY_ALIAS, KUPA_KEY_PASSWORD
    val keystorePath = System.getenv("KUPA_KEYSTORE_PATH").orEmpty()
    val releaseSigned = keystorePath.isNotEmpty() && File(keystorePath).exists() &&
        System.getenv("KUPA_KEYSTORE_PASSWORD") != null && System.getenv("KUPA_KEY_ALIAS") != null
    signingConfigs {
        if (releaseSigned) {
            create("release") {
                storeFile = File(keystorePath)
                storePassword = System.getenv("KUPA_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KUPA_KEY_ALIAS")
                keyPassword = System.getenv("KUPA_KEY_PASSWORD") ?: System.getenv("KUPA_KEYSTORE_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            // Só quando KUPA_BACKEND_URL_DEV existir (máquina do desenvolvedor). No GitHub Actions usa a de produção.
            if (kupaDevUrl.isNotEmpty()) {
                buildConfigField("String", "KUPA_BACKEND_URL", "\"$kupaDevUrl\"")
                buildConfigField("boolean", "KUPA_BACKEND_URL_IS_DEV", "true")
            }
        }
        release {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (releaseSigned) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sem dependências externas de propósito: menos coisa para quebrar na compilação.
dependencies {
}
