# Backend do KUPA — instalar, testar e publicar

O backend (Node.js, **sem dependências**) guarda a chave da OpenAI e conversa com a **API oficial da OpenAI**
(Responses API) em nome do app. O app Android só fala com ele; a chave nunca vai para o APK, o GitHub ou o Android.

```
KUPA Android ──HTTPS──▶ backend KUPA ──▶ API da OpenAI ──▶ backend ──▶ KUPA Android
```

## Endpoints reais (já existentes no código)

| Método e caminho | Login | Para quê |
|---|---|---|
| `GET /health` | não | health check: `{"status":"ok","ok":true,"service":"kupa-backend",...}` (sem segredos) |
| `GET /v1/config` | sim | provedor, modelo e se a chave está configurada (**nunca** mostra a chave) |
| `POST /v1/ai/test` | sim | faz uma chamada **de verdade** à OpenAI ("responda apenas: conexão funcionando") |
| `POST /v1/ai/respond` | sim | **conversa com a IA** (histórico, imagem, ferramentas) |

"Login" = cabeçalho `Authorization: Bearer <KUPA_APP_TOKEN>`.
CORS não é configurado de propósito: o app é nativo (não é um navegador) e CORS só serve para páginas web.

## 1. Instalar dependências

Só precisa de **Node.js 20 ou mais novo**. Não há pacotes para instalar (`npm install` não baixa nada).

```bash
cd backend
node --version     # deve ser v20 ou maior
```

## 2. Configurar a chave da OpenAI (variáveis de ambiente)

```bash
cp .env.example .env     # o arquivo .env está no .gitignore e NUNCA deve ir para o GitHub
```

Edite o `.env`:

| Variável | Obrigatória | Para quê |
|---|---|---|
| `OPENAI_API_KEY` | **sim** | chave secreta da OpenAI (só existe no backend) |
| `OPENAI_MODEL` | **sim** | nome do modelo. Sem valor padrão de propósito; use um modelo atual da documentação oficial que aceite imagem e busca na web |
| `KUPA_APP_TOKEN` | **sim** | senha entre o app e o backend. Gere: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"` |
| `PORT` | não | porta (o Render/Railway definem sozinhos; padrão 8787) |
| demais | não | veja os comentários do `.env.example` (timeout, limites, busca na web…) |

Sem `OPENAI_API_KEY` ou `OPENAI_MODEL` o servidor liga normalmente e responde **erro claro** (503) nas rotas de IA; ele não finge que funciona.

## 3. Rodar localmente

```bash
cd backend
npm test     # 26 testes automáticos (usam um servidor OpenAI falso SÓ nos testes)
npm start    # escuta em http://localhost:8787
```

## 4. Testar o health check

```bash
curl http://localhost:8787/health
# {"status":"ok","ok":true,"service":"kupa-backend","version":"0.1.0","uptimeSeconds":3}
```

## 5. Testar a IA de verdade (gasta uma chamada pequena da OpenAI)

```bash
TOKEN="o mesmo valor de KUPA_APP_TOKEN"

# diagnóstico: o backend pergunta algo real à OpenAI
curl -X POST -H "Authorization: Bearer $TOKEN" http://localhost:8787/v1/ai/test

# conversa
curl -X POST http://localhost:8787/v1/ai/respond \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","text":"O que é fotossíntese?"}],"options":{"language":"pt-BR"}}'
# {"status":"final","text":"...","sources":[],"webSearchUsed":false,"model":"..."}
```

Erros possíveis (sempre JSON `{"error":{"code","message"}}`): `401` token errado · `400` pedido inválido · `413` corpo grande ·
`429` limite · `503` chave/modelo não configurados · `502` problema na OpenAI (chave recusada, modelo inexistente, indisponível) · `504` timeout.

## 6. Publicar (Render ou Railway)

### Render (mais simples: já existe o `render.yaml` na raiz)
1. Suba este repositório para o GitHub (sem o `.env`).
2. No Render: **New → Blueprint**, escolha o repositório. Ele lê o `render.yaml`.
3. Quando pedir, preencha **`OPENAI_API_KEY`** e **`OPENAI_MODEL`**. O **`KUPA_APP_TOKEN`** o Render gera sozinho.
4. Aguarde o deploy ficar verde (o Render usa `/health` como verificação).

### Railway
1. New Project → Deploy from GitHub repo → **Root Directory = `backend`**.
2. Em Variables: `OPENAI_API_KEY`, `OPENAI_MODEL`, `KUPA_APP_TOKEN` (valor aleatório longo).
3. Start command: `npm start`. Em Settings → Networking, gere o domínio público.

HTTPS: as duas plataformas colocam HTTPS na frente automaticamente; o backend roda em HTTP atrás delas (normal).
Plano gratuito do Render "dorme" sem uso: a primeira chamada depois de um tempo parado pode levar ~1 minuto (o app espera até 25 s para conectar; use plano pago para ficar sempre ligado).

## 7. Variáveis a configurar no serviço

Obrigatórias: `OPENAI_API_KEY`, `OPENAI_MODEL`, `KUPA_APP_TOKEN`. O resto é opcional.

## 8. Como obter a URL pública

Render: página do serviço → no topo aparece algo como `https://<nome-do-servico>.onrender.com`.
Railway: Settings → Networking → domínio gerado. Confirme abrindo `<URL>/health` no navegador: deve mostrar `{"status":"ok",...}`.

## 9. Onde colocar a URL no Android (único ponto)

Arquivo **`android/kupa.properties`**:

```properties
KUPA_BACKEND_URL=https://a-url-real-do-seu-servico
```

(Não invente a URL: use a que apareceu no passo 8.) Alternativas sem editar o arquivo: variável de ambiente `KUPA_BACKEND_URL`
ou `-PKUPA_BACKEND_URL=...` no Gradle. Para testar no seu computador/rede local sem mexer na de produção:
`KUPA_BACKEND_URL_DEV=http://192.168.0.10:8787` em `android/kupa.local.properties` (ignorado pelo Git; vale só para builds *debug* locais).

O **token** (`KUPA_APP_TOKEN`) **não** vai no APK: abra o app → Configurações → Diagnóstico da IA → cole o token → *Salvar e verificar* → *TESTAR CONEXÃO COM A IA*.
No Render, o token está em: serviço → Environment → `KUPA_APP_TOKEN`.

Se a URL não estiver definida o app mostra: "Este APK foi gerado sem a URL do backend…" (e não tenta nada às cegas).

## 10. Gerar o APK de novo

Depois de editar `android/kupa.properties`, faça commit e push: o GitHub Actions gera de novo
`android/app/build/outputs/apk/debug/app-debug.apk`. Localmente: `cd android && gradle assembleDebug`.
(Opcional: no workflow, `env: KUPA_BACKEND_URL: ${{ vars.KUPA_BACKEND_URL }}` define a URL sem editar arquivos.)

## Segurança (resumo honesto)

- A chave da OpenAI só existe no backend (variável de ambiente). Os logs removem chaves e tokens.
- O `KUPA_APP_TOKEN` fica no aparelho (digitado por você), não no APK. Mesmo assim ele é uma senha compartilhada simples: serve para uso pessoal.
- Defina um **limite de gasto** na sua conta da OpenAI.
