# KUPA — assistente pessoal com o Popol e o lobo Kupa

Aplicativo Android (prioridade) + backend seguro. A IA vem da **API oficial da OpenAI** (Responses API), sempre pelo
backend: **a chave da OpenAI nunca vai para o app**.

> **Estado honesto deste projeto (leia primeiro):**
>
> | Parte | Situação |
> |---|---|
> | Backend (Node) | **Escrito e testado**: 53 testes automáticos passam, **todos contra servidores SIMULADOS** (OpenAI, Claude e Gemini falsos que imitam o formato documentado). **Nenhuma chamada real a provedor de IA foi feita** (sem chaves e sem rede neste ambiente). Pronto para Render/Railway (`render.yaml`, `README_BACKEND.md`). **Não está hospedado**: não existe URL pública. |
> | Camadas em Java puro (intenções, segurança, privacidade, URL do backend, falhas de rede, nome de ativação, verificação de voz, **ciclo de vida do microfone**, botão antibaip, desempenho) | **Testadas de verdade**: 895 verificações passam (`python3 tools/run_intent_tests.py`). |
> | App Android (Kotlin) | **Escrito, mas NÃO compilado por mim**: neste ambiente não há Kotlin/Android SDK nem rede. Passou numa checagem estática (`tools/check_android.py`) e numa auditoria (`tools/audit_security.py`), que **não substituem compilar**. **Nenhum APK foi gerado por mim**, **não testei em aparelho**. Quem compila é o seu GitHub Actions. |
> | Erro "APK gerado sem a URL do backend" | Causa e correção abaixo (é falta de configuração, não um defeito no código). |
> | Claude e Gemini | **Implementados e testados só com servidor simulado.** Nunca falaram com a API real. |
> | Reconhecimento de falante | **Não integrado** (desativado, documentado). Ver `docs/AVALIACAO_RECONHECIMENTO_DE_FALANTE.md`. |
> | Geração/edição de vídeo e MP4 | **Não implementado** (só texto). |
> | Play Protect | **Não consigo testar.** Removi a causa mais provável (serviço de acessibilidade). |
> | Visuais | 15 estados do Popol + Kupa prontos. |
> | Desktop | **Não implementado**. |

## O erro "Este APK foi gerado sem a URL do backend…"

**Diagnóstico (do código e do processo, não só da mensagem):**
1. `android/kupa.properties` existe, mas `KUPA_BACKEND_URL=` está **vazio**. O build lê a propriedade corretamente (ordem: `-PKUPA_BACKEND_URL`, variável de ambiente, arquivo), valida e a grava em `BuildConfig.KUPA_BACKEND_URL`; o app usa esse valor (`BackendConfig`) ou a URL digitada em Configurações → Diagnóstico da IA.
2. Vazio é o **esperado**: o backend nunca foi hospedado, então **não existe uma URL real** para colocar. A mensagem é o app avisando isso do jeito certo, não uma falha de leitura.
3. Portanto a correção depende de uma ação externa (hospedar o backend), que **eu não consigo fazer daqui** (sem rede nem contas). Não inventei nenhuma URL.

**O que o código passou a fazer (testado em Java puro onde possível):**
- **Valida a URL** (`BackendUrlValidator`, 59 verificações): exige HTTPS em produção; recusa `localhost`, exemplos (`exemplo.com`, `seu-…`), credenciais na URL, `?`/`#`, porta inválida; HTTP só no APK de teste e só para rede local. O mesmo rigor vale no Gradle (um APK com URL inválida nem é gerado).
- **Classifica a falha de rede** (`BackendFailure`): DNS, **TLS/certificado (nunca ignorado)**, conexão recusada, sem rota, timeout, "não é o backend do KUPA" (404 no `/health`), token recusado (401/403), limite (429), backend iniciando/indisponível (502/503/504), erro interno (5xx), resposta que não é do KUPA.
- **Diagnóstico separado**: o estado do **backend** (URL ausente / URL inválida / conectado / indisponível + motivo) é mostrado à parte do estado de **cada provedor** (configurado no backend? teste real por provedor), com botões **Salvar e verificar** e **Repetir diagnóstico**; ao corrigir a URL, o app volta a funcionar sem reinstalar.
- **Aviso na tela inicial** quando o backend não está configurado, com atalho "Configurar o backend agora".
- `gradle kupaConfigReport` mostra qual URL entraria no APK (sem gerar o APK).

**O que VOCÊ precisa fazer (uma vez):**
1. Hospede o backend (`README_BACKEND.md`: Render com `render.yaml`, ou Railway) e configure `OPENAI_API_KEY`, `OPENAI_MODEL` e `KUPA_APP_TOKEN` no painel.
2. Copie o endereço **https** que a hospedagem mostrar e abra `https://SEU-ENDERECO/health` no navegador: deve aparecer `{"status":"ok",…"service":"kupa-backend"}`.
3. Ou (A) coloque o endereço em `android/kupa.properties` (`KUPA_BACKEND_URL=https://…`), faça *push* e deixe o GitHub Actions gerar o APK; ou (B) sem recompilar: no app, **Configurações → Diagnóstico da IA**, cole a URL e o token e toque em **Salvar e verificar**.

## Arquitetura

```
 USUÁRIO ─voz/texto─▶ APP ANDROID (Kotlin, sem bibliotecas externas)
                        ├─ Popol + Kupa (PopolView: camada Popol + camada Kupa)
                        ├─ StateManager (15 estados) ── PopolAnimationController / KupaAnimationController
                        ├─ KUPA CORE (KupaCore): decide, controla ferramentas, estados, resposta
                        │    ├─ CommandRouter (comandos locais: modo gamer, contexto do jogo, cancelar)
                        │    ├─ ToolRegistry (analyze_screen, start_timer) ← só o que o usuário autorizou
                        │    └─ AiOrchestrator → AiProvider (interface) → KupaBackendProvider
                        ├─ Voz: SpeechRecognizer (ouvir) + TextToSpeech (falar)
                        ├─ Tela: MediaProjection (captura autorizada)
                        └─ Histórico (SQLite), Configurações, Diagnóstico da IA
                                   │ HTTPS + token do app
                                   ▼
                        BACKEND KUPA (Node 20+, sem dependências)
                          AIService ─▶ OpenAIProvider ─▶ API oficial da OpenAI (POST /v1/responses)
                          (chave só aqui: OPENAI_API_KEY)
```

**Por que Kotlin nativo (decisão técnica):** o pedido exige sobreposição sobre outros apps, captura de tela
(MediaProjection), reconhecimento/síntese de voz e serviço em primeiro plano. Tudo isso é API nativa do Android;
Flutter/React Native precisariam de módulos nativos para cada uma. O app **não usa nenhuma biblioteca externa**
(só Android SDK + Kotlin): menos coisa para quebrar no build.

**Por que backend sem dependências:** só Node 20+ (`fetch` embutido). Nada para `npm install`.

### Mapa do pedido → onde está

| Pedido | Arquivo |
|---|---|
| 15 estados exatos | `core/KupaState.kt` |
| StateManager | `core/StateManager.kt` |
| Popol / Kupa independentes | `character/PopolView.kt`, `LayerAnimator.kt` (`PopolAnimationController`, `KupaAnimationController`), `AnimationMath.kt` |
| KupaCore | `core/KupaCore.kt` |
| Palavra de ativação "Kupa" (+ "cupa", "culpa" com regras) | `core/WakeWord.kt`, `voice/VoiceController.kt` |
| Voz (ligar/desligar), TTS | `voice/*`, `settings/Settings.kt` |
| AIService / OpenAIProvider | `backend/src/services/aiService.js`, `backend/src/providers/openaiProvider.js` (app: `ai/AiProvider.kt`) |
| Ferramentas controladas pelo núcleo | `backend/src/tools/registry.js`, `tools/KupaTools.kt`, `ai/AiOrchestrator.kt` |
| Pesquisa na internet | ferramenta oficial `web_search` da OpenAI, ligada pelo backend |
| Análise de tela | `screen/ScreenCaptureManager.kt`, `screen/ScreenPermissionActivity.kt` |
| Modo Gamer | `gamer/GamerModeController.kt`, `core/KupaCore.kt`, `overlay/OverlayController.kt`, `ui/SettingsActivity.kt` |
| Contexto de jogo | `game/GameContextService.kt` |
| Popol flutuante, menu, arrastar | `overlay/OverlayController.kt`, `overlay/KupaService.kt` |
| Histórico (VOICE/TEXT/SEARCH/SCREEN_ANALYSIS/GAMER) | `history/HistoryDb.kt`, `ui/HistoryActivity.kt` |
| Tela de diagnóstico + teste real | `ui/DiagnosticsActivity.kt`, `ai/KupaBackendClient.kt`, `POST /v1/ai/test` |
| Logs sem segredos | `core/KupaLog.kt`, `backend/src/logger.js` |


## Controle do celular (o que foi implementado)

**Arquitetura: a IA interpreta, o Android executa, nada é arbitrário.**

```
voz/texto ─▶ atalhos aprendidos ─▶ INTERPRETADOR (intent = OPEN_APP / CALL_CONTACT / ANSWER_CALL …)
                                        │ intenção estruturada e validada
                                        ▼
                                  CommandCenter ─▶ ActionExecutor (Android) ─▶ ação real
                                        ▲
IA (OpenAI via backend) ── só pode pedir as ferramentas open_app / call_contact / incoming_call,
                           que passam pelo MESMO executor e SEMPRE pedem confirmação.
```
Frases claras (ex.: "abra o WhatsApp") são entendidas **no aparelho**, sem IA e sem enviar nada ao backend.
Frases que o interpretador não entende vão para a IA; ela pode chamar uma ferramenta, mas quem decide, valida e executa é o app.

### Dois modos de escuta (Configurações → Modo de escuta)

| | Ativação por "Kupa" (padrão) | Escuta contínua |
|---|---|---|
| Como funciona | espera "Kupa" (ou "cupa"/"culpa" no começo da frase ou depois de "oi"/"ei"), ouve **um** comando e volta a aguardar | cada frase é avaliada; vira ação só se for um **comando de celular reconhecido** (ou resposta a uma pergunta do KUPA, ou "Kupa, …") |
| Ex. | "Kupa, abra o WhatsApp." | "Abra o WhatsApp." … "Agora abra o Mobile Legends." … "Ligue para Dudu." |
| Conversa solta | — | **ignorada** (não vai à IA), a menos que você ligue "Frases soltas também vão para a IA" |
| Ligações | seguem a regra de confirmação | **sempre pedem confirmação** se você não disse "Kupa" antes (para a TV ou uma conversa não discar por você) |

Cuidados de bateria e privacidade: só escuta quando o KUPA está em espera; **pausa com a tela desligada** (opção); **pausa sozinho** após X minutos sem comandos (padrão 10; 0 = nunca); botão **Pausar/Retomar** na notificação; prefere reconhecimento **no aparelho** (opção); nenhum áudio vai ao backend do KUPA (só texto, e só o necessário).
**Limites do Android:** o microfone em segundo plano exige o serviço em primeiro plano com a notificação fixa; a escuta contínua gasta bateria e pode brigar com o microfone de outros apps/jogos; o reconhecedor do Android pode "bipar" ao reiniciar; o KUPA não escuta enquanto fala.

### Comandos

| Você diz | O que acontece (de verdade) |
|---|---|
| "abra o WhatsApp / YouTube / Mobile Legends / qualquer app" | procura **entre os apps instalados** (sem lista fixa), abre o app (`PackageManager`). Não achou: "Não encontrei esse aplicativo instalado." Dois parecidos: pergunta qual. |
| "abra a câmera / as configurações / o discador" | abre o app padrão do Android correspondente |
| "ligue para Dudu", "faça uma ligação para…", "chame…", "telefone para…" | acha o contato (Contatos), pega o número **real** (nunca inventa), e liga com `TelecomManager` |
| vários "Dudu" | "Encontrei 2 contatos parecidos com Dudu: … Qual deles?" (responda "o primeiro", "o do trabalho"…) |
| "quem está me ligando?" | diz o nome do contato (ou "número desconhecido", ou que falta permissão) |
| "atende" / "recusa" / "desliga a ligação" | `acceptRingingCall()` / `endCall()` (Android 9+ para recusar) |
| "deixa tocar" / "deixa chamar até cair" / "não atende" | **não faz nada** (o Android não deixa um app silenciar o toque): só confirma que vai deixar tocar |
| "abra o WhatsApp e depois o jogo", "abra X e abra Y" | executa em sequência; se uma parte falha ou pede confirmação, **para** e avisa |
| "abra a conversa com Dudu" | abre a conversa **no WhatsApp** (linha de dados do contato). Outros apps: não suportado, e o KUPA diz isso |
| "ligue para ele/ela", "atende" | usa o **contexto** (último contato / chamada atual). Sem contexto, pergunta; não inventa |

**Honestidade das respostas.** "Ligando…/Abri…" só quando o Android/serviço de acessibilidade confirmou (estado da chamada ou app em primeiro plano).
Quando não dá para confirmar (sempre, no caso de abrir apps): "Pedi ao Android para abrir…". Sem permissão: diz qual permissão falta.
**Abrir apps em segundo plano:** o Android (10+) só deixa um app iniciar telas quando tem a permissão "Aparecer sobre outros apps" **ou** está aberto. Sem nenhuma das duas o KUPA **não finge**: deixa uma notificação "Toque para abrir".

### Confirmação de ações sensíveis (Configurações → Ações sensíveis)
- **Confirmar** (padrão): "Encontrei Dudu. Quer que eu faça a ligação?" → "sim" / "não".
- **Executar direto**: liga sem perguntar (as proteções do Android continuam). **Abrir apps** é sempre direto.
- **Sempre pergunta**, mesmo em "direto": nome só *parecido* ("Maria" → "Mariana"), pedido **vindo da IA**, e voz solta no modo contínuo.
- Atender/recusar **não** pedem confirmação (têm hora para acontecer e você mandou explicitamente).

### Comandos aprendidos
- Por voz: "Kupa, quando eu disser 'chama Dudu', quero dizer ligar para Dudu." / "Quando eu falar 'abre o jogo', estou falando do Mobile Legends." / "Quando eu disser zap, estou falando do WhatsApp."
- O KUPA **repete o que entendeu e pede confirmação** antes de salvar. Nada muda em silêncio.
- Comandos de controle (atender, recusar, desligar, ignorar, sim/não, aprender) **não podem ser redefinidos**.
- "Esqueça o comando abre o jogo" remove; "quais comandos eu ensinei" lista.
- Configurações → **Comandos aprendidos**: ver, **editar**, **remover**, adicionar. Ficam no aparelho, **cifrados com o Android Keystore**.

### Permissões (só o necessário, cada uma com o motivo na tela)

| Permissão | Para quê | Obrigatória? |
|---|---|---|
| Microfone | ouvir "Kupa" e comandos | para voz |
| Notificações | aviso fixo do serviço | sim (Android 13+) |
| Contatos | achar o número de quem ligar / abrir conversa / nome de quem liga | para ligar |
| Ligações (`CALL_PHONE`) | ligar | para ligar direto (sem ela, abre o discador) |
| Atender chamadas (`ANSWER_PHONE_CALLS`) | atender / recusar / desligar | para atender e recusar |
| Estado do telefone (`READ_PHONE_STATE`) | saber se está tocando / confirmar ação | recomendada |
| Registro de chamadas (`READ_CALL_LOG`) | **só** ver o número de quem liga | opcional |
| Aparecer sobre outros apps | Popol flutuante e abrir apps em segundo plano | opcional |

### Serviço de acessibilidade — REMOVIDO
Uma versão anterior tinha um serviço de acessibilidade **opcional** (só para confirmar qual app abriu). Ele foi **removido por inteiro** (código, configuração e permissão): era a causa
mais provável do bloqueio do Play Protect e não era necessário para nenhum comando. Consequência honesta: o KUPA não consegue confirmar qual app ficou na frente, então diz
"Pedi ao Android para abrir…" (e não "Abri…"). Ele também não sabe qual app está aberto, a não ser os que ele mesmo abriu.

### Limites reais (não dá para contornar)
- Ligar/atender/recusar dependem das permissões acima; "recusar" exige Android 9+. O Android não deixa app silenciar o toque ("deixa tocar" só confirma).
- O **número de quem liga** só aparece com `READ_CALL_LOG`; sem ele o KUPA diz que não tem permissão (não diz "desconhecido").
- Com a ligação tocando, o toque atrapalha o reconhecimento de voz: pode ser preciso repetir.
- Abrir conversa direto só no WhatsApp (e WhatsApp Business). Ligar pelo WhatsApp/vídeo **não** é suportado (o KUPA não entende o pedido em vez de ligar para a pessoa errada).
- Android 15 pode exigir uma janela visível para a exceção de "aparecer sobre outros apps" (por exemplo, com o Popol escondido no modo gamer): nesse caso o KUPA deixa a notificação "Toque para abrir".

## Play Protect e auditoria (o APK bloqueado)

**O que acontece.** O aviso "O app foi bloqueado para proteger seu dispositivo… pode pedir acesso a dados sensíveis" é do **piloto anti-fraude do Google Play Protect** (hoje inclui o Brasil):
ele bloqueia a instalação de APKs obtidos **fora da loja** (navegador, mensageiro, gerenciador de arquivos) quando o manifesto declara **leitura de SMS, leitura de notificações ou um serviço de acessibilidade**.
**Causa mais provável (não confirmada):** a versão anterior do KUPA declarava um `AccessibilityService`. Isso não significa que o app seja malware: é uma regra automática por permissão.

**O que foi feito (de verdade):** o serviço de acessibilidade foi **removido** (menor privilégio: nenhum comando dependia dele). Nada foi escondido nem mascarado, e não há nenhuma tentativa de "enganar" o Play Protect.
**O que eu não consigo garantir:** que o aviso suma. Isso só se vê instalando o novo APK. Se ainda bloquear, o próximo passo honesto é reduzir mais permissões sensíveis (as candidatas estão em `docs/AUDITORIA_SEGURANCA.md`: `READ_CALL_LOG`, `ANSWER_PHONE_CALLS`, `CALL_PHONE`) ou distribuir pela Play Store / instalar por `adb`.

**Auditoria automática:** `python3 tools/audit_security.py` gera `docs/AUDITORIA_SEGURANCA.md` com: gatilhos do Play Protect no manifesto; cada permissão com onde é usada no código, finalidade, alternativa menos privilegiada e decisão; componentes exportados;
dependências (**nenhuma** de terceiros, nenhum código nativo, nenhum WebView, nenhuma telemetria); rede; segredos; DEBUG/RELEASE; logs. Falha (código de saída 1) se achar problema CRÍTICO.
Correções feitas por causa da auditoria: serviço de acessibilidade removido; token do app agora **cifrado** (Keystore) em vez de texto puro; tráfego HTTP **bloqueado no RELEASE** (só HTTPS; HTTP só em DEBUG para rede local); logs no Logcat **só em DEBUG**; RELEASE com **R8**, sem `debuggable`, assinatura por variáveis de ambiente (sem chave no repositório); chave falsa dos testes não parece mais uma chave real para scanners.

### DEBUG x RELEASE
| | DEBUG (`app-debug.apk`, o que o GitHub Actions gera hoje) | RELEASE |
|---|---|---|
| Assinatura | chave de debug **pública** do Android | **sua** chave (variáveis `KUPA_KEYSTORE_PATH`, `KUPA_KEYSTORE_PASSWORD`, `KUPA_KEY_ALIAS`, `KUPA_KEY_PASSWORD`); sem elas o APK sai **sem assinatura** |
| `debuggable` | sim | não |
| R8/redução de código e recursos | não | sim |
| HTTP (sem criptografia) | permitido só para rede local | **bloqueado** (só HTTPS) |
| Logcat | sim (sem segredos) | não escreve |
| Para quê | testar | distribuir |
Gerar: `cd android && gradle assembleRelease`. **Nunca** distribua o APK de debug. Nenhuma chave ou senha vai para o repositório: no GitHub Actions use *secrets* e `env:`.

## Segurança (SecurityCore, PrivacyGate e o que existe de verdade)

Hierarquia: **SecurityCore > PrivacyGate > KUPA CORE > IA > modos > automação > ferramentas.** Nenhum nível inferior consegue desativar o superior; só pode *perguntar* (decide) ou *informar* (report).
Código: `security/*.java` (lógica pura, **testada**) + `security/SecurityGuard.kt`, `NativeAuth.kt` (integração Android).

| Peça | O que faz (real) |
|---|---|
| **Níveis de risco** NONE…CRITICAL | cada ação tem um risco base; ligar = MEDIUM; número de **emergência, tarifa especial (0900), código USSD (`*`/`#`)** = HIGH; internacional = aviso de custo |
| **Política** `SecurityPolicy` | MEDIUM: confirma (config, alvo parecido, ou pedido vindo da IA); **HIGH: duas confirmações**; **CRITICAL: duas confirmações + autenticação do aparelho** (sem bloqueio de tela configurado = **bloqueia**: fail-closed) |
| **Estados** NORMAL, WARNING, SUSPICIOUS, COMPROMISED, SAFE_SHUTDOWN | WARNING sobe o risco e pede confirmação; SUSPICIOUS bloqueia MEDIUM+; COMPROMISED/SAFE_SHUTDOWN bloqueiam tudo (menos "parar") |
| **Tentativa de burlar as regras** | BLOCK → ALERT → LOG → STOP → **SAFE_SHUTDOWN** (para IA, voz, captura, automação e perguntas pendentes). Só volta com **autenticação do aparelho** (biometria/PIN) |
| **IA como dado não confiável** | allowlist de ferramentas; **argumentos validados no servidor** (tipo, limite, campos extras); argumentos com ordens tipo "ignore suas regras" são bloqueados e contam como sinal suspeito; 3 violações em 10 min → SUSPICIOUS |
| **Prompt injection** | regra no prompt (sites, pesquisa, tela, apps, outras IAs = dado não confiável) + detector + resultado de captura marcado como não confiável. Defesa real é a arquitetura (a IA nunca executa nada direto), não só o detector |
| **Result Verifier** | se a resposta da IA diz "abri/liguei/atendi/pesquisei…" sem **nenhuma ferramenta** ter confirmado, o app acrescenta aviso de que **não foi feito** |
| **PrivacyGate** | antes de enviar texto à IA remove **senhas, chaves de API, tokens, cartão (Luhn válido), CPF válido, CVV** e avisa o que removeu (nunca o valor). Dados pessoais comuns (nome, endereço) **não** são detectáveis com segurança |
| **Privacy Zones** | análise de tela bloqueada se o último app que o KUPA abriu é banco/carteira/senhas/autenticador/saúde (+ lista sua). **Limite honesto:** o KUPA só sabe qual app está na frente quando **ele** o abriu |
| **Screenshots** | capturar → analisar → **descartar** (nada é guardado); `FLAG_SECURE`/DRM **nunca** contornados |
| **Credenciais** | nunca capturadas nem guardadas; token do app e dados pessoais do KUPA **cifrados** com o Android Keystore |
| **PARAR KUPA** | botão na tela inicial, em Configurações e no menu do Popol; por voz "para tudo": interrompe IA, voz, captura, perguntas pendentes, pausa a escuta e sai do modo |
| **Indicadores de privacidade** | a tela inicial mostra, ao vivo: 🎤 microfone ouvindo · 🖥 captura de tela ativa · ☁ enviando ao backend/IA · ⚙ executando ação |
| **Enfraquecer proteção** | exige a confirmação do aparelho: "executar ligações direto", "frases soltas vão à IA", remover zona de privacidade |
| **Sinais de integridade** | depurador no release, app depurável fora do teste, chave de teste, binário `su`: só geram **WARNING** ("sinal fraco, não confirmo a origem"). Nunca dizem "malware" |

**O que NÃO existe (e por quê):**
- **Verificação de falante / vozes autorizadas / anti-spoofing:** o Android **não tem API oficial** de verificação de falante e eu não tenho como embutir um modelo real e validado aqui. Por isso **não há tela de "Vozes Autorizadas"** (seria um botão falso). A política já trata voz como **não verificada**: voz nunca autentica ação alguma.
- **Play Integrity API:** exige os Serviços do Google Play, um projeto na nuvem do Google e o backend verificando o veredito. Não está implementado.
- **Detecção de malware/invasão:** o KUPA **não é antivírus** e não finge ser. Só os sinais fracos acima. COMPROMISED só é acionado com evidência confiável (hoje nenhuma fonte a produz); use Play Protect e as ferramentas oficiais do Android.
- **Ações HIGH/CRITICAL de verdade** (pagamentos, transferências, apagar dados): **não existem como funções**. A infraestrutura (duas confirmações, autenticação nativa, bloqueio) está pronta e testada; o que existe hoje nessa categoria é ligar para emergência/tarifa especial/USSD.
- **Telemetria:** nenhuma. Nada é enviado além do texto necessário ao backend configurado.

## Botão "Silenciar bipe do microfone" (antibaip)

**De onde vem o bipe:** do **serviço de reconhecimento de voz do aparelho** (normalmente o app de voz do Google ou do fabricante), não do KUPA. O Android **não tem opção oficial** para desligá-lo. Por isso o botão **não consegue prometer** silêncio em todos os aparelhos.
**O que foi implementado (alternativa segura):** com a preferência ligada, o KUPA silencia o **canal de mídia por janelas curtas** (cerca de 1,5 s antes de abrir o reconhecedor, 0,7 s quando ele fica pronto e 0,9 s no fim/erro), que é o canal que muitos aparelhos usam para esse sinal.
- Configurações → Modo de escuta → **Silenciar bipe do microfone** (e um atalho na tela inicial). Fica **salvo** ao fechar o app e é **independente** do botão da palavra-chave e do "Falar as respostas".
- **Não muda o volume** (usa mudo/desmudo, que preserva o nível), **não liga o modo silencioso**, **não pede permissão especial**, não usa método oculto.
- **Não silencia outros apps:** se **há mídia tocando** (música, vídeo), ou o canal já estava mudo por outro motivo, o KUPA **não mexe** e o bipe pode tocar. Só desfaz o mudo que ele mesmo fez.
- As **respostas faladas continuam audíveis:** o mudo é desfeito **antes** de o KUPA falar, ao parar a escuta e ao encerrar; se o app morrer no meio de uma janela, ao abrir de novo ele **desfaz** o mudo que deixou.
- **Limites (não comprovados em aparelho):** se o seu aparelho toca o bipe por outro canal (notificação/sistema), o botão não o silencia (isso exigiria a permissão especial de "acesso à política de notificação", que o KUPA não pede). Música tocando enquanto você fala com o KUPA pode manter o bipe. Uma música que **começa** durante uma janela pode ficar muda por até ~1,5 s.
- **Teste:** `EarconGuardCore` (Java, 86 verificações com um áudio falso): preferência desligada não toca em nada; mídia tocando não é silenciada; mudo alheio nunca é desfeito; janelas sobrepostas = 1 mudo e 1 desmudo; liberar antes de falar; recuperação após crash; 20 sequências aleatórias com mudos == desmudos. **Isto prova a lógica, não que o bipe do seu aparelho some.**

## Voz e personalidade (Popol e Kupa)
- Três controles **independentes**: **palavra-chave** (escuta), **bipe do microfone** (acima) e **Falar as respostas em voz alta** (desligado: só texto, mas continua ouvindo). **Estilo descontraído** liga/desliga a personalidade brincalhona (desligado = respostas neutras e objetivas; testado no backend). A segurança do prompt vale nos dois estilos.
- Vozes: TTS do Android. Predefinições **Estilo Popol** (tom 135%, velocidade 112%) e **Estilo Kupa** (tom 80%, velocidade 92%) só mudam tom e velocidade da voz instalada. **Não imitam nem clonam** nenhuma voz; o quanto soam "personagem" depende da voz escolhida e instalada no seu Android. A tela lista as vozes pt-BR com qualidade, latência e se precisam de internet.
- O KUPA não ouve a própria voz: a escuta da palavra-chave só roda com o assistente em repouso (`IDLE`); falando, a escuta fica suspensa e volta depois.

## Prova da conexão REAL com a IA (estado: PENDENTE — NÃO CONCLUÍDO)
**Hoje não há prova.** O backend nunca foi hospedado, não existe URL pública e nenhuma chave de IA foi configurada; todos os testes automáticos usam **servidores simulados**. Eu não tenho rede nem credenciais neste ambiente. **Não considere a IA conectada** até a verificação abaixo passar.
**Como comprovar (quando o backend estiver hospedado e tiver chave):**
1. Rode `backend/scripts/e2e-real.mjs`: **no seu computador** (`KUPA_BACKEND_URL=https://… KUPA_APP_TOKEN=… node backend/scripts/e2e-real.mjs`, as credenciais por **variável de ambiente**, nunca no chat) **ou pelo GitHub** com o workflow `e2e-ia.yml` (secrets/variáveis no próprio GitHub, passo a passo no topo do arquivo).
2. O script confere: `/health` é mesmo do KUPA; sem token e com token errado a requisição é **rejeitada**; token certo é aceito e há provedor configurado; **chamada real a cada provedor** (modelo e latência); e uma conversa com **contexto**: manda um **código aleatório novo**, depois pergunta por ele numa segunda mensagem. **Um servidor com respostas prontas não consegue passar** (testado). Sai com código 0 só se tudo passar e grava `e2e-result.json` sem segredos.
3. No aparelho: **Configurações → Diagnóstico da IA → Testar [provedor]** faz a mesma chamada real a partir do app (app → backend → provedor), e uma pergunta no chat/voz mostra a resposta na tela e a fala em voz alta.
**O que o script prova:** backend → IA real → resposta. **O que ele NÃO prova:** o app Android (compilação, tela, voz e TTS), que precisa de teste num aparelho.

## Palavra-chave e microfone: ciclo de vida (correção do "microfone ativando repetidamente")

**Causas encontradas no código anterior (não são hipóteses; arquivo e comportamento):**
1. `VoiceController.kt` (versão antiga): em qualquer erro que não fosse "sem fala/sem correspondência" (reconhecedor **ocupado**, **rede**, **outro**), a escuta era reiniciada **para sempre**, com espera de até 8 s e **sem limite de tentativas**. Se o erro persistia (ex.: sem internet com reconhecimento offline ausente), o microfone ficava "ativando" em ciclo.
2. O reinício agendado **não era cancelado** ao desativar (`stopListening()` só mudava uma variável) e os callbacks só conferiam o "modo", **sem identidade de sessão**. Desativar e reativar logo em seguida deixava um temporizador/callback **antigo** agir na sessão **nova**: inícios duplicados.
3. Botão "Falar" com `LANGUAGE_UNAVAILABLE`: o comando reiniciava **sem limite**.
4. `KupaService.ensureStarted()` registrava um ouvinte em `Settings.onChange` **a cada início do serviço** e nunca o removia (vazamento; ouvintes mortos continuavam disparando).

**Correção (`voice/ListenMachine.java` + `VoiceController.kt`):** uma **máquina de estados única** decide se o microfone pode abrir; o `VoiceController` só executa os passos dela.
- Estados: `DISABLED, WAITING_PERMISSION, STARTING, LISTENING, COMMAND, STOPPING, SUSPENDED, ERROR, UNAVAILABLE`. **Preferência, permissão, disponibilidade e uso real do microfone são entradas separadas.**
- Cada início de escuta ganha um **token**. Callbacks e temporizadores de tokens antigos são **ignorados**. Desativar **invalida tudo na mesma chamada**.
- **Idempotente:** 50 pedidos de ativação criam **uma** sessão. No máximo **um** reconhecedor válido; a escuta da palavra e o comando **nunca coexistem**.
- **Recuperação limitada:** falhas recuperáveis têm no máximo **5** tentativas (espera 0,4 / 1 / 2,5 / 5 / 8 s) e depois vão para `ERROR`, que só sai por **ação do usuário** ("Tentar de novo", ou desativar e ativar a palavra-chave). Ciclos normais ("sem fala") não contam como falha. Permissão ausente e reconhecimento indisponível **não** viram tentativas: viram `WAITING_PERMISSION`/`UNAVAILABLE`.
- **Preferência do usuário vence:** com a palavra-chave desativada, nada reinicia o microfone (callback tardio, temporizador, recuperação). Um comando em andamento termina, e depois a escuta **não** volta se estiver desativada. O botão "Falar" funciona com a palavra-chave desativada e **não** liga a escuta contínua.
- **Indicador verdadeiro:** "microfone em uso" só aparece depois que o reconhecedor avisa que está pronto. A tela inicial mostra a linha "Escuta: …" (desativada / aguardando permissão / iniciando / ouvindo / comando / suspensa / erro / indisponível), um botão **Palavra-chave LIGADA/DESATIVADA** separado do assistente e **Tentar de novo** quando preciso.
- O ouvinte de configurações agora é removido ao encerrar o serviço.

**Testes (`tools/jvmtests/ListenMachineTests.java`, 318 verificações; tipo: teste unitário com um "Android falso", NÃO microfone físico):** ativar/desativar 200 ciclos com toques repetidos e callbacks tardios (nunca mais de 1 reconhecedor válido, sempre termina desativado e limpo); desativar durante `STARTING`; erro/sucesso tardio depois de desativar; temporizador antigo depois de reativar; 1000 ciclos normais sem erro; falha persistente (5 reinícios no máximo, depois `ERROR`, sem loop, nova tentativa manual cria uma sessão); falhas intercaladas; permissão revogada/restaurada; indisponibilidade; condição momentânea; alternância palavra ↔ comando; "parar tudo"; callbacks fora de ordem/duplicados; **fuzz com 100.000 eventos aleatórios** e invariantes. Um teste de **regressão** reproduz a lógica antiga e mostra que ela **viola** os critérios (100 reinícios em 100 falhas contra 5 da máquina nova; 3 inícios em ativar-desativar-ativar contra 2).
**O que NÃO está provado:** o comportamento do microfone físico. Falta testar em emulador e em aparelho. Limite conhecido do Android: o `SpeechRecognizer` termina um ciclo a cada poucos segundos (sem fala/sem correspondência); é normal o KUPA recriá-lo (~0,2 s), e alguns aparelhos mostram o ícone do microfone ou tocam um sinal a cada ciclo. Isso é do design da API e **não** é o loop corrigido acima.

## Provedores de IA (OpenAI, Claude, Gemini)
Arquitetura (backend): `AIProviderManager` → `AIRouter` → provedor (`OpenAIProvider`, `AnthropicProvider`, `GeminiProvider`) → validação das ferramentas pedidas → app. O app (`ResultVerifier`) só aceita "feito" com prova de execução.
Todos falam a **API oficial por HTTP** (sem SDK). Cada um declara suas **capacidades** (visão, ferramentas, busca, limite de contexto se informado) e só entra no roteamento se tiver **chave e modelo** no backend. As chaves ficam **só no backend**.

| Provedor | API | Estado |
|---|---|---|
| OpenAI | Responses (`/v1/responses`) | Implementado; testado só com servidor simulado. |
| Claude (Anthropic) | Messages (`/v1/messages`, `x-api-key`, `anthropic-version`; ferramentas `tool_use`/`tool_result`; busca `web_search_20250305`; `pause_turn`) | Implementado conforme a documentação oficial; testado só com servidor simulado. |
| Gemini (Google) | `generateContent` (`x-goog-api-key`; `functionDeclarations`/`functionCall`/`functionResponse`; `google_search`) | Implementado conforme a documentação oficial; testado só com servidor simulado. Limites: a busca do Google não é combinada com as ferramentas do KUPA na mesma chamada (a busca é omitida quando há ferramentas); imagem devolvida por ferramenta vai como parte `inlineData` ao lado do `functionResponse` (**não verificado** na API real). |

**Roteamento:** escolha manual (Diagnóstico da IA, ou preferência por modo) ou **Automático** = primeiro provedor *pronto* na ordem `KUPA_PROVIDER_ORDER`, descartando quem não suporta o pedido (imagem, ferramentas, contexto acima do limite informado). Dentro do provedor, o modelo vem da tarefa (imagem → `*_MODEL_VISION`; modo gamer/curto → `*_MODEL_FAST`; análise/nicho → `*_MODEL_REASONING`; senão `*_MODEL`). **Não há preço nem "qualidade" no roteador**: não tenho dados verificados, então não inventei.
**Escolha explícita não é trocada em silêncio:** se o provedor escolhido não está pronto, o pedido falha com a explicação.
**Fallback seguro:** desligado por padrão. Só com a **sua autorização** (Diagnóstico da IA → "Usar outro provedor se o escolhido falhar"), só para falha **do provedor** (rede, timeout, indisponível, limite, chave recusada, modelo não encontrado), **uma única alternativa**, **nunca** depois que uma ferramenta já rodou (para não duplicar ações) e **nunca** para erro do próprio pedido. A resposta informa `route.fallback`. Isso envia o mesmo conteúdo a outra empresa; por isso é opt-in.
**Assinaturas:** uma assinatura do ChatGPT, do Claude ou do Gemini **não dá crédito de API** e a API não acessa o histórico pessoal da sua conta. Cada provedor precisa de chave de API própria (com cobrança própria).
**Local:** não há IA local embutida; o que dá para fazer localmente (comandos, privacidade, segurança, verificação) já é local.

## Modos, proatividade e memória adaptativa
- **Modos** (Configurações → Modos): nome, objetivo, instruções, memória própria, proatividade, tela/pesquisa permitidas, classe de modelo. Um modo **só restringe ou orienta o estilo** (E lógico com as configurações globais) e **nunca** altera a segurança. Por voz: "ativar modo estudo", "sair do modo", "quais modos". **Criar modo por voz não existe**: use a tela. Há modelos prontos (Estudo, Programação, Pesquisa, Criação de conteúdo e Método Dark) e cada modo pode ter um **provedor de IA preferido**.
- **Proatividade** OFF/LOW/MEDIUM/HIGH: muda o prompt (quanto sugerir); toda sugestão vem como Observação, Hipótese ou Recomendação. **Não existe um "copiloto" que observa a tela sozinho**: o KUPA só sugere dentro das respostas.
- **Feedback** 👍 / 👎 / mais curto / mais detalhado / "sem sugestões": 3 👎 seguidos reduzem a proatividade do modo; "mais curto/detalhado" muda o estilo; tudo cifrado e apagável. Só aprende com o que você aperta (e apps que você pede para abrir). Nunca senhas.

## Conteúdo (só texto)
Configurações → Conteúdo: **nicho** (tema, público, estilo…), **levantamento do nicho** (com pesquisa na web e fontes), **5 hooks** com avaliação *qualitativa*, **roteiro**, **otimização** de título/legenda/hashtags/CTA, **análise de roteiro/texto colado**.
Regras no prompt: separar FATO/OBSERVAÇÃO/HIPÓTESE/RECOMENDAÇÃO; **nunca inventar métricas ou tendências** (sem fonte vira hipótese); nunca prometer viralização; não copiar obras protegidas; nada de engajamento artificial.
Os resultados podem ser salvos como **projetos** (texto, cifrados no aparelho, máximo 50, apagáveis).
**Não existe (bloqueado por dependência externa):** pipeline de vídeo (cenas, narração, legendas, edição, exportação MP4), análise de vídeo, integração com redes sociais, medição de métricas, publicação, geração de capa/thumbnail. O KUPA **não afirma** fazer nada disso. O que seria possível numa próxima etapa sem serviço externo: renderizar um vídeo vertical 9:16 de cenas com texto no aparelho usando `MediaCodec`/`MediaMuxer` (APIs oficiais do Android) com narração do TTS; isso precisa ser escrito e testado em aparelho, e não foi feito. Serviços de geração de vídeo por IA exigiriam provedor, chave, custo e licenças (mantendo a chave no backend). O KUPA não afirma fazer nada disso. Não há "multi-assistentes" separados: os **modos** cobrem esse uso. O fluxo "nova função criada por IA" não foi implementado.

## Nome do assistente e palavra de ativação
Configurações → "Nome do assistente e palavra de ativação": nome mostrado, palavra de ativação (uma palavra, 3 a 20 letras; palavras de comando como "abrir"/"atender" são recusadas), variantes (embutidas ativáveis/desativáveis, personalizadas, restaurar padrão) e a opção de **manter o nome antigo** (por padrão ele deixa de ativar).
`ActivationNameEngine` (Java, 76 verificações junto com a verificação de voz): o nome vale no começo da frase ou depois de "oi/ei"; **variantes só no começo/depois de chamado** (por isso "a culpa é minha" não ativa); **sem correspondência aproximada automática**. O KUPA só **sugere** variantes (palavra quase igual ao nome ouvida no começo de uma frase que não ativou, guardando só essa palavra e a contagem) e **você aceita ou ignora**. O nome vai à IA e às notificações; o aplicativo continua se chamando KUPA (um único app).
A palavra de ativação **só inicia** a conversa: não identifica quem falou e não autoriza nada. O modo de escuta contínua continua sendo "microfone aberto avaliando comandos", não detecção de palavra em segundo plano por hardware.

## Voz do assistente (TTS)
Usa o Text-to-Speech do Android. A tela mostra o **motor instalado**, quantas vozes em português existem e, para cada voz, o que o Android informa (qualidade, latência, se precisa de internet). Tom e velocidade têm três predefinições (Energética, Calma, Neutra); **não há controle de emoção ou de pausas porque o Android não o oferece**. Isso **não** transforma uma voz comum numa voz de personagem nem clona ninguém: o resultado depende das vozes instaladas (instale vozes de maior qualidade em Configurações do Android → Texto para fala). Voz de nuvem pelo backend **não está implementada**.

## Tablet e desempenho (um único KUPA)
- A tela inicial **se adapta à janela real**: coluna única no celular; **duas áreas** (comandos à esquerda, Popol + conversa à direita) quando a largura passa de 720 dp (tablet, paisagem, janela larga). Retrato/paisagem e **multi-janela** (`resizeableActivity`) funcionam; a mesma conversa é usada nos dois layouts.
- **PerformanceEngine/HardwareProfile:** lê do Android memória, núcleos, menor largura da tela, `isLowRamDevice`, bateria, economia de energia e **temperatura (quando o Android informa)**; o que não informa aparece como "indisponível". Categoria LOW/MEDIUM/HIGH/ULTRA é uma **heurística** (memória e núcleos), não benchmark.
- **Perfis:** AUTO, PERFORMANCE_MAX, BALANCED, BATTERY_SAVER, THERMAL_SAFE, AI_HEAVY, SCREEN_ANALYSIS, VOICE_LOW_LATENCY, ANIMATION_MAX. Cada um ajusta **de verdade** quadros por segundo do Popol, cache de imagens, fade e qualidade/tamanho da captura. AUTO: térmico SEVERE → THERMAL_SAFE; bateria ≤15% sem carregar ou economia ligada → BATTERY_SAVER; senão pela categoria. Nenhum perfil mexe em segurança. Perfis como AI_HEAVY/VOICE_LOW_LATENCY só mudam esses parâmetros (não aceleram a IA nem o reconhecimento de voz).
- Não há IA local no tablet: potência do aparelho não cria um modelo local que não existe.

## GitHub Actions

O workflow **não foi alterado** (eu não tenho acesso ao seu repositório). Ele continua precisando de: JDK 17, Gradle 8.9, SDK Android 35 e gera `android/app/build/outputs/apk/debug/app-debug.apk`.
O que mudou no build: `android/kupa.properties` (URL do backend, **vazia** por padrão: o build **não falha**, só avisa) e `buildFeatures.buildConfig = true`.
O build **só falha** se `KUPA_BACKEND_URL` estiver preenchida com algo inválido (para você não gerar um APK com URL quebrada).
URL pela linha de comando/CI sem editar arquivo: `KUPA_BACKEND_URL=https://... gradle assembleDebug` ou `env:` no workflow.

## 1) Backend

Requisitos: Node 20 ou mais novo.

```bash
cd backend
cp .env.example .env      # preencha OPENAI_API_KEY, OPENAI_MODEL e KUPA_APP_TOKEN
npm test                  # 24 testes (não usam a OpenAI de verdade)
npm start                 # escuta em 0.0.0.0:8787
```

Variáveis (`backend/.env`, que **nunca** deve ir para o GitHub):

| Variável | Para quê |
|---|---|
| `OPENAI_API_KEY` | chave secreta da OpenAI (só existe aqui) |
| `OPENAI_MODEL` | modelo usado. **Sem valor padrão de propósito**; troque sem mexer em código. Use um modelo atual da lista oficial da OpenAI que aceite imagem e busca na web. |
| `KUPA_APP_TOKEN` | senha compartilhada app ↔ backend (gere uma longa e aleatória) |
| outras | ver comentários no `.env.example` (timeout, `store`, busca na web, limites…) |

Rotas: `GET /health` (sem login) · `GET /v1/config` · `POST /v1/ai/test` (chamada real à OpenAI) · `POST /v1/ai/respond`.

Verificação rápida depois de configurar:
```bash
curl localhost:8787/health
curl -H "Authorization: Bearer SEU_TOKEN" -X POST localhost:8787/v1/ai/test
```

**Publicar:** para usar fora de casa, coloque o backend atrás de **HTTPS** (Render, Fly.io, Railway, um VPS com Caddy…).
Configure as variáveis no painel do serviço (variáveis secretas), nunca no código.

**Segurança — limites que você precisa conhecer**
- O `KUPA_APP_TOKEN` fica dentro do app, então alguém que extraia o APK consegue pegá-lo. Ele **impede uso casual**,
  não é autenticação forte. Para uso pessoal serve; para distribuir a outras pessoas, troque por login/token por aparelho.
- O backend limita requisições por minuto (padrão 60) e tamanho do corpo (8 MB), mas **defina um limite de gasto na sua conta da OpenAI**.
- O app só aceita HTTP puro para endereços de rede local; qualquer outro endereço precisa ser HTTPS.
  O manifesto libera cleartext por causa da rede local; a regra de verdade está em `ai/BackendUrlPolicy.kt`.

## 2) App Android

1. Instale o **Android Studio** (versão atual) e abra a pasta `android/`.
2. Deixe o Gradle sincronizar (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, compileSdk/targetSdk 35, minSdk 26).
   Se o Android Studio pedir, aceite instalar o SDK 35. Se faltar o `gradle-wrapper.jar`, rode uma vez `gradle wrapper --gradle-version 8.9`
   (ou deixe o Android Studio gerar).
3. **Build → Build APK(s)** (ou ▶ num celular com depuração USB). O APK sai em `android/app/build/outputs/apk/`.
4. No app: **Configurações → IA / Diagnóstico**, informe o endereço do backend (ex.: `http://192.168.0.10:8787` na rede local,
   ou `https://...`) e o token, toque em **Salvar e verificar** e depois em **TESTAR CONEXÃO COM A IA**.

Se o build acusar erros de compilação, copie a mensagem e me mande: o código nunca foi compilado por mim.

### Permissões e para que servem

| Permissão | Uso |
|---|---|
| Microfone | ouvir "Kupa" e seus comandos |
| Aparecer sobre outros apps | Popol flutuante (sem ela, o Popol aparece só dentro do app) |
| Notificações / serviço em primeiro plano | o Android exige o aviso fixo para manter microfone/overlay ativos |
| Captura de tela (aviso oficial do Android) | só quando você iniciar a captura; sem "burlar" nada |
| Alarme/timer | ferramenta `start_timer` |
| Vibração | confirmação discreta no Modo Gamer |

### Como o fluxo funciona

`Esperando → (você diz "Kupa") Ativado → Ouvindo → Pensando → [Pesquisando | Analisando tela | Traduzindo | Lendo | Executando comando] → Falando → Concluído → Esperando.`
Depois de responder o KUPA **não** continua ouvindo: para outra pergunta, chame "Kupa" de novo.
Erros mostram o estado **Erro** com mensagem clara e voltam a **Esperando** sozinhos.

### Troca dos visuais (sem reconstruir o app)

- Visuais atuais: `res/drawable-nodpi/state_XX_nome.webp` (Popol + Kupa juntos).
- Para trocar: coloque os PNGs novos numa pasta com os mesmos nomes e rode
  `python3 tools/prepare_sprites.py <pasta> android/app/src/main/res/drawable-nodpi` (padroniza tamanho e alinhamento).
- **Kupa animando sozinho:** adicione, por estado, `popol_XX_nome.webp` (só o Popol) **e** `kupa_XX_nome.webp` (só o lobo)
  na mesma pasta. O app detecta e liga as duas camadas independentes automaticamente.

## 3) Modo Gamer — o que dá e o que não dá (Android)

- "Kupa, ativar modo gamer": o Popol e o Kupa **somem da tela**, mas o núcleo, a IA, a pesquisa e as ferramentas continuam. Você ainda chama "Kupa" e recebe a resposta por voz.
  "Kupa, desativar modo gamer" traz tudo de volta (posição, tamanho e transparência restaurados).
- **Limites reais do Android (não dá para contornar):**
  - Escuta contínua do microfone gasta bateria e **briga com o microfone do jogo/chat de voz**. Há a opção "Só no botão Falar" (notificação) para esses casos.
  - O reconhecedor de voz do Android pode tocar um "bip" a cada reinício em alguns aparelhos.
  - O KUPA **não escuta enquanto fala** (para não ouvir a si mesmo): durante a resposta não dá para interromper por voz.
  - Jogos que bloqueiam captura de tela (FLAG_SECURE) devolvem tela preta: o KUPA detecta e **avisa** que a análise visual está indisponível, sem inventar.
  - Alguns fabricantes matam serviços em segundo plano: desative a otimização de bateria para o KUPA.
  - O KUPA nunca presume qual jogo está aberto: usa o que você disse ("estou jogando de Popol") ou o que a tela mostrou.

## 4) Desktop

**Não foi implementado.** O que já está pronto para isso: o backend e o protocolo (`/v1/ai/respond`) não dependem do Android,
e `AiProvider` isola o provedor. Caminho sugerido: Tauri reaproveitando os WebP dos estados, repetindo `KupaCore` em TypeScript/Rust.

## 5) O que ainda falta / não existe

- Compilar e testar o app num aparelho real (nunca rodou).
- Chamada real à OpenAI com a sua chave.
- Camadas separadas do Kupa (precisam dos arquivos).
- Ferramentas `translate`, `readScreen`, `saveMemory`, `getMemory`, `getCurrentApp`: **não existem como ferramentas separadas**.
  Traduzir/ler a tela já acontece pela `analyze_screen` (o modelo lê e traduz a imagem). Memória de longo prazo foi evitada de propósito.
- Voz: usa o TTS do Android; não há voz "personalizada" além de tom/velocidade.
- Pesquisa e raciocínio dependem do modelo que você escolher; se ele não aceitar imagem, a análise de tela falhará e o app mostrará o erro da OpenAI.

## Ferramentas de apoio

- `tools/prepare_sprites.py` — padroniza os 15 estados.
- `tools/check_android.py` — checagem estática do Kotlin/Java.
- `tools/audit_security.py` — auditoria de segurança (gera `docs/AUDITORIA_SEGURANCA.md`).
- `tools/run_intent_tests.py` — compila e roda os testes Java (intenções, segurança, privacidade, desempenho).
- `README_BACKEND.md` — instalar, testar e publicar o backend; onde colocar a URL.
