# KUPA — assistente pessoal com o Popol e o lobo Kupa

Aplicativo Android (prioridade) + backend seguro. A IA vem da **API oficial da OpenAI** (Responses API), sempre pelo
backend: **a chave da OpenAI nunca vai para o app**.

> **Estado honesto deste projeto (leia primeiro):**
>
> | Parte | Situação |
> |---|---|
> | Backend (Node) | **Escrito e testado**: 24 testes automáticos passam contra um servidor OpenAI *falso* (só nos testes). A chamada à OpenAI **de verdade ainda não foi feita** (precisa da sua chave). |
> | App Android (Kotlin) | **Escrito, mas NÃO compilado**: onde foi criado não há Kotlin/Android SDK nem rede. Passou numa checagem estática (`tools/check_android.py`), que **não substitui compilar**. Espere corrigir alguns erros pequenos no primeiro build. **Nenhum APK foi gerado.** |
> | Visuais | 15 estados do Popol + Kupa prontos (PNG transparente → WebP padronizado em `res/drawable-nodpi`). |
> | Desktop | **Não implementado** (veja "Desktop"). |
> | Kupa animando separado do Popol | **Preparado, mas inativo**: os 15 visuais trazem os dois juntos. |

## Arquitetura

```
 USUÁRIO ─voz/texto─▶ APP ANDROID (Kotlin, sem bibliotecas externas)
                        ├─ Popol + Kupa (PopolView: camada Popol + camada Kupa)
                        ├─ StateManager (15 estados) ── PopolAnimationController / KupaAnimationController
                        ├─ KUPA CORE (KupaCore): decide, controla ferramentas, estados, resposta
                        │    ├─ CommandRouter (comandos locais: modo gamer, contexto do jogo, cancelar)
                        │    ├─ ToolRegistry (analyze_screen, start_timer) ← só o que o usuário autorizou
                        │    └─ AiOrchestrator → AiProvider (interface) → KupaBackendProvider
                        ├─ Voz: SpeechRecognizer (ouvir) + TextToSpeech (falar)
                        ├─ Tela: MediaProjection (captura autorizada)
                        └─ Histórico (SQLite), Configurações, Diagnóstico da IA
                                   │ HTTPS + token do app
                                   ▼
                        BACKEND KUPA (Node 20+, sem dependências)
                          AIService ─▶ OpenAIProvider ─▶ API oficial da OpenAI (POST /v1/responses)
                          (chave só aqui: OPENAI_API_KEY)
```

**Por que Kotlin nativo (decisão técnica):** o pedido exige sobreposição sobre outros apps, captura de tela
(MediaProjection), reconhecimento/síntese de voz e serviço em primeiro plano. Tudo isso é API nativa do Android;
Flutter/React Native precisariam de módulos nativos para cada uma. O app **não usa nenhuma biblioteca externa**
(só Android SDK + Kotlin): menos coisa para quebrar no build.

**Por que backend sem dependências:** só Node 20+ (`fetch` embutido). Nada para `npm install`.

### Mapa do pedido → onde está

| Pedido | Arquivo |
|---|---|
| 15 estados exatos | `core/KupaState.kt` |
| StateManager | `core/StateManager.kt` |
| Popol / Kupa independentes | `character/PopolView.kt`, `LayerAnimator.kt` (`PopolAnimationController`, `KupaAnimationController`), `AnimationMath.kt` |
| KupaCore | `core/KupaCore.kt` |
| Palavra de ativação "Kupa" (+ "cupa", "culpa" com regras) | `core/WakeWord.kt`, `voice/VoiceController.kt` |
| Voz (ligar/desligar), TTS | `voice/*`, `settings/Settings.kt` |
| AIService / OpenAIProvider | `backend/src/services/aiService.js`, `backend/src/providers/openaiProvider.js` (app: `ai/AiProvider.kt`) |
| Ferramentas controladas pelo núcleo | `backend/src/tools/registry.js`, `tools/KupaTools.kt`, `ai/AiOrchestrator.kt` |
| Pesquisa na internet | ferramenta oficial `web_search` da OpenAI, ligada pelo backend |
| Análise de tela | `screen/ScreenCaptureManager.kt`, `screen/ScreenPermissionActivity.kt` |
| Modo Gamer | `gamer/GamerModeController.kt`, `core/KupaCore.kt`, `overlay/OverlayController.kt`, `ui/SettingsActivity.kt` |
| Contexto de jogo | `game/GameContextService.kt` |
| Popol flutuante, menu, arrastar | `overlay/OverlayController.kt`, `overlay/KupaService.kt` |
| Histórico (VOICE/TEXT/SEARCH/SCREEN_ANALYSIS/GAMER) | `history/HistoryDb.kt`, `ui/HistoryActivity.kt` |
| Tela de diagnóstico + teste real | `ui/DiagnosticsActivity.kt`, `ai/KupaBackendClient.kt`, `POST /v1/ai/test` |
| Logs sem segredos | `core/KupaLog.kt`, `backend/src/logger.js` |

## 1) Backend

Requisitos: Node 20 ou mais novo.

```bash
cd backend
cp .env.example .env      # preencha OPENAI_API_KEY, OPENAI_MODEL e KUPA_APP_TOKEN
npm test                  # 24 testes (não usam a OpenAI de verdade)
npm start                 # escuta em 0.0.0.0:8787
```

Variáveis (`backend/.env`, que **nunca** deve ir para o GitHub):

| Variável | Para quê |
|---|---|
| `OPENAI_API_KEY` | chave secreta da OpenAI (só existe aqui) |
| `OPENAI_MODEL` | modelo usado. **Sem valor padrão de propósito**; troque sem mexer em código. Use um modelo atual da lista oficial da OpenAI que aceite imagem e busca na web. |
| `KUPA_APP_TOKEN` | senha compartilhada app ↔ backend (gere uma longa e aleatória) |
| outras | ver comentários no `.env.example` (timeout, `store`, busca na web, limites…) |

Rotas: `GET /health` (sem login) · `GET /v1/config` · `POST /v1/ai/test` (chamada real à OpenAI) · `POST /v1/ai/respond`.

Verificação rápida depois de configurar:
```bash
curl localhost:8787/health
curl -H "Authorization: Bearer SEU_TOKEN" -X POST localhost:8787/v1/ai/test
```

**Publicar:** para usar fora de casa, coloque o backend atrás de **HTTPS** (Render, Fly.io, Railway, um VPS com Caddy…).
Configure as variáveis no painel do serviço (variáveis secretas), nunca no código.

**Segurança — limites que você precisa conhecer**
- O `KUPA_APP_TOKEN` fica dentro do app, então alguém que extraia o APK consegue pegá-lo. Ele **impede uso casual**,
  não é autenticação forte. Para uso pessoal serve; para distribuir a outras pessoas, troque por login/token por aparelho.
- O backend limita requisições por minuto (padrão 60) e tamanho do corpo (8 MB), mas **defina um limite de gasto na sua conta da OpenAI**.
- O app só aceita HTTP puro para endereços de rede local; qualquer outro endereço precisa ser HTTPS.
  O manifesto libera cleartext por causa da rede local; a regra de verdade está em `ai/BackendUrlPolicy.kt`.

## 2) App Android

1. Instale o **Android Studio** (versão atual) e abra a pasta `android/`.
2. Deixe o Gradle sincronizar (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, compileSdk/targetSdk 35, minSdk 26).
   Se o Android Studio pedir, aceite instalar o SDK 35. Se faltar o `gradle-wrapper.jar`, rode uma vez `gradle wrapper --gradle-version 8.9`
   (ou deixe o Android Studio gerar).
3. **Build → Build APK(s)** (ou ▶ num celular com depuração USB). O APK sai em `android/app/build/outputs/apk/`.
4. No app: **Configurações → IA / Diagnóstico**, informe o endereço do backend (ex.: `http://192.168.0.10:8787` na rede local,
   ou `https://...`) e o token, toque em **Salvar e verificar** e depois em **TESTAR CONEXÃO COM A IA**.

Se o build acusar erros de compilação, copie a mensagem e me mande: o código nunca foi compilado por mim.

### Permissões e para que servem

| Permissão | Uso |
|---|---|
| Microfone | ouvir "Kupa" e seus comandos |
| Aparecer sobre outros apps | Popol flutuante (sem ela, o Popol aparece só dentro do app) |
| Notificações / serviço em primeiro plano | o Android exige o aviso fixo para manter microfone/overlay ativos |
| Captura de tela (aviso oficial do Android) | só quando você iniciar a captura; sem "burlar" nada |
| Alarme/timer | ferramenta `start_timer` |
| Vibração | confirmação discreta no Modo Gamer |

### Como o fluxo funciona

`Esperando → (você diz "Kupa") Ativado → Ouvindo → Pensando → [Pesquisando | Analisando tela | Traduzindo | Lendo | Executando comando] → Falando → Concluído → Esperando.`
Depois de responder o KUPA **não** continua ouvindo: para outra pergunta, chame "Kupa" de novo.
Erros mostram o estado **Erro** com mensagem clara e voltam a **Esperando** sozinhos.

### Troca dos visuais (sem reconstruir o app)

- Visuais atuais: `res/drawable-nodpi/state_XX_nome.webp` (Popol + Kupa juntos).
- Para trocar: coloque os PNGs novos numa pasta com os mesmos nomes e rode
  `python3 tools/prepare_sprites.py <pasta> android/app/src/main/res/drawable-nodpi` (padroniza tamanho e alinhamento).
- **Kupa animando sozinho:** adicione, por estado, `popol_XX_nome.webp` (só o Popol) **e** `kupa_XX_nome.webp` (só o lobo)
  na mesma pasta. O app detecta e liga as duas camadas independentes automaticamente.

## 3) Modo Gamer — o que dá e o que não dá (Android)

- "Kupa, ativar modo gamer": o Popol e o Kupa **somem da tela**, mas o núcleo, a IA, a pesquisa e as ferramentas continuam. Você ainda chama "Kupa" e recebe a resposta por voz.
  "Kupa, desativar modo gamer" traz tudo de volta (posição, tamanho e transparência restaurados).
- **Limites reais do Android (não dá para contornar):**
  - Escuta contínua do microfone gasta bateria e **briga com o microfone do jogo/chat de voz**. Há a opção "Só no botão Falar" (notificação) para esses casos.
  - O reconhecedor de voz do Android pode tocar um "bip" a cada reinício em alguns aparelhos.
  - O KUPA **não escuta enquanto fala** (para não ouvir a si mesmo): durante a resposta não dá para interromper por voz.
  - Jogos que bloqueiam captura de tela (FLAG_SECURE) devolvem tela preta: o KUPA detecta e **avisa** que a análise visual está indisponível, sem inventar.
  - Alguns fabricantes matam serviços em segundo plano: desative a otimização de bateria para o KUPA.
  - O KUPA nunca presume qual jogo está aberto: usa o que você disse ("estou jogando de Popol") ou o que a tela mostrou.

## 4) Desktop

**Não foi implementado.** O que já está pronto para isso: o backend e o protocolo (`/v1/ai/respond`) não dependem do Android,
e `AiProvider` isola o provedor. Caminho sugerido: Tauri reaproveitando os WebP dos estados, repetindo `KupaCore` em TypeScript/Rust.

## 5) O que ainda falta / não existe

- Compilar e testar o app num aparelho real (nunca rodou).
- Chamada real à OpenAI com a sua chave.
- Camadas separadas do Kupa (precisam dos arquivos).
- Ferramentas `translate`, `readScreen`, `saveMemory`, `getMemory`, `getCurrentApp`: **não existem como ferramentas separadas**.
  Traduzir/ler a tela já acontece pela `analyze_screen` (o modelo lê e traduz a imagem). Memória de longo prazo foi evitada de propósito.
- Voz: usa o TTS do Android; não há voz "personalizada" além de tom/velocidade.
- Pesquisa e raciocínio dependem do modelo que você escolher; se ele não aceitar imagem, a análise de tela falhará e o app mostrará o erro da OpenAI.

## Ferramentas de apoio

- `tools/prepare_sprites.py` — padroniza os 15 estados.
- `tools/check_android.py` — checagem estática do Kotlin (`python3 tools/check_android.py`).
