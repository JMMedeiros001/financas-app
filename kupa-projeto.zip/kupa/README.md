# KUPA — assistente pessoal com o Popol e o lobo Kupa

Aplicativo Android (prioridade) + backend seguro. A IA vem da **API oficial da OpenAI** (Responses API), sempre pelo
backend: **a chave da OpenAI nunca vai para o app**.

> **Estado honesto deste projeto (leia primeiro):**
>
> | Parte | Situação |
> |---|---|
> | Backend (Node) | **Escrito e testado**: 26 testes automáticos passam contra um servidor OpenAI *falso* (só nos testes). A chamada à OpenAI **de verdade ainda não foi feita aqui** (precisa da sua chave). Pronto para Render/Railway (`render.yaml`, `README_BACKEND.md`). |
> | Camada de intenções (Java puro) | **Testada de verdade**: 138 verificações passam (`python3 tools/run_intent_tests.py`): abrir app, ligar, chamadas recebidas, sequências, aprendizado, escolhas sim/não. |
> | App Android (Kotlin) | **Escrito, mas NÃO compilado por mim**: neste ambiente não há Kotlin/Android SDK nem rede. Passou numa checagem estática (`tools/check_android.py`), que **não substitui compilar**. **Nenhum APK foi gerado por mim** e **não testei em aparelho**. Quem compila é o seu GitHub Actions. |
> | Ações no celular (abrir app, ligar, atender…) | Código escrito com as APIs oficiais do Android, **nunca executado num aparelho**. Cada resposta só diz o que o Android confirmou (ver "Controle do celular"). |
> | Visuais | 15 estados do Popol + Kupa prontos (PNG transparente → WebP padronizado em `res/drawable-nodpi`). |
> | Desktop | **Não implementado**. |
> | Kupa animando separado do Popol | **Preparado, mas inativo**: os 15 visuais trazem os dois juntos. |

## Arquitetura

```
 USUÁRIO ─voz/texto─▶ APP ANDROID (Kotlin, sem bibliotecas externas)
                        ├─ Popol + Kupa (PopolView: camada Popol + camada Kupa)
                        ├─ StateManager (15 estados) ── PopolAnimationController / KupaAnimationController
                        ├─ KUPA CORE (KupaCore): decide, controla ferramentas, estados, resposta
                        │    ├─ CommandRouter (comandos locais: modo gamer, contexto do jogo, cancelar)
                        │    ├─ ToolRegistry (analyze_screen, start_timer) ← só o que o usuário autorizou
                        │    └─ AiOrchestrator → AiProvider (interface) → KupaBackendProvider
                        ├─ Voz: SpeechRecognizer (ouvir) + TextToSpeech (falar)
                        ├─ Tela: MediaProjection (captura autorizada)
                        └─ Histórico (SQLite), Configurações, Diagnóstico da IA
                                   │ HTTPS + token do app
                                   ▼
                        BACKEND KUPA (Node 20+, sem dependências)
                          AIService ─▶ OpenAIProvider ─▶ API oficial da OpenAI (POST /v1/responses)
                          (chave só aqui: OPENAI_API_KEY)
```

**Por que Kotlin nativo (decisão técnica):** o pedido exige sobreposição sobre outros apps, captura de tela
(MediaProjection), reconhecimento/síntese de voz e serviço em primeiro plano. Tudo isso é API nativa do Android;
Flutter/React Native precisariam de módulos nativos para cada uma. O app **não usa nenhuma biblioteca externa**
(só Android SDK + Kotlin): menos coisa para quebrar no build.

**Por que backend sem dependências:** só Node 20+ (`fetch` embutido). Nada para `npm install`.

### Mapa do pedido → onde está

| Pedido | Arquivo |
|---|---|
| 15 estados exatos | `core/KupaState.kt` |
| StateManager | `core/StateManager.kt` |
| Popol / Kupa independentes | `character/PopolView.kt`, `LayerAnimator.kt` (`PopolAnimationController`, `KupaAnimationController`), `AnimationMath.kt` |
| KupaCore | `core/KupaCore.kt` |
| Palavra de ativação "Kupa" (+ "cupa", "culpa" com regras) | `core/WakeWord.kt`, `voice/VoiceController.kt` |
| Voz (ligar/desligar), TTS | `voice/*`, `settings/Settings.kt` |
| AIService / OpenAIProvider | `backend/src/services/aiService.js`, `backend/src/providers/openaiProvider.js` (app: `ai/AiProvider.kt`) |
| Ferramentas controladas pelo núcleo | `backend/src/tools/registry.js`, `tools/KupaTools.kt`, `ai/AiOrchestrator.kt` |
| Pesquisa na internet | ferramenta oficial `web_search` da OpenAI, ligada pelo backend |
| Análise de tela | `screen/ScreenCaptureManager.kt`, `screen/ScreenPermissionActivity.kt` |
| Modo Gamer | `gamer/GamerModeController.kt`, `core/KupaCore.kt`, `overlay/OverlayController.kt`, `ui/SettingsActivity.kt` |
| Contexto de jogo | `game/GameContextService.kt` |
| Popol flutuante, menu, arrastar | `overlay/OverlayController.kt`, `overlay/KupaService.kt` |
| Histórico (VOICE/TEXT/SEARCH/SCREEN_ANALYSIS/GAMER) | `history/HistoryDb.kt`, `ui/HistoryActivity.kt` |
| Tela de diagnóstico + teste real | `ui/DiagnosticsActivity.kt`, `ai/KupaBackendClient.kt`, `POST /v1/ai/test` |
| Logs sem segredos | `core/KupaLog.kt`, `backend/src/logger.js` |


## Controle do celular (o que foi implementado)

**Arquitetura: a IA interpreta, o Android executa, nada é arbitrário.**

```
voz/texto ─▶ atalhos aprendidos ─▶ INTERPRETADOR (intent = OPEN_APP / CALL_CONTACT / ANSWER_CALL …)
                                        │ intenção estruturada e validada
                                        ▼
                                  CommandCenter ─▶ ActionExecutor (Android) ─▶ ação real
                                        ▲
IA (OpenAI via backend) ── só pode pedir as ferramentas open_app / call_contact / incoming_call,
                           que passam pelo MESMO executor e SEMPRE pedem confirmação.
```
Frases claras (ex.: "abra o WhatsApp") são entendidas **no aparelho**, sem IA e sem enviar nada ao backend.
Frases que o interpretador não entende vão para a IA; ela pode chamar uma ferramenta, mas quem decide, valida e executa é o app.

### Dois modos de escuta (Configurações → Modo de escuta)

| | Ativação por "Kupa" (padrão) | Escuta contínua |
|---|---|---|
| Como funciona | espera "Kupa" (ou "cupa"/"culpa" no começo da frase ou depois de "oi"/"ei"), ouve **um** comando e volta a aguardar | cada frase é avaliada; vira ação só se for um **comando de celular reconhecido** (ou resposta a uma pergunta do KUPA, ou "Kupa, …") |
| Ex. | "Kupa, abra o WhatsApp." | "Abra o WhatsApp." … "Agora abra o Mobile Legends." … "Ligue para Dudu." |
| Conversa solta | — | **ignorada** (não vai à IA), a menos que você ligue "Frases soltas também vão para a IA" |
| Ligações | seguem a regra de confirmação | **sempre pedem confirmação** se você não disse "Kupa" antes (para a TV ou uma conversa não discar por você) |

Cuidados de bateria e privacidade: só escuta quando o KUPA está em espera; **pausa com a tela desligada** (opção); **pausa sozinho** após X minutos sem comandos (padrão 10; 0 = nunca); botão **Pausar/Retomar** na notificação; prefere reconhecimento **no aparelho** (opção); nenhum áudio vai ao backend do KUPA (só texto, e só o necessário).
**Limites do Android:** o microfone em segundo plano exige o serviço em primeiro plano com a notificação fixa; a escuta contínua gasta bateria e pode brigar com o microfone de outros apps/jogos; o reconhecedor do Android pode "bipar" ao reiniciar; o KUPA não escuta enquanto fala.

### Comandos

| Você diz | O que acontece (de verdade) |
|---|---|
| "abra o WhatsApp / YouTube / Mobile Legends / qualquer app" | procura **entre os apps instalados** (sem lista fixa), abre o app (`PackageManager`). Não achou: "Não encontrei esse aplicativo instalado." Dois parecidos: pergunta qual. |
| "abra a câmera / as configurações / o discador" | abre o app padrão do Android correspondente |
| "ligue para Dudu", "faça uma ligação para…", "chame…", "telefone para…" | acha o contato (Contatos), pega o número **real** (nunca inventa), e liga com `TelecomManager` |
| vários "Dudu" | "Encontrei 2 contatos parecidos com Dudu: … Qual deles?" (responda "o primeiro", "o do trabalho"…) |
| "quem está me ligando?" | diz o nome do contato (ou "número desconhecido", ou que falta permissão) |
| "atende" / "recusa" / "desliga a ligação" | `acceptRingingCall()` / `endCall()` (Android 9+ para recusar) |
| "deixa tocar" / "deixa chamar até cair" / "não atende" | **não faz nada** (o Android não deixa um app silenciar o toque): só confirma que vai deixar tocar |
| "abra o WhatsApp e depois o jogo", "abra X e abra Y" | executa em sequência; se uma parte falha ou pede confirmação, **para** e avisa |
| "abra a conversa com Dudu" | abre a conversa **no WhatsApp** (linha de dados do contato). Outros apps: não suportado, e o KUPA diz isso |
| "ligue para ele/ela", "atende" | usa o **contexto** (último contato / chamada atual). Sem contexto, pergunta; não inventa |

**Honestidade das respostas.** "Ligando…/Abri…" só quando o Android/serviço de acessibilidade confirmou (estado da chamada ou app em primeiro plano).
Quando não dá para confirmar: "Pedi ao Android para abrir…". Sem permissão: diz qual permissão falta.
**Abrir apps em segundo plano:** o Android (10+) só deixa um app iniciar telas quando tem a permissão "Aparecer sobre outros apps" **ou** o serviço de acessibilidade ligado **ou** está aberto. Sem nenhuma delas o KUPA **não finge**: deixa uma notificação "Toque para abrir".

### Confirmação de ações sensíveis (Configurações → Ações sensíveis)
- **Confirmar** (padrão): "Encontrei Dudu. Quer que eu faça a ligação?" → "sim" / "não".
- **Executar direto**: liga sem perguntar (as proteções do Android continuam). **Abrir apps** é sempre direto.
- **Sempre pergunta**, mesmo em "direto": nome só *parecido* ("Maria" → "Mariana"), pedido **vindo da IA**, e voz solta no modo contínuo.
- Atender/recusar **não** pedem confirmação (têm hora para acontecer e você mandou explicitamente).

### Comandos aprendidos
- Por voz: "Kupa, quando eu disser 'chama Dudu', quero dizer ligar para Dudu." / "Quando eu falar 'abre o jogo', estou falando do Mobile Legends." / "Quando eu disser zap, estou falando do WhatsApp."
- O KUPA **repete o que entendeu e pede confirmação** antes de salvar. Nada muda em silêncio.
- Comandos de controle (atender, recusar, desligar, ignorar, sim/não, aprender) **não podem ser redefinidos**.
- "Esqueça o comando abre o jogo" remove; "quais comandos eu ensinei" lista.
- Configurações → **Comandos aprendidos**: ver, **editar**, **remover**, adicionar. Ficam no aparelho, **cifrados com o Android Keystore**.

### Permissões (só o necessário, cada uma com o motivo na tela)

| Permissão | Para quê | Obrigatória? |
|---|---|---|
| Microfone | ouvir "Kupa" e comandos | para voz |
| Notificações | aviso fixo do serviço | sim (Android 13+) |
| Contatos | achar o número de quem ligar / abrir conversa / nome de quem liga | para ligar |
| Ligações (`CALL_PHONE`) | ligar | para ligar direto (sem ela, abre o discador) |
| Atender chamadas (`ANSWER_PHONE_CALLS`) | atender / recusar / desligar | para atender e recusar |
| Estado do telefone (`READ_PHONE_STATE`) | saber se está tocando / confirmar ação | recomendada |
| Registro de chamadas (`READ_CALL_LOG`) | **só** ver o número de quem liga | opcional |
| Aparecer sobre outros apps | Popol flutuante e abrir apps em segundo plano | opcional |
| Acessibilidade | **opcional**: confirmar qual app abriu | opcional |

### Serviço de acessibilidade — foi necessário?
**Não é necessário** para nenhum comando. Está disponível como **opcional** e é **mínimo**: só recebe o evento "qual app veio para a frente"
(`canRetrieveWindowContent=false`), **não lê a tela, não toca em nada, não executa ações**. Serve para o KUPA dizer "Abri o WhatsApp" com certeza e ajuda o Android a permitir abrir apps em segundo plano.
Como ativar: Configurações do Android → Acessibilidade → KUPA. **Android 13+ com APK instalado fora da loja:** antes, Informações do app → ⋮ → "Permitir configurações restritas". Para desligar: o mesmo caminho. 

### Limites reais (não dá para contornar)
- Ligar/atender/recusar dependem das permissões acima; "recusar" exige Android 9+. O Android não deixa app silenciar o toque ("deixa tocar" só confirma).
- O **número de quem liga** só aparece com `READ_CALL_LOG`; sem ele o KUPA diz que não tem permissão (não diz "desconhecido").
- Com a ligação tocando, o toque atrapalha o reconhecimento de voz: pode ser preciso repetir.
- Abrir conversa direto só no WhatsApp (e WhatsApp Business). Ligar pelo WhatsApp/vídeo **não** é suportado (o KUPA não entende o pedido em vez de ligar para a pessoa errada).
- Android 15 pode exigir uma janela visível para a exceção de "aparecer sobre outros apps": por isso a acessibilidade é a alternativa.

## GitHub Actions

O workflow **não foi alterado** (eu não tenho acesso ao seu repositório). Ele continua precisando de: JDK 17, Gradle 8.9, SDK Android 35 e gera `android/app/build/outputs/apk/debug/app-debug.apk`.
O que mudou no build: `android/kupa.properties` (URL do backend, **vazia** por padrão: o build **não falha**, só avisa) e `buildFeatures.buildConfig = true`.
O build **só falha** se `KUPA_BACKEND_URL` estiver preenchida com algo inválido (para você não gerar um APK com URL quebrada).
URL pela linha de comando/CI sem editar arquivo: `KUPA_BACKEND_URL=https://... gradle assembleDebug` ou `env:` no workflow.

## 1) Backend

Requisitos: Node 20 ou mais novo.

```bash
cd backend
cp .env.example .env      # preencha OPENAI_API_KEY, OPENAI_MODEL e KUPA_APP_TOKEN
npm test                  # 24 testes (não usam a OpenAI de verdade)
npm start                 # escuta em 0.0.0.0:8787
```

Variáveis (`backend/.env`, que **nunca** deve ir para o GitHub):

| Variável | Para quê |
|---|---|
| `OPENAI_API_KEY` | chave secreta da OpenAI (só existe aqui) |
| `OPENAI_MODEL` | modelo usado. **Sem valor padrão de propósito**; troque sem mexer em código. Use um modelo atual da lista oficial da OpenAI que aceite imagem e busca na web. |
| `KUPA_APP_TOKEN` | senha compartilhada app ↔ backend (gere uma longa e aleatória) |
| outras | ver comentários no `.env.example` (timeout, `store`, busca na web, limites…) |

Rotas: `GET /health` (sem login) · `GET /v1/config` · `POST /v1/ai/test` (chamada real à OpenAI) · `POST /v1/ai/respond`.

Verificação rápida depois de configurar:
```bash
curl localhost:8787/health
curl -H "Authorization: Bearer SEU_TOKEN" -X POST localhost:8787/v1/ai/test
```

**Publicar:** para usar fora de casa, coloque o backend atrás de **HTTPS** (Render, Fly.io, Railway, um VPS com Caddy…).
Configure as variáveis no painel do serviço (variáveis secretas), nunca no código.

**Segurança — limites que você precisa conhecer**
- O `KUPA_APP_TOKEN` fica dentro do app, então alguém que extraia o APK consegue pegá-lo. Ele **impede uso casual**,
  não é autenticação forte. Para uso pessoal serve; para distribuir a outras pessoas, troque por login/token por aparelho.
- O backend limita requisições por minuto (padrão 60) e tamanho do corpo (8 MB), mas **defina um limite de gasto na sua conta da OpenAI**.
- O app só aceita HTTP puro para endereços de rede local; qualquer outro endereço precisa ser HTTPS.
  O manifesto libera cleartext por causa da rede local; a regra de verdade está em `ai/BackendUrlPolicy.kt`.

## 2) App Android

1. Instale o **Android Studio** (versão atual) e abra a pasta `android/`.
2. Deixe o Gradle sincronizar (usa Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, compileSdk/targetSdk 35, minSdk 26).
   Se o Android Studio pedir, aceite instalar o SDK 35. Se faltar o `gradle-wrapper.jar`, rode uma vez `gradle wrapper --gradle-version 8.9`
   (ou deixe o Android Studio gerar).
3. **Build → Build APK(s)** (ou ▶ num celular com depuração USB). O APK sai em `android/app/build/outputs/apk/`.
4. No app: **Configurações → IA / Diagnóstico**, informe o endereço do backend (ex.: `http://192.168.0.10:8787` na rede local,
   ou `https://...`) e o token, toque em **Salvar e verificar** e depois em **TESTAR CONEXÃO COM A IA**.

Se o build acusar erros de compilação, copie a mensagem e me mande: o código nunca foi compilado por mim.

### Permissões e para que servem

| Permissão | Uso |
|---|---|
| Microfone | ouvir "Kupa" e seus comandos |
| Aparecer sobre outros apps | Popol flutuante (sem ela, o Popol aparece só dentro do app) |
| Notificações / serviço em primeiro plano | o Android exige o aviso fixo para manter microfone/overlay ativos |
| Captura de tela (aviso oficial do Android) | só quando você iniciar a captura; sem "burlar" nada |
| Alarme/timer | ferramenta `start_timer` |
| Vibração | confirmação discreta no Modo Gamer |

### Como o fluxo funciona

`Esperando → (você diz "Kupa") Ativado → Ouvindo → Pensando → [Pesquisando | Analisando tela | Traduzindo | Lendo | Executando comando] → Falando → Concluído → Esperando.`
Depois de responder o KUPA **não** continua ouvindo: para outra pergunta, chame "Kupa" de novo.
Erros mostram o estado **Erro** com mensagem clara e voltam a **Esperando** sozinhos.

### Troca dos visuais (sem reconstruir o app)

- Visuais atuais: `res/drawable-nodpi/state_XX_nome.webp` (Popol + Kupa juntos).
- Para trocar: coloque os PNGs novos numa pasta com os mesmos nomes e rode
  `python3 tools/prepare_sprites.py <pasta> android/app/src/main/res/drawable-nodpi` (padroniza tamanho e alinhamento).
- **Kupa animando sozinho:** adicione, por estado, `popol_XX_nome.webp` (só o Popol) **e** `kupa_XX_nome.webp` (só o lobo)
  na mesma pasta. O app detecta e liga as duas camadas independentes automaticamente.

## 3) Modo Gamer — o que dá e o que não dá (Android)

- "Kupa, ativar modo gamer": o Popol e o Kupa **somem da tela**, mas o núcleo, a IA, a pesquisa e as ferramentas continuam. Você ainda chama "Kupa" e recebe a resposta por voz.
  "Kupa, desativar modo gamer" traz tudo de volta (posição, tamanho e transparência restaurados).
- **Limites reais do Android (não dá para contornar):**
  - Escuta contínua do microfone gasta bateria e **briga com o microfone do jogo/chat de voz**. Há a opção "Só no botão Falar" (notificação) para esses casos.
  - O reconhecedor de voz do Android pode tocar um "bip" a cada reinício em alguns aparelhos.
  - O KUPA **não escuta enquanto fala** (para não ouvir a si mesmo): durante a resposta não dá para interromper por voz.
  - Jogos que bloqueiam captura de tela (FLAG_SECURE) devolvem tela preta: o KUPA detecta e **avisa** que a análise visual está indisponível, sem inventar.
  - Alguns fabricantes matam serviços em segundo plano: desative a otimização de bateria para o KUPA.
  - O KUPA nunca presume qual jogo está aberto: usa o que você disse ("estou jogando de Popol") ou o que a tela mostrou.

## 4) Desktop

**Não foi implementado.** O que já está pronto para isso: o backend e o protocolo (`/v1/ai/respond`) não dependem do Android,
e `AiProvider` isola o provedor. Caminho sugerido: Tauri reaproveitando os WebP dos estados, repetindo `KupaCore` em TypeScript/Rust.

## 5) O que ainda falta / não existe

- Compilar e testar o app num aparelho real (nunca rodou).
- Chamada real à OpenAI com a sua chave.
- Camadas separadas do Kupa (precisam dos arquivos).
- Ferramentas `translate`, `readScreen`, `saveMemory`, `getMemory`, `getCurrentApp`: **não existem como ferramentas separadas**.
  Traduzir/ler a tela já acontece pela `analyze_screen` (o modelo lê e traduz a imagem). Memória de longo prazo foi evitada de propósito.
- Voz: usa o TTS do Android; não há voz "personalizada" além de tom/velocidade.
- Pesquisa e raciocínio dependem do modelo que você escolher; se ele não aceitar imagem, a análise de tela falhará e o app mostrará o erro da OpenAI.

## Ferramentas de apoio

- `tools/prepare_sprites.py` — padroniza os 15 estados.
- `tools/check_android.py` — checagem estática do Kotlin/Java (`python3 tools/check_android.py`).
- `tools/run_intent_tests.py` — compila e roda os testes da camada de intenções (Java puro).
- `README_BACKEND.md` — instalar, testar e publicar o backend; onde colocar a URL.
