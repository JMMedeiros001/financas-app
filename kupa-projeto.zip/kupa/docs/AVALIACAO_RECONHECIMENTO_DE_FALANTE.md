# Avaliação: reconhecimento de falante no KUPA

**Conclusão (honesta): NÃO foi integrado nenhum mecanismo de reconhecimento de falante. A funcionalidade está DESATIVADA e a arquitetura preparatória está marcada como INDISPONÍVEL.**
Não existe tela de "Vozes autorizadas" porque ela seria um botão sem função. Nada nesta pasta afirma que o KUPA reconhece pessoas.

## Três coisas diferentes
| Função | O que faz | Situação no KUPA |
|---|---|---|
| Reconhecimento de **fala** | transforma áudio em palavras | existe (`SpeechRecognizer` do Android). Não identifica ninguém |
| Reconhecimento de **falante** | estima se a voz bate com um perfil cadastrado | **indisponível** (ver abaixo) |
| **Autenticação** | reúne evidência suficiente para autorizar algo protegido | a voz **nunca** autentica; ações HIGH/CRITICAL usam confirmações e a tela de credencial do aparelho |

## O que existe no Android
O Android não tem API oficial de verificação de falante. Qualquer solução exige um **modelo de embeddings de voz** embutido (ou um servidor).

## Alternativas reais avaliadas (por documentação pública; nada foi baixado nem executado aqui)
| Opção | O que é | Prós | Contras / riscos |
|---|---|---|---|
| **sherpa-onnx** (k2-fsa) | biblioteca Apache-2.0 com identificação e verificação de falante, com versão para Android, offline (onnxruntime) | roda local (privacidade), tem exemplos de APK para Android, licença do código permissiva | bibliotecas **nativas** (`.so`) e modelos de dezenas de MB; a própria documentação diz para **conferir a licença de cada modelo** |
| Modelos **3D-Speaker** (CAM++, ERes2Net) | embeddings de voz | listados como Apache-2.0 | treinados em dados de falantes de inglês/chinês; **sem medição em português do Brasil** |
| Modelos **WeSpeaker** | embeddings de voz (ResNet, CAM++, ECAPA) | boa disponibilidade | licença **varia por modelo** (há variantes CC-BY-4.0, que exigem atribuição) |
| NVIDIA **TitaNet** | embeddings de voz | modelo conhecido | licença CC-BY-4.0 (atribuição) e tamanho maior (dezenas a ~100 MB) |
| Serviço em nuvem | verificação por API | menos peso no app | **envia áudio biométrico** a terceiros: exige consentimento, LGPD, contrato; contraria a prioridade de processamento local |

## Por que NÃO integrei agora
1. **Sem rede e sem SDK Android neste ambiente**: não consigo baixar a biblioteca nem os modelos, nem compilar, nem rodar num aparelho. Adicionar uma dependência nativa às cegas poderia quebrar o seu build no GitHub Actions.
2. **Precisão desconhecida** para português do Brasil, microfone de celular e ruído real. Sem medir taxa de falsa aceitação/falsa rejeição com gravações reais, qualquer limiar seria um número inventado.
3. **Nenhuma proteção contra gravação reproduzida/voz sintética** (detecção de apresentação fraudulenta) vem com esses pacotes. Voz não pode ser a única proteção para nada sensível.
4. **Peso e escrutínio**: código nativo + modelos aumentam o APK e o escrutínio de instalação.
5. **Licenças por modelo** precisam ser escolhidas e documentadas antes de distribuir.

## O que já está pronto (e testado)
`voice/VoiceVerification.java`: interface `SpeakerVerifier`, resultados sem falsa certeza (`PROBABLE_MATCH`, `NOT_RECOGNIZED`, `INSUFFICIENT_SAMPLE`, `INCONCLUSIVE`, `UNAVAILABLE`, `TECHNICAL_FAILURE`) e a única implementação, `UnavailableSpeakerVerifier`, que **sempre** responde `UNAVAILABLE`.
Regra fixa testada: **nenhum resultado concede permissão** (`grantsAnyPermission` é sempre falso) e a política de segurança trata voz como não verificada: CRÍTICO exige a confirmação do aparelho, ALTO exige duas confirmações, e a voz não tira o KUPA do modo seguro.

## Plano para integrar de verdade (próxima etapa, com rede e SDK)
1. Escolher um modelo com licença clara (preferência: Apache-2.0, ex.: 3D-Speaker CAM++) e registrar a atribuição quando a licença exigir.
2. Adicionar a biblioteca (sherpa-onnx) como dependência verificada e compilar no CI; medir tamanho do APK.
3. Gravar um conjunto de teste **em português, com os microfones reais** (vozes cadastradas, outras vozes, ruído, gravação reproduzida) e **medir** falsa aceitação e falsa rejeição para só então fixar o limiar (não inventar).
4. Cadastro com **consentimento explícito da própria pessoa**: explicar finalidade, onde processa (no aparelho), como protege (embedding cifrado com o Android Keystore; sem guardar áudio bruto), por quanto tempo guarda e como apagar. Frases de cadastro, validação de qualidade da amostra, teste e exclusão.
5. Resultado sempre probabilístico; **nunca** autoriza sozinho. Em falha ou indisponibilidade: sem permissões extras e oferecer a autenticação alternativa do aparelho.
6. Sem sincronização de perfis biométricos entre aparelhos; sem uso para outra finalidade; apagar tudo ao desativar.
7. Testes: cadastro válido, sem consentimento, amostra ruim, voz cadastrada, voz desconhecida, inconclusivo, modelo indisponível, exclusão, revogação, falha no meio; mais testes de resistência a gravação reproduzida (os limites que não puderem ser testados devem ser documentados).
