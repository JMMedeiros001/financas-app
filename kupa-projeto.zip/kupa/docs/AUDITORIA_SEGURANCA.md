# Auditoria de segurança do KUPA (gerada automaticamente)

> Gerada por `python3 tools/audit_security.py` a partir do código. É uma **análise estática**: não executa o app, não prevê o Play Protect e não prova que o app é seguro. Aponta sinais reais e o que foi feito sobre eles.

## 1. Sinais que o Play Protect usa para bloquear a instalação (piloto anti-fraude)

Em países como o Brasil, o Play Protect bloqueia a instalação de APKs obtidos **fora da loja** (navegador, mensageiro, gerenciador de arquivos) quando o manifesto declara **RECEIVE_SMS, READ_SMS, serviço de leitura de notificações ou serviço de acessibilidade**. A mensagem é do tipo "Este app pode pedir acesso a dados sensíveis".

Nenhum desses itens está declarado no manifesto atual. Isso **não garante** que o Play Protect aceite o APK (ele também usa outros sinais e a reputação do app), mas remove o gatilho documentado.

Outras permissões **sensíveis** declaradas (não estão no gatilho documentado, mas aumentam o escrutínio): `RECORD_AUDIO`, `SYSTEM_ALERT_WINDOW`, `READ_CONTACTS`, `CALL_PHONE`, `ANSWER_PHONE_CALLS`, `READ_PHONE_STATE`, `READ_CALL_LOG`.

## 2. Permissões: uso real, finalidade, necessidade e alternativa

| Permissão | Nível | Onde é usada no código | Finalidade | Alternativa menos privilegiada | Decisão |
|---|---|---|---|---|---|
| `INTERNET` | normal | com/kupa/assistant/ai/KupaBackendClient.kt:7, com/kupa/assistant/ai/KupaBackendClient.kt:44 | Falar com o backend do KUPA (HTTPS). | Nenhuma: o app precisa de rede. | mantida |
| `ACCESS_NETWORK_STATE` | normal | com/kupa/assistant/ai/NetworkChecker.kt:4, com/kupa/assistant/ai/NetworkChecker.kt:10 (+1) | Saber se há internet antes de consultar a IA (não fingir pesquisa offline). | Nenhuma melhor. | mantida |
| `RECORD_AUDIO` | perigosa | com/kupa/assistant/voice/SpeechInput.kt:8, com/kupa/assistant/voice/SpeechInput.kt:22 (+10) | Ouvir 'Kupa' e comandos de voz. | Sem alternativa para voz; o texto continua funcionando se negada. | mantida |
| `SYSTEM_ALERT_WINDOW` | especial | com/kupa/assistant/actions/ActionExecutor.kt:96, com/kupa/assistant/overlay/OverlayController.kt:75 (+4) | Popol flutuante e permissão do Android para abrir apps em segundo plano. | Opcional: sem ela o Popol fica só dentro do app e o KUPA deixa uma notificação para tocar. | mantida |
| `POST_NOTIFICATIONS` | perigosa | com/kupa/assistant/overlay/KupaService.kt:234, com/kupa/assistant/overlay/Notifications.kt:5 (+5) | Aviso fixo obrigatório do serviço em primeiro plano e respostas no modo gamer. | Nenhuma: o Android exige o aviso. | mantida |
| `VIBRATE` | normal | com/kupa/assistant/core/KupaCore.kt:7, com/kupa/assistant/core/KupaCore.kt:8 (+2) | Vibração curta ao ativar no modo gamer. | Poderia ser removida: é só conforto. | mantida |
| `FOREGROUND_SERVICE` | normal | com/kupa/assistant/overlay/KupaService.kt:82, com/kupa/assistant/overlay/KupaService.kt:95 (+9) | Manter microfone/overlay ativos de forma visível. | Nenhuma. | mantida |
| `FOREGROUND_SERVICE_MICROPHONE` | normal | com/kupa/assistant/overlay/KupaService.kt:213 | Tipo do serviço que ouve o microfone (Android 14+). | Nenhuma. | mantida |
| `FOREGROUND_SERVICE_MEDIA_PROJECTION` | normal | com/kupa/assistant/overlay/KupaService.kt:211 | Tipo do serviço durante a captura de tela autorizada (Android 14+). | Nenhuma. | mantida |
| `FOREGROUND_SERVICE_SPECIAL_USE` | normal | com/kupa/assistant/overlay/KupaService.kt:214 | Serviço quando o microfone ainda não foi concedido (Android 14+). | Poderia sair se o serviço só iniciasse com microfone concedido. | mantida |
| `com.android.alarm.permission.SET_ALARM` | normal | com/kupa/assistant/tools/KupaTools.kt:154 | Ferramenta 'temporizador'. | Sem ela o temporizador não funciona; poderia sair se a ferramenta saísse. | mantida |
| `READ_CONTACTS` | perigosa | com/kupa/assistant/actions/ContactResolver.kt:8, com/kupa/assistant/actions/ContactResolver.kt:25 (+17) | Achar o número de quem você pede para ligar e o nome de quem liga. | Sem alternativa para 'ligue para <nome>'. | mantida |
| `CALL_PHONE` | perigosa | com/kupa/assistant/actions/ActionExecutor.kt:206, com/kupa/assistant/actions/ActionExecutor.kt:209 (+3) | Ligar para o contato escolhido. | ACTION_DIAL (abre o discador, o usuário toca em ligar) já é o fallback. | mantida |
| `ANSWER_PHONE_CALLS` | perigosa | com/kupa/assistant/actions/ActionExecutor.kt:327, com/kupa/assistant/actions/PhoneActions.kt:54 (+2) | Atender/recusar por comando de voz. | Sem alternativa por voz. | mantida |
| `READ_PHONE_STATE` | perigosa | com/kupa/assistant/actions/CallStateTracker.kt:32, com/kupa/assistant/actions/CallStateTracker.kt:55 | Saber se uma chamada está tocando/em andamento e confirmar ações. | Sem ela o KUPA age às cegas (diz 'pedi ao Android'). | mantida |
| `READ_CALL_LOG` | perigosa | com/kupa/assistant/actions/ActionExecutor.kt:298, com/kupa/assistant/actions/CallStateTracker.kt:57 (+1) | Só para o Android entregar o NÚMERO de quem liga. | CallScreeningService (papel do sistema) daria o número sem esta permissão; hoje não implementado. | mantida |

## 3. Componentes

- Activities: 11; services: 1; receivers declarados no manifesto: 0; providers: 0.
- Componentes exportados: 1 (apenas a tela inicial, com o filtro LAUNCHER).
- Service `.overlay.KupaService`: exportado=não; tipos de primeiro plano: `microphone|mediaProjection|specialUse`.
- Receivers de broadcast: **registrados em código** (estado de chamadas e tela ligada/desligada) e só enquanto o serviço roda; nenhum receiver no manifesto (nada inicia sozinho ao ligar o aparelho: não há `RECEIVE_BOOT_COMPLETED`).

## 4. Acessibilidade, MediaProjection, microfone, câmera, SMS

- **AccessibilityService:** não existe no projeto.
- **MediaProjection:** usado (captura SOB DEMANDA, só depois do aviso oficial do Android; quadro descartado após enviar; ver `ScreenCaptureManager`). Não contorna FLAG_SECURE/DRM: quadro preto é detectado e informado.
- **Microfone:** `SpeechRecognizer` (reconhecimento do Android). O app **não grava nem guarda áudio** e nenhum áudio vai ao backend; só o texto reconhecido.
- **Câmera:** sem permissão de câmera (abrir o app de câmera usa o intent padrão do Android).
- **SMS:** nenhuma permissão de SMS.

## 5. Dependências e código nativo

- Bibliotecas de terceiros no app: **0** (nenhuma: só o SDK do Android e a stdlib do Kotlin).
- Código nativo/binários embutidos (.so/.aar/.jar): **0**.
- WebView: não usado. Analytics/crash/telemetria de terceiros: nenhum.

## 6. Rede e backend

- Endereços literais no código: 2.
  - `https://endereco.com  (BackendUrlValidator.java)`
  - `https://…  (DiagnosticsActivity.kt)`
- O único destino de rede do app é a **URL do backend** (BuildConfig.KUPA_BACKEND_URL ou a digitada pelo usuário). O app **não** fala direto com a OpenAI.
- `usesCleartextTraffic` no manifesto principal: `false`; `networkSecurityConfig`: não.

## 7. Segredos no projeto

Nenhum padrão de chave/segredo encontrado (busca por `sk-…` e atribuições de api_key/secret/token).
- `OPENAI_API_KEY` existe **somente** no backend (variável de ambiente). O APK não a contém nem a recebe.
- O token do app (`KUPA_APP_TOKEN`) é guardado **cifrado** (AES-GCM, chave no Android Keystore).

## 8. DEBUG e RELEASE

- minSdk 26, targetSdk 35.
- RELEASE: R8/minify=ligado; assinatura por variáveis de ambiente=sim; debuggable=não.
- DEBUG (o que o GitHub Actions gera hoje, `app-debug.apk`): assinado com a chave de debug **pública**, `debuggable=true`. Serve para testar, **não** para distribuir. Para distribuir gere o RELEASE com a SUA chave (ver README).
- `allowBackup`: false.

## 9. Logs

- Chamadas ao Logcat: 112 (todas dentro de `KupaLog`, que remove chaves, tokens, Bearer e imagens, e só escreve no Logcat em builds DEBUG).
- Telemetria: nenhuma. Nada é enviado a ninguém além do backend configurado, e só o texto da pergunta/contexto necessário (ver PrivacyGate).

## 10. Achados e gravidade

Nenhum achado nesta execução.

## 11. O que esta auditoria NÃO prova

- Não substitui compilar, testar em aparelho nem a análise do próprio Play Protect.
- Não detecta malware nem vulnerabilidades em dependências (não há dependências de terceiros para checar).
- Não consegue confirmar a causa real de um bloqueio: ela só aponta a causa **mais provável** com base na documentação pública do Google.
