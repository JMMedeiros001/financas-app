#!/usr/bin/env python3
"""Auditoria estática de segurança do APK/projeto KUPA (somente leitura).

Gera docs/AUDITORIA_SEGURANCA.md a partir do que EXISTE no código: manifesto, permissões e onde são usadas, componentes,
dependências, rede, segredos, build e logs. Não executa o app e NÃO consegue prever o Play Protect: só aponta sinais.
Uso:  python3 tools/audit_security.py [--out docs/AUDITORIA_SEGURANCA.md]
Saída diferente de zero se encontrar problema CRÍTICO (ex.: segredo no código, serviço/permissão do grupo que o Play Protect bloqueia).
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "android" / "app"
SRC = APP / "src" / "main" / "java"
MANIFEST = APP / "src" / "main" / "AndroidManifest.xml"
GRADLE = APP / "build.gradle.kts"
OUT = ROOT / "docs" / "AUDITORIA_SEGURANCA.md"
if "--out" in sys.argv:
    OUT = Path(sys.argv[sys.argv.index("--out") + 1])

# Permissões/componentes que o Play Protect (piloto anti-fraude em apps instalados fora da loja) usa para bloquear a instalação
PLAY_PROTECT_PILOT = {
    "android.permission.RECEIVE_SMS": "ler SMS (interceptar códigos)",
    "android.permission.READ_SMS": "ler SMS (interceptar códigos)",
    "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE": "ler notificações (interceptar códigos)",
    "android.permission.BIND_ACCESSIBILITY_SERVICE": "serviço de acessibilidade (ler/controlar a tela)",
}

# conhecimento sobre cada permissão: (nível, onde procurar no código, finalidade, alternativa menos privilegiada)
KNOWN = {
    "android.permission.INTERNET": ("normal", ["HttpURLConnection"], "Falar com o backend do KUPA (HTTPS).", "Nenhuma: o app precisa de rede."),
    "android.permission.ACCESS_NETWORK_STATE": ("normal", ["ConnectivityManager"], "Saber se há internet antes de consultar a IA (não fingir pesquisa offline).", "Nenhuma melhor."),
    "android.permission.RECORD_AUDIO": ("perigosa", ["SpeechRecognizer"], "Ouvir 'Kupa' e comandos de voz.", "Sem alternativa para voz; o texto continua funcionando se negada."),
    "android.permission.SYSTEM_ALERT_WINDOW": ("especial", ["TYPE_APPLICATION_OVERLAY", "canDrawOverlays"], "Popol flutuante e permissão do Android para abrir apps em segundo plano.", "Opcional: sem ela o Popol fica só dentro do app e o KUPA deixa uma notificação para tocar."),
    "android.permission.POST_NOTIFICATIONS": ("perigosa", ["NotificationManager"], "Aviso fixo obrigatório do serviço em primeiro plano e respostas no modo gamer.", "Nenhuma: o Android exige o aviso."),
    "android.permission.FOREGROUND_SERVICE": ("normal", ["startForeground"], "Manter microfone/overlay ativos de forma visível.", "Nenhuma."),
    "android.permission.FOREGROUND_SERVICE_MICROPHONE": ("normal", ["FOREGROUND_SERVICE_TYPE_MICROPHONE"], "Tipo do serviço que ouve o microfone (Android 14+).", "Nenhuma."),
    "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION": ("normal", ["FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION"], "Tipo do serviço durante a captura de tela autorizada (Android 14+).", "Nenhuma."),
    "android.permission.FOREGROUND_SERVICE_SPECIAL_USE": ("normal", ["FOREGROUND_SERVICE_TYPE_SPECIAL_USE"], "Serviço quando o microfone ainda não foi concedido (Android 14+).", "Poderia sair se o serviço só iniciasse com microfone concedido."),
    "android.permission.VIBRATE": ("normal", ["Vibrator", "VibrationEffect"], "Vibração curta ao ativar no modo gamer.", "Poderia ser removida: é só conforto."),
    "com.android.alarm.permission.SET_ALARM": ("normal", ["ACTION_SET_TIMER"], "Ferramenta 'temporizador'.", "Sem ela o temporizador não funciona; poderia sair se a ferramenta saísse."),
    "android.permission.READ_CONTACTS": ("perigosa", ["ContactsContract"], "Achar o número de quem você pede para ligar e o nome de quem liga.", "Sem alternativa para 'ligue para <nome>'."),
    "android.permission.CALL_PHONE": ("perigosa", ["placeCall"], "Ligar para o contato escolhido.", "ACTION_DIAL (abre o discador, o usuário toca em ligar) já é o fallback."),
    "android.permission.ANSWER_PHONE_CALLS": ("perigosa", ["acceptRingingCall", "endCall"], "Atender/recusar por comando de voz.", "Sem alternativa por voz."),
    "android.permission.READ_PHONE_STATE": ("perigosa", ["ACTION_PHONE_STATE_CHANGED"], "Saber se uma chamada está tocando/em andamento e confirmar ações.", "Sem ela o KUPA age às cegas (diz 'pedi ao Android')."),
    "android.permission.READ_CALL_LOG": ("perigosa", ["EXTRA_INCOMING_NUMBER", "canSeeCallNumbers"], "Só para o Android entregar o NÚMERO de quem liga.", "CallScreeningService (papel do sistema) daria o número sem esta permissão; hoje não implementado."),
    "android.permission.USE_BIOMETRIC": ("normal", ["BiometricPrompt"], "Autenticação nativa para ações críticas.", "Nenhuma melhor (API oficial)."),
}

SENSITIVE_RUNTIME = {"android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS", "android.permission.CALL_PHONE",
                     "android.permission.ANSWER_PHONE_CALLS", "android.permission.RECORD_AUDIO", "android.permission.READ_PHONE_STATE",
                     "android.permission.SYSTEM_ALERT_WINDOW"}

findings = []   # (gravidade, texto)


def read_all_sources():
    files = []
    for ext in ("*.kt", "*.java"):
        files += sorted(SRC.rglob(ext))
    return {f: f.read_text(encoding="utf-8") for f in files}


def grep(sources, needles):
    hits = []
    for f, text in sources.items():
        for i, line in enumerate(text.splitlines(), 1):
            s = line.strip()
            if s.startswith("//") or s.startswith("*") or s.startswith("/*"):
                continue
            if any(n in line for n in needles):
                hits.append(f"{f.relative_to(SRC)}:{i}")
    return hits


def main():
    sources = read_all_sources()
    man = MANIFEST.read_text(encoding="utf-8")
    gradle = GRADLE.read_text(encoding="utf-8")
    out = []
    w = out.append

    perms = re.findall(r'<uses-permission\s+android:name="([^"]+)"', man)
    services = re.findall(r'<service\b(.*?)(?:/>|</service>)', man, re.S)
    activities = re.findall(r'<activity\b([^>]*)>', man)
    receivers = re.findall(r'<receiver\b([^>]*)>', man)
    providers = re.findall(r'<provider\b([^>]*)>', man)

    w("# Auditoria de segurança do KUPA (gerada automaticamente)\n")
    w("> Gerada por `python3 tools/audit_security.py` a partir do código. É uma **análise estática**: não executa o app, "
      "não prevê o Play Protect e não prova que o app é seguro. Aponta sinais reais e o que foi feito sobre eles.\n")

    # ---- 1. Play Protect
    w("## 1. Sinais que o Play Protect usa para bloquear a instalação (piloto anti-fraude)\n")
    w("Em países como o Brasil, o Play Protect bloqueia a instalação de APKs obtidos **fora da loja** (navegador, mensageiro, gerenciador de arquivos) "
      "quando o manifesto declara **RECEIVE_SMS, READ_SMS, serviço de leitura de notificações ou serviço de acessibilidade**. "
      "A mensagem é do tipo \"Este app pode pedir acesso a dados sensíveis\".\n")
    triggers = []
    for p in perms:
        if p in PLAY_PROTECT_PILOT:
            triggers.append((p, PLAY_PROTECT_PILOT[p]))
    for s in services:
        m = re.search(r'android:permission="([^"]+)"', s)
        if m and m.group(1) in PLAY_PROTECT_PILOT:
            nm = re.search(r'android:name="([^"]+)"', s)
            triggers.append((f"{m.group(1)} (serviço {nm.group(1) if nm else '?'})", PLAY_PROTECT_PILOT[m.group(1)]))
    if "android.accessibilityservice.AccessibilityService" in man:
        triggers.append(("<service> de acessibilidade declarado", "serviço de acessibilidade"))
    if triggers:
        w("**ENCONTRADO no manifesto atual:**\n")
        for t, why in triggers:
            w(f"- `{t}` — {why}")
            findings.append(("CRÍTICO", f"Manifesto declara item do grupo que o Play Protect bloqueia em instalações fora da loja: {t}."))
        w("")
    else:
        w("Nenhum desses itens está declarado no manifesto atual. Isso **não garante** que o Play Protect aceite o APK (ele também usa outros sinais "
          "e a reputação do app), mas remove o gatilho documentado.\n")
    w("Outras permissões **sensíveis** declaradas (não estão no gatilho documentado, mas aumentam o escrutínio): " +
      (", ".join(f"`{p.split('.')[-1]}`" for p in perms if p in SENSITIVE_RUNTIME) or "nenhuma") + ".\n")

    # ---- 2. Permissões
    w("## 2. Permissões: uso real, finalidade, necessidade e alternativa\n")
    w("| Permissão | Nível | Onde é usada no código | Finalidade | Alternativa menos privilegiada | Decisão |")
    w("|---|---|---|---|---|---|")
    for p in perms:
        level, needles, purpose, alt = KNOWN.get(p, ("?", [], "SEM FINALIDADE DOCUMENTADA", "?"))
        hits = grep(sources, needles) if needles else []
        used = ", ".join(hits[:2]) + (f" (+{len(hits)-2})" if len(hits) > 2 else "")
        if p not in KNOWN:
            findings.append(("ALTO", f"Permissão sem finalidade documentada: {p}."))
            decision = "REVISAR"
        elif not hits and needles:
            findings.append(("MÉDIO", f"Permissão declarada mas sem uso encontrado no código: {p}."))
            decision = "REMOVER (sem uso)"
        else:
            decision = "mantida"
        w(f"| `{p.split('android.permission.')[-1]}` | {level} | {used or '—'} | {purpose} | {alt} | {decision} |")
    w("")

    # ---- 3. Componentes
    w("## 3. Componentes\n")
    w(f"- Activities: {len(activities)}; services: {len(services)}; receivers declarados no manifesto: {len(receivers)}; providers: {len(providers)}.")
    exported = [a for a in activities + [s for s in services] if 'android:exported="true"' in a]
    w(f"- Componentes exportados: {len(exported)} (apenas a tela inicial, com o filtro LAUNCHER).")
    for a in activities:
        if 'android:exported="true"' in a and "MainActivity" not in a:
            findings.append(("ALTO", "Activity exportada além da tela inicial."))
    for s in services:
        nm = re.search(r'android:name="([^"]+)"', s)
        ex = 'android:exported="true"' in s
        w(f"- Service `{nm.group(1) if nm else '?'}`: exportado={'sim' if ex else 'não'}; tipos de primeiro plano: "
          f"`{(re.search(r'foregroundServiceType=\"([^\"]+)\"', s) or [None, '—'])[1]}`.")
        if ex:
            findings.append(("ALTO", f"Service exportado: {nm.group(1) if nm else '?'}"))
    w("- Receivers de broadcast: **registrados em código** (estado de chamadas e tela ligada/desligada) e só enquanto o serviço roda; nenhum receiver no manifesto "
      "(nada inicia sozinho ao ligar o aparelho: não há `RECEIVE_BOOT_COMPLETED`).")
    if "RECEIVE_BOOT_COMPLETED" in man:
        findings.append(("ALTO", "RECEIVE_BOOT_COMPLETED declarado: o app iniciaria sozinho."))
    w("")

    # ---- 4. Serviços especiais
    w("## 4. Acessibilidade, MediaProjection, microfone, câmera, SMS\n")
    acc = "accessibilityservice" in man.lower() or "AccessibilityService" in "".join(sources.values())
    w(f"- **AccessibilityService:** {'PRESENTE' if acc else 'não existe no projeto'}.")
    w(f"- **MediaProjection:** {'usado (captura SOB DEMANDA, só depois do aviso oficial do Android; quadro descartado após enviar; ver `ScreenCaptureManager`)' if grep(sources, ['MediaProjection']) else 'não usado'}. "
      "Não contorna FLAG_SECURE/DRM: quadro preto é detectado e informado.")
    w(f"- **Microfone:** `SpeechRecognizer` (reconhecimento do Android). O app **não grava nem guarda áudio** e nenhum áudio vai ao backend; só o texto reconhecido.")
    w(f"- **Câmera:** {'permissão declarada' if 'permission.CAMERA' in man else 'sem permissão de câmera (abrir o app de câmera usa o intent padrão do Android)'}.")
    w(f"- **SMS:** {'permissão declarada' if re.search(r'SMS', man) else 'nenhuma permissão de SMS'}.\n")

    # ---- 5. Dependências
    w("## 5. Dependências e código nativo\n")
    deps_block = re.search(r'dependencies\s*\{(.*?)\n\}', gradle, re.S)
    deps = [l.strip() for l in (deps_block.group(1).splitlines() if deps_block else []) if l.strip() and not l.strip().startswith("//")]
    w(f"- Bibliotecas de terceiros no app: **{len(deps)}** {'(' + ', '.join(deps) + ')' if deps else '(nenhuma: só o SDK do Android e a stdlib do Kotlin)'}.")
    native = [p for p in APP.rglob("*") if p.suffix in (".so", ".aar", ".jar") and "build" not in p.parts]
    w(f"- Código nativo/binários embutidos (.so/.aar/.jar): **{len(native)}**.")
    w(f"- WebView: {'usado' if grep(sources, ['WebView']) else 'não usado'}. Analytics/crash/telemetria de terceiros: "
      f"{'ENCONTRADO' if grep(sources, ['Firebase', 'Crashlytics', 'Sentry', 'Analytics']) else 'nenhum'}.\n")

    # ---- 6. Rede
    w("## 6. Rede e backend\n")
    urls = set()
    for f, t in sources.items():
        for m in re.finditer(r'https?://[^\s"\')]+', t):
            urls.add(f"{m.group(0)}  ({f.name})")
    w(f"- Endereços literais no código: {len(urls)}.")
    for u in sorted(urls):
        w(f"  - `{u}` (exemplo/documentação)" if "exemplo" in u or "10.0.2.2" in u or "192.168" in u else f"  - `{u}`")
    w("- O único destino de rede do app é a **URL do backend** (BuildConfig.KUPA_BACKEND_URL ou a digitada pelo usuário). O app **não** fala direto com a OpenAI.")
    cleartext = re.search(r'usesCleartextTraffic="(\w+)"', man)
    w(f"- `usesCleartextTraffic` no manifesto principal: `{cleartext.group(1) if cleartext else 'não definido'}`; "
      f"`networkSecurityConfig`: {'sim' if 'networkSecurityConfig' in man else 'não'}.")
    if cleartext and cleartext.group(1) == "true":
        findings.append(("MÉDIO", "Tráfego sem criptografia (HTTP) liberado no manifesto principal (vale para release)."))
    w("")

    # ---- 7. Segredos
    w("## 7. Segredos no projeto\n")
    secret_hits = []
    for p in ROOT.rglob("*"):
        if not p.is_file() or ".git" in p.parts or "node_modules" in p.parts or p.suffix in (".webp", ".png", ".zip", ".patch", ".jar"):
            continue
        try:
            t = p.read_text(encoding="utf-8")
        except Exception:
            continue
        if re.search(r'sk-[A-Za-z0-9_-]{20,}', t) or re.search(r'(?i)(api[_-]?key|secret|token)\s*[:=]\s*["\'][A-Za-z0-9_\-]{24,}["\']', t):
            secret_hits.append(str(p.relative_to(ROOT)))
    if secret_hits:
        w("**POSSÍVEL SEGREDO em:** " + ", ".join(secret_hits))
        findings.append(("CRÍTICO", "Possível segredo no código: " + ", ".join(secret_hits)))
    else:
        w("Nenhum padrão de chave/segredo encontrado (busca por `sk-…` e atribuições de api_key/secret/token).")
    w("- `OPENAI_API_KEY` existe **somente** no backend (variável de ambiente). O APK não a contém nem a recebe.")
    plain_token = grep({f: t for f, t in sources.items() if f.name == "Settings.kt"}, ['StrPref(prefs, "appToken"'])
    if plain_token:
        w("- ⚠ O token do app (`KUPA_APP_TOKEN`) é guardado em SharedPreferences **sem cifra**.")
        findings.append(("MÉDIO", "Token do app guardado sem cifra (SharedPreferences)."))
    else:
        w("- O token do app (`KUPA_APP_TOKEN`) é guardado **cifrado** (AES-GCM, chave no Android Keystore).")
    w("")

    # ---- 8. Build
    w("## 8. DEBUG e RELEASE\n")
    min_sdk = re.search(r'minSdk\s*=\s*(\d+)', gradle)
    tgt_sdk = re.search(r'targetSdk\s*=\s*(\d+)', gradle)
    w(f"- minSdk {min_sdk.group(1) if min_sdk else '?'}, targetSdk {tgt_sdk.group(1) if tgt_sdk else '?'}.")
    rel = re.search(r'release\s*\{(.*?)\n        \}', gradle, re.S)
    rel_txt = rel.group(1) if rel else ""
    minify = re.search(r'isMinifyEnabled\s*=\s*(true|false)', rel_txt)
    w(f"- RELEASE: R8/minify={'ligado' if minify and minify.group(1) == 'true' else 'DESLIGADO'}; "
      f"assinatura por variáveis de ambiente={'sim' if 'KUPA_KEYSTORE' in gradle else 'não'}; debuggable={'sim' if 'isDebuggable = true' in rel_txt else 'não'}.")
    if not (minify and minify.group(1) == "true"):
        findings.append(("MÉDIO", "RELEASE sem R8/minify."))
    if 'android:debuggable="true"' in man:
        findings.append(("ALTO", "android:debuggable=true no manifesto."))
    w("- DEBUG (o que o GitHub Actions gera hoje, `app-debug.apk`): assinado com a chave de debug **pública**, `debuggable=true`. "
      "Serve para testar, **não** para distribuir. Para distribuir gere o RELEASE com a SUA chave (ver README).")
    w(f"- `allowBackup`: {'false' if 'allowBackup=\"false\"' in man else 'NÃO é false'}.\n")

    # ---- 9. Logs
    w("## 9. Logs\n")
    logs = grep(sources, ["Log.d(", "Log.i(", "Log.w(", "Log.e("])
    w(f"- Chamadas ao Logcat: {len(logs)} (todas dentro de `KupaLog`, que remove chaves, tokens, Bearer e imagens, e só escreve no Logcat em builds DEBUG).")
    w("- Telemetria: nenhuma. Nada é enviado a ninguém além do backend configurado, e só o texto da pergunta/contexto necessário (ver PrivacyGate).\n")

    # ---- 10. Achados
    w("## 10. Achados e gravidade\n")
    if not findings:
        w("Nenhum achado nesta execução.")
    for sev in ("CRÍTICO", "ALTO", "MÉDIO"):
        for s, txt in findings:
            if s == sev:
                w(f"- **{s}** — {txt}")
    w("\n## 11. O que esta auditoria NÃO prova\n")
    w("- Não substitui compilar, testar em aparelho nem a análise do próprio Play Protect.")
    w("- Não detecta malware nem vulnerabilidades em dependências (não há dependências de terceiros para checar).")
    w("- Não consegue confirmar a causa real de um bloqueio: ela só aponta a causa **mais provável** com base na documentação pública do Google.")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(out) + "\n", encoding="utf-8")
    crit = [f for f in findings if f[0] == "CRÍTICO"]
    print(f"Relatório: {OUT}")
    print(f"Permissões declaradas: {len(perms)} | achados: " + ", ".join(f"{sev}={sum(1 for s,_ in findings if s==sev)}" for sev in ('CRÍTICO', 'ALTO', 'MÉDIO')))
    for s, t in findings:
        print(f" - [{s}] {t}")
    sys.exit(1 if crit else 0)


if __name__ == "__main__":
    main()
