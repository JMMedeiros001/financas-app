#!/usr/bin/env python3
"""Checagem estática EXTRA: procura nomes de classe (Capitalizados) usados num arquivo Kotlin que NÃO são declarados no projeto,
nem importados, nem da biblioteca padrão. Pega "Unresolved reference" por import esquecido. Não é um compilador."""
import re, sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / "android" / "app" / "src" / "main" / "java"
sys.path.insert(0, str(Path(__file__).resolve().parent))

def strip(text):
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            while i < n and text[i] != "\n": i += 1
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2); i = n if j < 0 else j + 2
        elif text.startswith('"""', i):
            j = text.find('"""', i + 3); i = n if j < 0 else j + 3; out.append('""')
        elif c == '"':
            j = i + 1; buf = []
            while j < n and text[j] != '"':
                if text[j] == "\\": j += 1
                elif text[j] == "$" and j + 1 < n and text[j + 1] == "{":  # expressão dentro da string: mantém
                    depth = 1; k = j + 2
                    while k < n and depth:
                        depth += (text[k] == "{") - (text[k] == "}"); k += 1
                    buf.append(" " + text[j + 2:k - 1] + " "); j = k; continue
                j += 1
            out.append('"" ' + " ".join(buf) + " "); i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and text[j] != "'":
                if text[j] == "\\": j += 1
                j += 1
            out.append("' '"); i = j + 1
        else:
            out.append(c); i += 1
    return "".join(out)

STD = set("""String Int Long Boolean Float Double Short Byte Char Number Any Unit Nothing Array IntArray ByteArray CharArray LongArray FloatArray BooleanArray
List MutableList Map MutableMap Set MutableSet Collection MutableCollection Iterable Iterator MutableIterator Sequence Pair Triple
ArrayList HashMap HashSet LinkedHashMap LinkedHashSet Exception RuntimeException IllegalArgumentException IllegalStateException
UnsupportedOperationException NumberFormatException IndexOutOfBoundsException NullPointerException ArithmeticException ClassCastException
Throwable Error Runnable Thread StringBuilder System Math Character Comparable Comparator Regex Result Lazy Enum Object Class Process
Suppress Deprecated Volatile Synchronized JvmStatic JvmField JvmOverloads Throws Override InterruptedException CharSequence Appendable
Iterable Cloneable Void Runtime StackTraceElement AssertionError OutOfMemoryError SecurityException UnsupportedEncodingException
ReadWriteProperty KProperty SuppressWarnings FunctionalInterface Charsets Lazy Companion Serializable""".split())

files = sorted(SRC.rglob("*.kt"))
declared = set()
for f in files:
    t = strip(f.read_text(encoding="utf-8"))
    declared |= set(re.findall(r"\b(?:class|object|interface|typealias)\s+(\w+)", t))
    declared |= set(re.findall(r"\benum\s+class\s+(\w+)", t))
# classes Java do projeto
for f in SRC.rglob("*.java"):
    t = f.read_text(encoding="utf-8")
    declared |= set(re.findall(r"\b(?:class|enum|interface)\s+(\w+)", t))
# entradas de enum Kotlin
for f in files:
    t = strip(f.read_text(encoding="utf-8"))
    for m in re.finditer(r"enum\s+class\s+\w+[^{]*\{([^}]*)\}", t):
        declared |= set(re.findall(r"\b([A-Z][A-Z0-9_]*)\b", m.group(1)))

problems = []
for f in files:
    raw = f.read_text(encoding="utf-8")
    t = strip(raw)
    imports = re.findall(r"^import\s+([\w.]+)(?:\s+as\s+(\w+))?", raw, re.M)
    imported = {(alias or full.split(".")[-1]) for full, alias in imports}
    stars = [full for full in re.findall(r"^import\s+([\w.]+)\.\*", raw, re.M)]
    pkg = re.search(r"^package\s+([\w.]+)", raw, re.M)
    body = re.sub(r"^(import|package)\s.*$", "", t, flags=re.M)
    for m in re.finditer(r"(?<![\w.])([A-Z][A-Za-z0-9_]*)\b", body):
        name = m.group(1)
        if name in STD or name in declared or name in imported: continue
        if re.fullmatch(r"[A-Z][A-Z0-9_]*", name): continue          # constantes (RESULT_OK, TAG...)
        if len(name) == 1: continue                                  # parâmetros de tipo (T, R)
        line = body[:m.start()].count("\n") + 1
        problems.append((f.name, line, name, stars))
seen = set()
real = []
for fn, line, name, stars in problems:
    key = (fn, name)
    if key in seen: continue
    seen.add(key)
    real.append(f"{fn}:{line}: '{name}' não é declarado, importado nem da biblioteca padrão" + (f" (o arquivo tem import com *: {', '.join(stars)})" if stars else ""))
if real:
    print(f"{len(real)} POSSÍVEL(IS) PROBLEMA(S):")
    for r in real: print(" -", r)
    sys.exit(1)
print("OK: todos os nomes de classe usados estão declarados, importados ou são da biblioteca padrão.")
