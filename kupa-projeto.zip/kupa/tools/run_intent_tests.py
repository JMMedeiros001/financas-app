#!/usr/bin/env python3
"""Compila e roda os testes da camada de intenções (Java puro, sem Android).
Precisa de um JDK (javac). Aqui usamos o módulo jdk.compiler do próprio Java, que funciona sem o binário 'javac'."""
import shutil, subprocess, sys, tempfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
src = sorted((root / "android/app/src/main/java/com/kupa/assistant/intent").glob("*.java"))
tests = root / "tools/jvmtests/IntentTests.java"
out = Path(tempfile.mkdtemp(prefix="kupa-intent-"))
javac = [shutil.which("javac")] if shutil.which("javac") else ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
cp = subprocess.run(javac + ["-encoding", "UTF-8", "-Xlint:all", "-d", str(out)] + [str(f) for f in src] + [str(tests)])
if cp.returncode != 0:
    sys.exit("falha ao compilar")
sys.exit(subprocess.run(["java", "-Dfile.encoding=UTF-8", "-cp", str(out), "IntentTests"]).returncode)
