#!/usr/bin/env python3
"""Compila e roda os testes da camada de intenções e do núcleo de segurança (Java puro, sem Android).
Precisa de um JDK (javac). Aqui usamos o módulo jdk.compiler do próprio Java, que funciona sem o binário 'javac'."""
import shutil, subprocess, sys, tempfile
from pathlib import Path

root = Path(__file__).resolve().parent.parent
base = root / "android/app/src/main/java/com/kupa/assistant"
src = sorted(base.glob("intent/*.java")) + sorted(base.glob("security/*.java")) + sorted(base.glob("ai/*.java")) + sorted(base.glob("voice/*.java")) + sorted(base.glob("visual/*.java"))
tests = sorted((root / "tools/jvmtests").glob("*.java"))
out = Path(tempfile.mkdtemp(prefix="kupa-intent-"))
javac = [shutil.which("javac")] if shutil.which("javac") else ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main"]
cp = subprocess.run(javac + ["-encoding", "UTF-8", "-Xlint:all", "-d", str(out)] + [str(f) for f in src] + [str(t) for t in tests])
if cp.returncode != 0:
    sys.exit("falha ao compilar")
codes = [subprocess.run(["java", "-Dfile.encoding=UTF-8", "-cp", str(out), t.stem]).returncode for t in tests]
sys.exit(0 if all(c == 0 for c in codes) else 1)
