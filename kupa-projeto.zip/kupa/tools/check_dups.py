#!/usr/bin/env python3
"""Checagem estática EXTRA (Kotlin): declarações duplicadas no MESMO escopo ("Conflicting declarations") e atribuição a `val`
("Val cannot be reassigned"). Foi criada depois que o compilador real apontou um `val` declarado duas vezes. Não é um compilador."""
import re, sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / "android" / "app" / "src" / "main" / "java"

def strip(text):
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            while i < n and text[i] != "\n": i += 1
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2); i = n if j < 0 else j + 2
        elif text.startswith('"""', i):
            j = text.find('"""', i + 3); seg = text[i:j + 3 if j >= 0 else n]; out.append("\n" * seg.count("\n") + '""'); i = n if j < 0 else j + 3
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                if text[j] == "\\": j += 1
                j += 1
            out.append('""'); i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and text[j] != "'":
                if text[j] == "\\": j += 1
                j += 1
            out.append("' '"); i = j + 1
        else:
            out.append(c); i += 1
    return "".join(out)

def match_brace(t, i):
    d = 0
    for k in range(i, len(t)):
        if t[k] == "{": d += 1
        elif t[k] == "}":
            d -= 1
            if d == 0: return k
    return -1

def depth1_decls(body):
    """(nome, posição) de `val|var nome` que estão EXATAMENTE no nível 1 do corpo (fora de lambdas e blocos internos)."""
    res, depth, i = [], 0, 0
    while i < len(body):
        ch = body[i]
        if ch == "{": depth += 1
        elif ch == "}": depth -= 1
        elif depth == 1:
            m = re.match(r"\b(val|var)\s+(\w+)\b", body[i:])
            if m and (i == 0 or not re.match(r"[\w.]", body[i - 1])):
                res.append((m.group(2), m.group(1), i)); i += m.end() - 1
        i += 1
    return res

problems = []
for f in sorted(SRC.rglob("*.kt")):
    t = strip(f.read_text(encoding="utf-8"))
    line = lambda pos: t[:pos].count("\n") + 1
    # 1) locais duplicados no mesmo corpo de função / lambda de nível de função
    for m in re.finditer(r"\bfun\b[^{=\n]*(?:\([^)]*\))?[^{=\n]*\{", t):
        b0 = t.index("{", m.start() + m.group(0).rfind("{"))
        b1 = match_brace(t, b0)
        if b1 < 0: continue
        body = t[b0:b1 + 1]
        seen = {}
        locals_val = {}
        for name, kind, off in depth1_decls(body):
            if name in seen:
                problems.append(f"{f.name}:{line(b0 + off)}: 'Conflicting declarations': '{name}' já foi declarado neste mesmo escopo (linha {line(b0 + seen[name])})")
            seen[name] = off
            if kind == "val": locals_val[name] = off
        # 2) reatribuição de val local (nível 1)
        for name, off in locals_val.items():
            for am in re.finditer(r"(?<![\w.])" + re.escape(name) + r"\s*=(?!=)", body[off + len(name) + 4:]):
                p = off + len(name) + 4 + am.start()
                prefix = body[max(0, p - 6):p]
                if re.search(r"\b(val|var)\s*$", prefix): continue
                # ignora argumento nomeado "foo(name = x)": precisa estar no início de um comando
                before = body[:p].rstrip()
                if before and before[-1] in ";{}\n" or before.endswith(")") and False:
                    problems.append(f"{f.name}:{line(b0 + p)}: 'Val cannot be reassigned': '{name}' é val (declarado na linha {line(b0 + off)})")
                    break
    # 3) membros duplicados no nível da classe: propriedades e funções (mesmo nome e mesma quantidade de parâmetros)
    for cm in re.finditer(r"\b(?:class|object|interface)\s+(\w+)[^{;]*\{", t):
        c0 = t.index("{", cm.start() + len(cm.group(0)) - 1)
        c1 = match_brace(t, c0)
        if c1 < 0: continue
        body = t[c0:c1 + 1]
        props, funs = {}, {}
        depth = 0
        paren = 0
        i = 0
        while i < len(body):
            ch = body[i]
            if ch == "(": paren += 1
            elif ch == ")": paren -= 1
            if ch == "{": depth += 1
            elif ch == "}": depth -= 1
            elif depth == 1 and paren == 0:
                m = re.match(r"(?:(?:private|public|protected|internal|override|lateinit|const|abstract|open|final|@Volatile|@JvmField)\s+)*(val|var)\s+(\w+)\b", body[i:])
                if m and (i == 0 or body[i - 1] in " \n\t{"):
                    if m.group(2) in props:
                        problems.append(f"{f.name}:{line(c0 + i)}: 'Conflicting declarations': propriedade '{m.group(2)}' declarada duas vezes na classe {cm.group(1)}")
                    props[m.group(2)] = i; i += m.end() - 1
                else:
                    fm = re.match(r"fun\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)\s*\(([^)]*)\)", body[i:])
                    if fm and (i == 0 or body[i - 1] in " \n\t{"):
                        key = (fm.group(1), len([a for a in fm.group(2).split(",") if a.strip()]))
                        if key in funs:
                            problems.append(f"{f.name}:{line(c0 + i)}: 'Conflicting overloads': função '{key[0]}' com {key[1]} parâmetro(s) declarada duas vezes em {cm.group(1)}")
                        funs[key] = i
            i += 1

if problems:
    print(f"{len(problems)} PROBLEMA(S):")
    for p in sorted(set(problems)): print(" -", p)
    sys.exit(1)
print("OK: nenhuma declaração duplicada no mesmo escopo e nenhuma reatribuição de val encontrada.")
