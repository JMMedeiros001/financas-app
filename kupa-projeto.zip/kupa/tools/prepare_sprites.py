#!/usr/bin/env python3
"""Padroniza os 15 estados do Popol+Kupa (PNG com fundo transparente) para o app.

Uso:  python3 tools/prepare_sprites.py <pasta_com_state_XX_nome.png> <res/drawable-nodpi>

- recorta pelo conteúdo visível (canal alfa),
- encaixa sem distorcer num quadro fixo (mesmo tamanho para todos os estados),
- alinha pela base e centraliza, para o personagem não "pular" ao trocar de estado,
- salva em WebP com transparência (leve para o APK).

Para trocar os visuais depois, basta rodar de novo com as imagens novas (mesmos nomes).
"""
import sys
from pathlib import Path
from PIL import Image

CANVAS_W, CANVAS_H = 640, 720
MARGIN = 6


def prepare(src: Path, dst: Path) -> tuple:
    im = Image.open(src).convert("RGBA")
    alpha = im.split()[3].point(lambda v: 255 if v > 8 else 0)
    bbox = alpha.getbbox()
    if bbox is None:
        raise SystemExit(f"{src.name}: imagem totalmente transparente")
    im = im.crop(bbox)
    scale = min((CANVAS_W - 2 * MARGIN) / im.width, (CANVAS_H - 2 * MARGIN) / im.height)
    size = (max(1, round(im.width * scale)), max(1, round(im.height * scale)))
    im = im.resize(size, Image.LANCZOS)
    canvas = Image.new("RGBA", (CANVAS_W, CANVAS_H), (0, 0, 0, 0))
    x = (CANVAS_W - size[0]) // 2
    y = CANVAS_H - MARGIN - size[1]
    canvas.paste(im, (x, y), im)
    canvas.save(dst, "WEBP", quality=90, method=6, lossless=False, exact=True)
    return bbox, size


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    src_dir, dst_dir = Path(sys.argv[1]), Path(sys.argv[2])
    dst_dir.mkdir(parents=True, exist_ok=True)
    files = sorted(src_dir.glob("state_??_*.png"))
    if len(files) != 15:
        print(f"AVISO: esperava 15 estados, encontrei {len(files)}")
    total = 0
    for f in files:
        out = dst_dir / (f.stem + ".webp")
        bbox, size = prepare(f, out)
        total += out.stat().st_size
        print(f"{f.name:34s} -> {out.name:30s} conteúdo {bbox[2]-bbox[0]}x{bbox[3]-bbox[1]} -> {size[0]}x{size[1]}  {out.stat().st_size/1024:5.0f} KB")
    print(f"total: {total/1024/1024:.2f} MB em {len(files)} arquivos")


if __name__ == "__main__":
    main()
