#!/usr/bin/env python3
"""Confere que os NOMES de estado usados em CoreMode.resolve (Java) existem de fato no enum KupaState (Kotlin).
Se alguém renomear um estado, o núcleo deixaria de reagir sem nenhum erro: esta checagem pega isso."""
import re, sys
from pathlib import Path
base = Path(__file__).resolve().parent.parent / "android/app/src/main/java/com/kupa/assistant"
kt = (base / "core/KupaState.kt").read_text(encoding="utf-8")
names = set(re.findall(r"^\s*([A-Z_]+)\(", kt, re.M))
java = (base / "visual/CoreMode.java").read_text(encoding="utf-8")
used = set(re.findall(r's\.equals\("([A-Z_]+)"\)', java))
missing = sorted(used - names)
if missing or not used:
    print("PROBLEMA: estados usados no núcleo que NÃO existem em KupaState:", missing or "(nenhum nome encontrado no CoreMode)")
    print("Estados do enum:", sorted(names))
    sys.exit(1)
print(f"OK: os {len(used)} nomes de estado usados no núcleo existem em KupaState ({len(names)} estados).")
