#!/usr/bin/env python3
"""Checagem estática do projeto Android (NÃO substitui compilar!).

Aqui não há Kotlin nem Android SDK, então este script pega só os erros mais comuns de digitação:
  1. parênteses/chaves/colchetes desbalanceados (ignorando textos e comentários);
  2. imports do próprio projeto que apontam para classes que não existem;
  3. membros usados em settings./core./states./gamer./screen./app. que não existem na classe;
  4. nomes do AndroidManifest (activities/service/application) que não existem no código;
  5. recursos referenciados (R.drawable.x) e sprites dos 15 estados.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "android" / "app" / "src" / "main"
SRC = ROOT / "java"
PKG = "com.kupa.assistant"
errors, warnings = [], []


def strip_code(text: str) -> str:
    """Remove comentários e conteúdo de strings (mantém quebras de linha) para contar delimitadores."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        two = text[i:i + 2]
        if two == "//":
            while i < n and text[i] != "\n":
                i += 1
        elif two == "/*":
            j = text.find("*/", i + 2)
            j = n if j == -1 else j + 2
            out.append("\n" * text[i:j].count("\n"))
            i = j
        elif text[i:i + 3] == '"""':
            j = text.find('"""', i + 3)
            j = n if j == -1 else j + 3
            out.append("\n" * text[i:j].count("\n"))
            i = j
        elif c == '"':
            i += 1
            while i < n and text[i] != '"':
                if text[i] == "\\":
                    i += 1
                if i < n and text[i] == "\n":
                    out.append("\n")
                i += 1
            i += 1
        elif c == "'":
            j = i + 1
            if j < n and text[j] == "\\":
                j += 1
            j += 1
            if j < n and text[j] == "'":
                i = j + 1
            else:
                out.append(c)
                i += 1
        else:
            out.append(c)
            i += 1
    return "".join(out)


files = sorted(SRC.rglob("*.kt"))
declared = {}      # pacote -> {nomes}
members = {}       # classe -> {membros}
sources = {}
decl_re = re.compile(r"^\s*(?:(?:public|private|internal|open|abstract|sealed|data|enum|fun|annotation|inner)\s+)*(?:class|object|interface)\s+(\w+)", re.M)
for f in files:
    text = f.read_text(encoding="utf-8")
    sources[f] = text
    pkg = re.search(r"^package\s+([\w.]+)", text, re.M)
    if not pkg:
        errors.append(f"{f.name}: sem 'package'")
        continue
    declared.setdefault(pkg.group(1), set()).update(decl_re.findall(text))

# 1) delimitadores
for f, text in sources.items():
    code = strip_code(text)
    stack, line = [], 1
    pairs = {")": "(", "]": "[", "}": "{"}
    for ch in code:
        if ch == "\n":
            line += 1
        elif ch in "([{":
            stack.append((ch, line))
        elif ch in ")]}":
            if not stack or stack[-1][0] != pairs[ch]:
                errors.append(f"{f.relative_to(SRC)}:{line}: '{ch}' sem par")
                break
            stack.pop()
    else:
        if stack:
            errors.append(f"{f.relative_to(SRC)}: '{stack[-1][0]}' aberto na linha {stack[-1][1]} nunca foi fechado")

# 2) imports do projeto
for f, text in sources.items():
    for m in re.finditer(r"^import\s+(com\.kupa\.assistant[\w.]*)", text, re.M):
        parts = m.group(1).split(".")
        if parts == ["com", "kupa", "assistant", "R"]:
            continue  # gerada pelo Gradle a partir de res/
        # procura o maior prefixo que seja pacote e o próximo item como classe
        ok = False
        for k in range(len(parts) - 1, 2, -1):
            pkg = ".".join(parts[:k])
            if pkg in declared and parts[k] in declared[pkg]:
                ok = True
                break
        if not ok:
            errors.append(f"{f.relative_to(SRC)}: import não resolvido: {m.group(1)}")

# 3) membros usados vs. declarados
def collect_members(path: Path, cls: str) -> set:
    text = strip_code(sources[path])
    start = text.index(f"class {cls}")
    body = text[start:]
    found = set(re.findall(r"\b(?:val|var|fun)\s+(?:<[^>]+>\s*)?(?:\w+\.)?(\w+)", body))
    found |= set(re.findall(r"^\s*(?:private |public |internal )?(?:val|var)\s+(\w+)", body, re.M))
    return found

def file_of(name: str) -> Path:
    for f in files:
        if re.search(rf"\b(?:class|object)\s+{name}\b", sources[f]):
            return f
    raise SystemExit(f"classe {name} não encontrada")

receivers = {
    "settings": "Settings",
    "core": "KupaCore",
    "states": "StateManager",
    "gamer": "GamerModeController",
    "screen": "ScreenCaptureManager",
    "gameContext": "GameContextService",
    "history": "HistoryDb",
    "speech": "SpeechOutput",
    "client": "KupaBackendClient",
    "sprites": "SpriteRepository",
}
known = {}
for recv, cls in receivers.items():
    known[recv] = collect_members(file_of(cls), cls)
app_members = collect_members(file_of("KupaApp"), "KupaApp")
checked = 0
for f, text in sources.items():
    code = strip_code(text)
    for recv, cls in receivers.items():
        if re.search(rf"^ {{8,}}(?:val|var)\s+{recv}\b", code, re.M):
            continue  # variável local com o mesmo nome (ex.: seção de tela), não é o receptor conhecido
        for m in re.finditer(rf"(?<![\w.]){recv}(?:\?)?\.(\w+)", code):
            name = m.group(1)
            checked += 1
            if f == file_of(cls):
                continue
            if name not in known[recv]:
                errors.append(f"{f.relative_to(SRC)}: '{recv}.{name}' não existe em {cls}")
    if f.name == "KupaCore.kt" or "private val app: Application" in code:
        continue  # nesses arquivos 'app' é o Application genérico
    for m in re.finditer(r"(?<![\w.])app\.(\w+)", code):
        name = m.group(1)
        checked += 1
        if name not in app_members and name not in {"settings", "core", "states", "history", "gameContext", "gamer", "screen", "sprites", "isForeground"}:
            if f.name != "KupaApp.kt":
                errors.append(f"{f.relative_to(SRC)}: 'app.{name}' não existe em KupaApp")

# 4) manifest
manifest = (ROOT / "AndroidManifest.xml").read_text(encoding="utf-8")
for name in re.findall(r'android:name="(\.[\w.]+)"', manifest):
    parts = name.lstrip(".").split(".")
    pkg = ".".join([PKG] + parts[:-1])
    if parts[-1] not in declared.get(pkg, set()):
        errors.append(f"AndroidManifest.xml: classe não encontrada: {name}")

# 5) recursos
res = ROOT / "res"
drawables = {p.stem for p in (res / "drawable-nodpi").glob("*")}
for f, text in sources.items():
    for m in re.finditer(r"R\.drawable\.(\w+)", text):
        if m.group(1) not in drawables:
            errors.append(f"{f.relative_to(SRC)}: R.drawable.{m.group(1)} não existe")
for ref in re.findall(r'@drawable/(\w+)', manifest):
    if ref not in drawables:
        errors.append(f"AndroidManifest.xml: @drawable/{ref} não existe")
for style in re.findall(r'@style/([\w.]+)', manifest):
    if f'name="{style}"' not in (res / "values" / "themes.xml").read_text(encoding="utf-8"):
        errors.append(f"AndroidManifest.xml: @style/{style} não existe")
state_file = next(f for f in files if f.name == "KupaState.kt")
for sprite in re.findall(r'"(state_\d\d_\w+)"', sources[state_file]):
    if sprite not in drawables:
        errors.append(f"sprite do estado ausente: {sprite}")
if len(re.findall(r'"(state_\d\d_\w+)"', sources[state_file])) != 15:
    errors.append("KupaState deveria ter 15 estados")

print(f"{len(files)} arquivos Kotlin, {sum(len(v) for v in declared.values())} classes/objetos, {checked} acessos de membros conferidos")
for w in warnings:
    print("AVISO:", w)
if errors:
    print(f"\n{len(errors)} PROBLEMA(S):")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("OK: nenhuma inconsistência encontrada pela checagem estática (isto NÃO é uma compilação).")
