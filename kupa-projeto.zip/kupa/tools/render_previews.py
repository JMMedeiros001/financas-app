#!/usr/bin/env python3
"""Gera as prévias PNG do núcleo (todos os estados), do símbolo e do ícone, com a MESMA geometria do app.
Uso: python3 tools/render_previews.py [pasta-de-saída]   (padrão: docs/preview)"""
import subprocess, sys, tempfile
from pathlib import Path
root = Path(__file__).resolve().parent.parent
out = Path(sys.argv[1]) if len(sys.argv) > 1 else root / "docs" / "preview"
base = root / "android/app/src/main/java/com/kupa/assistant/visual"
srcs = sorted(base.glob("*.java")) + [root / "tools" / "PreviewRenderer.java"]
tmp = Path(tempfile.mkdtemp())
r = subprocess.run(["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-encoding", "UTF-8", "-d", str(tmp)] + [str(s) for s in srcs], capture_output=True, text=True)
if r.returncode != 0:
    print(r.stdout + r.stderr); sys.exit(1)
sys.exit(subprocess.run(["java", "-Djava.awt.headless=true", "-cp", str(tmp), "PreviewRenderer", str(out)]).returncode)
