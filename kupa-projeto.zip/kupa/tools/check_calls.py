#!/usr/bin/env python3
"""Checagem estática EXTRA dos arquivos Kotlin: confere, para funções e construtores declarados UMA vez no projeto,
se as chamadas têm a quantidade de argumentos e os nomes de parâmetros compatíveis. Pega erros de assinatura que edições
por trecho podem introduzir. NÃO é um compilador: não confere tipos."""
import re, sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent / "android" / "app" / "src" / "main" / "java"

def strip(text):
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if text.startswith("//", i):
            while i < n and text[i] != "\n": i += 1
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2); i = n if j < 0 else j + 2
        elif text.startswith('"""', i):
            j = text.find('"""', i + 3); i = n if j < 0 else j + 3; out.append('""')
        elif c == '"':
            j = i + 1
            while j < n and text[j] != '"':
                if text[j] == "\\": j += 1
                j += 1
            out.append('""'); i = j + 1
        elif c == "'":
            j = i + 1
            while j < n and text[j] != "'":
                if text[j] == "\\": j += 1
                j += 1
            out.append("' '"); i = j + 1
        else:
            out.append(c); i += 1
    return "".join(out)

def split_top(s):
    """Divide por vírgulas de nível zero. Conta (), [], {} e <> (genéricos), ignorando a seta '->'."""
    parts, depth, cur = [], 0, []
    prev = ""
    for ch in s:
        if ch in "([{": depth += 1
        elif ch in ")]}": depth -= 1
        elif ch == "<": depth += 1
        elif ch == ">" and prev != "-": depth -= 1
        if ch == "," and depth == 0:
            parts.append("".join(cur)); cur = []
        else:
            cur.append(ch)
        prev = ch
    if "".join(cur).strip(): parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]

def balanced(text, start):
    """texto[start] == '(' -> índice do ')' correspondente."""
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "(": depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0: return i
    return -1

def parse_params(s):
    params = []
    for p in split_top(s):
        p = re.sub(r"^(?:private |public |internal |protected )?(?:val |var )?", "", p.strip())
        p = re.sub(r"^(?:vararg |noinline |crossinline )", "", p)
        m = re.match(r"(\w+)\s*:\s*(.*)", p, re.S)
        if not m: continue
        name, rest = m.group(1), m.group(2)
        has_default = " = " in rest.replace("=>", "")
        typ = rest.split(" = ")[0].strip()
        params.append((name, has_default, "->" in typ))
    return params

files = sorted(SRC.rglob("*.kt"))
texts = {f: strip(f.read_text(encoding="utf-8")) for f in files}

decls = {}   # nome -> lista de (params, arquivo)
for f, t in texts.items():
    for m in re.finditer(r"\bclass\s+(\w+)\s*(?:<[^>]*>)?\s*(?:private\s+|internal\s+)?(?:constructor\s*)?\(", t):
        i = t.index("(", m.end() - 1); j = balanced(t, i)
        if j > 0: decls.setdefault(m.group(1), []).append((parse_params(t[i + 1:j]), f.name, "class"))
    for m in re.finditer(r"\bfun\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?(\w+)\s*\(", t):
        i = t.index("(", m.end() - 1); j = balanced(t, i)
        if j > 0: decls.setdefault(m.group(1), []).append((parse_params(t[i + 1:j]), f.name, "fun"))

errors = []
IGNORE = {"finish", "put", "onDone", "clamp", "if", "when", "for", "while", "catch", "return", "super", "this", "listOf", "mapOf", "setOf", "arrayOf", "Pair", "Triple"}
for f, t in texts.items():
    for name, lst in decls.items():
        if len(lst) != 1 or name in IGNORE: continue
        params, declfile, kind = lst[0]
        for m in re.finditer(r"(?<![\w.])" + re.escape(name) + r"\s*\(", t):
            start = m.start()
            before = t[max(0, start - 12):start]
            if re.search(r"\b(fun|class)\s+(?:<[^>]*>\s*)?$", before) or re.search(r"\bfun\s+[\w.<>?, ]*\.$", before):
                continue
            i = t.index("(", m.end() - 1); j = balanced(t, i)
            if j < 0: continue
            args = split_top(t[i + 1:j].replace('<', ' lt ').replace('>=', ' ge ').replace('->', '=>').replace('>', ' gt '))
            after = t[j + 1:j + 4].lstrip()
            trailing = after.startswith("{")
            named = [re.match(r"(\w+)\s*=(?!=)", a).group(1) for a in args if re.match(r"(\w+)\s*=(?!=)", a)]
            positional = len(args) - len(named) + (1 if trailing else 0)
            pnames = [p[0] for p in params]
            for n in named:
                if n not in pnames:
                    line = t[:start].count("\n") + 1
                    errors.append(f"{f.name}:{line}: {name}(...) não tem o parâmetro nomeado '{n}' (declarado em {declfile})")
            required = [p for p in params if not p[1]]
            if positional + len(named) > len(params):
                line = t[:start].count("\n") + 1
                errors.append(f"{f.name}:{line}: {name}(...) recebe {positional + len(named)} argumento(s), mas {declfile} declara {len(params)}")
            else:
                n_pos = positional - (1 if trailing else 0)
                provided_names = set(named) | set(pnames[:n_pos]) | ({pnames[-1]} if trailing and pnames else set())
                missing = [p[0] for p in required if p[0] not in provided_names]
                if missing:
                    line = t[:start].count("\n") + 1
                    errors.append(f"{f.name}:{line}: {name}(...) sem o(s) parâmetro(s) obrigatório(s) {missing} (declarado em {declfile})")

if errors:
    print(f"{len(errors)} PROBLEMA(S):")
    for e in sorted(set(errors)): print(" -", e)
    sys.exit(1)
print(f"OK: {sum(1 for v in decls.values() if len(v) == 1)} funções/construtores únicos conferidos; nenhuma chamada com aridade ou nome de parâmetro incompatível.")
