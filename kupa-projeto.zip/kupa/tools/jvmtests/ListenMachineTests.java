import com.kupa.assistant.voice.ListenMachine;
import com.kupa.assistant.voice.ListenMachine.Cmd;
import com.kupa.assistant.voice.ListenMachine.Outcome;
import com.kupa.assistant.voice.ListenMachine.State;
import com.kupa.assistant.voice.ListenMachine.Step;
import java.util.*;

/**
 * Testes da máquina de estados da escuta. Um "Android falso" (Driver) executa os passos como o VoiceController faz e RASTREIA os
 * reconhecedores e temporizadores vivos, inclusive os "zumbis" (já cancelados que ainda podem entregar callbacks atrasados).
 * Prova a lógica; NÃO prova o comportamento do microfone físico.
 */
public class ListenMachineTests {
    static int passed = 0, failed = 0;
    static void check(boolean ok, String name, String detail) { if (ok) passed++; else { failed++; System.out.println("FALHOU: " + name + "  ->  " + detail); } }
    static void eq(Object e, Object a, String name) { check(Objects.equals(e, a), name, "esperado=" + e + " obtido=" + a); }

    /** Simula o VoiceController + SpeechInput. */
    static final class Driver {
        final ListenMachine m = new ListenMachine();
        boolean wanted = false, perm = true, avail = true, allowed = true;
        final List<Long> live = new ArrayList<>();      // reconhecedores rodando (válidos ou não)
        final List<Long> zombies = new ArrayList<>();   // cancelados, mas podem entregar callback tardio
        long timer = 0;                                 // temporizador agendado (0 = nenhum)
        int starts = 0, commandStarts = 0, maxLive = 0, maxValidLive = 0, restartsScheduled = 0, staleIgnored = 0;

        void apply(Step s) {
            if (s.stale) staleIgnored++;
            if (s.cancelTimer) timer = 0;
            switch (s.cmd) {
                case STOP: zombies.addAll(live); live.clear(); break;
                case START_WAKE:
                case START_COMMAND:
                    zombies.addAll(live); live.clear();            // SpeechInput.start() cancela o anterior
                    live.add(s.token);
                    if (s.cmd == Cmd.START_WAKE) starts++; else commandStarts++;
                    break;
                case RESTART_LATER: timer = s.token; restartsScheduled++; break;
                default: break;
            }
            maxLive = Math.max(maxLive, live.size());
            int valid = 0;
            for (long t : live) if (m.isCurrentWake(t) || m.isCurrentCommand(t)) valid++;
            maxValidLive = Math.max(maxValidLive, valid);
        }
        void rec() { apply(m.reconcile(wanted, perm, avail, allowed)); }
        void enable() { wanted = true; rec(); }
        void disable() { wanted = false; rec(); }
        long current() { return live.isEmpty() ? 0 : live.get(live.size() - 1); }
        void ready(long t) { apply(m.onReady(t)); }
        void end(long t, Outcome o) { live.remove(Long.valueOf(t)); apply(m.onCycleEnd(t, o)); }
        void wake(long t) { live.remove(Long.valueOf(t)); apply(m.onWakeDetected(t)); }
        void fireTimer() { long t = timer; timer = 0; apply(m.onRestartTimer(t, wanted, perm, avail, allowed)); }
        void lateCallbackFromZombies(Outcome o) { for (long z : new ArrayList<>(zombies)) { apply(m.onReady(z)); apply(m.onCycleEnd(z, o)); apply(m.onWakeDetected(z)); } }
    }


    /**
     * Reprodução FIEL da lógica ANTIGA do VoiceController: checa só o "modo" (sem token de sessão), reinicia SEM LIMITE e o temporizador
     * pendente não é cancelado ao desativar. Serve para provar que os testes novos têm dentes: este modelo DEVE violar os critérios.
     */
    static final class LegacyModel {
        boolean modeListen = false, restartScheduled = false;
        int starts = 0, consecutiveFailures = 0, restartsAfterFailures = 0;
        long timerDue = -1;
        void beginCycle() { starts++; }
        void refreshNow(boolean allowed) {
            if (!allowed) { if (modeListen) { modeListen = false; } return; }   // stopListening(): NÃO cancela o temporizador pendente
            if (!modeListen) { modeListen = true; consecutiveFailures = 0; beginCycle(); }
        }
        void scheduleRestart(long now, long delay) { if (restartScheduled) return; restartScheduled = true; timerDue = now + delay; }
        void onFailureOther(long now) { if (!modeListen) return; consecutiveFailures++; scheduleRestart(now, Math.min(8000, 600L * consecutiveFailures * consecutiveFailures)); }
        void tick(long now, boolean allowed) {
            if (restartScheduled && now >= timerDue) {
                restartScheduled = false;
                if (modeListen && allowed) { beginCycle(); restartsAfterFailures++; }
            }
        }
    }

    public static void main(String[] args) {
        // ---------------- 1) ativar / desativar e idempotência
        Driver d = new Driver();
        eq(State.DISABLED, d.m.state(), "começa desativada");
        for (int i = 0; i < 50; i++) d.enable();
        eq(1, d.starts, "50 pedidos de ativação = UMA sessão");
        eq(State.STARTING, d.m.state(), "STARTING até o reconhecedor avisar que está pronto");
        check(!d.m.micOpen(), "microfone NÃO é mostrado como ativo antes de estar pronto", "");
        d.ready(d.current());
        eq(State.LISTENING, d.m.state(), "LISTENING só depois do aviso de pronto");
        check(d.m.micOpen(), "agora o microfone está realmente em uso", "");
        d.disable();
        eq(State.DISABLED, d.m.state(), "desativar volta a DISABLED");
        check(d.live.isEmpty() && !d.m.hasValidSession() && !d.m.hasPendingTimer(), "desativar para o reconhecedor e invalida tudo", "");
        d.lateCallbackFromZombies(Outcome.FAIL_RECOVERABLE);
        eq(1, d.starts, "callbacks tardios depois de desativar NÃO reiniciam");
        eq(State.DISABLED, d.m.state(), "continua DISABLED");

        // ---------------- 2) desativar durante STARTING
        d = new Driver(); d.enable(); long t1 = d.current(); d.disable();
        d.ready(t1); d.end(t1, Outcome.FAIL_RECOVERABLE); d.wake(t1);
        eq(State.DISABLED, d.m.state(), "desativar durante STARTING: onReady/erro/palavra tardios são ignorados");
        eq(1, d.starts, "e nada reiniciou");
        check(!d.m.hasPendingTimer(), "sem temporizador pendente", "");

        // ---------------- 3) reativar: cria no máximo uma sessão válida; callbacks da sessão antiga não valem
        d = new Driver(); d.enable(); long old = d.current(); d.ready(old); d.disable(); d.enable(); long cur = d.current();
        check(cur != old, "reativar cria um token NOVO", "");
        d.end(old, Outcome.FAIL_RECOVERABLE);
        eq(State.STARTING, d.m.state(), "erro da sessão antiga não afeta a nova");
        d.wake(old);
        eq(State.STARTING, d.m.state(), "palavra detectada da sessão antiga não afeta a nova");
        eq(0, d.m.failures(), "e não conta como falha da nova");
        eq(1, d.maxValidLive, "no máximo 1 reconhecedor válido");

        // ---------------- 4) temporizador de reinício antigo não atua depois de desativar e reativar
        d = new Driver(); d.enable(); d.ready(d.current()); d.end(d.current(), Outcome.NO_SPEECH);
        long oldTimer = d.timer; check(oldTimer != 0, "agendou reinício", "");
        d.disable(); eq(0L, d.timer, "desativar CANCELA o temporizador");
        d.enable(); int startsBefore = d.starts;
        Step late = d.m.onRestartTimer(oldTimer, d.wanted, d.perm, d.avail, d.allowed);
        check(late.stale && late.cmd == Cmd.NONE, "temporizador antigo é ignorado", "");
        eq(startsBefore, d.starts, "e não iniciou outra sessão");

        // ---------------- 5) ciclos normais (sem fala / sem match) nunca viram erro
        d = new Driver(); d.enable(); d.ready(d.current());
        for (int i = 0; i < 1000; i++) { d.end(d.current(), i % 2 == 0 ? Outcome.NO_SPEECH : Outcome.HEARD_NO_WAKE); d.fireTimer(); d.ready(d.current()); }
        eq(State.LISTENING, d.m.state(), "1000 ciclos normais continuam em LISTENING");
        eq(0, d.m.failures(), "sem falhas acumuladas");
        eq(1, d.maxValidLive, "sempre 1 reconhecedor válido");

        // ---------------- 6) falha persistente: LIMITE, depois ERROR; sem loop
        d = new Driver(); d.enable();
        int attempts = 0;
        for (int i = 0; i < 100 && d.m.state() != State.ERROR; i++) {
            d.end(d.current(), Outcome.FAIL_RECOVERABLE);
            if (d.timer != 0) { d.fireTimer(); attempts++; }
        }
        eq(State.ERROR, d.m.state(), "falhas persistentes terminam em ERROR");
        check(attempts <= ListenMachine.MAX_RECOVERABLE_FAILURES, "no máximo " + ListenMachine.MAX_RECOVERABLE_FAILURES + " reinícios automáticos (foram " + attempts + ")", "");
        check(!d.m.hasPendingTimer() && d.live.isEmpty(), "em ERROR não há temporizador nem reconhecedor", "");
        int before = d.starts;
        for (int i = 0; i < 20; i++) d.rec();
        eq(before, d.starts, "em ERROR, reconciliar NÃO reinicia sozinho (sem loop)");
        d.apply(d.m.manualRetry(d.wanted, d.perm, d.avail, d.allowed));
        eq(State.STARTING, d.m.state(), "a nova tentativa MANUAL reinicia");
        eq(before + 1, d.starts, "com uma única sessão");
        eq(0, d.m.failures(), "e zera as falhas");
        // desativar e reativar (ação do usuário) também limpa o ERROR
        d = new Driver(); d.enable();
        for (int i = 0; i < 100 && d.m.state() != State.ERROR; i++) { d.end(d.current(), Outcome.FAIL_RECOVERABLE); if (d.timer != 0) d.fireTimer(); }
        d.disable(); d.enable();
        eq(State.STARTING, d.m.state(), "desativar+ativar sai do ERROR");

        // ---------------- 7) uma tentativa boa entre falhas zera o contador
        d = new Driver(); d.enable();
        for (int round = 0; round < 10; round++) {
            for (int k = 0; k < 3; k++) { d.end(d.current(), Outcome.FAIL_RECOVERABLE); d.fireTimer(); }
            d.ready(d.current()); d.end(d.current(), Outcome.NO_SPEECH); d.fireTimer();
        }
        check(d.m.state() != State.ERROR, "falhas intercaladas com ciclos bons não acumulam até ERROR", d.m.state() + "");

        // ---------------- 8) permissão revogada e restaurada
        d = new Driver(); d.enable(); d.ready(d.current());
        d.perm = false; d.rec();
        eq(State.WAITING_PERMISSION, d.m.state(), "permissão revogada: WAITING_PERMISSION");
        check(d.live.isEmpty() && !d.m.hasValidSession(), "e o reconhecedor é parado", "");
        int s0 = d.starts; for (int i = 0; i < 10; i++) d.rec();
        eq(s0, d.starts, "sem permissão não tenta iniciar");
        d.perm = true; d.rec();
        eq(State.STARTING, d.m.state(), "permissão restaurada: nova tentativa controlada");
        eq(s0 + 1, d.starts, "uma só sessão nova");
        d.end(d.current(), Outcome.FAIL_PERMISSION);
        eq(State.WAITING_PERMISSION, d.m.state(), "falha de permissão vira WAITING_PERMISSION (não ERROR, não loop)");
        check(!d.m.hasPendingTimer(), "sem temporizador de reinício", "");

        // ---------------- 9) reconhecimento indisponível
        d = new Driver(); d.avail = false; d.enable();
        eq(State.UNAVAILABLE, d.m.state(), "sem reconhecimento: UNAVAILABLE");
        eq(0, d.starts, "não tenta iniciar");
        d.avail = true; d.rec();
        eq(State.STARTING, d.m.state(), "ficou disponível: inicia");
        d.end(d.current(), Outcome.FAIL_UNAVAILABLE);
        eq(State.UNAVAILABLE, d.m.state(), "falha de disponibilidade vira UNAVAILABLE sem reiniciar");

        // ---------------- 10) condição momentânea (tela desligada, assistente ocupado)
        d = new Driver(); d.enable(); d.ready(d.current());
        d.allowed = false; d.rec();
        eq(State.SUSPENDED, d.m.state(), "condição momentânea: SUSPENDED");
        check(d.live.isEmpty(), "reconhecedor parado", "");
        d.allowed = true; d.rec();
        eq(State.STARTING, d.m.state(), "condição resolvida e preferência mantida: volta a iniciar");
        d.disable(); d.allowed = false; d.rec(); d.allowed = true; d.rec();
        eq(State.DISABLED, d.m.state(), "preferência desativada vence a recuperação por condição");

        // ---------------- 11) palavra detectada -> comando (alternância sem sessões conflitantes)
        d = new Driver(); d.enable(); long w = d.current(); d.ready(w);
        d.wake(w);
        eq(State.SUSPENDED, d.m.state(), "palavra detectada: o detector entrega o microfone");
        check(d.live.isEmpty(), "reconhecedor da palavra encerrado", "");
        d.apply(d.m.beginCommand(true, true)); long c = d.current();
        eq(State.COMMAND, d.m.state(), "comando em andamento");
        check(d.m.micOpen(), "microfone em uso pelo comando", "");
        int sw = d.starts; for (int i = 0; i < 10; i++) d.rec();
        eq(sw, d.starts, "durante o comando, reconciliar NÃO inicia o detector (sem sessões conflitantes)");
        d.end(w, Outcome.FAIL_RECOVERABLE); d.wake(w);
        eq(State.COMMAND, d.m.state(), "callbacks tardios do detector não mexem no comando");
        d.live.remove(Long.valueOf(c)); d.apply(d.m.onCommandEnd(c)); d.rec();
        eq(State.STARTING, d.m.state(), "comando concluído e preferência mantida: o detector volta");
        eq(1, d.maxValidLive, "nunca dois reconhecedores válidos juntos");
        // usuário desativa durante o comando
        d = new Driver(); d.enable(); d.ready(d.current()); d.wake(d.current()); d.apply(d.m.beginCommand(true, true)); long c2 = d.current();
        d.disable();
        eq(State.COMMAND, d.m.state(), "desativar a palavra durante um comando não corta o comando em andamento");
        d.live.remove(Long.valueOf(c2)); d.apply(d.m.onCommandEnd(c2)); d.rec();
        eq(State.DISABLED, d.m.state(), "mas depois do comando NÃO volta a escutar a palavra");
        check(d.live.isEmpty() && !d.m.hasPendingTimer(), "sem reconhecedor nem temporizador", "");
        // comando com a palavra-chave desativada (botão "Falar") é permitido e não liga a palavra
        d = new Driver(); d.apply(d.m.beginCommand(true, true)); long c3 = d.current(); d.live.remove(Long.valueOf(c3)); d.apply(d.m.onCommandEnd(c3)); d.rec();
        eq(State.DISABLED, d.m.state(), "botão Falar com a palavra desativada: ouve um comando e NÃO liga a escuta contínua");
        eq(0, d.starts, "nenhuma sessão de palavra-chave foi criada");
        eq(Cmd.NONE, d.m.beginCommand(false, true).cmd, "sem permissão: o comando é recusado");
        eq(Cmd.NONE, d.m.beginCommand(true, false).cmd, "voz desativada: o comando é recusado");
        check(d.m.onCommandEnd(12345L).stale, "fim de comando de token desconhecido é ignorado", "");

        // ---------------- 12) "parar tudo" (suspend)
        d = new Driver(); d.enable(); d.ready(d.current());
        d.apply(d.m.suspend("parar tudo"));
        eq(State.SUSPENDED, d.m.state(), "suspend para o reconhecedor");
        check(d.live.isEmpty() && !d.m.hasPendingTimer(), "e invalida timers", "");
        d.rec();
        eq(State.STARTING, d.m.state(), "a preferência continua habilitada: reconciliar retoma (como o núcleo faz ao voltar a IDLE)");
        d = new Driver();
        eq(Cmd.NONE, d.m.suspend("x").cmd, "suspend sem nada ativo não faz nada");

        // ---------------- 13) callbacks fora de ordem / duplicados
        d = new Driver(); d.enable(); long t = d.current();
        d.end(t, Outcome.NO_SPEECH);          // terminou antes de ficar pronto
        d.ready(t);                           // onReady tardio do mesmo ciclo
        d.end(t, Outcome.NO_SPEECH);          // e um segundo fim
        check(d.staleIgnored >= 2, "onReady e fim duplicados do ciclo encerrado são ignorados", "ignorados=" + d.staleIgnored);
        check(d.restartsScheduled == 1, "só UM reinício foi agendado", "agendados=" + d.restartsScheduled);
        d.ready(d.m.isCurrentWake(0) ? 0 : 999); // token inexistente
        eq(State.STARTING, d.m.state(), "token inexistente não muda nada");

        // ---------------- 14) 200 ciclos de ativar/desativar com callbacks tardios e toques repetidos
        d = new Driver();
        int enables = 0;
        for (int i = 0; i < 200; i++) {
            d.enable(); d.enable(); d.enable(); enables++;
            if (i % 2 == 0) d.ready(d.current());
            if (i % 3 == 0) d.end(d.current(), Outcome.FAIL_RECOVERABLE);
            d.disable(); d.disable();
            d.lateCallbackFromZombies(i % 2 == 0 ? Outcome.FAIL_RECOVERABLE : Outcome.NO_SPEECH);
            if (d.timer != 0) d.fireTimer(); // um temporizador que sobrou tenta agir
            check(d.m.state() == State.DISABLED && !d.m.hasValidSession() && !d.m.hasPendingTimer() && d.live.isEmpty(), "ciclo " + i + ": termina desativado e limpo", d.m.state() + "");
        }
        check(d.starts <= enables, "no máximo 1 início por ativação do usuário (" + d.starts + " inícios em " + enables + " ativações)", "");
        eq(1, d.maxValidLive, "nunca mais de 1 reconhecedor válido durante os 200 ciclos");
        check(d.maxLive <= 1, "nunca mais de 1 reconhecedor vivo (o início cancela o anterior)", "vivos=" + d.maxLive);

        // ---------------- 15) fuzz: sequências aleatórias com os invariantes
        long totalEvents = 0;
        for (int seed = 1; seed <= 40; seed++) {
            Random r = new Random(seed);
            d = new Driver();
            List<Long> history = new ArrayList<>();
            int consecutiveRestartsOnFailure = 0;
            for (int step = 0; step < 2500; step++) {
                totalEvents++;
                switch (r.nextInt(14)) {
                    case 0: d.wanted = r.nextBoolean(); d.rec(); break;
                    case 1: d.perm = r.nextInt(5) != 0; d.rec(); break;
                    case 2: d.avail = r.nextInt(6) != 0; d.rec(); break;
                    case 3: d.allowed = r.nextBoolean(); d.rec(); break;
                    case 4: if (d.current() != 0) d.ready(d.current()); break;
                    case 5: if (d.current() != 0) { history.add(d.current()); d.end(d.current(), Outcome.values()[r.nextInt(Outcome.values().length)]); } break;
                    case 6: if (d.current() != 0) { history.add(d.current()); d.wake(d.current()); } break;
                    case 7: if (d.timer != 0) d.fireTimer(); break;
                    case 8: d.apply(d.m.beginCommand(d.perm, r.nextInt(8) != 0)); break;
                    case 9: if (d.m.state() == State.COMMAND && d.current() != 0) { history.add(d.current()); d.live.remove(Long.valueOf(d.current())); d.apply(d.m.onCommandEnd(history.get(history.size() - 1))); } break;
                    case 10: if (!history.isEmpty()) { long old2 = history.get(r.nextInt(history.size())); d.ready(old2); d.end(old2, Outcome.values()[r.nextInt(Outcome.values().length)]); d.wake(old2); } break;
                    case 11: d.apply(d.m.suspend("fuzz")); break;
                    case 12: d.apply(d.m.manualRetry(d.wanted, d.perm, d.avail, d.allowed)); break;
                    default: d.rec(); break;
                }
                // --- invariantes ---
                State s = d.m.state();
                int valid = 0;
                for (long tk : d.live) if (d.m.isCurrentWake(tk) || d.m.isCurrentCommand(tk)) valid++;
                if (valid > 1) check(false, "invariante: no máximo 1 reconhecedor válido (seed " + seed + ")", "válidos=" + valid);
                if (d.live.size() > 1) check(false, "invariante: no máximo 1 reconhecedor vivo (seed " + seed + ")", "vivos=" + d.live.size());
                if (s == State.COMMAND && d.m.isCurrentWake(1) ) check(false, "invariante: COMMAND sem token de palavra", "");
                if (s == State.DISABLED && (d.m.hasValidSession() || d.m.hasPendingTimer())) check(false, "invariante: DISABLED sem sessão nem timer (seed " + seed + ")", "");
                if (s == State.ERROR && (d.m.hasValidSession() || d.m.hasPendingTimer())) check(false, "invariante: ERROR sem sessão nem timer (seed " + seed + ")", "");
                if ((s == State.WAITING_PERMISSION || s == State.UNAVAILABLE) && d.m.hasValidSession() && !d.live.isEmpty() && false) check(false, "n/a", "");
                if (!d.wanted && s != State.COMMAND && s != State.DISABLED && d.m.hasValidSession()) check(false, "invariante: sem preferência não há sessão (seed " + seed + ")", s + "");
                if (d.m.failures() > ListenMachine.MAX_RECOVERABLE_FAILURES + 1) check(false, "invariante: falhas limitadas (seed " + seed + ")", d.m.failures() + "");
            }
            passed++;
        }

        // ---------------- 16) REGRESSÃO: o modelo ANTIGO viola os critérios (prova que os testes novos pegam o bug)
        LegacyModel lg = new LegacyModel();
        lg.refreshNow(true);                       // ativa: 1 início
        lg.onFailureOther(0);                      // falha de rede/ocupado: agenda reinício
        lg.refreshNow(false);                      // usuário DESATIVA (o temporizador NÃO é cancelado)
        lg.refreshNow(true);                       // usuário REATIVA em seguida: novo início
        lg.tick(1000, true);                       // o temporizador ANTIGO dispara e reinicia a sessão NOVA
        int legacyDuplicateStarts = lg.starts;
        check(lg.starts >= 3, "modelo ANTIGO: ativar/desativar/ativar rápido gera inícios duplicados (" + lg.starts + " inícios; o certo é 2)", "");
        lg = new LegacyModel(); lg.refreshNow(true);
        long clock = 0; int legacyRestarts = 0;
        for (int i = 0; i < 100; i++) { lg.onFailureOther(clock); clock += 9000; int b = lg.starts; lg.tick(clock, true); legacyRestarts += lg.starts - b; }
        check(legacyRestarts >= 99, "modelo ANTIGO: 100 falhas seguidas => " + legacyRestarts + " reinícios (SEM limite = loop de ativação)", "");
        Driver nd = new Driver(); nd.enable(); int newRestarts = 0;
        for (int i = 0; i < 100; i++) { if (nd.current() == 0) break; nd.end(nd.current(), Outcome.FAIL_RECOVERABLE); if (nd.timer != 0) { nd.fireTimer(); newRestarts++; } }
        check(newRestarts <= ListenMachine.MAX_RECOVERABLE_FAILURES, "máquina NOVA: as mesmas 100 falhas => " + newRestarts + " reinícios (limite " + ListenMachine.MAX_RECOVERABLE_FAILURES + ") e depois ERROR", "");
        System.out.println("comparação: ANTIGO = " + legacyRestarts + " reinícios em 100 falhas | NOVO = " + newRestarts + " (limitado) | ativar-desativar-ativar: ANTIGO fez " + legacyDuplicateStarts + " inícios (o certo é 2)");

        System.out.println("fuzz: " + totalEvents + " eventos aleatórios em 40 sementes sem violar invariantes");

        System.out.println("\n" + passed + " verificações passaram, " + failed + " falharam.");
        System.exit(failed == 0 ? 0 : 1);
    }
}
