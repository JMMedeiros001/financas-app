import com.kupa.assistant.voice.EarconGuardCore;
import com.kupa.assistant.voice.EarconGuardCore.Window;
import java.util.*;

/** Testes da lógica do botão "Silenciar bipe do microfone" com um áudio falso. Prova a lógica de segurança; NÃO prova que o bipe some num aparelho. */
public class EarconTests {
    static int passed = 0, failed = 0;
    static void check(boolean ok, String name, String detail) { if (ok) passed++; else { failed++; System.out.println("FALHOU: " + name + "  ->  " + detail); } }
    static void eq(Object e, Object a, String name) { check(Objects.equals(e, a), name, "esperado=" + e + " obtido=" + a); }

    static final class FakeAudio implements EarconGuardCore.Audio {
        boolean muted, musicActive, refuse;
        int muteCalls = 0, unmuteCalls = 0;
        public boolean isMusicActive() { return musicActive; }
        public boolean isMusicMuted() { return muted; }
        public boolean muteMusic() { muteCalls++; if (refuse) return false; muted = true; return true; }
        public void unmuteMusic() { unmuteCalls++; muted = false; }
    }
    static final class FakeStore implements EarconGuardCore.Store {
        boolean flag; int writes = 0;
        public boolean mutedByUs() { return flag; }
        public void setMutedByUs(boolean v) { flag = v; writes++; }
    }

    public static void main(String[] args) {
        // 1) preferência desligada: não toca em nada
        FakeAudio a = new FakeAudio(); FakeStore s = new FakeStore(); EarconGuardCore g = new EarconGuardCore(a, s);
        check(!g.request(false, 1000).muting, "preferência desligada: não silencia", "");
        eq(0, a.muteCalls + a.unmuteCalls, "preferência desligada: nenhuma chamada ao áudio");

        // 2) ligada: silencia, e ao fim da janela desfaz
        Window w = g.request(true, 1200);
        check(w.muting && a.muted, "silencia o canal de mídia", "");
        check(s.flag, "grava 'fui eu' antes de silenciar", "");
        check(g.onWindowEnd(w.epoch), "a janela termina", "");
        check(!a.muted && !s.flag, "desfaz o mudo e limpa a marca", "");
        eq(1, g.mutes(), "1 mudo"); eq(1, g.unmutes(), "1 desmudo");

        // 3) outro app tocando mídia: NÃO silencia
        a = new FakeAudio(); a.musicActive = true; s = new FakeStore(); g = new EarconGuardCore(a, s);
        check(!g.request(true, 1000).muting, "mídia de outro app tocando: não silencia", "");
        eq(0, a.muteCalls, "e nem tenta");

        // 4) já mudo por outro motivo: não mexe e NUNCA desmuda o que não foi o KUPA que mudou
        a = new FakeAudio(); a.muted = true; s = new FakeStore(); g = new EarconGuardCore(a, s);
        check(!g.request(true, 1000).muting, "já estava mudo: não silencia", "");
        g.release(); g.release();
        check(a.muted && a.unmuteCalls == 0, "release não desmuda o que não foi o KUPA que mudou", "");

        // 5) janelas sobrepostas: um único mudo e um único desmudo, na última janela
        a = new FakeAudio(); s = new FakeStore(); g = new EarconGuardCore(a, s);
        Window w1 = g.request(true, 1000), w2 = g.request(true, 1000), w3 = g.request(true, 1000);
        eq(1, a.muteCalls, "3 pedidos = 1 só mudo");
        check(!g.onWindowEnd(w1.epoch) && !g.onWindowEnd(w2.epoch), "janelas antigas são ignoradas", "");
        check(a.muted, "continua mudo até a última janela", "");
        check(g.onWindowEnd(w3.epoch) && !a.muted, "a última janela desfaz", "");
        eq(1, a.unmuteCalls, "um só desmudo");

        // 6) liberar antes de o KUPA falar
        a = new FakeAudio(); s = new FakeStore(); g = new EarconGuardCore(a, s);
        Window wf = g.request(true, 5000);
        g.release();
        check(!a.muted && !g.isMuting(), "release antes de falar desmuda na hora", "");
        check(!g.onWindowEnd(wf.epoch), "o temporizador antigo depois do release é ignorado", "");
        eq(1, a.unmuteCalls, "sem desmudo duplo");
        g.release();
        eq(1, a.unmuteCalls, "release repetido é idempotente");

        // 7) desligar a preferência no meio de uma janela solta na hora
        a = new FakeAudio(); s = new FakeStore(); g = new EarconGuardCore(a, s);
        g.request(true, 5000);
        g.request(false, 5000);
        check(!a.muted && !s.flag, "desligar a preferência desfaz o mudo imediatamente", "");

        // 8) o sistema recusou o mudo
        a = new FakeAudio(); a.refuse = true; s = new FakeStore(); g = new EarconGuardCore(a, s);
        check(!g.request(true, 1000).muting && !g.isMuting() && !s.flag, "mudo recusado: nada fica marcado", "");

        // 9) o processo morreu com o canal mudo: recuperação ao iniciar
        a = new FakeAudio(); s = new FakeStore(); g = new EarconGuardCore(a, s);
        g.request(true, 1000); // "morre" aqui: o estado fica salvo
        EarconGuardCore novo = new EarconGuardCore(a, s);
        check(a.muted && s.flag, "(o app morreu mudo)", "");
        novo.recoverAfterCrash();
        check(!a.muted && !s.flag, "ao iniciar, desfaz o mudo que o KUPA fez", "");
        a = new FakeAudio(); s = new FakeStore(); new EarconGuardCore(a, s).recoverAfterCrash();
        eq(0, a.unmuteCalls, "sem marca, a recuperação não mexe em nada");

        // 10) 2000 ciclos aleatórios: sempre equilibrado e nunca desmuda o que não é dele
        Random r = new Random(7);
        for (int seed = 1; seed <= 20; seed++) {
            r = new Random(seed);
            a = new FakeAudio(); s = new FakeStore(); g = new EarconGuardCore(a, s);
            List<Long> pend = new ArrayList<>();
            boolean userMutedBefore = false;
            for (int i = 0; i < 2000; i++) {
                switch (r.nextInt(7)) {
                    case 0: a.musicActive = r.nextBoolean(); break;
                    case 1: if (!g.isMuting()) { a.muted = r.nextInt(4) == 0; userMutedBefore = a.muted; } break;
                    case 2: case 3: { Window x = g.request(r.nextInt(5) != 0, 800); if (x.muting) pend.add(x.epoch); break; }
                    case 4: if (!pend.isEmpty()) g.onWindowEnd(pend.remove(r.nextInt(pend.size()))); break;
                    case 5: g.release(); break;
                    default: break;
                }
                if (g.isMuting() && !a.muted) check(false, "invariante: marcado mudo => canal mudo (seed " + seed + ")", "");
                if (g.isMuting() && !s.flag) check(false, "invariante: mudo do KUPA sempre tem a marca de recuperação", "");
                if (!g.isMuting() && s.flag) check(false, "invariante: sem mudo do KUPA não há marca", "");
            }
            g.release();
            check(g.mutes() == g.unmutes(), "seed " + seed + ": mudos == desmudos (" + g.mutes() + ")", g.mutes() + " x " + g.unmutes());
            check(!g.isMuting() && !s.flag, "seed " + seed + ": termina limpo", "");
            passed++;
        }
        System.out.println("\n" + passed + " verificações passaram, " + failed + " falharam.");
        System.exit(failed == 0 ? 0 : 1);
    }
}
