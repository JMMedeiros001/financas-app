import com.kupa.assistant.intent.*;
import com.kupa.assistant.security.*;
import com.kupa.assistant.voice.*;
import com.kupa.assistant.voice.VoiceVerification.Result;
import java.util.*;

/** Testes do motor da palavra de ativação e da arquitetura de verificação de voz (hoje indisponível). */
public class VoiceTests {
    static int passed = 0, failed = 0;
    static void check(boolean ok, String name, String detail) { if (ok) passed++; else { failed++; System.out.println("FALHOU: " + name + "  ->  " + detail); } }
    static void eq(Object e, Object a, String name) { check(Objects.equals(e, a), name, "esperado=" + e + " obtido=" + a); }
    static ActivationNameEngine kupa() { return new ActivationNameEngine("Kupa", ActivationNameEngine.DEFAULT_PHONETIC_VARIANTS); }
    static String cmd(ActivationNameEngine e, String text, boolean variants) { ActivationNameEngine.Match m = e.match(text, variants); return m == null ? null : m.command; }

    public static void main(String[] args) {
        // ---- nome padrão: comportamento antigo preservado
        ActivationNameEngine k = kupa();
        eq("abra o WhatsApp", cmd(k, "Kupa, abra o WhatsApp", true), "Kupa, comando");
        eq("", cmd(k, "Kupa", true), "só o nome");
        eq("abra o youtube", cmd(k, "oi kupa abra o youtube", true), "depois de 'oi'");
        eq("liga pro Dudu", cmd(k, "Cupa liga pro Dudu", true), "variante 'cupa' no começo");
        eq("abre a câmera", cmd(k, "Culpa, abre a câmera", true), "variante 'culpa' no começo");
        eq(null, cmd(k, "a culpa é minha", true), "'culpa' no meio NÃO ativa");
        eq(null, cmd(k, "foi culpa dele", true), "'culpa' no meio NÃO ativa (2)");
        eq(null, cmd(k, "Culpa abre a câmera", false), "variantes desligadas");
        eq("abre o app", cmd(k, "Kupá, abre o app", true), "acento no nome");
        eq(null, cmd(k, "bom dia pessoal tudo certo kupa", true), "nome longe do começo não ativa");
        eq(null, cmd(k, "", true), "vazio");
        eq(null, cmd(k, "   ", true), "espaços");
        check(k.match("Kupa, abra", true).exact, "nome exato é 'exact'", "");
        check(!k.match("Cupa abra", true).exact, "variante não é 'exact'", "");

        // ---- nome personalizado
        ActivationNameEngine luna = new ActivationNameEngine("Luna", Collections.<String>emptyList());
        eq("abra o WhatsApp", cmd(luna, "Luna, abra o WhatsApp", true), "nome novo ativa");
        eq(null, cmd(luna, "Kupa, abra o WhatsApp", true), "nome antigo NÃO ativa depois da troca");
        eq(null, cmd(luna, "Cupa abra", true), "variantes do nome antigo não vazam para o novo");
        eq("oi tudo bem", cmd(luna, "ei luna oi tudo bem", true), "depois de chamado");
        ActivationNameEngine both = new ActivationNameEngine("Luna", Arrays.asList("kupa"));
        eq("abra", cmd(both, "Kupa abra", true), "o usuário pode MANTER o nome antigo como variante");
        eq("abra", cmd(new ActivationNameEngine("Luna", Arrays.asList("luma", "Lúna")), "Luma abra", true), "variante personalizada");
        check(new ActivationNameEngine("Luna", Arrays.asList("luna", "  ", "dois nomes", "ab")).variants().size() >= 0, "variantes inválidas são ignoradas sem quebrar", "");
        eq(1, new ActivationNameEngine("Luna", Arrays.asList("luna", "luma", "dois nomes")).variants().size(), "variante igual ao nome e com espaço são descartadas");
        eq(Collections.emptySet(), new ActivationNameEngine("Luna", null).variants(), "sem variantes");
        eq(null, cmd(new ActivationNameEngine("", null), "Kupa abra", true), "sem nome nunca ativa");

        // ---- validação de nomes
        eq(null, ActivationNameEngine.validateName("Luna"), "nome válido");
        eq(null, ActivationNameEngine.validateName("Jarvis"), "nome válido 2");
        eq(null, ActivationNameEngine.validateName("Zé2"), "nome curto com número");
        check(ActivationNameEngine.validateName("") != null, "vazio é inválido", "");
        check(ActivationNameEngine.validateName("ab") != null, "muito curto", "");
        check(ActivationNameEngine.validateName("dona luna") != null, "duas palavras", "");
        check(ActivationNameEngine.validateName("abrir") != null, "palavra de comando", "");
        check(ActivationNameEngine.validateName("Oi") != null, "chamado comum", "");
        check(ActivationNameEngine.validateName("atender") != null, "comando de chamadas", "");
        check(ActivationNameEngine.validateName("12345") != null, "só números", "");
        check(ActivationNameEngine.validateName("a".repeat(21)) != null, "longo demais", "");
        check(ActivationNameEngine.validateName("Lu-na") != null, "símbolos", "");
        eq(null, ActivationNameEngine.validateVariant("luma", "luna"), "variante válida");
        check(ActivationNameEngine.validateVariant("luna", "Luna") != null, "variante igual ao nome", "");
        check(ActivationNameEngine.validateVariant("para", "luna") != null, "variante com palavra de comando", "");
        check(ActivationNameEngine.validateVariant("duas palavras", "luna") != null, "variante com espaço", "");

        // ---- sugestões (aprendizado SÓ com confirmação)
        eq("kupo", k.suggestCandidate("Kupo abre o zap"), "palavra quase igual vira CANDIDATO");
        eq("kupu", k.suggestCandidate("oi kupu liga pro dudu"), "candidato depois de chamado");
        eq(null, k.suggestCandidate("kupa abre o zap"), "já é o nome: sem candidato");
        eq(null, k.suggestCandidate("cupa abre o zap"), "já é variante: sem candidato");
        eq(null, k.suggestCandidate("abra o zap"), "palavra distante não é candidato");
        eq(null, k.suggestCandidate("o kupo abre"), "só olha o começo da frase");
        eq(null, new ActivationNameEngine("Zé", null).suggestCandidate("zo abre"), "nomes curtos não geram candidatos (evita excesso)");
        check(!kupa().variants().contains("kupo"), "candidato NÃO vira variante sozinho", "");
        eq(1, ActivationNameEngine.distance("kupa", "kupo"), "distância de edição");
        eq(0, ActivationNameEngine.distance("kupa", "kupa"), "distância zero");
        eq(2, ActivationNameEngine.distance("kupa", "kapo"), "distância 2");

        // ---- TextNorm usa as palavras configuradas
        TextNorm.setWakeWords(new ActivationNameEngine("Luna", Arrays.asList("luma")).allWords());
        eq("abra o whatsapp", TextNorm.stripWake(TextNorm.normalize("Luna, abra o WhatsApp")), "TextNorm limpa o novo nome");
        eq("abra o whatsapp", TextNorm.stripWake(TextNorm.normalize("oi luma abra o whatsapp")), "TextNorm limpa a variante");
        eq("kupa abra o whatsapp", TextNorm.stripWake(TextNorm.normalize("Kupa abra o WhatsApp")), "o nome antigo deixa de ser removido");
        eq(KupaIntent.Kind.OPEN_APP, new CommandInterpreter().interpret("Luna, abra o WhatsApp").intents.get(0).kind, "o interpretador entende comandos com o nome novo");
        TextNorm.setWakeWords(k.allWords());
        eq(KupaIntent.Kind.OPEN_APP, new CommandInterpreter().interpret("Kupa, abra o WhatsApp").intents.get(0).kind, "e volta ao nome padrão");

        // ---- reconhecimento de falante: INDISPONÍVEL, nunca concede nada
        VoiceVerification.SpeakerVerifier v = new VoiceVerification.UnavailableSpeakerVerifier();
        check(!v.isAvailable(), "verificador real não existe hoje", "");
        eq(Result.UNAVAILABLE, v.verify(new byte[3200]), "resultado é UNAVAILABLE");
        eq(Result.UNAVAILABLE, v.verify(null), "amostra nula também");
        check(v.describe().contains("INDISPONÍVEL") && v.describe().contains("não identifica"), "a descrição diz a verdade", v.describe());
        for (Result r : Result.values()) check(!VoiceVerification.grantsAnyPermission(r), "nenhum resultado concede permissão: " + r, "");
        for (Result r : Result.values()) check(!VoiceVerification.explain(r).isEmpty(), "todo resultado tem explicação: " + r, "");
        // a política trata voz como NÃO verificada, mesmo se o "verificador" disser que reconheceu
        eq(Verdict.Kind.NATIVE_AUTH, SecurityPolicy.decide(RiskLevel.CRITICAL, Origin.USER_VOICE, SecurityState.NORMAL, false, false, true).kind, "voz reconhecida ou não: CRÍTICO exige autenticação do aparelho");
        eq(Verdict.Kind.CONFIRM_TWICE, SecurityPolicy.decide(RiskLevel.HIGH, Origin.USER_VOICE, SecurityState.NORMAL, false, false, true).kind, "voz reconhecida ou não: ALTO exige 2 confirmações");
        eq(Verdict.Kind.BLOCK, SecurityPolicy.decide(RiskLevel.LOW, Origin.USER_VOICE, SecurityState.SAFE_SHUTDOWN, false, false, true).kind, "voz não reativa o modo seguro");
        check(SecurityPolicy.weakeningSettingNeedsAuth(), "voz não enfraquece proteções", "");

        System.out.println("\n" + passed + " verificações passaram, " + failed + " falharam.");
        System.exit(failed == 0 ? 0 : 1);
    }
}
