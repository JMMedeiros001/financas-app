import com.kupa.assistant.ai.*;
import com.kupa.assistant.ai.BackendUrlValidator.Problem;
import java.net.*;
import java.util.Objects;
import javax.net.ssl.SSLHandshakeException;

/** Testes da validação da URL do backend e da classificação de falhas de conexão. */
public class BackendTests {
    static int passed = 0, failed = 0;
    static void check(boolean ok, String name, String detail) { if (ok) passed++; else { failed++; System.out.println("FALHOU: " + name + "  ->  " + detail); } }
    static void eq(Object e, Object a, String name) { check(Objects.equals(e, a), name, "esperado=" + e + " obtido=" + a); }
    static Problem prod(String u) { return BackendUrlValidator.validate(u, false).problem; }
    static Problem dev(String u) { return BackendUrlValidator.validate(u, true).problem; }

    public static void main(String[] args) {
        // ---- produção
        eq(Problem.EMPTY, prod(""), "vazio");
        eq(Problem.EMPTY, prod("   "), "só espaços");
        eq(Problem.EMPTY, prod(null), "nulo");
        eq(Problem.NONE, prod("https://kupa-backend.onrender.com"), "https remoto válido");
        eq("https://kupa-backend.onrender.com", BackendUrlValidator.validate("  https://KUPA-backend.onrender.com/  ", false).normalized, "normaliza (espaços, caixa, barra final)");
        eq("https://api.meudominio.com.br:8443/kupa", BackendUrlValidator.validate("https://api.meudominio.com.br:8443/kupa/", false).normalized, "mantém porta e caminho");
        eq(Problem.INSECURE_REMOTE, prod("http://meu-servidor.com"), "http remoto é recusado");
        eq(Problem.INSECURE_REMOTE, prod("http://192.168.0.10:8787"), "http mesmo local é recusado em produção");
        eq(Problem.LOOPBACK, prod("https://localhost"), "localhost em produção aponta para o próprio celular");
        eq(Problem.LOOPBACK, prod("https://127.0.0.1:8787"), "127.0.0.1 em produção");
        eq(Problem.PLACEHOLDER, prod("https://exemplo.com"), "exemplo.com não é real");
        eq(Problem.PLACEHOLDER, prod("https://seu-backend.onrender.com"), "seu-backend é modelo");
        eq(Problem.PLACEHOLDER, prod("https://<endereço-do-backend>"), "<...> é modelo");
        eq(Problem.PLACEHOLDER, prod("https://nome-do-seu-servico.onrender.com"), "nome-do-seu-servico é modelo");
        eq(Problem.MALFORMED, prod("kupa-backend.onrender.com"), "sem esquema");
        eq(Problem.MALFORMED, prod("https://"), "sem host");
        eq(Problem.MALFORMED, prod("https://a b.com"), "com espaço");
        eq(Problem.UNSUPPORTED_SCHEME, prod("ftp://servidor.com"), "ftp");
        eq(Problem.HAS_CREDENTIALS, prod("https://usuario:senha@servidor.com"), "credenciais na URL");
        eq(Problem.HAS_QUERY_OR_FRAGMENT, prod("https://servidor.com/?token=abc"), "query na URL");
        eq(Problem.HAS_QUERY_OR_FRAGMENT, prod("https://servidor.com/#x"), "fragmento");
        eq(Problem.BAD_PORT, prod("https://servidor.com:99999"), "porta inválida");
        check(!BackendUrlValidator.validate("https://servidor.com?x=1", false).message.isEmpty(), "toda falha tem mensagem em português", "");
        for (String bad : new String[]{"", "x", "http://a.com", "https://localhost", "https://exemplo.com", "ftp://a.com", "https://u:p@a.com"}) {
            check(!BackendUrlValidator.validate(bad, false).ok() && BackendUrlValidator.validate(bad, false).normalized.isEmpty(), "inválida não devolve URL normalizada: " + bad, "");
        }
        // ---- desenvolvimento (debug)
        eq(Problem.NONE, dev("http://192.168.0.10:8787"), "debug: http em rede local");
        eq(Problem.NONE, dev("http://10.0.2.2:8787"), "debug: emulador");
        eq(Problem.NONE, dev("http://172.16.5.4:8787"), "debug: 172.16/12");
        eq(Problem.NONE, dev("http://meupc.local:8787"), "debug: mDNS .local");
        eq(Problem.NONE, dev("http://localhost:8787"), "debug: localhost (com adb reverse)");
        eq(Problem.INSECURE_REMOTE, dev("http://meu-servidor.com"), "debug: http remoto continua recusado");
        eq(Problem.INSECURE_REMOTE, dev("http://172.32.0.1:8787"), "debug: 172.32 NÃO é rede privada");
        eq(Problem.INSECURE_REMOTE, dev("http://8.8.8.8"), "debug: IP público");
        eq(Problem.NONE, dev("https://kupa-backend.onrender.com"), "debug: https remoto também vale");
        eq(Problem.PLACEHOLDER, dev("http://exemplo.local"), "debug: exemplo continua recusado");

        // ---- classificação de falhas
        eq(BackendFailure.Kind.DNS, BackendFailure.fromException(new UnknownHostException("x")).kind, "DNS");
        eq(BackendFailure.Kind.TLS, BackendFailure.fromException(new SSLHandshakeException("PKIX path building failed")).kind, "TLS (certificado)");
        eq(BackendFailure.Kind.TLS, BackendFailure.fromException(new java.io.IOException(new SSLHandshakeException("x"))).kind, "TLS embrulhado em outra exceção");
        eq(BackendFailure.Kind.TIMEOUT, BackendFailure.fromException(new SocketTimeoutException("t")).kind, "timeout");
        eq(BackendFailure.Kind.CONNECTION_REFUSED, BackendFailure.fromException(new ConnectException("refused")).kind, "recusada");
        eq(BackendFailure.Kind.UNREACHABLE, BackendFailure.fromException(new NoRouteToHostException("x")).kind, "sem rota");
        eq(BackendFailure.Kind.UNREACHABLE, BackendFailure.fromException(new java.io.IOException("x")).kind, "IO genérico");
        eq(BackendFailure.Kind.UNKNOWN, BackendFailure.fromException(new IllegalStateException("x")).kind, "desconhecido");
        check(BackendFailure.fromException(new SSLHandshakeException("x")).message.contains("não ignora"), "mensagem TLS promete não ignorar certificado", "");
        eq(BackendFailure.Kind.HTTP_NOT_BACKEND, BackendFailure.fromHttpStatus(404, true).kind, "404 no /health = não é o backend");
        eq(BackendFailure.Kind.HTTP_OTHER, BackendFailure.fromHttpStatus(404, false).kind, "404 em outra rota");
        eq(BackendFailure.Kind.HTTP_AUTH, BackendFailure.fromHttpStatus(401, false).kind, "401 = token");
        eq(BackendFailure.Kind.HTTP_AUTH, BackendFailure.fromHttpStatus(403, false).kind, "403 = token");
        eq(BackendFailure.Kind.HTTP_RATE_LIMIT, BackendFailure.fromHttpStatus(429, false).kind, "429");
        eq(BackendFailure.Kind.HTTP_STARTING, BackendFailure.fromHttpStatus(503, true).kind, "503 = iniciando/indisponível");
        eq(BackendFailure.Kind.HTTP_STARTING, BackendFailure.fromHttpStatus(502, true).kind, "502");
        eq(BackendFailure.Kind.HTTP_SERVER, BackendFailure.fromHttpStatus(500, true).kind, "500");
        eq("http_503", BackendFailure.fromHttpStatus(503, true).code, "código estável");
        eq(BackendFailure.Kind.INVALID_RESPONSE, BackendFailure.invalidResponse().kind, "resposta que não é do KUPA");

        System.out.println("\n" + passed + " verificações passaram, " + failed + " falharam.");
        System.exit(failed == 0 ? 0 : 1);
    }
}
