import com.kupa.assistant.visual.*;
import com.kupa.assistant.visual.CoreScene.Prim;
import java.util.*;

/** Testes do núcleo visual: mapeamento de modo (só fatos reais), animações honestas, limites, contraste e paleta. */
public class CoreSceneTests {
    static int passed = 0, failed = 0;
    static void check(boolean ok, String name, String detail) { if (ok) passed++; else { failed++; System.out.println("FALHOU: " + name + "  ->  " + detail); } }
    static void eq(Object e, Object a, String name) { check(Objects.equals(e, a), name, "esperado=" + e + " obtido=" + a); }

    static String sig(List<Prim> l) {
        StringBuilder sb = new StringBuilder();
        for (Prim p : l) sb.append(p.kind).append(',').append(Math.round(p.x * 1000)).append(',').append(Math.round(p.y * 1000)).append(',').append(Math.round(p.r * 1000))
            .append(',').append(Math.round(p.a0 * 100)).append(',').append(Math.round(p.sweep * 100)).append(',').append(Math.round(p.x2 * 1000)).append(',').append(Math.round(p.y2 * 1000))
            .append(',').append(Math.round(p.w * 10000)).append(',').append(p.argb).append(';');
        return sb.toString();
    }
    static CoreMode m(boolean svc, boolean perm, boolean mic, boolean cmd, String st, boolean conf, boolean safe) { return CoreMode.resolve(svc, perm, mic, cmd, st, conf, safe); }
    static int countRgb(List<Prim> l, int rgb) { int n = 0; for (Prim p : l) if ((p.argb & 0xFFFFFF) == (rgb & 0xFFFFFF)) n++; return n; }

    public static void main(String[] args) {
        // ---------------- mapeamento de modo
        eq(CoreMode.IDLE, m(true, true, false, false, "WAITING", false, false), "serviço rodando, nada acontecendo = IDLE");
        eq(CoreMode.OFF, m(false, true, false, false, "WAITING", false, false), "serviço parado = OFF");
        eq(CoreMode.NEEDS_PERMISSION, m(true, false, false, false, "WAITING", false, false), "sem permissão = NEEDS_PERMISSION");
        eq(CoreMode.LISTENING, m(true, true, true, false, "WAITING", false, false), "microfone ABERTO = LISTENING");
        eq(CoreMode.COMMAND, m(true, true, true, true, "LISTENING", false, false), "ouvindo comando com microfone aberto = COMMAND");
        eq(CoreMode.STARTING, m(true, true, false, false, "LISTENING", false, false), "o assistente quer ouvir mas o microfone NÃO abriu = STARTING (não finge escuta)");
        eq(CoreMode.STARTING, m(true, true, false, false, "ACTIVATED", false, false), "ativado, microfone ainda fechado = STARTING");
        for (String s : new String[]{"THINKING", "SEARCHING", "SCREEN_ANALYSIS", "EXECUTING", "TRANSLATING", "READING"}) eq(CoreMode.PROCESSING, m(true, true, false, false, s, false, false), s + " = PROCESSING");
        eq(CoreMode.SPEAKING, m(true, true, false, false, "SPEAKING", false, false), "falando = SPEAKING");
        eq(CoreMode.CONFIRM, m(true, true, false, false, "WAITING", true, false), "confirmação pendente = CONFIRM");
        eq(CoreMode.CONFIRM, m(true, true, false, false, "SPEAKING", true, false), "confirmação vence a fala");
        eq(CoreMode.ERROR, m(true, true, true, false, "ERROR", true, false), "erro vence tudo");
        eq(CoreMode.ERROR, m(true, true, false, false, "WAITING", false, true), "modo seguro = ERROR");
        eq(CoreMode.PROCESSING, m(true, true, true, false, "THINKING", false, false), "processando vence microfone aberto");
        eq(CoreMode.IDLE, CoreMode.resolve(true, true, false, false, null, false, false), "estado nulo não quebra");
        // verdade por força bruta: LISTENING/COMMAND SÓ com o microfone realmente aberto
        String[] states = {"WAITING", "LISTENING", "ACTIVATED", "THINKING", "SPEAKING", "ERROR", "COMPLETED", "HAPPY", "SEARCHING", "EXECUTING", "SURPRISED"};
        int combos = 0;
        for (boolean svc : new boolean[]{true, false}) for (boolean perm : new boolean[]{true, false}) for (boolean mic : new boolean[]{true, false})
            for (boolean cmd : new boolean[]{true, false}) for (String st : states) for (boolean conf : new boolean[]{true, false}) for (boolean safe : new boolean[]{true, false}) {
                CoreMode r = m(svc, perm, mic, cmd, st, conf, safe);
                combos++;
                if ((r == CoreMode.LISTENING || r == CoreMode.COMMAND) && !mic) check(false, "invariante: escuta só com microfone aberto", r + " mic=" + mic);
                if (safe && r != CoreMode.ERROR) check(false, "invariante: modo seguro sempre ERROR", r + "");
            }
        passed++;
        System.out.println("mapeamento: " + combos + " combinações de fatos conferidas");

        // ---------------- animações honestas
        CoreMode[] all = CoreMode.values();
        for (CoreMode md : new CoreMode[]{CoreMode.OFF, CoreMode.NEEDS_PERMISSION, CoreMode.ERROR}) {
            eq(sig(CoreScene.build(md, 0f, 0f, 0f, true)), sig(CoreScene.build(md, 37.2f, 1f, 1f, true)), md + " é ESTÁTICO (nenhuma atividade fingida)");
        }
        eq(sig(CoreScene.build(CoreMode.IDLE, 5f, 0f, 0f, true)), sig(CoreScene.build(CoreMode.IDLE, 5f, 1f, 1f, true)), "IDLE ignora nível de microfone e pulso (não finge escuta nem fala)");
        check(!sig(CoreScene.build(CoreMode.LISTENING, 5f, 0f, 0f, true)).equals(sig(CoreScene.build(CoreMode.LISTENING, 5f, 1f, 0f, true))), "LISTENING reage ao nível REAL do microfone", "");
        check(!sig(CoreScene.build(CoreMode.COMMAND, 5f, 0f, 0f, true)).equals(sig(CoreScene.build(CoreMode.COMMAND, 5f, 1f, 0f, true))), "COMMAND reage ao nível do microfone", "");
        eq(sig(CoreScene.build(CoreMode.LISTENING, 5f, 0f, 0f, true)), sig(CoreScene.build(CoreMode.LISTENING, 5f, 0f, 1f, true)), "LISTENING ignora pulso de fala");
        check(!sig(CoreScene.build(CoreMode.SPEAKING, 5f, 0f, 0f, true)).equals(sig(CoreScene.build(CoreMode.SPEAKING, 5f, 0f, 1f, true))), "SPEAKING reage ao pulso REAL da fala", "");
        eq(sig(CoreScene.build(CoreMode.SPEAKING, 5f, 1f, 0f, true)), sig(CoreScene.build(CoreMode.SPEAKING, 5f, 0f, 0f, true)), "SPEAKING ignora nível de microfone");
        for (CoreMode md : all) {
            eq(sig(CoreScene.build(md, 0f, 0f, 0f, false)), sig(CoreScene.build(md, 9.9f, 1f, 1f, false)), md + ": movimento reduzido = quadro estático, sem nível nem pulso");
        }
        check(!sig(CoreScene.build(CoreMode.IDLE, 0f, 0f, 0f, true)).equals(sig(CoreScene.build(CoreMode.IDLE, 2f, 0f, 0f, true))), "IDLE se move (rotação lenta)", "");
        // velocidade: o anel A (primeiro ARC de r=0.85) gira mais rápido no processamento que no repouso
        float dIdle = Math.abs(firstArc(CoreScene.build(CoreMode.IDLE, 1f, 0, 0, true), 0.85f) - firstArc(CoreScene.build(CoreMode.IDLE, 0f, 0, 0, true), 0.85f));
        float dProc = Math.abs(firstArc(CoreScene.build(CoreMode.PROCESSING, 0.5f, 0, 0, true), 0.85f) - firstArc(CoreScene.build(CoreMode.PROCESSING, 0f, 0, 0, true), 0.85f));
        check(dProc * 2 > dIdle * 3, "PROCESSING gira bem mais rápido que IDLE (" + dProc * 2 + "° /s contra " + dIdle + "°/s)", "");
        int whiteIdle = countRgb(CoreScene.build(CoreMode.IDLE, 1f, 0, 0, true), Palette.COLD_WHITE);
        int whiteProc = countRgb(CoreScene.build(CoreMode.PROCESSING, 1f, 0, 0, true), Palette.COLD_WHITE);
        check(whiteProc >= whiteIdle + 3, "PROCESSING tem 3 pulsos luminosos que o repouso não tem", whiteIdle + " vs " + whiteProc);

        // âmbar só em aviso/confirmação
        for (CoreMode md : all) {
            int amber = countRgb(CoreScene.build(md, 1f, 0.5f, 0.5f, true), Palette.AMBER);
            boolean allowed = md == CoreMode.CONFIRM || md == CoreMode.NEEDS_PERMISSION;
            check(allowed ? amber > 0 : amber == 0, "âmbar só em confirmação/aviso: " + md + " (" + amber + " prims)", "");
        }
        check(countRgb(CoreScene.build(CoreMode.ERROR, 1f, 0, 0, true), Palette.ERROR_RED) > 0, "ERROR usa a cor de erro", "");

        // todos os modos têm aparência distinta
        Set<String> sigs = new HashSet<>();
        for (CoreMode md : all) sigs.add(sig(CoreScene.build(md, 1.3f, 0.6f, 0.6f, true)));
        eq(all.length, sigs.size(), "cada um dos " + all.length + " modos tem aparência própria");

        // ---------------- limites e desempenho
        int maxPrims = 0;
        for (CoreMode md : all) for (float t : new float[]{0f, 0.37f, 1.9f, 33.3f, 1000f}) for (float lv : new float[]{0f, 0.5f, 1f, 7f, -3f}) {
            List<Prim> fr = CoreScene.build(md, t, lv, lv, true);
            maxPrims = Math.max(maxPrims, fr.size());
            for (Prim p : fr) {
                float reach;
                if (p.kind == CoreScene.LINE) reach = (float) Math.max(Math.hypot(p.x, p.y), Math.hypot(p.x2, p.y2)) + p.w / 2;
                else if (p.kind == CoreScene.DISC) reach = (float) Math.hypot(p.x, p.y) + p.r;
                else reach = p.r + p.w / 2;
                boolean finite = !Float.isNaN(reach) && !Float.isInfinite(reach) && !Float.isNaN(p.a0) && !Float.isNaN(p.sweep);
                if (!finite || reach > 1.02f || p.w < 0 || (p.argb >>> 24) > 255) check(false, "primitiva dentro do círculo unitário e finita (" + md + ")", "alcance=" + reach);
            }
        }
        passed++;
        check(maxPrims <= 200, "no máximo 200 primitivas por quadro (custo de desenho controlado): " + maxPrims, "");
        check(CoreScene.build(CoreMode.IDLE, 0, 0, 0, true).size() <= CoreScene.build(CoreMode.PROCESSING, 0, 0, 0, true).size(), "repouso desenha menos que processamento", "");

        // ---------------- símbolo original
        List<Prim> mk = CoreScene.mark();
        check(mk.size() >= 10 && mk.size() <= 30, "símbolo com " + mk.size() + " primitivas", "");
        for (Prim p : mk) {
            float reach = p.kind == CoreScene.LINE ? (float) Math.max(Math.hypot(p.x, p.y), Math.hypot(p.x2, p.y2)) + p.w / 2 : p.kind == CoreScene.DISC ? (float) Math.hypot(p.x, p.y) + p.r : p.r + p.w / 2;
            if (reach > 1.0f) check(false, "símbolo cabe no círculo", "alcance=" + reach);
        }
        passed++;
        eq(sig(CoreScene.mark()), sig(CoreScene.mark()), "símbolo é determinístico");

        // ---------------- paleta: valores pedidos e contraste legível
        eq(0xFF0756A5, Palette.TARDIS_BLUE, "azul TARDIS #0756A5");
        eq(0xFF061426, Palette.DEEP_BLUE, "azul profundo #061426");
        eq(0xFF030811, Palette.SPACE, "fundo espacial #030811");
        eq(0xFF167DDB, Palette.TECH_BLUE, "azul tecnológico #167DDB");
        eq(0xFF50E6FF, Palette.CYAN, "ciano holográfico #50E6FF");
        eq(0xFFEAF7FF, Palette.COLD_WHITE, "branco frio #EAF7FF");
        eq(0xFF10253C, Palette.PANEL, "azul de painel #10253C");
        eq(0xFF42DDAA, Palette.OK_GREEN, "verde de confirmação #42DDAA");
        eq(0xFFFFBF69, Palette.AMBER, "âmbar #FFBF69");
        check(Palette.contrast(Palette.COLD_WHITE, Palette.PANEL) >= 7.0, "texto principal no painel: contraste >= 7 (" + String.format("%.1f", Palette.contrast(Palette.COLD_WHITE, Palette.PANEL)) + ")", "");
        check(Palette.contrast(Palette.COLD_WHITE, Palette.SPACE) >= 7.0, "texto principal no fundo: contraste >= 7", "");
        check(Palette.contrast(Palette.MUTED, Palette.PANEL) >= 4.5, "texto secundário no painel: contraste >= 4.5 (" + String.format("%.1f", Palette.contrast(Palette.MUTED, Palette.PANEL)) + ")", "");
        check(Palette.contrast(Palette.MUTED, Palette.SPACE) >= 4.5, "texto secundário no fundo: contraste >= 4.5", "");
        check(Palette.contrast(Palette.CYAN, Palette.PANEL) >= 4.5, "ciano no painel: contraste >= 4.5", "");
        check(Palette.contrast(Palette.AMBER, Palette.PANEL) >= 4.5, "âmbar no painel: contraste >= 4.5", "");
        check(Palette.contrast(Palette.OK_GREEN, Palette.PANEL) >= 4.5, "verde no painel: contraste >= 4.5", "");
        check(Palette.contrast(Palette.ERROR_RED, Palette.PANEL) >= 4.5, "vermelho de erro no painel: contraste >= 4.5", "");
        check(Palette.contrast(Palette.COLD_WHITE, Palette.TARDIS_BLUE) >= 4.5, "texto no botão azul TARDIS: contraste >= 4.5 (" + String.format("%.1f", Palette.contrast(Palette.COLD_WHITE, Palette.TARDIS_BLUE)) + ")", "");
        eq(0x80FFFFFF, Palette.withAlpha(0xFFFFFFFF, 0.5f) | 0, "withAlpha 50%");

        // textos de cada estado: todos preenchidos e sem prometer o que não acontece
        for (CoreMode md : all) {
            check(md.title() != null && !md.title().isEmpty() && md.hint("Kupa") != null && !md.hint("Kupa").isEmpty(), "título e dica de " + md, "");
        }
        check(CoreMode.LISTENING.title().contains("ouvindo") && !CoreMode.STARTING.title().contains("ouvindo"), "só LISTENING diz 'ouvindo'; STARTING diz 'iniciando'", "");
        check(CoreMode.IDLE.hint("Luna").contains("Luna"), "a dica usa o nome escolhido", "");

        System.out.println("\n" + passed + " verificações passaram, " + failed + " falharam.");
        System.exit(failed == 0 ? 0 : 1);
    }

    static float firstArc(List<Prim> l, float r) { for (Prim p : l) if (p.kind == CoreScene.ARC && Math.abs(p.r - r) < 1e-4) return p.a0; return -1f; }
}
