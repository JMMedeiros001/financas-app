import com.kupa.assistant.intent.*;
import com.kupa.assistant.intent.AppMatcher.AppEntry;
import com.kupa.assistant.intent.ContactMatcher.ContactEntry;
import java.util.*;

/** Testes da camada de intenções (Java puro). Rodar: python3 tools/run_intent_tests.py */
public class IntentTests {
    static int passed = 0, failed = 0;
    static final CommandInterpreter I = new CommandInterpreter();

    static void check(boolean ok, String name, String detail) {
        if (ok) { passed++; } else { failed++; System.out.println("FALHOU: " + name + "  ->  " + detail); }
    }
    static void eq(Object expected, Object actual, String name) { check(Objects.equals(expected, actual), name, "esperado=" + expected + " obtido=" + actual); }

    static KupaIntent one(String text) {
        Interpretation r = I.interpret(text);
        return r.intents.size() == 1 ? r.intents.get(0) : null;
    }
    static void open(String text, String app) { eq(KupaIntent.openApp(app), one(text), "abrir: " + text); }
    static void call(String text, String who) { eq(KupaIntent.callContact(who, false), one(text), "ligar: " + text); }
    static void simple(String text, KupaIntent.Kind k) { eq(KupaIntent.simple(k), one(text), "controle: " + text); }
    static void none(String text) { Interpretation r = I.interpret(text); check(r.isEmpty(), "não é comando: " + text, "interpretou " + r); }

    public static void main(String[] args) {
        // ---- abrir aplicativos (qualquer app, sem lista fixa)
        open("Kupa, abra o WhatsApp.", "whatsapp");
        open("abre o youtube", "youtube");
        open("Abra a câmera", "camera");
        open("abra as configurações", "configuracoes");
        open("Kupa, abra o Mobile Legends", "mobile legends");
        open("por favor abre o app do instagram", "instagram");
        open("Pode abrir o Spotify pra mim", "spotify");
        open("agora abra o Mobile Legends", "mobile legends");
        open("oi kupa abre o google maps", "google maps");
        open("quero abrir o Telegram", "telegram");
        open("inicia o Chrome", "chrome");
        open("Culpa, abra o Netflix", "netflix");

        // ---- ligações
        call("Ligue para Dudu.", "dudu");
        call("Faça uma ligação para Dudu.", "dudu");
        call("Chame Dudu.", "dudu");
        call("Telefone para Dudu.", "dudu");
        call("liga pro Dudu", "dudu");
        call("ligue para minha mãe", "mae");
        call("Liga para o João da Silva", "joao da silva");
        call("quero ligar para a Maria agora", "maria");
        call("faz uma ligação pro Dudu", "dudu");
        eq(KupaIntent.callContact("ele", true), one("ligue para ele"), "ligar: pronome");
        eq(KupaIntent.callContact("ele", true), one("liga pra ela"), "ligar: pronome ela");

        // ---- chamadas recebidas
        simple("Kupa, quem está me ligando?", KupaIntent.Kind.WHO_IS_CALLING);
        simple("quem tá ligando", KupaIntent.Kind.WHO_IS_CALLING);
        simple("de quem é essa ligação", KupaIntent.Kind.WHO_IS_CALLING);
        simple("quem me ligou", KupaIntent.Kind.WHO_IS_CALLING);
        simple("quem ligou?", KupaIntent.Kind.WHO_IS_CALLING);
        simple("Atende.", KupaIntent.Kind.ANSWER_CALL);
        simple("Kupa, atende", KupaIntent.Kind.ANSWER_CALL);
        simple("atenda a ligação", KupaIntent.Kind.ANSWER_CALL);
        simple("pode atender", KupaIntent.Kind.ANSWER_CALL);
        simple("Recusa.", KupaIntent.Kind.REJECT_CALL);
        simple("recuse a chamada", KupaIntent.Kind.REJECT_CALL);
        simple("rejeita a ligação", KupaIntent.Kind.REJECT_CALL);
        simple("deixa tocar", KupaIntent.Kind.IGNORE_CALL);
        simple("Kupa, deixa chamar até cair", KupaIntent.Kind.IGNORE_CALL);
        simple("não atende", KupaIntent.Kind.IGNORE_CALL);
        simple("ignora a ligação", KupaIntent.Kind.IGNORE_CALL);
        simple("desliga a ligação", KupaIntent.Kind.END_CALL);
        simple("encerra a chamada", KupaIntent.Kind.END_CALL);

        // ---- conversa (contexto: "agora abra a conversa com Dudu")
        eq(KupaIntent.openChat("dudu", false, null), one("Agora abra a conversa com Dudu"), "conversa");
        eq(KupaIntent.openChat("dudu", false, "whatsapp"), one("abre a conversa do Dudu no WhatsApp"), "conversa com app");
        eq(KupaIntent.openChat("ele", true, null), one("abra a conversa com ele"), "conversa pronome");
        eq(KupaIntent.openChat("dudu", false, null), one("abre o chat com o Dudu"), "chat");

        // ---- comandos combinados
        Interpretation seq = I.interpret("Kupa, abra o WhatsApp e depois o jogo");
        eq(Arrays.asList(KupaIntent.openApp("whatsapp"), KupaIntent.openApp("jogo")), seq.intents, "sequência: e depois");
        seq = I.interpret("abra o whatsapp e abra o youtube");
        eq(Arrays.asList(KupaIntent.openApp("whatsapp"), KupaIntent.openApp("youtube")), seq.intents, "sequência: e abra");
        seq = I.interpret("ligue para dudu e depois para maria");
        eq(Arrays.asList(KupaIntent.callContact("dudu", false), KupaIntent.callContact("maria", false)), seq.intents, "sequência: ligações");
        seq = I.interpret("abre o whatsapp depois a camera");
        eq(Arrays.asList(KupaIntent.openApp("whatsapp"), KupaIntent.openApp("camera")), seq.intents, "sequência: depois");
        check(I.interpret("abra o whatsapp e depois ligue para dudu").intents.size() == 2, "sequência mista", "não separou");
        check(I.interpret("abra a a e depois b e depois c e depois d e depois e e depois f").isEmpty(), "sequência longa demais é recusada", "aceitou");

        seq = I.interpret("abre o whatsapp e o youtube");
        eq(Arrays.asList(KupaIntent.openApp("whatsapp"), KupaIntent.openApp("youtube")), seq.intents, "sequência: e o");
        none("ligue para dudu e conte uma piada");
        none("abra o whatsapp e depois conte uma piada");

        // ---- NÃO são comandos (vão para a IA, sem ação no celular)
        none("o que é fotossíntese");
        none("quem foi Santos Dumont");
        none("liga o wifi");
        none("desliga o wifi");
        none("me conte uma piada");
        none("abre");
        none("deixa tocar uma música");
        none("quem ligou o rádio");
        none("quem está ligando a tv");
        none("ligue para dudu no whatsapp");
        none("ligue para dudu por vídeo");
        none("abra o whatsapp e conte uma piada");   // parte não entendida: nada executa pela metade
        none("");
        none("   ");

        // ---- aprender / esquecer / listar
        KupaIntent l1 = one("Kupa, quando eu disser 'chama Dudu', quero dizer para ligar para Dudu.");
        eq(KupaIntent.learn("chama dudu", "ligar para dudu"), l1, "aprender 1");
        KupaIntent l2 = one("Quando eu falar 'abre o jogo', estou falando do Mobile Legends.");
        eq(KupaIntent.learn("abre o jogo", "mobile legends"), l2, "aprender 2 (exemplo do pedido)");
        eq(KupaIntent.learn("zap", "whatsapp"), one("quando eu disser zap estou falando do whatsapp"), "aprender apelido");
        eq(KupaIntent.learn("zap", "whatsapp"), one("aprenda que zap significa whatsapp"), "aprender (aprenda que)");
        eq(KupaIntent.forget("abre o jogo"), one("esquece o comando abre o jogo"), "esquecer");
        simple("quais comandos eu ensinei", KupaIntent.Kind.LIST_LEARNED);

        // ---- planejamento seguro do aprendizado
        LearningPlanner.Plan p = LearningPlanner.plan("chama dudu", "ligar para dudu", I);
        check(p.ok && p.kind == LearnedCommand.Kind.PHRASE && p.expansion.equals("ligue para dudu"), "plano: frase -> ligação", p.expansion + " " + p.error);
        p = LearningPlanner.plan("abre o jogo", "mobile legends", I);
        check(p.ok && p.kind == LearnedCommand.Kind.PHRASE && p.expansion.equals("abra mobile legends"), "plano: 'abre o jogo' -> Mobile Legends", p.expansion + " " + p.error);
        p = LearningPlanner.plan("zap", "whatsapp", I);
        check(p.ok && p.kind == LearnedCommand.Kind.ENTITY && p.expansion.equals("whatsapp"), "plano: apelido", p.expansion + " " + p.error);
        p = LearningPlanner.plan("atende", "ligar para dudu", I);
        check(!p.ok, "plano: não redefine 'atende'", "aceitou");
        p = LearningPlanner.plan("recusa", "abrir whatsapp", I);
        check(!p.ok, "plano: não redefine 'recusa'", "aceitou");
        p = LearningPlanner.plan("minha rotina", "atende", I);
        check(!p.ok, "plano: significado de controle é recusado", "aceitou");
        p = LearningPlanner.plan("blá blá blá blá blá blá blá blá blá", "abrir whatsapp", I);
        check(!p.ok, "plano: frase longa demais", "aceitou");
        p = LearningPlanner.plan("quando", "", I);
        check(!p.ok, "plano: sem significado", "aceitou");

        List<LearnedCommand> learned = Arrays.asList(
            new LearnedCommand("1", LearnedCommand.Kind.PHRASE, "abre o jogo", "abra mobile legends", 0),
            new LearnedCommand("2", LearnedCommand.Kind.ENTITY, "zap", "whatsapp", 0));
        eq("abra mobile legends", LearningPlanner.expandPhrase("Kupa, abre o jogo!", learned), "usar atalho aprendido");
        eq(null, LearningPlanner.expandPhrase("abre o youtube", learned), "atalho não casa com outra frase");
        eq("whatsapp", LearningPlanner.aliasEntity("Zap", learned), "apelido de nome");
        eq("youtube", LearningPlanner.aliasEntity("youtube", learned), "nome sem apelido fica igual");
        eq(KupaIntent.openApp("mobile legends"), one(LearningPlanner.expandPhrase("abre o jogo", learned)), "atalho vira comando válido");

        // ---- ida e volta: render -> interpretar devolve a mesma intenção
        KupaIntent[] roundtrip = {
            KupaIntent.openApp("mobile legends"), KupaIntent.callContact("dudu", false), KupaIntent.openChat("dudu", false, null),
            KupaIntent.openChat("dudu", false, "whatsapp"), KupaIntent.simple(KupaIntent.Kind.WHO_IS_CALLING), KupaIntent.simple(KupaIntent.Kind.ANSWER_CALL),
            KupaIntent.simple(KupaIntent.Kind.REJECT_CALL), KupaIntent.simple(KupaIntent.Kind.END_CALL), KupaIntent.simple(KupaIntent.Kind.IGNORE_CALL)};
        for (KupaIntent k : roundtrip) eq(k, one(Render.canonical(k)), "ida e volta: " + k);

        // ---- sensibilidade e proteção
        check(KupaIntent.callContact("dudu", false).isSensitive(), "ligar é sensível", "");
        check(!KupaIntent.openApp("x").isSensitive(), "abrir app não é sensível", "");
        check(KupaIntent.simple(KupaIntent.Kind.ANSWER_CALL).isProtected(), "atender é protegido", "");
        check(!KupaIntent.openApp("x").isProtected(), "abrir app pode ser atalho", "");

        // ---- respostas: sim / não / escolha
        eq("YES", ReplyParser.parse("Sim", null).type.name(), "resposta: sim");
        eq("YES", ReplyParser.parse("pode ligar", null).type.name(), "resposta: pode ligar");
        eq("YES", ReplyParser.parse("Kupa, claro", null).type.name(), "resposta: claro");
        eq("NO", ReplyParser.parse("não", null).type.name(), "resposta: não");
        eq("NO", ReplyParser.parse("nao pode", null).type.name(), "resposta: não pode");
        eq("NO", ReplyParser.parse("melhor não", null).type.name(), "resposta: melhor não");
        eq("NO", ReplyParser.parse("pode não", null).type.name(), "resposta: pode não");
        eq("NO", ReplyParser.parse("cancela", null).type.name(), "resposta: cancela");
        eq("UNKNOWN", ReplyParser.parse("talvez amanhã", null).type.name(), "resposta: talvez");
        eq("UNKNOWN", ReplyParser.parse("ligue para maria", null).type.name(), "resposta: comando novo não é 'sim'");
        eq("YES", ReplyParser.parse("liga", null).type.name(), "resposta: liga");
        eq("YES", ReplyParser.parse("faz isso", null).type.name(), "resposta: faz isso");
        eq("UNKNOWN", ReplyParser.parse("", null).type.name(), "resposta: vazio");
        List<String> opts = Arrays.asList("Dudu (celular)", "Dudu (trabalho)", "Dudu Silva");
        ReplyParser.Reply r = ReplyParser.parse("o segundo", opts);
        check(r.type == ReplyParser.Type.CHOICE && r.index == 1, "escolha: o segundo", r.toString());
        r = ReplyParser.parse("2", opts);
        check(r.type == ReplyParser.Type.CHOICE && r.index == 1, "escolha: 2", r.toString());
        r = ReplyParser.parse("o primeiro", opts);
        check(r.type == ReplyParser.Type.CHOICE && r.index == 0, "escolha: o primeiro", r.toString());
        r = ReplyParser.parse("o último", opts);
        check(r.type == ReplyParser.Type.CHOICE && r.index == 2, "escolha: o último", r.toString());
        r = ReplyParser.parse("o do trabalho", opts);
        check(r.type == ReplyParser.Type.CHOICE && r.index == 1, "escolha: por descrição", r.toString());
        r = ReplyParser.parse("o silva", opts);
        check(r.type == ReplyParser.Type.CHOICE && r.index == 2, "escolha: por sobrenome", r.toString());
        eq("UNKNOWN", ReplyParser.parse("sim", opts).type.name(), "com várias opções 'sim' não escolhe nada");
        eq("NO", ReplyParser.parse("não", opts).type.name(), "com várias opções 'não' cancela");
        eq("UNKNOWN", ReplyParser.parse("o dudu", opts).type.name(), "escolha ambígua não escolhe");

        // ---- contatos
        List<ContactEntry> c1 = Arrays.asList(new ContactEntry(1, "Dudu"), new ContactEntry(2, "Dudu Silva"), new ContactEntry(3, "Maria"));
        ContactMatcher.Result cr = ContactMatcher.resolve("Dudu", c1);
        check(cr.chosen != null && cr.chosen.id == 1 && !cr.ambiguous && !cr.weak, "contato: exato vence parcial", cr.ranked.toString());
        cr = ContactMatcher.resolve("dudu", Arrays.asList(new ContactEntry(1, "Dudu Silva"), new ContactEntry(2, "Dudu Costa")));
        check(cr.ambiguous && cr.chosen == null && cr.ranked.size() == 2, "contato: dois Dudus = perguntar", cr.ranked.toString());
        cr = ContactMatcher.resolve("minha mãe", Arrays.asList(new ContactEntry(7, "Mãe"), new ContactEntry(8, "Pai")));
        check(cr.chosen != null && cr.chosen.id == 7, "contato: 'minha mãe' -> Mãe", cr.ranked.toString());
        cr = ContactMatcher.resolve("joao", Arrays.asList(new ContactEntry(1, "João da Silva")));
        check(cr.chosen != null && !cr.weak, "contato: primeiro nome", cr.ranked.toString());
        cr = ContactMatcher.resolve("maria", Arrays.asList(new ContactEntry(1, "Mariana")));
        check(cr.chosen != null && cr.weak, "contato: Maria->Mariana é fraco (sempre confirmar)", cr.ranked.toString());
        cr = ContactMatcher.resolve("dudo", Arrays.asList(new ContactEntry(1, "Dudu")));
        check(cr.chosen != null && cr.weak, "contato: erro de 1 letra é fraco", cr.ranked.toString());
        cr = ContactMatcher.resolve("fulano", c1);
        check(cr.chosen == null && !cr.ambiguous && cr.ranked.isEmpty(), "contato: inexistente não inventa", cr.ranked.toString());
        cr = ContactMatcher.resolve("dudu", Arrays.asList(new ContactEntry(1, "Dudu"), new ContactEntry(1, "Dudu")));
        check(cr.chosen != null && cr.ranked.size() == 1, "contato: mesmo contato com 2 linhas conta uma vez", cr.ranked.toString());
        cr = ContactMatcher.resolve("", c1);
        check(cr.chosen == null && cr.ranked.isEmpty(), "contato: consulta vazia", "");

        // ---- aplicativos instalados
        List<AppEntry> apps = Arrays.asList(
            new AppEntry("com.whatsapp", "WhatsApp"), new AppEntry("com.whatsapp.w4b", "WhatsApp Business"),
            new AppEntry("com.google.android.youtube", "YouTube"), new AppEntry("com.google.android.apps.youtube.music", "YouTube Music"),
            new AppEntry("com.mobile.legends", "Mobile Legends: Bang Bang"), new AppEntry("com.a.galeria1", "Galeria"), new AppEntry("com.b.galeria2", "Galeria"),
            new AppEntry("com.spotify.music", "Spotify"));
        AppMatcher.Result ar = AppMatcher.resolve("whatsapp", apps);
        check(ar.chosen != null && ar.chosen.app.packageName.equals("com.whatsapp") && !ar.ambiguous, "app: WhatsApp exato", ar.ranked.toString());
        ar = AppMatcher.resolve("youtube", apps);
        check(ar.chosen != null && ar.chosen.app.packageName.equals("com.google.android.youtube"), "app: YouTube (não o Music)", ar.ranked.toString());
        ar = AppMatcher.resolve("mobile legends", apps);
        check(ar.chosen != null && ar.chosen.app.packageName.equals("com.mobile.legends"), "app: Mobile Legends", ar.ranked.toString());
        ar = AppMatcher.resolve("instagram", apps);
        check(ar.chosen == null && !ar.ambiguous, "app: não instalado -> nada", ar.ranked.toString());
        ar = AppMatcher.resolve("galeria", apps);
        check(ar.ambiguous && ar.ranked.size() == 2, "app: dois iguais = perguntar", ar.ranked.toString());
        ar = AppMatcher.resolve("o spotify", apps);
        check(ar.chosen != null && ar.chosen.app.label.equals("Spotify"), "app: artigo ignorado", ar.ranked.toString());
        ar = AppMatcher.resolve("zap", apps);
        check(ar.chosen == null, "app: 'zap' sem apelido ensinado não adivinha", ar.ranked.toString());

        System.out.println("\n" + passed + " verificações passaram, " + failed + " falharam.");
        System.exit(failed == 0 ? 0 : 1);
    }
}
