import com.kupa.assistant.visual.*;
import com.kupa.assistant.visual.CoreScene.Prim;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import javax.imageio.ImageIO;

/** Gera prévias PNG usando a MESMA geometria (CoreScene) que o app desenha no Android. Para revisão visual; não faz parte do app. */
public class PreviewRenderer {
    static void draw(Graphics2D g, List<Prim> prims, double cx, double cy, double R) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        for (Prim p : prims) {
            g.setColor(new Color(p.argb, true));
            switch (p.kind) {
                case CoreScene.ARC: {
                    g.setStroke(new BasicStroke((float) (p.w * R), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g.draw(new Arc2D.Double(cx + (p.x - p.r) * R, cy + (p.y - p.r) * R, 2 * p.r * R, 2 * p.r * R, -p.a0, -p.sweep, Arc2D.OPEN));
                    break;
                }
                case CoreScene.LINE: {
                    g.setStroke(new BasicStroke((float) (p.w * R), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    g.draw(new Line2D.Double(cx + p.x * R, cy + p.y * R, cx + p.x2 * R, cy + p.y2 * R));
                    break;
                }
                case CoreScene.CIRCLE: {
                    g.setStroke(new BasicStroke((float) (p.w * R)));
                    g.draw(new Ellipse2D.Double(cx + (p.x - p.r) * R, cy + (p.y - p.r) * R, 2 * p.r * R, 2 * p.r * R));
                    break;
                }
                default: {
                    g.fill(new Ellipse2D.Double(cx + (p.x - p.r) * R, cy + (p.y - p.r) * R, 2 * p.r * R, 2 * p.r * R));
                }
            }
        }
    }

    /** Cópia da primitiva em branco (mesma geometria, alfa preservado) para o ícone monocromático. */
    static Prim mono(Prim p, int rgb, int alpha) {
        try {
            java.lang.reflect.Constructor<Prim> c = Prim.class.getDeclaredConstructor(int.class, float.class, float.class, float.class, float.class, float.class, float.class, float.class, float.class, int.class);
            c.setAccessible(true);
            return c.newInstance(p.kind, p.x, p.y, p.r, p.a0, p.sweep, p.x2, p.y2, p.w, (alpha << 24) | (rgb & 0xFFFFFF));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static BufferedImage frame(CoreMode mode, int size, float t, float level, float pulse, boolean animate) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setColor(new Color(Palette.SPACE)); g.fillRect(0, 0, size, size);
        draw(g, CoreScene.build(mode, t, level, pulse, animate), size / 2.0, size / 2.0, size * 0.47);
        // marcador do lugar onde o Popol aparece no app (só na prévia)
        g.setColor(new Color(0x40EAF7FF, true)); g.setStroke(new BasicStroke(1f));
        g.draw(new Ellipse2D.Double(size / 2.0 - size * 0.47 * 0.28, size / 2.0 - size * 0.47 * 0.28, size * 0.47 * 0.56, size * 0.47 * 0.56));
        g.dispose();
        return img;
    }

    public static void main(String[] args) throws Exception {
        File dir = new File(args[0]); dir.mkdirs();
        CoreMode[] modes = CoreMode.values();
        float[] levels = new float[modes.length];
        for (int i = 0; i < modes.length; i++) {
            float lvl = (modes[i] == CoreMode.LISTENING || modes[i] == CoreMode.COMMAND || modes[i] == CoreMode.SPEAKING) ? 0.8f : 0f;
            ImageIO.write(frame(modes[i], 720, 1.7f, lvl, lvl, true), "png", new File(dir, "nucleo-" + modes[i].name().toLowerCase() + ".png"));
        }
        // folha de contato 5 x 2
        int cell = 360;
        BufferedImage sheet = new BufferedImage(cell * 5, cell * 2, BufferedImage.TYPE_INT_ARGB);
        Graphics2D sg = sheet.createGraphics();
        sg.setColor(new Color(Palette.SPACE)); sg.fillRect(0, 0, sheet.getWidth(), sheet.getHeight());
        for (int i = 0; i < modes.length; i++) {
            float lvl = (modes[i] == CoreMode.LISTENING || modes[i] == CoreMode.COMMAND || modes[i] == CoreMode.SPEAKING) ? 0.8f : 0f;
            sg.drawImage(frame(modes[i], cell, 1.7f, lvl, lvl, true), (i % 5) * cell, (i / 5) * cell, null);
        }
        sg.dispose();
        ImageIO.write(sheet, "png", new File(dir, "nucleo-todos-os-estados.png"));
        // símbolo e ícone do app
        BufferedImage mark = new BufferedImage(512, 512, BufferedImage.TYPE_INT_ARGB);
        Graphics2D mg = mark.createGraphics();
        mg.setColor(new Color(Palette.SPACE)); mg.fillRect(0, 0, 512, 512);
        draw(mg, CoreScene.mark(), 256, 256, 230);
        mg.dispose();
        ImageIO.write(mark, "png", new File(dir, "simbolo.png"));
        BufferedImage icon = new BufferedImage(512, 512, BufferedImage.TYPE_INT_ARGB);
        Graphics2D ig = icon.createGraphics();
        ig.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        ig.setPaint(new RadialGradientPaint(256, 220, 330, new float[]{0f, 1f}, new Color[]{new Color(0xFF0B2B4D), new Color(Palette.SPACE)}));
        ig.fillRect(0, 0, 512, 512);
        draw(ig, CoreScene.mark(), 256, 256, 205);
        ig.dispose();
        ImageIO.write(icon, "png", new File(dir, "ic_launcher.png"));
        // ícone pequeno de notificação: precisa ser MONOCROMÁTICO (o Android usa só o canal alfa); branco sobre transparente
        BufferedImage stat = new BufferedImage(96, 96, BufferedImage.TYPE_INT_ARGB);
        Graphics2D tg = stat.createGraphics();
        java.util.List<Prim> monoPrims = new java.util.ArrayList<>();
        java.util.List<Prim> src = CoreScene.mark();
        for (int i = 1; i < src.size(); i++) { // pula o disco de fundo
            Prim p = src.get(i);
            int a = (p.argb >>> 24);
            monoPrims.add(mono(p, 0xFFFFFFFF, a));
        }
        draw(tg, monoPrims, 48, 48, 46);
        tg.dispose();
        ImageIO.write(stat, "png", new File(dir, "ic_stat_kupa.png"));
        System.out.println("prévias geradas em " + dir.getPath());
    }
}
