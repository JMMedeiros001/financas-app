import { useState } from 'react'
import { hashPin } from '@/lib/pin'
import { InterfaceStyle } from '@/lib/styleInfo'
import { StylePicker } from './StylePicker'
import { Field, inputClass } from './Modal'

export function Onboarding({
  onDone
}: {
  onDone: (name: string, pinHash: string, interfaceStyle: InterfaceStyle) => void
}) {
  const [step, setStep] = useState<1 | 2>(1)
  const [name, setName] = useState('')
  const [pin, setPin] = useState('')
  const [pinHash, setPinHash] = useState('')
  const [style, setStyle] = useState<InterfaceStyle>('classica')
  const [error, setError] = useState('')

  const goToStyleStep = async (withPin: boolean) => {
    if (withPin) {
      if (!/^\d{4,6}$/.test(pin)) return setError('Use uma senha de 4 a 6 dígitos.')
      setPinHash(await hashPin(pin))
    } else {
      setPinHash('')
    }
    setError('')
    setStep(2)
  }

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-end md:items-center justify-center">
      <div className="bg-[#141416] border border-line rounded-t-2xl md:rounded-2xl p-5 w-full max-w-md">
        {step === 1 ? (
          <>
            <h2 className="text-lg font-semibold mb-1">Bem-vindo ao FINANÇAS</h2>
            <Field label="Seu nome">
              <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
            </Field>
            <p className="text-mut text-sm mb-2">Você deseja proteger seu aplicativo com senha?</p>
            <Field label="Senha (4 a 6 dígitos) — opcional">
              <input
                className={inputClass}
                type="password"
                inputMode="numeric"
                maxLength={6}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
              />
            </Field>
            {error && <p className="text-neg text-sm mb-2">{error}</p>}
            <div className="flex gap-2 mt-2">
              <button onClick={() => goToStyleStep(true)} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">
                🔐 Ativar senha
              </button>
              <button onClick={() => goToStyleStep(false)} className="border border-line rounded-lg px-4 py-2.5 flex-1">
                🔓 Continuar sem senha
              </button>
            </div>
          </>
        ) : (
          <>
            <h2 className="text-lg font-semibold mb-1">Estilo da interface</h2>
            <p className="text-mut text-sm mb-3">Escolha como o FINANÇAS deve apresentar suas informações.</p>
            <StylePicker value={style} onChange={setStyle} />
            <button
              onClick={() => onDone(name.trim(), pinHash, style)}
              className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 w-full mt-4"
            >
              CONTINUAR
            </button>
          </>
        )}
      </div>
    </div>
  )
}
