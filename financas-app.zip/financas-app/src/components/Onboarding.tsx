import { useState } from 'react'
import { hashPin } from '@/lib/pin'
import { Field, inputClass } from './Modal'

export function Onboarding({
  onDone
}: {
  onDone: (name: string, pinHash: string) => void
}) {
  const [name, setName] = useState('')
  const [pin, setPin] = useState('')
  const [error, setError] = useState('')

  const withPin = async () => {
    if (!/^\d{4,6}$/.test(pin)) return setError('Use uma senha de 4 a 6 dígitos.')
    onDone(name.trim(), await hashPin(pin))
  }

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-end md:items-center justify-center">
      <div className="bg-[#141416] border border-line rounded-t-2xl md:rounded-2xl p-5 w-full max-w-md">
        <h2 className="text-lg font-semibold mb-1">Bem-vindo ao FINANÇAS</h2>
        <Field label="Seu nome">
          <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <p className="text-mut text-sm mb-2">Você deseja proteger seu aplicativo com senha?</p>
        <Field label="Senha (4 a 6 dígitos) — opcional">
          <input className={inputClass} type="password" inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value)} />
        </Field>
        {error && <p className="text-neg text-sm mb-2">{error}</p>}
        <div className="flex gap-2 mt-2">
          <button onClick={withPin} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">🔐 Ativar senha</button>
          <button onClick={() => onDone(name.trim(), '')} className="border border-line rounded-lg px-4 py-2.5 flex-1">🔓 Continuar sem senha</button>
        </div>
      </div>
    </div>
  )
}
