import { useState } from 'react'
import { Payment, PaymentType } from '@/types'
import { EXPENSE_CATEGORIES } from '@/lib/categories'
import { todayISO } from '@/lib/calc'
import { PAYMENT_TYPE_LABEL } from '@/lib/payments'
import { Field, inputClass } from './Modal'

const TYPES: PaymentType[] = ['divida', 'emprestimo', 'parcela']

export function PaymentForm({
  initial,
  onSubmit,
  onCancel
}: {
  initial?: Payment
  onSubmit: (p: Omit<Payment, 'id' | 'installmentsPaid' | 'createdAt' | 'updatedAt'>) => void
  onCancel: () => void
}) {
  const [type, setType] = useState<PaymentType>(initial?.type ?? 'divida')
  const [name, setName] = useState(initial?.name ?? '')
  const [totalAmount, setTotalAmount] = useState(initial?.totalAmount?.toString() ?? '')
  const [installmentAmount, setInstallmentAmount] = useState(initial?.installmentAmount?.toString() ?? '')
  const [installmentsTotal, setInstallmentsTotal] = useState(initial?.installmentsTotal?.toString() ?? '1')
  const [dueDate, setDueDate] = useState(initial?.dueDate ?? todayISO())
  const [category, setCategory] = useState(initial?.category ?? EXPENSE_CATEGORIES[0])
  const [notes, setNotes] = useState(initial?.notes ?? '')
  const [error, setError] = useState('')

  const isSimple = type === 'divida'

  const submit = () => {
    if (!name.trim()) return setError('Informe um nome/descrição.')

    if (isSimple) {
      const v = parseFloat(totalAmount)
      if (!(v > 0)) return setError('Informe o valor total.')
      onSubmit({ type, name: name.trim(), totalAmount: v, installmentAmount: v, installmentsTotal: 1, dueDate, category, notes })
      return
    }

    const inst = parseFloat(installmentAmount)
    const count = parseInt(installmentsTotal, 10)
    if (!(inst > 0) || !(count > 0)) return setError('Informe o valor e a quantidade de parcelas.')
    onSubmit({ type, name: name.trim(), totalAmount: inst * count, installmentAmount: inst, installmentsTotal: count, dueDate, category, notes })
  }

  return (
    <div>
      <h2 className="text-lg font-semibold mb-3">{initial ? 'Editar pagamento' : 'Novo pagamento'}</h2>

      <Field label="Tipo">
        <select className={inputClass} value={type} onChange={(e) => setType(e.target.value as PaymentType)}>
          {TYPES.map((t) => (
            <option key={t} value={t}>{PAYMENT_TYPE_LABEL[t]}</option>
          ))}
        </select>
      </Field>

      <Field label="Nome / descrição">
        <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Cartão de crédito, Notebook, Empréstimo consignado" />
      </Field>

      {isSimple ? (
        <Field label="Valor total (R$)">
          <input className={inputClass} type="number" step="0.01" inputMode="decimal" value={totalAmount} onChange={(e) => setTotalAmount(e.target.value)} />
        </Field>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <Field label="Valor da parcela (R$)">
            <input className={inputClass} type="number" step="0.01" inputMode="decimal" value={installmentAmount} onChange={(e) => setInstallmentAmount(e.target.value)} />
          </Field>
          <Field label="Quantidade de parcelas">
            <input className={inputClass} type="number" inputMode="numeric" min={1} value={installmentsTotal} onChange={(e) => setInstallmentsTotal(e.target.value)} />
          </Field>
        </div>
      )}

      <Field label={isSimple ? 'Vencimento' : 'Vencimento da próxima parcela'}>
        <input className={inputClass} type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
      </Field>

      <Field label="Categoria">
        <select className={inputClass} value={category} onChange={(e) => setCategory(e.target.value)}>
          {EXPENSE_CATEGORIES.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </Field>

      <Field label="Observação">
        <input className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>

      {error && <p className="text-neg text-sm mb-2">{error}</p>}
      <div className="flex gap-2 mt-2">
        <button onClick={submit} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">
          {initial ? 'Salvar' : 'Criar pagamento'}
        </button>
        <button onClick={onCancel} className="border border-line rounded-lg px-4 py-2.5">Cancelar</button>
      </div>
    </div>
  )
}
