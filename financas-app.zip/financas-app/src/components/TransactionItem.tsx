import { Transaction } from '@/types'
import { CATEGORY_ICON } from '@/lib/categories'
import { formatBRL } from '@/lib/calc'

export function TransactionItem({
  t,
  onEdit,
  onDelete
}: {
  t: Transaction
  onEdit: () => void
  onDelete: () => void
}) {
  return (
    <div className="flex items-center gap-3 py-2.5 border-b border-line last:border-0">
      <span className="text-xl">{CATEGORY_ICON[t.category] || '•'}</span>
      <div className="flex-1 min-w-0">
        <div className="truncate">{t.description || t.category}</div>
        <small className="text-mut">{t.category} · {t.date.split('-').reverse().join('/')}</small>
      </div>
      <b className={t.type === 'income' ? 'text-pos' : 'text-neg'}>
        {t.type === 'income' ? '+ ' : '- '}{formatBRL(t.amount)}
      </b>
      <button onClick={onEdit} className="p-1.5 border border-line rounded-lg">✎</button>
      <button onClick={onDelete} className="p-1.5 border border-line rounded-lg">🗑</button>
    </div>
  )
}
