export function SavingsBar({ percent, label = 'Economia' }: { percent: number; label?: string }) {
  const w = Math.max(0, Math.min(100, percent))
  return (
    <div className="mt-2">
      <div className="flex items-center justify-between text-sm">
        <span className="text-mut">{label}</span>
        <b className="text-gold">{percent.toFixed(0)}%</b>
      </div>
      <div className="h-1 rounded-full bg-line overflow-hidden mt-1.5">
        <div className="h-full rounded-full bg-gold transition-[width] duration-500" style={{ width: `${w}%` }} />
      </div>
    </div>
  )
}
