import { PropsWithChildren } from 'react'

export function Card({ children, className = '' }: PropsWithChildren<{ className?: string }>) {
  return <div className={`bg-card border border-line rounded-xl2 p-4 ${className}`}>{children}</div>
}
