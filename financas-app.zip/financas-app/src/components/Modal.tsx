import { PropsWithChildren } from 'react'

export function Modal({ open, onClose, children }: PropsWithChildren<{ open: boolean; onClose: () => void }>) {
  if (!open) return null
  return (
    <div className="fixed inset-0 bg-black/70 z-40 flex items-end md:items-center justify-center" onClick={onClose}>
      <div
        className="bg-[#141416] border border-line rounded-t-2xl md:rounded-2xl p-5 w-full max-w-lg max-h-[90%] overflow-y-auto"
        style={{ paddingBottom: 'calc(1.25rem + env(safe-area-inset-bottom, 0px))' }}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  )
}

export function Field({ label, children }: PropsWithChildren<{ label: string }>) {
  return (
    <label className="block text-xs text-mut mb-3">
      {label}
      <div className="mt-1">{children}</div>
    </label>
  )
}

export const inputClass =
  'w-full bg-[#0f0f11] text-ink border border-line rounded-lg px-3 py-2.5 outline-none focus:border-gold'
