import { Goal } from '@/types'
import { formatBRL } from '@/lib/calc'
import { goalProgress } from '@/lib/calc'
import { ProgressBar } from './ProgressBar'
import { Card } from './Card'

export function GoalCard({
  g,
  onMoveMoney,
  onDelete,
  padClass = ''
}: {
  g: Goal
  onMoveMoney: () => void
  onDelete: () => void
  padClass?: string
}) {
  const p = goalProgress(g)
  return (
    <Card className={`mb-2.5 ${padClass}`}>
      <div className="flex justify-between items-start">
        <b>{g.icon} {g.name}</b>
        <span className="text-gold">{p.toFixed(1).replace('.', ',')}%</span>
      </div>
      <div className="my-2"><ProgressBar percent={p} /></div>
      <small className="text-mut">
        {formatBRL(g.currentAmount)} / {formatBRL(g.targetAmount)}
        {g.deadline ? ` · até ${g.deadline.split('-').reverse().join('/')}` : ''}
      </small>
      <div className="mt-3 flex gap-2">
        <button onClick={onMoveMoney} className="border border-line rounded-lg px-3 py-1.5 text-sm">± Valor</button>
        <button onClick={onDelete} className="border border-line rounded-lg px-3 py-1.5 text-sm text-neg">Excluir</button>
      </div>
    </Card>
  )
}
