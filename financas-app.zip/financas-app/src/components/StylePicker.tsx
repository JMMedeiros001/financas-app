import { InterfaceStyle, STYLE_INFO, STYLE_ORDER } from '@/lib/styleInfo'

export function StylePicker({
  value,
  onChange
}: {
  value: InterfaceStyle
  onChange: (style: InterfaceStyle) => void
}) {
  return (
    <div className="space-y-2">
      {STYLE_ORDER.map((id) => {
        const info = STYLE_INFO[id]
        const active = value === id
        return (
          <button
            key={id}
            type="button"
            onClick={() => onChange(id)}
            className={`w-full text-left border rounded-xl2 p-3 flex items-start gap-3 ${
              active ? 'border-gold bg-[#1c1a10]' : 'border-line bg-card'
            }`}
          >
            <span
              className={`mt-0.5 w-4 h-4 rounded-full border flex-none flex items-center justify-center ${
                active ? 'border-gold' : 'border-line'
              }`}
            >
              {active && <span className="w-2 h-2 rounded-full bg-gold" />}
            </span>
            <span>
              <b className={active ? 'text-gold' : ''}>{info.label}</b>
              <span className="block text-mut text-sm">{info.description}</span>
            </span>
          </button>
        )
      })}
    </div>
  )
}
