import { InterfaceStyle } from '@/lib/styleInfo'
import logo from '@/assets/logo.png'

export function LoadingScreen({ style }: { style: InterfaceStyle }) {
  return (
    <div className="fixed inset-0 bg-bg z-50 flex flex-col items-center justify-center text-center px-6">
      {style === 'classica' && (
        <>
          <img src={logo} alt="" className="w-16 h-16 rounded-xl object-contain animate-pulse" />
          <p className="text-mut text-sm mt-4">Carregando o FINANÇAS…</p>
        </>
      )}

      {style === 'compacta' && (
        <img src={logo} alt="" className="w-10 h-10 rounded-lg object-contain animate-pulse" />
      )}

      {style === 'minimalista' && <img src={logo} alt="" className="w-12 h-12 rounded-lg object-contain opacity-90" />}

      {style === 'avancada' && (
        <>
          <div className="relative w-20 h-20">
            <span className="absolute inset-0 rounded-full border-2 border-gold/30 border-t-gold animate-spin" />
            <img src={logo} alt="" className="absolute inset-2 rounded-lg object-contain" />
          </div>
          <p className="text-gold text-xs tracking-[3px] mt-4">FINANÇAS NÚCLEO</p>
        </>
      )}
    </div>
  )
}
