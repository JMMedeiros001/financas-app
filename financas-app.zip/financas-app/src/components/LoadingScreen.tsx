import { useEffect, useState } from 'react'
import logo from '@/assets/logo.png'

/** Primeira tela: logo centralizada. Não depende do estilo escolhido —
 *  é sempre a mesma, para nunca mais criar a impressão de "duas telas
 *  diferentes" dependendo da configuração do usuário. */
export function SplashLogo() {
  return (
    <div className="fixed inset-0 bg-bg z-50 flex items-center justify-center">
      <img src={logo} alt="" className="w-16 h-16 rounded-xl object-contain" />
    </div>
  )
}

const DURATION_MS = 900
const HOLD_AT_100_MS = 150

/** Segunda tela: carregamento percentual — nome "FINANÇAS", barra fina
 *  dourada, percentual. Sobe de 0% a 100% de forma suave; quando chega a
 *  100%, segura por um instante e então chama onDone(). */
export function SplashProgress({ onDone }: { onDone: () => void }) {
  const [percent, setPercent] = useState(0)

  useEffect(() => {
    let raf = 0
    let holdTimeout: ReturnType<typeof setTimeout>
    const start = performance.now()

    const tick = (now: number) => {
      const elapsed = now - start
      const pct = Math.min(100, Math.round((elapsed / DURATION_MS) * 100))
      setPercent(pct)
      if (pct < 100) {
        raf = requestAnimationFrame(tick)
      } else {
        holdTimeout = setTimeout(onDone, HOLD_AT_100_MS)
      }
    }
    raf = requestAnimationFrame(tick)

    return () => {
      cancelAnimationFrame(raf)
      clearTimeout(holdTimeout)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div className="fixed inset-0 bg-bg z-50 flex flex-col items-center justify-center px-10 overflow-hidden">
      {/* acentos diagonais discretos nos cantos, como na referência */}
      <div className="pointer-events-none absolute -top-10 -left-10 w-52 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent rotate-45" />
      <div className="pointer-events-none absolute -bottom-10 -right-10 w-52 h-px bg-gradient-to-r from-transparent via-gold/50 to-transparent rotate-45" />

      <img src={logo} alt="" className="w-20 h-20 rounded-2xl object-contain" />
      <h1 className="text-xl font-semibold tracking-[6px] mt-5">FINANÇAS</h1>
      <p className="text-mut text-sm mt-1">Preparando seu aplicativo…</p>

      <div className="w-full max-w-[240px] mt-7">
        <div className="h-1.5 rounded-full bg-line overflow-hidden">
          <div
            className="h-full rounded-full bg-gold transition-[width] duration-150 ease-linear"
            style={{ width: `${percent}%` }}
          />
        </div>
      </div>
      <p className="text-gold text-sm mt-3 tabular-nums">{percent}%</p>
    </div>
  )
}
