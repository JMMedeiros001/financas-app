import { Payment } from '@/types'
import { formatBRL } from '@/lib/calc'
import { paymentStatus, progressPercent, installmentsRemaining, PAYMENT_TYPE_LABEL, PAYMENT_TYPE_ICON } from '@/lib/payments'
import { Card } from './Card'
import { ProgressBar } from './ProgressBar'

const STATUS_STYLE: Record<string, string> = {
  pendente: 'text-mut',
  pago: 'text-pos',
  atrasado: 'text-neg'
}

const STATUS_LABEL: Record<string, string> = {
  pendente: 'Pendente',
  pago: 'Pago',
  atrasado: 'Atrasado'
}

export function PaymentCard({
  p,
  padClass = '',
  onMarkPaid,
  onUnmarkPaid,
  onEdit,
  onDelete
}: {
  p: Payment
  padClass?: string
  onMarkPaid: () => void
  onUnmarkPaid: () => void
  onEdit: () => void
  onDelete: () => void
}) {
  const status = paymentStatus(p)
  const done = status === 'pago'
  const left = installmentsRemaining(p)

  return (
    <Card className={`mb-2.5 ${padClass}`}>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <small className="text-mut">{PAYMENT_TYPE_ICON[p.type]} {PAYMENT_TYPE_LABEL[p.type]}</small>
          <b className="block truncate">{p.name}</b>
        </div>
        <b className={STATUS_STYLE[status]}>{STATUS_LABEL[status]}</b>
      </div>

      <div className="mt-2">
        <ProgressBar percent={progressPercent(p)} color={done ? 'bg-pos' : status === 'atrasado' ? 'bg-neg' : 'bg-gold'} />
      </div>

      <div className="flex items-center justify-between text-sm mt-1.5">
        {p.installmentsTotal > 1 ? (
          <span className="text-mut">
            Parcela {Math.min(p.installmentsPaid + (done ? 0 : 1), p.installmentsTotal)} de {p.installmentsTotal}
          </span>
        ) : (
          <span className="text-mut">Valor</span>
        )}
        <span>{formatBRL(p.installmentAmount)}</span>
      </div>

      {!done && (
        <p className="text-mut text-sm mt-0.5">
          {p.installmentsTotal > 1 ? `${left} restante(s) · ` : ''}vence {p.dueDate ? p.dueDate.split('-').reverse().join('/') : '—'}
        </p>
      )}

      <div className="flex gap-2 mt-3 flex-wrap">
        {!done ? (
          <button onClick={onMarkPaid} className="bg-gold text-black font-semibold rounded-lg px-3 py-1.5 text-sm">
            {p.installmentsTotal > 1 ? 'Marcar parcela como paga' : 'Marcar como pago'}
          </button>
        ) : (
          <button onClick={onUnmarkPaid} className="border border-line rounded-lg px-3 py-1.5 text-sm">
            Desfazer última parcela
          </button>
        )}
        <button onClick={onEdit} className="border border-line rounded-lg px-3 py-1.5 text-sm">Editar</button>
        <button onClick={onDelete} className="border border-line rounded-lg px-3 py-1.5 text-sm text-neg">Excluir</button>
      </div>
    </Card>
  )
}
