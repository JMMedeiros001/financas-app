import { useState } from 'react'
import { verifyPin } from '@/lib/pin'
import logo from '@/assets/logo.png'

export function PinLockScreen({ pinHash, onUnlock }: { pinHash: string; onUnlock: () => void }) {
  const [buf, setBuf] = useState('')
  const [error, setError] = useState(false)

  const press = async (k: string) => {
    setError(false)
    const next = k === '<' ? buf.slice(0, -1) : buf.length < 6 ? buf + k : buf
    setBuf(next)
    if (next.length >= 4 && (await verifyPin(next, pinHash))) {
      onUnlock()
      setBuf('')
    } else if (next.length === 6) {
      setError(true)
      setTimeout(() => setBuf(''), 400)
    }
  }

  return (
    <div className="fixed inset-0 bg-bg z-50 flex flex-col items-center justify-center text-center px-6">
      <img src={logo} alt="FINANÇAS" className="w-16 h-16 rounded-xl object-contain" />
      <h2 className="text-lg font-semibold mt-4">Finanças protegidas</h2>
      <p className="text-mut text-sm mt-1">Digite sua senha para continuar.</p>
      <div className={`h-8 mt-4 text-2xl tracking-[10px] ${error ? 'text-neg' : ''}`}>{'●'.repeat(buf.length) || ' '}</div>
      <div className="grid grid-cols-3 gap-3 mt-4">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', '<'].map((k, i) =>
          k === '' ? (
            <span key={i} />
          ) : (
            <button
              key={i}
              onClick={() => press(k)}
              className="w-16 h-14 rounded-full bg-card border border-line text-xl"
            >
              {k === '<' ? '⌫' : k}
            </button>
          )
        )}
      </div>
    </div>
  )
}
