import { useState } from 'react'
import { Goal } from '@/types'
import { Field, inputClass } from './Modal'

const ICONS = ['🎯', '💻', '📱', '🏍️', '✈️', '🛟', '🎓']

export function GoalForm({
  onSubmit,
  onCancel
}: {
  onSubmit: (g: Omit<Goal, 'id' | 'currentAmount' | 'createdAt' | 'updatedAt'>) => void
  onCancel: () => void
}) {
  const [name, setName] = useState('')
  const [targetAmount, setTargetAmount] = useState('')
  const [deadline, setDeadline] = useState('')
  const [icon, setIcon] = useState<string>(ICONS[0])
  const [customEmoji, setCustomEmoji] = useState('')
  const [error, setError] = useState('')

  const isCustom = icon === '+'

  const submit = () => {
    const v = parseFloat(targetAmount)
    const finalIcon = isCustom ? customEmoji.trim() : icon
    if (!name.trim() || !(v > 0)) return setError('Informe nome e valor objetivo.')
    if (!finalIcon) return setError('Escolha um emoji para a meta.')
    onSubmit({ name: name.trim(), targetAmount: v, deadline, icon: finalIcon, color: '#d4af37' })
  }

  return (
    <div>
      <h2 className="text-lg font-semibold mb-3">Nova meta</h2>
      <Field label="Nome">
        <input className={inputClass} value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <Field label="Valor objetivo (R$)">
        <input className={inputClass} type="number" inputMode="decimal" value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} />
      </Field>
      <Field label="Prazo">
        <input className={inputClass} type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} />
      </Field>
      <Field label="Ícone">
        <select className={inputClass} value={icon} onChange={(e) => setIcon(e.target.value)}>
          {ICONS.map((i) => (
            <option key={i}>{i}</option>
          ))}
          <option value="+">+ Escolher outro emoji</option>
        </select>
      </Field>
      {isCustom && (
        <Field label="Toque no campo e abra o teclado de emojis">
          <input
            className={inputClass}
            value={customEmoji}
            onChange={(e) => setCustomEmoji(e.target.value.slice(0, 8))}
            placeholder="😀"
            maxLength={8}
          />
        </Field>
      )}
      {error && <p className="text-neg text-sm mb-2">{error}</p>}
      <div className="flex gap-2 mt-2">
        <button onClick={submit} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">Criar meta</button>
        <button onClick={onCancel} className="border border-line rounded-lg px-4 py-2.5">Cancelar</button>
      </div>
    </div>
  )
}
