import { useEffect, useState } from 'react'
import { authAvailable, signUp, signIn, signOutUser, onAuthChange, authErrorMessage, type User } from '@/lib/backend/auth'
import { syncAvailable, pushToServer, pullFromServer, type RemoteData } from '@/lib/backend/sync'
import { AppState } from '@/lib/storage'
import { Card } from './Card'
import { Modal, inputClass } from './Modal'

export function AccountSection({
  state,
  onReplaceData,
  onUpdateSettings
}: {
  state: AppState
  onReplaceData: (tx: AppState['tx'], goals: AppState['goals'], payments?: AppState['payments']) => void
  onUpdateSettings: (patch: Partial<AppState['settings']>) => void
}) {
  const [user, setUser] = useState<User | null>(null)
  const [authOpen, setAuthOpen] = useState(false)
  const [mode, setMode] = useState<'in' | 'up'>('in')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState('')
  const [pullPreview, setPullPreview] = useState<RemoteData | null>(null)
  const [pushConfirmOpen, setPushConfirmOpen] = useState(false)

  useEffect(() => onAuthChange(setUser), [])

  const submit = async () => {
    setError('')
    setBusy(true)
    try {
      if (mode === 'up') await signUp(email, password)
      else await signIn(email, password)
      setAuthOpen(false)
      setEmail('')
      setPassword('')
    } catch (err) {
      setError(authErrorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const doPush = async () => {
    if (!user) return
    setBusy(true)
    setError('')
    try {
      await pushToServer(user.uid, state)
      setPushConfirmOpen(false)
      setMsg('Dados enviados para a nuvem.')
    } catch (err) {
      setError(authErrorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const startPull = async () => {
    if (!user) return
    setBusy(true)
    setError('')
    try {
      const remote = await pullFromServer(user.uid)
      if (!remote) {
        setMsg('Ainda não há dados salvos na nuvem para esta conta.')
      } else {
        setPullPreview(remote)
      }
    } catch (err) {
      setError(authErrorMessage(err))
    } finally {
      setBusy(false)
    }
  }

  const confirmPull = () => {
    if (!pullPreview) return
    onReplaceData(pullPreview.tx, pullPreview.goals, pullPreview.payments)
    onUpdateSettings({ name: pullPreview.settings.name, interfaceStyle: pullPreview.settings.interfaceStyle })
    setPullPreview(null)
    setMsg('Dados baixados da nuvem.')
  }

  if (!authAvailable()) {
    return (
      <Card className="mb-2.5">
        <small className="text-mut">CONTA</small>
        <p className="text-mut text-sm mt-1">Sincronização em nuvem ainda não configurada.</p>
      </Card>
    )
  }

  return (
    <Card className="mb-2.5">
      <small className="text-mut">CONTA</small>

      {user ? (
        <>
          <p className="text-sm mt-2 truncate">{user.email}</p>
          {syncAvailable() && (
            <div className="flex gap-2 flex-wrap mt-2">
              <button onClick={() => setPushConfirmOpen(true)} className="border border-line rounded-lg px-3 py-1.5 text-sm">
                Enviar dados para a nuvem
              </button>
              <button onClick={startPull} className="border border-line rounded-lg px-3 py-1.5 text-sm">
                Baixar dados da nuvem
              </button>
            </div>
          )}
          <button
            onClick={async () => {
              await signOutUser()
              setMsg('')
            }}
            className="border border-line rounded-lg px-3 py-1.5 text-sm text-neg mt-2"
          >
            Sair da conta
          </button>
        </>
      ) : (
        <div className="flex gap-2 mt-2">
          <button
            onClick={() => {
              setMode('in')
              setAuthOpen(true)
            }}
            className="border border-line rounded-lg px-4 py-2 text-sm flex-1"
          >
            Entrar
          </button>
          <button
            onClick={() => {
              setMode('up')
              setAuthOpen(true)
            }}
            className="bg-gold text-black font-semibold rounded-lg px-4 py-2 text-sm flex-1"
          >
            Criar conta
          </button>
        </div>
      )}

      {(msg || error) && <p className={`text-sm mt-2 ${error ? 'text-neg' : 'text-mut'}`}>{error || msg}</p>}

      <Modal
        open={authOpen}
        onClose={() => {
          setAuthOpen(false)
          setError('')
        }}
      >
        <h2 className="text-lg font-semibold mb-1">{mode === 'up' ? 'Criar conta' : 'Entrar'}</h2>
        <p className="text-mut text-sm mb-3">
          {mode === 'up' ? 'Cria uma conta pra sincronizar seus dados entre aparelhos.' : 'Entre com sua conta pra sincronizar seus dados.'}
        </p>
        <input className={inputClass} type="email" placeholder="E-mail" value={email} onChange={(e) => setEmail(e.target.value)} />
        <input className={inputClass} type="password" placeholder="Senha (mín. 6 caracteres)" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error && <p className="text-neg text-sm">{error}</p>}
        <button onClick={submit} disabled={busy} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 w-full mt-2 disabled:opacity-50">
          {mode === 'up' ? 'Criar conta' : 'Entrar'}
        </button>
      </Modal>

      <Modal open={pushConfirmOpen} onClose={() => setPushConfirmOpen(false)}>
        <h2 className="text-lg font-semibold mb-1">Enviar dados para a nuvem</h2>
        <p className="text-mut text-sm mb-3">
          Isso substitui, na nuvem, qualquer dado salvo antes para esta conta por {state.tx.length} lançamento(s),{' '}
          {state.goals.length} meta(s) e {state.payments.length} pagamento(s) deste aparelho.
        </p>
        <div className="flex gap-2">
          <button onClick={doPush} disabled={busy} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1 disabled:opacity-50">
            Enviar
          </button>
          <button onClick={() => setPushConfirmOpen(false)} className="border border-line rounded-lg px-4 py-2.5 flex-1">
            Cancelar
          </button>
        </div>
      </Modal>

      <Modal open={!!pullPreview} onClose={() => setPullPreview(null)}>
        <h2 className="text-lg font-semibold mb-1">Baixar dados da nuvem</h2>
        {pullPreview && (
          <p className="text-mut text-sm mb-3">
            A nuvem tem {pullPreview.tx.length} lançamento(s), {pullPreview.goals.length} meta(s) e{' '}
            {pullPreview.payments.length} pagamento(s). Isso substitui os dados deste aparelho — essa ação não pode ser
            desfeita. Sua senha do PIN não é afetada.
          </p>
        )}
        <div className="flex gap-2">
          <button onClick={confirmPull} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">
            Baixar e substituir
          </button>
          <button onClick={() => setPullPreview(null)} className="border border-line rounded-lg px-4 py-2.5 flex-1">
            Cancelar
          </button>
        </div>
      </Modal>
    </Card>
  )
}
