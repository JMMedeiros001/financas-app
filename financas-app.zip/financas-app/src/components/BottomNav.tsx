export type Tab = 'home' | 'finance' | 'goals' | 'payments' | 'reports' | 'ai' | 'profile'

const ITEMS: { id: Tab; label: string; icon: string }[] = [
  { id: 'home', label: 'Início', icon: '🏠' },
  { id: 'finance', label: 'Finanças', icon: '💰' },
  { id: 'goals', label: 'Metas', icon: '🎯' },
  { id: 'payments', label: 'Pagamentos', icon: '💳' },
  { id: 'reports', label: 'Relatórios', icon: '📊' },
  { id: 'ai', label: 'IA', icon: '🤖' },
  { id: 'profile', label: 'Perfil', icon: '👤' }
]

export function BottomNav({ tab, onChange }: { tab: Tab; onChange: (t: Tab) => void }) {
  return (
    <nav
      className="fixed left-0 right-0 bottom-0 md:top-0 md:bottom-auto md:right-auto md:w-48 md:h-full
                 flex md:flex-col bg-[#111113] border-t md:border-t-0 md:border-r border-line z-30"
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
    >
      {ITEMS.map((it) => (
        <button
          key={it.id}
          onClick={() => onChange(it.id)}
          className={`flex-1 md:flex-none md:text-left py-2 md:py-3 md:px-5 text-[10px] md:text-sm
                      ${tab === it.id ? 'text-gold' : 'text-mut'}`}
        >
          <span className="block md:inline md:mr-2 text-lg md:text-base">{it.icon}</span>
          {it.label}
        </button>
      ))}
    </nav>
  )
}
