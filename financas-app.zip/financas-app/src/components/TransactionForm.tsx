import { useState } from 'react'
import { Transaction, TxType } from '@/types'
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES, PAYMENT_METHODS } from '@/lib/categories'
import { todayISO } from '@/lib/calc'
import { Field, inputClass } from './Modal'

export function TransactionForm({
  type,
  initial,
  onSubmit,
  onCancel
}: {
  type: TxType
  initial?: Transaction
  onSubmit: (t: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => void
  onCancel: () => void
}) {
  const isIncome = type === 'income'
  const cats = isIncome ? INCOME_CATEGORIES : EXPENSE_CATEGORIES
  const [amount, setAmount] = useState(initial?.amount?.toString() ?? '')
  const [description, setDescription] = useState(initial?.description ?? '')
  const [category, setCategory] = useState(initial?.category ?? cats[0])
  const [date, setDate] = useState(initial?.date ?? todayISO())
  const [paymentMethod, setPaymentMethod] = useState(initial?.paymentMethod ?? (isIncome ? '' : PAYMENT_METHODS[0]))
  const [notes, setNotes] = useState(initial?.notes ?? '')
  const [error, setError] = useState('')

  const submit = () => {
    const v = parseFloat(amount)
    if (!(v > 0)) return setError('Informe um valor maior que zero.')
    onSubmit({ type, amount: v, description: description.trim(), category, date, paymentMethod, notes, demo: false })
  }

  return (
    <div>
      <h2 className="text-lg font-semibold mb-3">{initial ? 'Editar' : isIncome ? 'Nova receita' : 'Novo gasto'}</h2>
      <Field label="Valor (R$)">
        <input className={inputClass} type="number" step="0.01" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
      </Field>
      <Field label="Descrição">
        <input className={inputClass} value={description} onChange={(e) => setDescription(e.target.value)} />
      </Field>
      <Field label="Categoria">
        <select className={inputClass} value={category} onChange={(e) => setCategory(e.target.value)}>
          {cats.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </Field>
      <Field label="Data">
        <input className={inputClass} type="date" value={date} onChange={(e) => setDate(e.target.value)} />
      </Field>
      <Field label={isIncome ? 'Origem' : 'Forma de pagamento'}>
        {isIncome ? (
          <input className={inputClass} value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)} />
        ) : (
          <select className={inputClass} value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
            {PAYMENT_METHODS.map((p) => (
              <option key={p}>{p}</option>
            ))}
          </select>
        )}
      </Field>
      <Field label="Observação">
        <input className={inputClass} value={notes} onChange={(e) => setNotes(e.target.value)} />
      </Field>
      {error && <p className="text-neg text-sm mb-2">{error}</p>}
      <div className="flex gap-2 mt-2">
        <button onClick={submit} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">
          {isIncome ? 'Registrar receita' : 'Registrar gasto'}
        </button>
        <button onClick={onCancel} className="border border-line rounded-lg px-4 py-2.5">Cancelar</button>
      </div>
    </div>
  )
}
