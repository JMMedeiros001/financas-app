export function ProgressBar({ percent, color = 'bg-gold' }: { percent: number; color?: string }) {
  const w = Math.max(0, Math.min(100, percent))
  return (
    <div className="h-2 rounded-full bg-line overflow-hidden">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${w}%` }} />
    </div>
  )
}
