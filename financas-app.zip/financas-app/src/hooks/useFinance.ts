import { useCallback, useEffect, useState } from 'react'
import { Transaction, Goal } from '@/types'
import { AppState, defaultState, loadState, saveState } from '@/lib/storage'

export function useFinance() {
  const [state, setState] = useState<AppState>(defaultState)
  const [loaded, setLoaded] = useState(false)

  useEffect(() => {
    setState(loadState())
    setLoaded(true)
  }, [])

  useEffect(() => {
    if (loaded) saveState(state)
  }, [state, loaded])

  const addTransaction = useCallback((t: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString()
    setState((s) => ({ ...s, tx: [...s.tx, { ...t, id: crypto.randomUUID(), createdAt: now, updatedAt: now }] }))
  }, [])

  const updateTransaction = useCallback((id: string, patch: Partial<Transaction>) => {
    setState((s) => ({
      ...s,
      tx: s.tx.map((t) => (t.id === id ? { ...t, ...patch, updatedAt: new Date().toISOString() } : t))
    }))
  }, [])

  const deleteTransaction = useCallback((id: string) => {
    setState((s) => ({ ...s, tx: s.tx.filter((t) => t.id !== id) }))
  }, [])

  const addGoal = useCallback((g: Omit<Goal, 'id' | 'currentAmount' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString()
    setState((s) => ({
      ...s,
      goals: [...s.goals, { ...g, id: crypto.randomUUID(), currentAmount: 0, createdAt: now, updatedAt: now }]
    }))
  }, [])

  const moveGoalMoney = useCallback((id: string, delta: number) => {
    setState((s) => ({
      ...s,
      goals: s.goals.map((g) =>
        g.id === id ? { ...g, currentAmount: Math.max(0, g.currentAmount + delta), updatedAt: new Date().toISOString() } : g
      )
    }))
  }, [])

  const deleteGoal = useCallback((id: string) => {
    setState((s) => ({ ...s, goals: s.goals.filter((g) => g.id !== id) }))
  }, [])

  const updateSettings = useCallback((patch: Partial<AppState['settings']>) => {
    setState((s) => ({ ...s, settings: { ...s.settings, ...patch } }))
  }, [])

  const replaceData = useCallback((tx: Transaction[], goals: Goal[]) => {
    setState((s) => ({ ...s, tx, goals }))
  }, [])

  const loadDemoData = useCallback(() => {
    const n = new Date().toISOString().slice(0, 10)
    const demo: Array<[Transaction['type'], number, string, string]> = [
      ['income', 2500, 'Salário', 'Salário'],
      ['expense', 350, 'Alimentação', 'Mercado'],
      ['expense', 180, 'Transporte', 'Uber'],
      ['expense', 120, 'Lazer', 'Cinema'],
      ['expense', 50, 'Assinaturas', 'Streaming']
    ]
    setState((s) => ({
      ...s,
      tx: [
        ...s.tx,
        ...demo.map(([type, amount, category, description], i) => ({
          id: 'demo-' + i + '-' + Date.now(),
          type,
          amount,
          category,
          description,
          date: n,
          paymentMethod: '',
          notes: '',
          demo: true,
          createdAt: n,
          updatedAt: n
        }))
      ]
    }))
  }, [])

  const clearDemoData = useCallback(() => {
    setState((s) => ({ ...s, tx: s.tx.filter((t) => !t.demo) }))
  }, [])

  return {
    state,
    loaded,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addGoal,
    moveGoalMoney,
    deleteGoal,
    updateSettings,
    replaceData,
    loadDemoData,
    clearDemoData
  }
}
