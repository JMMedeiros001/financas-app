import { useCallback, useEffect, useState } from 'react'
import { Transaction, Goal, Payment } from '@/types'
import { AppState, loadState, saveState } from '@/lib/storage'
import { nextMonth } from '@/lib/payments'

export function useFinance() {
  // loadState() é síncrono (localStorage), então já usamos o valor real
  // desde a primeira renderização — sem isso, o app renderizava um
  // instante com dados padrão (estilo "clássica") e só depois trocava
  // para o estilo real salvo, causando um segundo "flash" visual na
  // inicialização.
  const [state, setState] = useState<AppState>(() => loadState())
  const [loaded] = useState(true)

  useEffect(() => {
    saveState(state)
  }, [state])

  const addTransaction = useCallback((t: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString()
    setState((s) => ({ ...s, tx: [...s.tx, { ...t, id: crypto.randomUUID(), createdAt: now, updatedAt: now }] }))
  }, [])

  const updateTransaction = useCallback((id: string, patch: Partial<Transaction>) => {
    setState((s) => ({
      ...s,
      tx: s.tx.map((t) => (t.id === id ? { ...t, ...patch, updatedAt: new Date().toISOString() } : t))
    }))
  }, [])

  const deleteTransaction = useCallback((id: string) => {
    setState((s) => ({ ...s, tx: s.tx.filter((t) => t.id !== id) }))
  }, [])

  const addGoal = useCallback((g: Omit<Goal, 'id' | 'currentAmount' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString()
    setState((s) => ({
      ...s,
      goals: [...s.goals, { ...g, id: crypto.randomUUID(), currentAmount: 0, createdAt: now, updatedAt: now }]
    }))
  }, [])

  const moveGoalMoney = useCallback((id: string, delta: number) => {
    setState((s) => ({
      ...s,
      goals: s.goals.map((g) =>
        g.id === id ? { ...g, currentAmount: Math.max(0, g.currentAmount + delta), updatedAt: new Date().toISOString() } : g
      )
    }))
  }, [])

  const deleteGoal = useCallback((id: string) => {
    setState((s) => ({ ...s, goals: s.goals.filter((g) => g.id !== id) }))
  }, [])

  const updateSettings = useCallback((patch: Partial<AppState['settings']>) => {
    setState((s) => ({ ...s, settings: { ...s.settings, ...patch } }))
  }, [])

  const replaceData = useCallback((tx: Transaction[], goals: Goal[], payments?: Payment[]) => {
    setState((s) => ({ ...s, tx, goals, payments: payments ?? s.payments }))
  }, [])

  const addPayment = useCallback((p: Omit<Payment, 'id' | 'installmentsPaid' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString()
    setState((s) => ({
      ...s,
      payments: [...s.payments, { ...p, id: crypto.randomUUID(), installmentsPaid: 0, createdAt: now, updatedAt: now }]
    }))
  }, [])

  const updatePayment = useCallback((id: string, patch: Partial<Payment>) => {
    setState((s) => ({
      ...s,
      payments: s.payments.map((p) => (p.id === id ? { ...p, ...patch, updatedAt: new Date().toISOString() } : p))
    }))
  }, [])

  const deletePayment = useCallback((id: string) => {
    setState((s) => ({ ...s, payments: s.payments.filter((p) => p.id !== id) }))
  }, [])

  /** Marca a próxima parcela como paga: soma 1 em installmentsPaid e, se
   *  ainda restarem parcelas, avança o vencimento pro mês seguinte —
   *  progresso e status (ver lib/payments.ts) atualizam sozinhos, por
   *  serem sempre derivados desses mesmos dados. */
  const markInstallmentPaid = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      payments: s.payments.map((p) => {
        if (p.id !== id) return p
        const paid = Math.min(p.installmentsTotal, p.installmentsPaid + 1)
        const stillOpen = paid < p.installmentsTotal
        return { ...p, installmentsPaid: paid, dueDate: stillOpen ? nextMonth(p.dueDate) : p.dueDate, updatedAt: new Date().toISOString() }
      })
    }))
  }, [])

  const unmarkInstallmentPaid = useCallback((id: string) => {
    setState((s) => ({
      ...s,
      payments: s.payments.map((p) =>
        p.id === id ? { ...p, installmentsPaid: Math.max(0, p.installmentsPaid - 1), updatedAt: new Date().toISOString() } : p
      )
    }))
  }, [])

  const loadDemoData = useCallback(() => {
    const n = new Date().toISOString().slice(0, 10)
    const demo: Array<[Transaction['type'], number, string, string]> = [
      ['income', 2500, 'Salário', 'Salário'],
      ['expense', 350, 'Alimentação', 'Mercado'],
      ['expense', 180, 'Transporte', 'Uber'],
      ['expense', 120, 'Lazer', 'Cinema'],
      ['expense', 50, 'Assinaturas', 'Streaming']
    ]
    setState((s) => ({
      ...s,
      tx: [
        ...s.tx,
        ...demo.map(([type, amount, category, description], i) => ({
          id: 'demo-' + i + '-' + Date.now(),
          type,
          amount,
          category,
          description,
          date: n,
          paymentMethod: '',
          notes: '',
          demo: true,
          createdAt: n,
          updatedAt: n
        }))
      ]
    }))
  }, [])

  const clearDemoData = useCallback(() => {
    setState((s) => ({ ...s, tx: s.tx.filter((t) => !t.demo) }))
  }, [])

  return {
    state,
    loaded,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addGoal,
    moveGoalMoney,
    deleteGoal,
    addPayment,
    updatePayment,
    deletePayment,
    markInstallmentPaid,
    unmarkInstallmentPaid,
    updateSettings,
    replaceData,
    loadDemoData,
    clearDemoData
  }
}
