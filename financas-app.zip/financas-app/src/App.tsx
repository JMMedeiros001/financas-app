import { useEffect, useRef, useState } from 'react'
import { useFinance } from '@/hooks/useFinance'
import { Transaction, TxType } from '@/types'
import { BottomNav, Tab } from '@/components/BottomNav'
import { Modal } from '@/components/Modal'
import { TransactionForm } from '@/components/TransactionForm'
import { Onboarding } from '@/components/Onboarding'
import { PinLockScreen } from '@/components/PinLockScreen'
import { Home } from '@/pages/Home'
import { Finance } from '@/pages/Finance'
import { Goals } from '@/pages/Goals'
import { Reports } from '@/pages/Reports'
import { AI } from '@/pages/AI'
import { Profile } from '@/pages/Profile'

export default function App() {
  const {
    state,
    loaded,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addGoal,
    moveGoalMoney,
    deleteGoal,
    updateSettings,
    replaceData,
    loadDemoData,
    clearDemoData
  } = useFinance()

  const [tab, setTab] = useState<Tab>('home')
  const [txModal, setTxModal] = useState<{ type: TxType; editing?: Transaction } | null>(null)
  const [locked, setLocked] = useState(false)
  const hiddenAt = useRef<number | null>(null)

  // Bloqueia ao voltar do segundo plano, de acordo com o tempo configurado.
  useEffect(() => {
    if (!loaded) return
    if (state.settings.pinHash) setLocked(true)

    const onVisibility = () => {
      if (document.hidden) {
        hiddenAt.current = Date.now()
        return
      }
      if (!state.settings.pinHash || locked) return
      const mins = state.settings.autoLockMinutes
      if (mins < 0) return
      const elapsed = hiddenAt.current ? Date.now() - hiddenAt.current : 0
      if (elapsed >= mins * 60_000) setLocked(true)
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => document.removeEventListener('visibilitychange', onVisibility)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded])

  if (!loaded) return null

  if (!state.settings.setupDone) {
    return (
      <Onboarding
        onDone={(name, pinHash) => {
          updateSettings({ name, pinHash, setupDone: true })
        }}
      />
    )
  }

  if (locked && state.settings.pinHash) {
    return <PinLockScreen pinHash={state.settings.pinHash} onUnlock={() => setLocked(false)} />
  }

  return (
    <div className="min-h-full">
      <BottomNav tab={tab} onChange={setTab} />
      <main className="pb-24 md:pb-8 md:ml-48 max-w-3xl mx-auto px-4 pt-5">
        {tab === 'home' && (
          <Home state={state} onNewExpense={() => setTxModal({ type: 'expense' })} onNewIncome={() => setTxModal({ type: 'income' })} />
        )}
        {tab === 'finance' && (
          <Finance
            state={state}
            onNewExpense={() => setTxModal({ type: 'expense' })}
            onNewIncome={() => setTxModal({ type: 'income' })}
            onEdit={(t) => setTxModal({ type: t.type, editing: t })}
            onDelete={(id) => confirm('Excluir lançamento?') && deleteTransaction(id)}
          />
        )}
        {tab === 'goals' && (
          <Goals
            state={state}
            onAddGoal={addGoal}
            onMoveMoney={moveGoalMoney}
            onDeleteGoal={(id) => confirm('Excluir meta? O valor volta ao saldo livre.') && deleteGoal(id)}
          />
        )}
        {tab === 'reports' && <Reports state={state} />}
        {tab === 'ai' && <AI state={state} onRegister={addTransaction} />}
        {tab === 'profile' && (
          <Profile
            state={state}
            onUpdateSettings={updateSettings}
            onReplaceData={replaceData}
            onLoadDemo={loadDemoData}
            onClearDemo={clearDemoData}
          />
        )}
      </main>

      <Modal open={!!txModal} onClose={() => setTxModal(null)}>
        {txModal && (
          <TransactionForm
            type={txModal.type}
            initial={txModal.editing}
            onCancel={() => setTxModal(null)}
            onSubmit={(t) => {
              if (txModal.editing) updateTransaction(txModal.editing.id, t)
              else addTransaction(t)
              setTxModal(null)
            }}
          />
        )}
      </Modal>
    </div>
  )
}
