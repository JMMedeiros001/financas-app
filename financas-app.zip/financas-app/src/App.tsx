import { useEffect, useState } from 'react'
import { useFinance } from '@/hooks/useFinance'
import { Transaction, TxType } from '@/types'
import { markBackgrounded, clearBackgrounded, shouldLock } from '@/lib/pinTimer'
import { BottomNav, Tab } from '@/components/BottomNav'
import { Modal } from '@/components/Modal'
import { TransactionForm } from '@/components/TransactionForm'
import { Onboarding } from '@/components/Onboarding'
import { PinLockScreen } from '@/components/PinLockScreen'
import { LoadingScreen } from '@/components/LoadingScreen'
import { Home } from '@/pages/Home'
import { Finance } from '@/pages/Finance'
import { Goals } from '@/pages/Goals'
import { Reports } from '@/pages/Reports'
import { AI } from '@/pages/AI'
import { Profile } from '@/pages/Profile'

const MIN_SPLASH_MS = 500

export default function App() {
  const {
    state,
    loaded,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    addGoal,
    moveGoalMoney,
    deleteGoal,
    updateSettings,
    replaceData,
    loadDemoData,
    clearDemoData
  } = useFinance()

  const [tab, setTab] = useState<Tab>('home')
  const [txModal, setTxModal] = useState<{ type: TxType; editing?: Transaction } | null>(null)
  const [locked, setLocked] = useState(false)
  const [splashDone, setSplashDone] = useState(false)

  // Tela de carregamento com duração mínima, pra sempre aparecer de forma
  // perceptível (mesmo quando os dados carregam quase instantaneamente).
  useEffect(() => {
    const t = setTimeout(() => setSplashDone(true), MIN_SPLASH_MS)
    return () => clearTimeout(t)
  }, [])

  // Ao carregar os dados: se houver PIN, decide se bloqueia com base no tempo
  // configurado e em quando o app foi pro segundo plano pela última vez —
  // isso é lido de um armazenamento que sobrevive ao processo ser encerrado,
  // então cobre tanto "voltar do segundo plano" quanto "reabrir depois de
  // o Android ter matado o app".
  useEffect(() => {
    if (!loaded) return
    if (state.settings.pinHash && shouldLock(state.settings.autoLockMinutes)) {
      setLocked(true)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loaded])

  // Observa quando o app sai/volta do primeiro plano. Recriado sempre que o
  // PIN ou o tempo configurado mudam, pra nunca usar valores desatualizados.
  useEffect(() => {
    const onVisibility = () => {
      if (document.hidden) {
        markBackgrounded()
        return
      }
      if (state.settings.pinHash && shouldLock(state.settings.autoLockMinutes)) {
        setLocked(true)
      }
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => document.removeEventListener('visibilitychange', onVisibility)
  }, [state.settings.pinHash, state.settings.autoLockMinutes])

  if (!loaded || !splashDone) {
    return <LoadingScreen style={loaded ? state.settings.interfaceStyle : 'classica'} />
  }

  if (!state.settings.setupDone) {
    return (
      <Onboarding
        onDone={(name, pinHash, interfaceStyle) => {
          updateSettings({ name, pinHash, interfaceStyle, setupDone: true })
        }}
      />
    )
  }

  if (locked && state.settings.pinHash) {
    return (
      <PinLockScreen
        pinHash={state.settings.pinHash}
        onUnlock={() => {
          clearBackgrounded()
          setLocked(false)
        }}
      />
    )
  }

  return (
    <div className="min-h-full">
      <BottomNav tab={tab} onChange={setTab} />
      <main className="pb-24 md:pb-8 md:ml-48 max-w-3xl mx-auto px-4 pt-5">
        {tab === 'home' && (
          <Home state={state} onNewExpense={() => setTxModal({ type: 'expense' })} onNewIncome={() => setTxModal({ type: 'income' })} />
        )}
        {tab === 'finance' && (
          <Finance
            state={state}
            onNewExpense={() => setTxModal({ type: 'expense' })}
            onNewIncome={() => setTxModal({ type: 'income' })}
            onEdit={(t) => setTxModal({ type: t.type, editing: t })}
            onDelete={(id) => confirm('Excluir lançamento?') && deleteTransaction(id)}
          />
        )}
        {tab === 'goals' && (
          <Goals
            state={state}
            onAddGoal={addGoal}
            onMoveMoney={moveGoalMoney}
            onDeleteGoal={(id) => confirm('Excluir meta? O valor volta ao saldo livre.') && deleteGoal(id)}
          />
        )}
        {tab === 'reports' && <Reports state={state} />}
        {tab === 'ai' && <AI state={state} onRegister={addTransaction} />}
        {tab === 'profile' && (
          <Profile
            state={state}
            onUpdateSettings={updateSettings}
            onReplaceData={replaceData}
            onLoadDemo={loadDemoData}
            onClearDemo={clearDemoData}
          />
        )}
      </main>

      <Modal open={!!txModal} onClose={() => setTxModal(null)}>
        {txModal && (
          <TransactionForm
            type={txModal.type}
            initial={txModal.editing}
            onCancel={() => setTxModal(null)}
            onSubmit={(t) => {
              if (txModal.editing) updateTransaction(txModal.editing.id, t)
              else addTransaction(t)
              setTxModal(null)
            }}
          />
        )}
      </Modal>
    </div>
  )
}
