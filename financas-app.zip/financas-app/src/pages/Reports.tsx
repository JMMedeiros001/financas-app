import { useMemo, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from 'recharts'
import { AppState } from '@/lib/storage'
import { sumByType, byCategory, formatBRL, monthKey } from '@/lib/calc'
import { cardPad, showDetails } from '@/lib/theme'
import { Card } from '@/components/Card'
import { ProgressBar } from '@/components/ProgressBar'
import { TransactionItem } from '@/components/TransactionItem'

type Range = 'm' | 'q' | 'y'

export function Reports({ state }: { state: AppState }) {
  const pad = cardPad(state.settings.interfaceStyle)
  const detailed = showDetails(state.settings.interfaceStyle)
  const [range, setRange] = useState<Range>('m')

  const periodTx = useMemo(() => {
    if (range === 'y') {
      const year = String(new Date().getFullYear())
      return state.tx.filter((t) => t.date.startsWith(year))
    }
    const n = range === 'q' ? 3 : 1
    const keys = Array.from({ length: n }, (_, k) => monthKey(k))
    return state.tx.filter((t) => keys.some((k) => t.date.startsWith(k)))
  }, [state.tx, range])

  const income = sumByType(periodTx, 'income')
  const expense = sumByType(periodTx, 'expense')
  const cats = byCategory(periodTx, 'expense')
  const top = [...periodTx].filter((t) => t.type === 'expense').sort((a, b) => b.amount - a.amount).slice(0, 5)

  const evolution = Array.from({ length: 6 }, (_, i) => 5 - i).map((k) => {
    const key = monthKey(k)
    const ms = state.tx.filter((t) => t.date.startsWith(key))
    return { name: key.slice(5) + '/' + key.slice(2, 4), Entradas: sumByType(ms, 'income'), Saídas: sumByType(ms, 'expense') }
  })

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-3">Relatórios</h1>
      <div className="flex gap-1.5 mb-3">
        {([['m', 'Mês'], ['q', 'Trimestre'], ['y', 'Ano']] as [Range, string][]).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setRange(id)}
            className={`px-3 py-1.5 text-sm rounded-lg border ${range === id ? 'border-gold text-gold' : 'border-line text-mut'}`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2.5 mb-2.5">
        <Card className={pad}><small className="text-mut">RECEITAS</small><b className="block text-lg text-pos mt-1">{formatBRL(income)}</b></Card>
        <Card className={pad}><small className="text-mut">GASTOS</small><b className="block text-lg text-neg mt-1">{formatBRL(expense)}</b></Card>
        <Card className={pad}><small className="text-mut">SALDO</small><b className="block text-lg mt-1">{formatBRL(income - expense)}</b></Card>
        <Card className={pad}><small className="text-mut">ECONOMIA</small><b className="block text-lg text-gold mt-1">{income ? (((income - expense) / income) * 100).toFixed(0) + '%' : '—'}</b></Card>
      </div>

      <Card className={`mb-2.5 ${pad}`}>
        <small className="text-mut">GASTOS POR CATEGORIA</small>
        {cats.length ? (
          <div className="mt-2 space-y-2">
            {cats.map(([c, v]) => (
              <div key={c} className="flex items-center gap-2 text-sm">
                <span className="w-24 truncate">{c}</span>
                <div className="flex-1"><ProgressBar percent={(v / cats[0][1]) * 100} color="bg-neg" /></div>
                <b className="w-24 text-right">{formatBRL(v)}</b>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-mut text-sm mt-2">Sem gastos no período.</p>
        )}
      </Card>

      <Card className={`mb-2.5 ${pad}`}>
        <small className="text-mut">MAIORES DESPESAS</small>
        {top.length ? top.map((t) => <TransactionItem key={t.id} t={t} onEdit={() => {}} onDelete={() => {}} />) : <p className="text-mut text-sm mt-2">Sem despesas no período.</p>}
      </Card>

      {detailed && (
        <Card className={pad}>
          <small className="text-mut">EVOLUÇÃO MENSAL</small>
          <div className="h-56 mt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={evolution}>
                <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2f" />
                <XAxis dataKey="name" stroke="#8b8b93" fontSize={11} />
                <YAxis stroke="#8b8b93" fontSize={11} width={40} />
                <Tooltip formatter={(v: number) => formatBRL(v)} contentStyle={{ background: '#17171a', border: '1px solid #2a2a2f' }} />
                <Legend />
                <Bar dataKey="Entradas" fill="#3ddc84" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Saídas" fill="#ff5d73" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}
    </div>
  )
}
