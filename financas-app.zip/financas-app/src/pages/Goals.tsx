import { useState } from 'react'
import { AppState } from '@/lib/storage'
import { Goal } from '@/types'
import { balance, reserved, formatBRL } from '@/lib/calc'
import { GoalCard } from '@/components/GoalCard'
import { Modal, Field, inputClass } from '@/components/Modal'
import { GoalForm } from '@/components/GoalForm'

export function Goals({
  state,
  onAddGoal,
  onMoveMoney,
  onDeleteGoal
}: {
  state: AppState
  onAddGoal: (g: Omit<Goal, 'id' | 'currentAmount' | 'createdAt' | 'updatedAt'>) => void
  onMoveMoney: (id: string, delta: number) => void
  onDeleteGoal: (id: string) => void
}) {
  const [creating, setCreating] = useState(false)
  const [moving, setMoving] = useState<Goal | null>(null)
  const [amount, setAmount] = useState('')
  const [error, setError] = useState('')

  const res = reserved(state.goals)
  const free = balance(state.tx) - res

  const confirmMove = (sign: 1 | -1) => {
    if (!moving) return
    const v = parseFloat(amount)
    if (!(v > 0)) return setError('Informe um valor.')
    if (sign > 0 && v > free) return setError('Saldo livre insuficiente.')
    if (sign < 0 && v > moving.currentAmount) return setError('Maior que o valor guardado.')
    onMoveMoney(moving.id, sign * v)
    setMoving(null)
    setAmount('')
    setError('')
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Metas</h1>
      <p className="text-mut text-sm mb-3">
        Reservado <b className="text-gold">{formatBRL(res)}</b> · Saldo livre {formatBRL(free)}
      </p>
      <button onClick={() => setCreating(true)} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 mb-3">
        + Nova meta
      </button>

      {state.goals.length ? (
        state.goals.map((g) => (
          <GoalCard key={g.id} g={g} onMoveMoney={() => setMoving(g)} onDelete={() => onDeleteGoal(g.id)} />
        ))
      ) : (
        <p className="text-mut text-sm">Nenhuma meta ainda. Crie a primeira e comece a reservar.</p>
      )}

      <Modal open={creating} onClose={() => setCreating(false)}>
        <GoalForm
          onSubmit={(g) => {
            onAddGoal(g)
            setCreating(false)
          }}
          onCancel={() => setCreating(false)}
        />
      </Modal>

      <Modal open={!!moving} onClose={() => setMoving(null)}>
        {moving && (
          <div>
            <h2 className="text-lg font-semibold mb-3">{moving.name}</h2>
            <Field label="Valor (R$)">
              <input className={inputClass} type="number" inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} />
            </Field>
            {error && <p className="text-neg text-sm mb-2">{error}</p>}
            <div className="flex gap-2">
              <button onClick={() => confirmMove(1)} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">Adicionar</button>
              <button onClick={() => confirmMove(-1)} className="border border-line rounded-lg px-4 py-2.5 flex-1">Retirar</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
