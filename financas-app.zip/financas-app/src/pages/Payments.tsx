import { useMemo, useState } from 'react'
import { AppState } from '@/lib/storage'
import { Payment } from '@/types'
import { formatBRL } from '@/lib/calc'
import { cardPad } from '@/lib/theme'
import { paymentStatus, remainingAmount } from '@/lib/payments'
import { Card } from '@/components/Card'
import { Modal } from '@/components/Modal'
import { PaymentForm } from '@/components/PaymentForm'
import { PaymentCard } from '@/components/PaymentCard'

export function Payments({
  state,
  onAdd,
  onUpdate,
  onDelete,
  onMarkPaid,
  onUnmarkPaid
}: {
  state: AppState
  onAdd: (p: Omit<Payment, 'id' | 'installmentsPaid' | 'createdAt' | 'updatedAt'>) => void
  onUpdate: (id: string, patch: Partial<Payment>) => void
  onDelete: (id: string) => void
  onMarkPaid: (id: string) => void
  onUnmarkPaid: (id: string) => void
}) {
  const pad = cardPad(state.settings.interfaceStyle)
  const [creating, setCreating] = useState(false)
  const [editing, setEditing] = useState<Payment | null>(null)

  const sorted = useMemo(() => {
    const order = { atrasado: 0, pendente: 1, pago: 2 }
    return [...state.payments].sort((a, b) => {
      const byStatus = order[paymentStatus(a)] - order[paymentStatus(b)]
      if (byStatus !== 0) return byStatus
      return a.dueDate.localeCompare(b.dueDate)
    })
  }, [state.payments])

  const pendingTotal = useMemo(
    () =>
      state.payments
        .filter((p) => paymentStatus(p) !== 'pago')
        .reduce((s, p) => s + remainingAmount(p), 0),
    [state.payments]
  )
  const lateCount = useMemo(() => state.payments.filter((p) => paymentStatus(p) === 'atrasado').length, [state.payments])

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Pagamentos</h1>
      <p className="text-mut text-sm mb-3">
        Em aberto: <b className="text-ink">{formatBRL(pendingTotal)}</b>
        {lateCount > 0 && <> · <b className="text-neg">{lateCount} atrasado(s)</b></>}
      </p>

      <button onClick={() => setCreating(true)} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 mb-3">
        + Novo pagamento
      </button>

      {sorted.length ? (
        sorted.map((p) => (
          <PaymentCard
            key={p.id}
            p={p}
            padClass={pad}
            onMarkPaid={() => onMarkPaid(p.id)}
            onUnmarkPaid={() => onUnmarkPaid(p.id)}
            onEdit={() => setEditing(p)}
            onDelete={() => onDelete(p.id)}
          />
        ))
      ) : (
        <Card className={pad}>
          <p className="text-mut text-sm">
            Nenhum pagamento cadastrado. Use "+ Novo pagamento" para registrar dívidas, empréstimos ou compras parceladas.
          </p>
        </Card>
      )}

      <Modal open={creating} onClose={() => setCreating(false)}>
        <PaymentForm
          onSubmit={(p) => {
            onAdd(p)
            setCreating(false)
          }}
          onCancel={() => setCreating(false)}
        />
      </Modal>

      <Modal open={!!editing} onClose={() => setEditing(null)}>
        {editing && (
          <PaymentForm
            initial={editing}
            onSubmit={(p) => {
              onUpdate(editing.id, p)
              setEditing(null)
            }}
            onCancel={() => setEditing(null)}
          />
        )}
      </Modal>
    </div>
  )
}
