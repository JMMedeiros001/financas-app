import { useRef, useState } from 'react'
import { AppState } from '@/lib/storage'
import { Transaction } from '@/types'
import { interpret } from '@/lib/ai'
import { formatBRL } from '@/lib/calc'
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from '@/lib/categories'
import { stackGap, showDetails } from '@/lib/theme'

type Msg = { from: 'u' | 'a'; text: string }

const SUGGESTIONS = [
  'Monte um plano para eu economizar',
  'Onde estou gastando demais?',
  'Como junto dinheiro para minhas metas?',
  'Analise minhas finanças'
]

export function AI({
  state,
  onRegister
}: {
  state: AppState
  onRegister: (t: Omit<Transaction, 'id' | 'createdAt' | 'updatedAt'>) => void
}) {
  const gap = stackGap(state.settings.interfaceStyle)
  const showSuggestions = showDetails(state.settings.interfaceStyle)
  const [messages, setMessages] = useState<Msg[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [usedServer, setUsedServer] = useState<boolean | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const ask = async (q?: string) => {
    const question = (q ?? input).trim()
    if (!question || busy) return
    setInput('')
    setMessages((m) => [...m, { from: 'u', text: question }])
    setBusy(true)
    const { result, usedServer: fromServer } = await interpret(state, question)
    setUsedServer(fromServer)

    let answer = ''
    if (result.action === 'register') {
      const list = result.type === 'income' ? INCOME_CATEGORIES : EXPENSE_CATEGORIES
      const category = (list as readonly string[]).includes(result.category) ? result.category : 'Outros'
      onRegister({
        type: result.type,
        amount: result.amount,
        category,
        description: result.description || '',
        date: new Date().toISOString().slice(0, 10),
        paymentMethod: '',
        notes: 'via IA',
        demo: false
      })
      answer = `Registrado: ${result.type === 'income' ? 'receita' : 'gasto'} de ${formatBRL(result.amount)} · ${category}${result.description ? ' · ' + result.description : ''}.`
    } else {
      answer = result.text
    }

    setMessages((m) => [...m, { from: 'a', text: answer }])
    setBusy(false)
    inputRef.current?.focus()
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">🤖 IA Financeira</h1>
      <p className="text-mut text-sm mb-3">
        {usedServer === null
          ? 'Responde com base nos seus dados reais e registra por comando.'
          : usedServer
          ? 'Conectada à IA real do servidor.'
          : 'Modo offline por regras (servidor de IA indisponível nesta sessão).'}
      </p>

      {showSuggestions && (
        <div className="flex gap-1.5 flex-wrap mb-3">
          {SUGGESTIONS.map((s) => (
            <button key={s} onClick={() => ask(s)} className="border border-line rounded-lg px-3 py-1.5 text-sm text-left">
              {s}
            </button>
          ))}
        </div>
      )}

      <div className={`${gap} mb-3`}>
        {messages.map((m, i) => (
          <div
            key={i}
            className={`rounded-xl px-3 py-2.5 max-w-[90%] border ${
              m.from === 'u' ? 'ml-auto bg-[#2a2410] border-[#5a4a15]' : 'bg-card border-line'
            }`}
          >
            {m.text}
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <input
          ref={inputRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && ask()}
          placeholder="Pergunte ou registre..."
          className="flex-1 bg-[#0f0f11] border border-line rounded-lg px-3 py-2.5 outline-none focus:border-gold"
        />
        <button onClick={() => ask()} disabled={busy} className="bg-gold text-black rounded-lg px-4 disabled:opacity-50">➤</button>
      </div>
    </div>
  )
}
