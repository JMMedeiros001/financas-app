import { useMemo, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { AppState } from '@/lib/storage'
import { Transaction } from '@/types'
import { balance, reserved, sumByType, byCategory, formatBRL, monthKey } from '@/lib/calc'
import { cardPad, showDetails } from '@/lib/theme'
import { Card } from '@/components/Card'
import { ProgressBar } from '@/components/ProgressBar'
import { SavingsBar } from '@/components/SavingsBar'
import { TransactionItem } from '@/components/TransactionItem'

type Filter = 'all' | 'income' | 'expense'

export function Finance({
  state,
  onNewExpense,
  onNewIncome,
  onEdit,
  onDelete
}: {
  state: AppState
  onNewExpense: () => void
  onNewIncome: () => void
  onEdit: (t: Transaction) => void
  onDelete: (id: string) => void
}) {
  const style = state.settings.interfaceStyle
  const pad = cardPad(style)
  const detailed = showDetails(style)
  const [monthOffset, setMonthOffset] = useState(0)
  const [filter, setFilter] = useState<Filter>('all')
  const [catFilter, setCatFilter] = useState('')

  const key = monthKey(monthOffset)
  const monthTx = useMemo(() => state.tx.filter((t) => t.date.startsWith(key)), [state.tx, key])

  const income = sumByType(monthTx, 'income')
  const expense = sumByType(monthTx, 'expense')
  const res = reserved(state.goals)
  const bal = balance(state.tx)
  const savings = income ? ((income - expense) / income) * 100 : 0
  const cats = byCategory(monthTx, 'expense')

  const monthLabel = new Date(key + '-01T12:00').toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })

  const flowData = [
    { name: 'Entradas', valor: income },
    { name: 'Saídas', valor: expense },
    { name: 'Saldo', valor: income - expense }
  ]

  const list = monthTx
    .filter((t) => (filter === 'all' || t.type === filter) && (!catFilter || t.category === catFilter))
    .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt))

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-3">Finanças</h1>
      <div className="flex items-center justify-between mb-3">
        <button onClick={() => setMonthOffset((m) => m + 1)} className="border border-line rounded-lg px-3 py-1.5">‹</button>
        <b className="capitalize">{monthLabel}</b>
        <button onClick={() => setMonthOffset((m) => Math.max(0, m - 1))} className="border border-line rounded-lg px-3 py-1.5">›</button>
      </div>

      <div className="grid grid-cols-2 gap-2.5 mb-2.5">
        <Card className={pad}><small className="text-mut">ENTROU</small><b className="block text-lg text-pos mt-1">{formatBRL(income)}</b></Card>
        <Card className={pad}><small className="text-mut">SAIU</small><b className="block text-lg text-neg mt-1">{formatBRL(expense)}</b></Card>
      </div>

      <Card className={`mb-2.5 ${pad}`}>
        <small className="text-mut">SALDO LIVRE</small>
        <div className="text-3xl font-bold mt-1">{formatBRL(bal - res)}</div>
        <small className="text-mut">Saldo total {formatBRL(bal)} · Reservado {formatBRL(res)}</small>
        <SavingsBar percent={savings} />
      </Card>

      <div className="flex gap-2 mb-4">
        <button onClick={onNewExpense} className="border border-line rounded-lg px-4 py-2.5 flex-1">- Gasto</button>
        <button onClick={onNewIncome} className="border border-line rounded-lg px-4 py-2.5 flex-1">+ Receita</button>
      </div>

      {detailed && (
        <Card className={`mb-2.5 ${pad}`}>
          <small className="text-mut">FLUXO DO MÊS</small>
          {monthTx.length ? (
            <div className="h-48 mt-2">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={flowData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#2a2a2f" />
                  <XAxis dataKey="name" stroke="#8b8b93" fontSize={12} />
                  <YAxis stroke="#8b8b93" fontSize={11} width={40} />
                  <Tooltip formatter={(v: number) => formatBRL(v)} contentStyle={{ background: '#17171a', border: '1px solid #2a2a2f' }} />
                  <Bar dataKey="valor" fill="#d4af37" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="text-mut text-sm mt-2">Nenhuma movimentação registrada neste mês.</p>
          )}
        </Card>
      )}

      {detailed && (
        <Card className={`mb-2.5 ${pad}`}>
          <small className="text-mut">GASTOS POR CATEGORIA (toque para filtrar)</small>
          {cats.length ? (
            <div className="mt-2 space-y-2">
              {cats.map(([c, v]) => (
                <button key={c} onClick={() => setCatFilter(c)} className="w-full flex items-center gap-2 text-sm text-left">
                  <span className="w-24 truncate">{c}</span>
                  <div className="flex-1"><ProgressBar percent={(v / cats[0][1]) * 100} color="bg-neg" /></div>
                  <b className="w-28 text-right">{formatBRL(v)} · {((v / expense) * 100).toFixed(0)}%</b>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-mut text-sm mt-2">Sem gastos neste mês.</p>
          )}
        </Card>
      )}

      <small className="text-mut">MOVIMENTAÇÕES</small>
      <div className="flex gap-1.5 my-2 flex-wrap">
        {([['all', 'Todos'], ['income', 'Receitas'], ['expense', 'Gastos']] as [Filter, string][]).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setFilter(id)}
            className={`px-3 py-1.5 text-sm rounded-lg border ${filter === id ? 'border-gold text-gold' : 'border-line text-mut'}`}
          >
            {label}
          </button>
        ))}
        {catFilter && (
          <button onClick={() => setCatFilter('')} className="px-3 py-1.5 text-sm rounded-lg border border-gold text-gold">
            {catFilter} ✕
          </button>
        )}
      </div>

      <Card className={pad}>
        {list.length ? (
          list.map((t) => <TransactionItem key={t.id} t={t} onEdit={() => onEdit(t)} onDelete={() => onDelete(t.id)} />)
        ) : (
          <p className="text-mut text-sm">Nenhum lançamento. Toque em "- Gasto" ou "+ Receita".</p>
        )}
      </Card>
    </div>
  )
}
