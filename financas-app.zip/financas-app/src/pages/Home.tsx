import { useMemo, useState } from 'react'
import { AppState } from '@/lib/storage'
import { Transaction } from '@/types'
import { balance, reserved, sumByType, byCategory, savingsRate, formatBRL, todayISO, monthKey, inMonth } from '@/lib/calc'
import { CATEGORY_ICON } from '@/lib/categories'
import { Card } from '@/components/Card'
import { ProgressBar } from '@/components/ProgressBar'
import { SavingsBar } from '@/components/SavingsBar'
import logo from '@/assets/logo.png'

type Period = 'day' | 'week' | 'month' | 'prev'

interface HomeProps {
  state: AppState
  onNewExpense: () => void
  onNewIncome: () => void
}

const PERIODS: [Period, string][] = [
  ['day', 'Hoje'],
  ['week', 'Esta semana'],
  ['month', 'Este mês'],
  ['prev', 'Mês anterior']
]

function greeting(name: string) {
  const h = new Date().getHours()
  const saudacao = h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'
  return name ? `${saudacao}, ${name}` : saudacao
}

function PeriodTabs({ period, onChange }: { period: Period; onChange: (p: Period) => void }) {
  return (
    <div className="flex gap-1.5 overflow-x-auto">
      {PERIODS.map(([id, label]) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`px-3 py-1.5 text-sm rounded-lg border whitespace-nowrap ${
            period === id ? 'border-gold text-gold' : 'border-line text-mut'
          }`}
        >
          {label}
        </button>
      ))}
    </div>
  )
}

function ActionButtons({ onNewExpense, onNewIncome }: { onNewExpense: () => void; onNewIncome: () => void }) {
  return (
    <div className="flex gap-2 mt-4">
      <button onClick={onNewExpense} className="border border-line rounded-lg px-4 py-2.5 flex-1">- Gasto</button>
      <button onClick={onNewIncome} className="border border-line rounded-lg px-4 py-2.5 flex-1">+ Receita</button>
    </div>
  )
}

// ---------- Clássica: simples e direta ----------
function ClassicaHome({ state, filtered, period, setPeriod, bal, onNewExpense, onNewIncome }: HomeVariantProps) {
  const recent = useMemo(() => [...state.tx].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)).slice(0, 4), [state.tx])

  return (
    <div>
      <h1 className="text-2xl font-semibold">{greeting(state.settings.name)}</h1>

      <Card className="mt-4">
        <small className="text-mut">SALDO</small>
        <div className="text-4xl font-bold mt-1">{formatBRL(bal)}</div>
      </Card>

      <div className="my-3">
        <PeriodTabs period={period} onChange={setPeriod} />
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <Card>
          <small className="text-mut">↑ Entradas</small>
          <b className="block text-lg text-pos mt-1">{formatBRL(sumByType(filtered, 'income'))}</b>
        </Card>
        <Card>
          <small className="text-mut">↓ Saídas</small>
          <b className="block text-lg text-neg mt-1">{formatBRL(sumByType(filtered, 'expense'))}</b>
        </Card>
      </div>

      <ActionButtons onNewExpense={onNewExpense} onNewIncome={onNewIncome} />

      <small className="text-mut block mt-5 mb-2">MOVIMENTAÇÕES RECENTES</small>
      <Card>
        {recent.length ? (
          recent.map((t) => (
            <div key={t.id} className="flex items-center gap-3 py-2 border-b border-line last:border-0">
              <span className="text-lg">{CATEGORY_ICON[t.category] || '•'}</span>
              <span className="flex-1 truncate">{t.description || t.category}</span>
              <b className={t.type === 'income' ? 'text-pos' : 'text-neg'}>
                {t.type === 'income' ? '+ ' : '- '}
                {formatBRL(t.amount)}
              </b>
            </div>
          ))
        ) : (
          <p className="text-mut text-sm">Nenhum lançamento ainda.</p>
        )}
      </Card>
    </div>
  )
}

// ---------- Compacta: mais informação, menos espaço ----------
function CompactaHome({ state, filtered, period, setPeriod, bal, res, onNewExpense, onNewIncome }: HomeVariantProps) {
  const recent = useMemo(() => [...state.tx].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)).slice(0, 6), [state.tx])
  const cats = useMemo(() => byCategory(filtered, 'expense'), [filtered])
  const expenseTotal = sumByType(filtered, 'expense')

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">{greeting(state.settings.name)}</h1>
      </div>

      <Card className="mt-3 !p-3">
        <small className="text-mut">SALDO</small>
        <div className="text-3xl font-bold">{formatBRL(bal)}</div>
        <div className="flex gap-4 mt-1 text-sm">
          <span className="text-pos">↑ {formatBRL(sumByType(filtered, 'income'))}</span>
          <span className="text-neg">↓ {formatBRL(expenseTotal)}</span>
          <span className="text-gold">🎯 {formatBRL(res)}</span>
        </div>
      </Card>

      <div className="my-2">
        <PeriodTabs period={period} onChange={setPeriod} />
      </div>

      <div className="flex gap-2">
        <button onClick={onNewExpense} className="border border-line rounded-lg px-3 py-1.5 text-sm flex-1">- Gasto</button>
        <button onClick={onNewIncome} className="border border-line rounded-lg px-3 py-1.5 text-sm flex-1">+ Receita</button>
      </div>

      <small className="text-mut block mt-3 mb-1">ÚLTIMAS MOVIMENTAÇÕES</small>
      <Card className="!p-3">
        {recent.length ? (
          recent.map((t) => (
            <div key={t.id} className="flex items-center gap-2 py-1.5 text-sm border-b border-line last:border-0">
              <span>{t.type === 'income' ? '🟢' : '🔴'}</span>
              <span className="flex-1 truncate">{t.description || t.category}</span>
              <b className={t.type === 'income' ? 'text-pos' : 'text-neg'}>
                {t.type === 'income' ? '+' : '-'}
                {formatBRL(t.amount)}
              </b>
            </div>
          ))
        ) : (
          <p className="text-mut text-sm">Sem lançamentos.</p>
        )}
      </Card>

      {cats.length > 0 && (
        <>
          <small className="text-mut block mt-3 mb-1">CATEGORIAS</small>
          <Card className="!p-3 space-y-1.5">
            {cats.slice(0, 4).map(([c, v]) => (
              <div key={c} className="flex items-center gap-2 text-sm">
                <span className="w-24 truncate">{c}</span>
                <div className="flex-1"><ProgressBar percent={(v / expenseTotal) * 100} color="bg-neg" /></div>
                <b className="w-10 text-right">{((v / expenseTotal) * 100).toFixed(0)}%</b>
              </div>
            ))}
          </Card>
        </>
      )}
    </div>
  )
}

// ---------- Minimalista: só o essencial ----------
function MinimalistaHome({ state, bal, filtered, onNewExpense, onNewIncome }: HomeVariantProps) {
  return (
    <div className="flex flex-col items-center text-center pt-6">
      <p className="text-mut text-sm">{greeting(state.settings.name)}</p>

      <div className="mt-8">
        <small className="text-mut tracking-widest">SALDO</small>
        <div className="text-5xl font-bold mt-2">{formatBRL(bal)}</div>
      </div>

      <div className="mt-10 w-full space-y-5">
        <div>
          <small className="text-mut">Entradas</small>
          <div className="text-2xl text-pos">+ {formatBRL(sumByType(filtered, 'income'))}</div>
        </div>
        <div>
          <small className="text-mut">Saídas</small>
          <div className="text-2xl text-neg">- {formatBRL(sumByType(filtered, 'expense'))}</div>
        </div>
      </div>

      <div className="flex gap-4 mt-10">
        <button
          onClick={onNewExpense}
          aria-label="Novo gasto"
          className="w-14 h-14 rounded-full border border-line text-2xl flex items-center justify-center"
        >
          −
        </button>
        <button
          onClick={onNewIncome}
          aria-label="Nova receita"
          className="w-14 h-14 rounded-full bg-gold text-black text-2xl flex items-center justify-center"
        >
          +
        </button>
      </div>
    </div>
  )
}

// ---------- Avançada: mais detalhes e análises ----------
function AvancadaHome({ state, filtered, period, setPeriod, bal, res, onNewExpense, onNewIncome }: HomeVariantProps) {
  const thisMonth = useMemo(() => state.tx.filter((t) => inMonth(t, monthKey(0))), [state.tx])
  const prevMonth = useMemo(() => state.tx.filter((t) => inMonth(t, monthKey(1))), [state.tx])
  const cats = useMemo(() => byCategory(thisMonth, 'expense'), [thisMonth])
  const expenseNow = sumByType(thisMonth, 'expense')
  const expensePrev = sumByType(prevMonth, 'expense')
  const diff = expensePrev ? ((expenseNow - expensePrev) / expensePrev) * 100 : 0
  const rate = savingsRate(thisMonth)

  return (
    <div>
      <div className="flex items-center gap-3">
        <img src={logo} alt="" className="w-10 h-10 rounded-lg object-contain" />
        <div>
          <p className="text-gold text-[10px] tracking-[3px]">FINANÇAS</p>
          <h1 className="text-xl font-semibold">{greeting(state.settings.name)}</h1>
        </div>
      </div>

      <Card className="mt-4 !border-gold/30">
        <small className="text-mut">SALDO ATUAL</small>
        <div className="text-4xl font-bold mt-1">{formatBRL(bal)}</div>
        <SavingsBar percent={Math.max(0, rate)} label="Economia do mês" />
      </Card>

      <div className="my-3">
        <PeriodTabs period={period} onChange={setPeriod} />
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <Card><small className="text-mut">ENTRADAS</small><b className="block text-lg text-pos mt-1">{formatBRL(sumByType(filtered, 'income'))}</b></Card>
        <Card><small className="text-mut">SAÍDAS</small><b className="block text-lg text-neg mt-1">{formatBRL(sumByType(filtered, 'expense'))}</b></Card>
        <Card><small className="text-mut">RESERVADO</small><b className="block text-lg text-gold mt-1">{formatBRL(res)}</b></Card>
        <Card><small className="text-mut">SALDO LIVRE</small><b className="block text-lg mt-1">{formatBRL(bal - res)}</b></Card>
      </div>

      <ActionButtons onNewExpense={onNewExpense} onNewIncome={onNewIncome} />

      <small className="text-mut block mt-5 mb-2">ANÁLISE DO MÊS</small>
      <Card className="mb-2.5">
        <div className="flex justify-between text-sm">
          <span className="text-mut">Gastos vs. mês passado</span>
          <b className={diff > 0 ? 'text-neg' : 'text-pos'}>
            {expensePrev ? `${diff > 0 ? '+' : ''}${diff.toFixed(0)}%` : '—'}
          </b>
        </div>
        {cats[0] && (
          <div className="flex justify-between text-sm mt-2">
            <span className="text-mut">Maior categoria</span>
            <b>{cats[0][0]} · {formatBRL(cats[0][1])}</b>
          </div>
        )}
      </Card>
      {cats.length > 0 && (
        <Card className="space-y-1.5">
          {cats.slice(0, 5).map(([c, v]) => (
            <div key={c} className="flex items-center gap-2 text-sm">
              <span className="w-24 truncate">{c}</span>
              <div className="flex-1"><ProgressBar percent={(v / cats[0][1]) * 100} color="bg-neg" /></div>
              <b className="w-24 text-right">{formatBRL(v)}</b>
            </div>
          ))}
        </Card>
      )}
    </div>
  )
}

interface HomeVariantProps {
  state: AppState
  filtered: Transaction[]
  period: Period
  setPeriod: (p: Period) => void
  bal: number
  res: number
  onNewExpense: () => void
  onNewIncome: () => void
}

export function Home({ state, onNewExpense, onNewIncome }: HomeProps) {
  const [period, setPeriod] = useState<Period>('month')

  const filtered = useMemo(() => {
    const today = todayISO()
    return state.tx.filter((t) => {
      if (period === 'day') return t.date === today
      if (period === 'week') {
        const d = new Date()
        d.setDate(d.getDate() - 6)
        const from = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
        return t.date >= from && t.date <= today
      }
      const now = new Date()
      const key =
        period === 'prev'
          ? `${now.getFullYear()}-${String(now.getMonth()).padStart(2, '0')}`
          : `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      return t.date.startsWith(key)
    })
  }, [state.tx, period])

  const bal = balance(state.tx)
  const res = reserved(state.goals)
  const variantProps: HomeVariantProps = { state, filtered, period, setPeriod, bal, res, onNewExpense, onNewIncome }

  switch (state.settings.interfaceStyle) {
    case 'compacta':
      return <CompactaHome {...variantProps} />
    case 'minimalista':
      return <MinimalistaHome {...variantProps} />
    case 'avancada':
      return <AvancadaHome {...variantProps} />
    default:
      return <ClassicaHome {...variantProps} />
  }
}
