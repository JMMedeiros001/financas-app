import { useMemo, useState } from 'react'
import { AppState } from '@/lib/storage'
import { balance, reserved, sumByType, formatBRL, todayISO } from '@/lib/calc'
import { Card } from '@/components/Card'
import logo from '@/assets/logo.png'

type Period = 'day' | 'week' | 'month' | 'prev'

export function Home({
  state,
  onNewExpense,
  onNewIncome
}: {
  state: AppState
  onNewExpense: () => void
  onNewIncome: () => void
}) {
  const [period, setPeriod] = useState<Period>('month')

  const filtered = useMemo(() => {
    const today = todayISO()
    return state.tx.filter((t) => {
      if (period === 'day') return t.date === today
      if (period === 'week') {
        const d = new Date()
        d.setDate(d.getDate() - 6)
        const from = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
        return t.date >= from && t.date <= today
      }
      const now = new Date()
      const key =
        period === 'prev'
          ? `${now.getFullYear()}-${String(now.getMonth()).padStart(2, '0')}`
          : `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`
      return t.date.startsWith(key)
    })
  }, [state.tx, period])

  const bal = balance(state.tx)
  const res = reserved(state.goals)

  return (
    <div>
      <div className="flex items-center gap-3">
        <img src={logo} alt="" className="w-11 h-11 rounded-xl object-contain" />
        <div>
          <h1 className="text-2xl font-semibold">Olá{state.settings.name ? `, ${state.settings.name}` : ''}</h1>
          <p className="text-mut text-sm">Como estão suas finanças?</p>
        </div>
      </div>

      <Card className="mt-4">
        <small className="text-mut">SALDO ATUAL</small>
        <div className="text-4xl font-bold mt-1">{formatBRL(bal)}</div>
      </Card>

      <div className="flex gap-1.5 overflow-x-auto my-3">
        {([['day', 'Hoje'], ['week', 'Esta semana'], ['month', 'Este mês'], ['prev', 'Mês anterior']] as [Period, string][]).map(
          ([id, label]) => (
            <button
              key={id}
              onClick={() => setPeriod(id)}
              className={`px-3 py-1.5 text-sm rounded-lg border whitespace-nowrap ${period === id ? 'border-gold text-gold' : 'border-line text-mut'}`}
            >
              {label}
            </button>
          )
        )}
      </div>

      <div className="grid grid-cols-2 gap-2.5">
        <Card><small className="text-mut">ENTRADAS</small><b className="block text-lg text-pos mt-1">{formatBRL(sumByType(filtered, 'income'))}</b></Card>
        <Card><small className="text-mut">SAÍDAS</small><b className="block text-lg text-neg mt-1">{formatBRL(sumByType(filtered, 'expense'))}</b></Card>
        <Card><small className="text-mut">RESERVADO</small><b className="block text-lg text-gold mt-1">{formatBRL(res)}</b></Card>
        <Card><small className="text-mut">SALDO LIVRE</small><b className="block text-lg mt-1">{formatBRL(bal - res)}</b></Card>
      </div>

      <div className="flex gap-2 mt-4">
        <button onClick={onNewExpense} className="border border-line rounded-lg px-4 py-2.5 flex-1">- Gasto</button>
        <button onClick={onNewIncome} className="border border-line rounded-lg px-4 py-2.5 flex-1">+ Receita</button>
      </div>
    </div>
  )
}
