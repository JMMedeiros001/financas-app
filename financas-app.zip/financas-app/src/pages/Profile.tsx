import { useRef, useState } from 'react'
import { AppState, exportCSV, exportJSON, importJSON } from '@/lib/storage'
import { hashPin, verifyPin } from '@/lib/pin'
import { InterfaceStyle, STYLE_INFO } from '@/lib/styleInfo'
import { Card } from '@/components/Card'
import { Modal, inputClass } from '@/components/Modal'
import { StylePicker } from '@/components/StylePicker'

const LOCK_OPTIONS: [number, string][] = [
  [0, 'Imediatamente'],
  [1, 'Após 1 minuto'],
  [5, 'Após 5 minutos'],
  [15, 'Após 15 minutos'],
  [-1, 'Nunca']
]

function downloadFile(filename: string, content: string, mime: string) {
  const blob = new Blob([content], { type: mime })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export function Profile({
  state,
  onUpdateSettings,
  onReplaceData,
  onGoHome
}: {
  state: AppState
  onUpdateSettings: (patch: Partial<AppState['settings']>) => void
  onReplaceData: (tx: AppState['tx'], goals: AppState['goals']) => void
  // Mantidas por compatibilidade — dados de demonstração saíram da interface
  // (ver seção 7 do pedido), mas a função pode continuar existindo tecnicamente.
  onLoadDemo?: () => void
  onClearDemo?: () => void
  onGoHome: () => void
}) {
  const [pin, setPin] = useState('')
  const [msg, setMsg] = useState('')
  const [confirmingDeactivate, setConfirmingDeactivate] = useState(false)
  const [deactivatePin, setDeactivatePin] = useState('')
  const [deactivateError, setDeactivateError] = useState('')

  const [stylePanelOpen, setStylePanelOpen] = useState(false)
  const [draftStyle, setDraftStyle] = useState<InterfaceStyle>(state.settings.interfaceStyle)

  const [exportPanelOpen, setExportPanelOpen] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [importPreview, setImportPreview] = useState<{ tx: AppState['tx']; goals: AppState['goals'] } | null>(null)
  const [importError, setImportError] = useState('')

  const activatePin = async () => {
    if (!/^\d{4,6}$/.test(pin)) return setMsg('Use uma senha de 4 a 6 dígitos.')
    onUpdateSettings({ pinHash: await hashPin(pin) })
    setPin('')
    setMsg('Senha ativada.')
  }

  const confirmDeactivate = async () => {
    if (!(await verifyPin(deactivatePin, state.settings.pinHash))) {
      setDeactivateError('Senha incorreta.')
      return
    }
    onUpdateSettings({ pinHash: '' })
    setConfirmingDeactivate(false)
    setDeactivatePin('')
    setDeactivateError('')
  }

  const applyStyle = () => {
    onUpdateSettings({ interfaceStyle: draftStyle })
    setStylePanelOpen(false)
    onGoHome()
  }

  const doExport = (kind: 'json' | 'csv') => {
    const date = new Date().toISOString().slice(0, 10)
    if (kind === 'json') downloadFile(`financas-backup-${date}.json`, exportJSON(state), 'application/json')
    else downloadFile(`financas-backup-${date}.csv`, exportCSV(state), 'text/csv')
    setExportPanelOpen(false)
    setMsg('Backup exportado.')
  }

  const onFilePicked = async (file: File) => {
    setImportError('')
    try {
      const text = await file.text()
      const result = importJSON(state, text)
      if (!result) {
        setImportError('Arquivo inválido. Selecione um backup em JSON exportado pelo FINANÇAS.')
        return
      }
      setImportPreview({ tx: result.tx, goals: result.goals })
    } catch {
      setImportError('Não consegui ler esse arquivo.')
    }
  }

  const confirmImport = () => {
    if (!importPreview) return
    onReplaceData(importPreview.tx, importPreview.goals)
    setImportPreview(null)
    setMsg('Dados importados.')
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-3">Perfil</h1>

      <Card className="mb-2.5">
        <label className="block text-xs text-mut">
          Nome
          <input
            className={inputClass + ' mt-1'}
            value={state.settings.name}
            onChange={(e) => onUpdateSettings({ name: e.target.value })}
          />
        </label>
      </Card>

      <Card className="mb-2.5">
        <button
          onClick={() => {
            setDraftStyle(state.settings.interfaceStyle)
            setStylePanelOpen(true)
          }}
          className="w-full flex items-center gap-3 text-left"
        >
          <span className="text-xl">🎨</span>
          <span className="flex-1">
            <b className="block">Estilos</b>
            <small className="text-mut">{STYLE_INFO[state.settings.interfaceStyle].label}</small>
          </span>
          <span className="text-mut text-lg">›</span>
        </button>
      </Card>

      <Card className="mb-2.5">
        <small className="text-mut">SEGURANÇA</small>
        {state.settings.pinHash ? (
          <>
            <label className="block text-xs text-mut mt-3">
              Bloqueio automático
              <select
                className={inputClass + ' mt-1'}
                value={state.settings.autoLockMinutes}
                onChange={(e) => onUpdateSettings({ autoLockMinutes: +e.target.value })}
              >
                {LOCK_OPTIONS.map(([v, l]) => (
                  <option key={v} value={v}>{l}</option>
                ))}
              </select>
            </label>
            <button
              onClick={() => setConfirmingDeactivate(true)}
              className="border border-line rounded-lg px-4 py-2 text-neg mt-3"
            >
              Desativar senha
            </button>
          </>
        ) : (
          <>
            <label className="block text-xs text-mut mt-3">
              Senha (4 a 6 dígitos)
              <input className={inputClass + ' mt-1'} type="password" inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value)} />
            </label>
            <button onClick={activatePin} className="bg-gold text-black font-semibold rounded-lg px-4 py-2 mt-2">
              Ativar senha
            </button>
          </>
        )}
      </Card>

      <Card>
        <small className="text-mut">BACKUP E DADOS</small>
        <p className="text-mut text-sm mt-1 mb-3">Mantenha uma cópia segura das suas informações.</p>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setExportPanelOpen(true)} className="border border-line rounded-lg px-4 py-2 text-sm">
            Exportar dados
          </button>
          <button onClick={() => fileInputRef.current?.click()} className="border border-line rounded-lg px-4 py-2 text-sm">
            Importar backup
          </button>
        </div>
        <input
          ref={fileInputRef}
          type="file"
          accept=".json,application/json"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) onFilePicked(file)
            e.target.value = ''
          }}
        />
        {msg && <p className="text-mut text-sm mt-2">{msg}</p>}
      </Card>

      <Modal open={stylePanelOpen} onClose={() => setStylePanelOpen(false)}>
        <h2 className="text-lg font-semibold mb-1">Estilos</h2>
        <p className="text-mut text-sm mb-3">Escolha como o FINANÇAS apresentará suas informações.</p>
        <StylePicker value={draftStyle} onChange={setDraftStyle} />
        <button onClick={applyStyle} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 w-full mt-4">
          Aplicar
        </button>
      </Modal>

      <Modal open={exportPanelOpen} onClose={() => setExportPanelOpen(false)}>
        <h2 className="text-lg font-semibold mb-1">Exportar dados</h2>
        <p className="text-mut text-sm mb-3">Escolha o formato.</p>
        <div className="space-y-2">
          <button onClick={() => doExport('csv')} className="w-full text-left border border-line rounded-xl2 p-3">
            <b className="block">CSV</b>
            <small className="text-mut">Para abrir em planilhas.</small>
          </button>
          <button onClick={() => doExport('json')} className="w-full text-left border border-line rounded-xl2 p-3">
            <b className="block">JSON</b>
            <small className="text-mut">Para uma cópia completa dos dados.</small>
          </button>
        </div>
      </Modal>

      <Modal open={!!importPreview} onClose={() => setImportPreview(null)}>
        <h2 className="text-lg font-semibold mb-1">Confirmar importação</h2>
        {importPreview && (
          <p className="text-mut text-sm mb-3">
            Este backup tem {importPreview.tx.length} lançamento(s) e {importPreview.goals.length} meta(s). Importar
            substitui os dados atuais do aplicativo — essa ação não pode ser desfeita.
          </p>
        )}
        <div className="flex gap-2">
          <button onClick={confirmImport} className="bg-gold text-black font-semibold rounded-lg px-4 py-2.5 flex-1">
            Importar e substituir
          </button>
          <button onClick={() => setImportPreview(null)} className="border border-line rounded-lg px-4 py-2.5 flex-1">
            Cancelar
          </button>
        </div>
      </Modal>

      {importError && !importPreview && (
        <Modal open={!!importError} onClose={() => setImportError('')}>
          <h2 className="text-lg font-semibold mb-1">Não foi possível importar</h2>
          <p className="text-mut text-sm mb-3">{importError}</p>
          <button onClick={() => setImportError('')} className="border border-line rounded-lg px-4 py-2.5 w-full">
            Entendi
          </button>
        </Modal>
      )}

      <Modal
        open={confirmingDeactivate}
        onClose={() => {
          setConfirmingDeactivate(false)
          setDeactivatePin('')
          setDeactivateError('')
        }}
      >
        <h2 className="text-lg font-semibold mb-1">Desativar senha</h2>
        <p className="text-mut text-sm mb-3">Digite sua senha atual para confirmar.</p>
        <input
          className={inputClass}
          type="password"
          inputMode="numeric"
          maxLength={6}
          autoFocus
          value={deactivatePin}
          onChange={(e) => {
            setDeactivatePin(e.target.value)
            setDeactivateError('')
          }}
        />
        {deactivateError && <p className="text-neg text-sm mt-1">{deactivateError}</p>}
        <div className="flex gap-2 mt-3">
          <button onClick={confirmDeactivate} className="border border-line rounded-lg px-4 py-2 text-neg flex-1">
            Confirmar
          </button>
          <button
            onClick={() => {
              setConfirmingDeactivate(false)
              setDeactivatePin('')
              setDeactivateError('')
            }}
            className="border border-line rounded-lg px-4 py-2 flex-1"
          >
            Cancelar
          </button>
        </div>
      </Modal>
    </div>
  )
}
