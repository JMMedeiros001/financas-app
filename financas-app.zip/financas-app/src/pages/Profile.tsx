import { useState } from 'react'
import { AppState, exportCSV, exportJSON, importJSON } from '@/lib/storage'
import { hashPin, verifyPin } from '@/lib/pin'
import { InterfaceStyle } from '@/lib/styleInfo'
import { Card } from '@/components/Card'
import { Modal, inputClass } from '@/components/Modal'
import { StylePicker } from '@/components/StylePicker'

const LOCK_OPTIONS: [number, string][] = [
  [0, 'Imediatamente'],
  [1, 'Após 1 minuto'],
  [5, 'Após 5 minutos'],
  [15, 'Após 15 minutos'],
  [-1, 'Nunca']
]

export function Profile({
  state,
  onUpdateSettings,
  onReplaceData,
  onLoadDemo,
  onClearDemo
}: {
  state: AppState
  onUpdateSettings: (patch: Partial<AppState['settings']>) => void
  onReplaceData: (tx: AppState['tx'], goals: AppState['goals']) => void
  onLoadDemo: () => void
  onClearDemo: () => void
}) {
  const [pin, setPin] = useState('')
  const [text, setText] = useState('')
  const [msg, setMsg] = useState('')
  const [pendingStyle, setPendingStyle] = useState<InterfaceStyle>(state.settings.interfaceStyle)
  const [confirmingDeactivate, setConfirmingDeactivate] = useState(false)
  const [deactivatePin, setDeactivatePin] = useState('')
  const [deactivateError, setDeactivateError] = useState('')

  const activatePin = async () => {
    if (!/^\d{4,6}$/.test(pin)) return setMsg('Use uma senha de 4 a 6 dígitos.')
    onUpdateSettings({ pinHash: await hashPin(pin) })
    setPin('')
    setMsg('Senha ativada.')
  }

  const confirmDeactivate = async () => {
    if (!(await verifyPin(deactivatePin, state.settings.pinHash))) {
      setDeactivateError('Senha incorreta.')
      return
    }
    onUpdateSettings({ pinHash: '' })
    setConfirmingDeactivate(false)
    setDeactivatePin('')
    setDeactivateError('')
  }

  const doExport = (kind: 'json' | 'csv') => {
    const out = kind === 'json' ? exportJSON(state) : exportCSV(state)
    setText(out)
    navigator.clipboard?.writeText(out).catch(() => {})
    setMsg('Copiado para a área de transferência.')
  }

  const doImport = () => {
    const result = importJSON(state, text)
    if (!result) return setMsg('JSON inválido.')
    if (!confirm('Importar substitui seus dados atuais. Continuar?')) return
    onReplaceData(result.tx, result.goals)
    setMsg('Dados importados.')
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-3">Perfil</h1>

      <Card className="mb-2.5">
        <label className="block text-xs text-mut">
          Nome
          <input
            className={inputClass + ' mt-1'}
            value={state.settings.name}
            onChange={(e) => onUpdateSettings({ name: e.target.value })}
          />
        </label>
      </Card>

      <Card className="mb-2.5">
        <small className="text-mut">ESTILO DA INTERFACE</small>
        <p className="text-mut text-sm mt-1 mb-3">Escolha como o FINANÇAS deve apresentar suas informações.</p>
        <StylePicker value={pendingStyle} onChange={setPendingStyle} />
        <button
          onClick={() => onUpdateSettings({ interfaceStyle: pendingStyle })}
          className="bg-gold text-black font-semibold rounded-lg px-4 py-2 mt-3"
        >
          Aplicar
        </button>
      </Card>

      <Card className="mb-2.5">
        <small className="text-mut">SEGURANÇA</small>
        {state.settings.pinHash ? (
          <>
            <label className="block text-xs text-mut mt-3">
              Bloqueio automático
              <select
                className={inputClass + ' mt-1'}
                value={state.settings.autoLockMinutes}
                onChange={(e) => onUpdateSettings({ autoLockMinutes: +e.target.value })}
              >
                {LOCK_OPTIONS.map(([v, l]) => (
                  <option key={v} value={v}>{l}</option>
                ))}
              </select>
            </label>
            <button
              onClick={() => setConfirmingDeactivate(true)}
              className="border border-line rounded-lg px-4 py-2 text-neg mt-3"
            >
              Desativar senha
            </button>
          </>
        ) : (
          <>
            <label className="block text-xs text-mut mt-3">
              Senha (4 a 6 dígitos)
              <input className={inputClass + ' mt-1'} type="password" inputMode="numeric" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value)} />
            </label>
            <button onClick={activatePin} className="bg-gold text-black font-semibold rounded-lg px-4 py-2 mt-2">
              Ativar senha
            </button>
          </>
        )}
      </Card>

      <Card className="mb-2.5">
        <small className="text-mut">BACKUP</small>
        <div className="flex gap-2 flex-wrap mt-2 mb-2">
          <button onClick={() => doExport('json')} className="border border-line rounded-lg px-3 py-1.5 text-sm">Exportar JSON</button>
          <button onClick={() => doExport('csv')} className="border border-line rounded-lg px-3 py-1.5 text-sm">Exportar CSV</button>
          <button onClick={doImport} className="border border-line rounded-lg px-3 py-1.5 text-sm">Importar JSON</button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Exporte para copiar o texto, ou cole aqui um JSON para importar"
          className={inputClass + ' h-24'}
        />
        {msg && <p className="text-mut text-sm mt-1">{msg}</p>}
      </Card>

      <Card>
        <small className="text-mut">DADOS DE DEMONSTRAÇÃO</small>
        <div className="flex gap-2 mt-2">
          <button onClick={onLoadDemo} className="border border-line rounded-lg px-3 py-1.5 text-sm">Carregar demo</button>
          <button onClick={onClearDemo} className="border border-line rounded-lg px-3 py-1.5 text-sm">Limpar demo</button>
        </div>
      </Card>

      <Modal
        open={confirmingDeactivate}
        onClose={() => {
          setConfirmingDeactivate(false)
          setDeactivatePin('')
          setDeactivateError('')
        }}
      >
        <h2 className="text-lg font-semibold mb-1">Desativar senha</h2>
        <p className="text-mut text-sm mb-3">Digite sua senha atual para confirmar.</p>
        <input
          className={inputClass}
          type="password"
          inputMode="numeric"
          maxLength={6}
          autoFocus
          value={deactivatePin}
          onChange={(e) => {
            setDeactivatePin(e.target.value)
            setDeactivateError('')
          }}
        />
        {deactivateError && <p className="text-neg text-sm mt-1">{deactivateError}</p>}
        <div className="flex gap-2 mt-3">
          <button onClick={confirmDeactivate} className="border border-line rounded-lg px-4 py-2 text-neg flex-1">
            Confirmar
          </button>
          <button
            onClick={() => {
              setConfirmingDeactivate(false)
              setDeactivatePin('')
              setDeactivateError('')
            }}
            className="border border-line rounded-lg px-4 py-2 flex-1"
          >
            Cancelar
          </button>
        </div>
      </Modal>
    </div>
  )
}
