import { InterfaceStyle } from '@/lib/styleInfo'

export type TxType = 'income' | 'expense'

export interface Transaction {
  id: string
  type: TxType
  amount: number
  description: string
  category: string
  date: string // YYYY-MM-DD
  paymentMethod: string
  notes: string
  createdAt: string
  updatedAt: string
  demo?: boolean
}

export interface Goal {
  id: string
  name: string
  targetAmount: number
  currentAmount: number
  deadline: string
  icon: string
  color: string
  createdAt: string
  updatedAt: string
}

export interface AppSettings {
  name: string
  pinHash: string
  autoLockMinutes: number // -1 = nunca, 0 = imediatamente
  setupDone: boolean
  interfaceStyle: InterfaceStyle
}

export interface FinancialSettings {
  currency: string
}

export type PaymentType = 'divida' | 'emprestimo' | 'parcela'
export type PaymentStatus = 'pendente' | 'pago' | 'atrasado'

export interface Payment {
  id: string
  type: PaymentType
  name: string
  totalAmount: number
  installmentAmount: number
  installmentsTotal: number
  installmentsPaid: number
  dueDate: string // próximo vencimento, YYYY-MM-DD
  category: string
  notes: string
  createdAt: string
  updatedAt: string
}
