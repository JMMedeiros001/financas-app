import { Payment, PaymentType, PaymentStatus } from '@/types'
import { todayISO, formatBRL } from './calc'

export const PAYMENT_TYPE_LABEL: Record<PaymentType, string> = {
  divida: 'Dívida',
  emprestimo: 'Empréstimo',
  parcela: 'Parcela'
}

export const PAYMENT_TYPE_ICON: Record<PaymentType, string> = {
  divida: '📄',
  emprestimo: '🏦',
  parcela: '🧾'
}

/** Status sempre calculado a partir dos dados reais — nunca fica
 *  desatualizado, porque não existe um campo "status" salvo pra sincronizar
 *  manualmente: ele é sempre a verdade derivada de parcelas pagas/vencimento. */
export function paymentStatus(p: Payment): PaymentStatus {
  if (p.installmentsPaid >= p.installmentsTotal) return 'pago'
  if (p.dueDate && p.dueDate < todayISO()) return 'atrasado'
  return 'pendente'
}

export function installmentsRemaining(p: Payment): number {
  return Math.max(0, p.installmentsTotal - p.installmentsPaid)
}

export function remainingAmount(p: Payment): number {
  return installmentsRemaining(p) * p.installmentAmount
}

export function progressPercent(p: Payment): number {
  if (!p.installmentsTotal) return 0
  return Math.min(100, (p.installmentsPaid / p.installmentsTotal) * 100)
}

/** Avança a data de vencimento em um mês (mesmo dia do mês seguinte, com
 *  ajuste automático se o mês seguinte não tiver esse dia). */
export function nextMonth(dateISO: string): string {
  if (!dateISO) return dateISO
  const d = new Date(dateISO + 'T12:00:00')
  d.setMonth(d.getMonth() + 1)
  return d.toISOString().slice(0, 10)
}

export function formatRemaining(p: Payment): string {
  const left = installmentsRemaining(p)
  if (p.installmentsTotal <= 1) return left === 0 ? 'Quitado' : formatBRL(p.totalAmount)
  return `${left} de ${p.installmentsTotal} restante(s) · ${formatBRL(remainingAmount(p))}`
}
