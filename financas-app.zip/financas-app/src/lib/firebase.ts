// Integração com Firebase — OPCIONAL. O app funciona 100% offline sem isto.
//
// Para ativar (login por conta + sincronização entre aparelhos via Firestore):
// 1) crie um projeto em https://console.firebase.google.com
// 2) copie as chaves para o seu .env (veja .env.example) como VITE_FIREBASE_*
// 3) descomente o código abaixo e troque `readLocalState`/`writeLocalState`
//    (em src/hooks/useFinance.ts) para ler/escrever no Firestore em vez do localStorage
// 4) nas regras do Firestore, garanta que cada usuário só acesse os próprios dados, ex:
//      match /users/{uid}/{document=**} { allow read, write: if request.auth.uid == uid; }

/*
import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
}

export const firebaseApp = initializeApp(firebaseConfig)
export const auth = getAuth(firebaseApp)
export const db = getFirestore(firebaseApp)
*/

export const firebaseEnabled = false
