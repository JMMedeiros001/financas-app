// Integração real com Firebase (Auth + Firestore) — mas só ativa de verdade
// quando as variáveis VITE_FIREBASE_* existem (ver .env.example). Sem elas,
// `firebaseReady` fica false e auth/db ficam undefined — o resto do app
// (100% local) continua funcionando exatamente igual, sem quebrar nada.
//
// Como ativar:
// 1) crie um projeto em https://console.firebase.google.com
// 2) Build > Authentication > Sign-in method > ative "E-mail/senha"
// 3) Build > Firestore Database > criar banco
// 4) Project settings > seus apps > Web app > copie o firebaseConfig
// 5) preencha VITE_FIREBASE_* no seu .env (local) e como Secrets/Variables
//    no GitHub Actions (ver README, seção Backend)
// 6) publique as regras de segurança em firestore.rules (na raiz do projeto)
//    no Firestore do console — sem isso, ninguém consegue ler/escrever nada

import { initializeApp, FirebaseApp } from 'firebase/app'
import { getAuth, Auth } from 'firebase/auth'
import { getFirestore, Firestore } from 'firebase/firestore'

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
}

export const firebaseReady = Boolean(config.apiKey && config.projectId && config.appId)

let app: FirebaseApp | undefined
let authInstance: Auth | undefined
let dbInstance: Firestore | undefined

if (firebaseReady) {
  try {
    app = initializeApp(config)
    authInstance = getAuth(app)
    dbInstance = getFirestore(app)
  } catch {
    // Configuração presente mas inválida — o app continua funcionando local,
    // só a seção "Conta" no Perfil mostra que a nuvem está indisponível.
    app = undefined
    authInstance = undefined
    dbInstance = undefined
  }
}

export const auth = authInstance
export const db = dbInstance
