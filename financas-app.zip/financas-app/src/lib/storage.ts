// Armazenamento local do app. Usa localStorage por padrão (simples e síncrono,
// suficiente para o volume de dados de um app financeiro pessoal).
//
// Quer trocar por IndexedDB/SQLite (ex: para um app com anos de histórico)?
// Troque só este arquivo — o resto do app fala apenas com `loadState`/`saveState`,
// então a troca de motor de armazenamento não exige mexer em telas.

import { Transaction, Goal, AppSettings } from '@/types'

const KEY = 'financas:v1'

export interface AppState {
  tx: Transaction[]
  goals: Goal[]
  settings: AppSettings
}

export const defaultState: AppState = {
  tx: [],
  goals: [],
  settings: { name: '', pinHash: '', autoLockMinutes: 5, setupDone: false }
}

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(KEY)
    if (!raw) return structuredClone(defaultState)
    const parsed = JSON.parse(raw)
    return { ...structuredClone(defaultState), ...parsed }
  } catch {
    return structuredClone(defaultState)
  }
}

export function saveState(state: AppState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state))
    return true
  } catch {
    return false
  }
}

export function exportJSON(state: AppState) {
  return JSON.stringify({ tx: state.tx, goals: state.goals }, null, 2)
}

export function exportCSV(state: AppState) {
  const header = 'data,tipo,valor,categoria,descricao,forma_pagamento\n'
  const rows = state.tx
    .map((t) =>
      [t.date, t.type, t.amount, t.category, `"${(t.description || '').replace(/"/g, '""')}"`, t.paymentMethod || '']
        .join(',')
    )
    .join('\n')
  return header + rows
}

export function importJSON(state: AppState, json: string): AppState | null {
  try {
    const data = JSON.parse(json)
    if (!Array.isArray(data.tx) || !Array.isArray(data.goals)) return null
    return { ...state, tx: data.tx, goals: data.goals }
  } catch {
    return null
  }
}
