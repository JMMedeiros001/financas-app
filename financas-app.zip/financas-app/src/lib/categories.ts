export const EXPENSE_CATEGORIES = [
  'Alimentação', 'Moradia', 'Transporte', 'Saúde', 'Lazer',
  'Educação', 'Assinaturas', 'Outros'
] as const

export const INCOME_CATEGORIES = [
  'Salário', 'Freelance', 'Vendas', 'Investimentos', 'Extra', 'Outros'
] as const

export const PAYMENT_METHODS = [
  'Dinheiro', 'PIX', 'Débito', 'Crédito', 'Boleto', 'Transferência', 'Outro'
] as const

export const CATEGORY_ICON: Record<string, string> = {
  'Alimentação': '🍽️', 'Moradia': '🏠', 'Transporte': '🚗', 'Saúde': '💊',
  'Lazer': '🎮', 'Educação': '📚', 'Assinaturas': '🔁', 'Salário': '💼',
  'Freelance': '💻', 'Vendas': '🛍️', 'Investimentos': '📈', 'Extra': '✨', 'Outros': '•'
}
