// Este arquivo só descreve a FORMA dos dados que um backend real usaria no
// futuro — nada aqui está conectado a nada ainda, e nada disto é chamado
// pelo resto do aplicativo. É a "planta baixa" pedida na etapa de
// preparação de arquitetura (usuários, sessão, sincronização).
//
// Quando o backend existir de verdade, o formato local (AppState, em
// src/lib/storage.ts) migra pra isto sem perder dado nenhum: cada campo
// de AppState.settings mapeia direto pra UserAccount.settings, e
// AppState.tx/goals mapeiam direto pra FinanceData.tx/goals.

import { Transaction, Goal } from '@/types'
import { InterfaceStyle } from '@/lib/styleInfo'

export interface UserAccount {
  id: string
  name: string
  email: string
  createdAt: string
  settings: {
    interfaceStyle: InterfaceStyle
    autoLockMinutes: number
  }
}

export interface FinanceData {
  userId: string
  tx: Transaction[]
  goals: Goal[]
  updatedAt: string
}

// Um token de sessão nunca deve ser a senha em si, nem nada derivado dela
// de forma reversível — só uma referência opaca emitida pelo servidor
// depois da autenticação, com validade e possibilidade de revogação.
export interface Session {
  userId: string
  token: string
  expiresAt: string
}
