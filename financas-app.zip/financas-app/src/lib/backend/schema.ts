// Descreve a FORMA dos dados do backend. UserAccount/FinanceData documentam
// o modelo-alvo (ver README, seção Backend, sobre a decisão de manter os
// dados de finanças num único documento por usuário por enquanto, em vez de
// coleções separadas de Contas/Categorias).
//
// Session, por outro lado, já É real na prática: o Firebase Auth cuida disso
// sozinho (token, validade, renovação) — o objeto `User` retornado por
// src/lib/backend/auth.ts é a sessão de verdade. A interface abaixo continua
// documentando o conceito, útil se um dia o backend mudar de Firebase pra
// outra coisa que exija implementar isso na mão.

import { Transaction, Goal } from '@/types'
import { InterfaceStyle } from '@/lib/styleInfo'

export interface UserAccount {
  id: string
  name: string
  email: string
  createdAt: string
  updatedAt: string
  lastLoginAt: string
  status: 'active' | 'disabled'
  settings: {
    interfaceStyle: InterfaceStyle
    // autoLockMinutes fica de fora de propósito — é PIN, proteção local,
    // nunca sincroniza (ver sync.ts).
  }
  // Campo reservado pra quando Premium/assinaturas existirem (não
  // implementado nesta etapa — ver seção 25 do pedido).
  plan?: 'free' | 'premium'
}

export interface FinanceData {
  userId: string
  tx: Transaction[]
  goals: Goal[]
  updatedAt: string
}

// Um token de sessão nunca deve ser a senha em si, nem nada derivado dela
// de forma reversível — só uma referência opaca emitida pelo servidor
// depois da autenticação, com validade e possibilidade de revogação.
export interface Session {
  userId: string
  token: string
  expiresAt: string
}
