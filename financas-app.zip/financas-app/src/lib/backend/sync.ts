// Sincronização real com o Firestore. Cada usuário tem exatamente um
// documento (users/{uid}/financas/data) com o mesmo formato que já existe
// localmente (AppState.tx/goals/settings) — ver README sobre a decisão de
// não normalizar em coleções separadas ainda.
//
// Nada aqui roda sozinho: tanto enviar quanto baixar são ações explícitas
// do usuário (dois botões separados na seção "Conta" do Perfil), pelo mesmo
// motivo da importação de backup já existente — nunca sobrescrever dados
// silenciosamente.

import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore'
import { db, firebaseReady } from '@/lib/firebase'
import { AppState } from '@/lib/storage'

export function syncAvailable(): boolean {
  return firebaseReady && !!db
}

function userDocRef(uid: string) {
  if (!db) throw new Error('Sincronização em nuvem ainda não configurada.')
  return doc(db, 'users', uid, 'financas', 'data')
}

// O PIN (pinHash/autoLockMinutes) é proteção LOCAL do aparelho e nunca
// sincroniza — só nome e estilo da interface, que são preferências, não
// segurança. Ver seção 8 do pedido: autenticação e PIN são camadas
// independentes, não misturar.
export type SyncableSettings = { name: string; interfaceStyle: AppState['settings']['interfaceStyle'] }

export async function pushToServer(uid: string, state: AppState): Promise<void> {
  if (!syncAvailable()) throw new Error('Sincronização em nuvem ainda não configurada.')
  const settings: SyncableSettings = { name: state.settings.name, interfaceStyle: state.settings.interfaceStyle }
  await setDoc(userDocRef(uid), {
    tx: state.tx,
    goals: state.goals,
    payments: state.payments,
    settings,
    updatedAt: serverTimestamp()
  })
}

export interface RemoteData {
  tx: AppState['tx']
  goals: AppState['goals']
  payments: AppState['payments']
  settings: SyncableSettings
}

export async function pullFromServer(uid: string): Promise<RemoteData | null> {
  if (!syncAvailable()) return null
  const snap = await getDoc(userDocRef(uid))
  if (!snap.exists()) return null
  const data = snap.data()
  return {
    tx: data.tx || [],
    goals: data.goals || [],
    payments: data.payments || [],
    settings: data.settings || { name: '', interfaceStyle: 'classica' }
  }
}

/*
NOTAS DE SEGURANÇA:

- HTTPS obrigatório — o SDK do Firebase já garante isso sozinho.
- O token de sessão fica só na memória/armazenamento interno do SDK do
  Firebase, gerenciado por ele — este código nunca manuseia o token direto.
- A senha nunca passa por aqui nem é guardada por nós — vai direto pro
  Firebase Auth, que cuida do hash/salt do lado deles.
- Nenhuma chave secreta fica no app: os valores VITE_FIREBASE_* (ver
  src/lib/firebase.ts) são identificadores públicos do projeto, não
  segredos — a segurança de verdade está nas Security Rules do Firestore
  (ver firestore.rules na raiz do projeto), que rodam no servidor do
  Firebase e barram qualquer tentativa de um usuário ler/escrever dados
  de outro, mesmo que o app fosse adulterado.
*/
