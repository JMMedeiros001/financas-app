// Camada de sincronização — por enquanto só funções vazias (no-ops), que
// NADA no aplicativo chama ainda. O app continua 100% local (localStorage,
// ver src/lib/storage.ts) até que um backend real exista e estas funções
// sejam implementadas e ligadas ao fluxo real do app.
//
// Objetivo futuro: celular ↕ servidor ↕ versão web, mesmo usuário acessando
// os mesmos dados dos dois lados.

import { AppState } from '@/lib/storage'
import { Session } from './schema'

export async function pushToServer(_session: Session, _state: AppState): Promise<void> {
  // TODO: enviar tx/goals/settings pro servidor, autenticado pelo token da sessão.
  // Por enquanto não faz nada — os dados continuam só no localStorage do aparelho.
}

export async function pullFromServer(_session: Session): Promise<AppState | null> {
  // TODO: buscar o estado mais recente do servidor pra este usuário e
  // devolver no mesmo formato de AppState, pra continuar compatível com
  // tudo que já existe (useFinance.ts não precisaria mudar).
  return null
}

/*
NOTAS DE SEGURANÇA — ler antes de implementar de verdade:

- HTTPS obrigatório em qualquer chamada real; nunca HTTP puro.
- O token de sessão fica só em armazenamento seguro do dispositivo, nunca
  em log, nunca em URL.
- A senha do usuário nunca é comparada nem guardada em texto puro no
  servidor — hash com salt (bcrypt/argon2 ou equivalente), sempre do lado
  do servidor.
- Nenhuma chave secreta (de API, de banco de dados etc.) pode ficar no
  código do aplicativo — elas ficam só no servidor, do mesmo jeito que já
  é feito com a chave da IA (ver /api/ai.ts e a variável AI_API_KEY).
- O servidor sempre valida de novo quem é o dono de cada dado — o app
  instalado no celular pode ser adulterado por quem o tem em mãos, então
  confiar só na validação feita no frontend nunca é suficiente.
- Cada usuário só pode ler/escrever os próprios dados — mesmo princípio já
  documentado em src/lib/firebase.ts.
*/
