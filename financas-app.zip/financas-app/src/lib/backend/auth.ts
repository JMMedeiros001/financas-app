// Autenticação real via Firebase Auth. Toda função checa se o backend está
// configurado antes de tentar qualquer chamada — se não estiver, retorna um
// erro compreensível em vez de quebrar o aplicativo (ver seção 21 do pedido:
// o app não pode simplesmente quebrar quando o backend está indisponível).
//
// IMPORTANTE — isto é diferente do PIN: autenticação identifica QUEM é o
// usuário (pra sincronizar dados na nuvem); o PIN protege o acesso local ao
// aparelho. São camadas independentes — uma não substitui a outra.

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type User
} from 'firebase/auth'
import { auth, firebaseReady } from '@/lib/firebase'

export type { User }

export function authAvailable(): boolean {
  return firebaseReady && !!auth
}

export async function signUp(email: string, password: string): Promise<User> {
  if (!auth) throw new Error('Sincronização em nuvem ainda não configurada.')
  const cred = await createUserWithEmailAndPassword(auth, email, password)
  return cred.user
}

export async function signIn(email: string, password: string): Promise<User> {
  if (!auth) throw new Error('Sincronização em nuvem ainda não configurada.')
  const cred = await signInWithEmailAndPassword(auth, email, password)
  return cred.user
}

export async function signOutUser(): Promise<void> {
  if (!auth) return
  await signOut(auth)
}

/** Observa mudanças de sessão (login/logout/sessão restaurada ao reabrir o
 *  app). Se o backend não estiver configurado, chama callback(null) uma vez
 *  e não faz mais nada — nunca deixa o app esperando por algo que não existe. */
export function onAuthChange(callback: (user: User | null) => void): () => void {
  if (!auth) {
    callback(null)
    return () => {}
  }
  return onAuthStateChanged(auth, callback)
}

/** Traduz os erros mais comuns do Firebase Auth pra mensagens que fazem
 *  sentido pro usuário — nunca mostra detalhes internos do backend. */
export function authErrorMessage(err: unknown): string {
  const code = (err as { code?: string })?.code || ''
  if (code.includes('email-already-in-use')) return 'Já existe uma conta com esse e-mail.'
  if (code.includes('invalid-email')) return 'E-mail inválido.'
  if (code.includes('weak-password')) return 'A senha precisa ter pelo menos 6 caracteres.'
  if (code.includes('user-not-found') || code.includes('wrong-password') || code.includes('invalid-credential')) {
    return 'E-mail ou senha incorretos.'
  }
  if (code.includes('network-request-failed')) return 'Sem conexão com a internet.'
  if (code.includes('too-many-requests')) return 'Muitas tentativas. Aguarde um pouco e tente de novo.'
  return 'Não foi possível completar a operação.'
}
