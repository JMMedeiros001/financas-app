// Helpers compartilhados que traduzem o "estilo da interface" em pequenas
// diferenças de apresentação (densidade, o que mostrar) — sem duplicar
// nenhuma página. Cada página lê `state.settings.interfaceStyle` e usa
// estas funções puras para ajustar como já renderiza o mesmo conteúdo.

import { InterfaceStyle } from './styleInfo'

/** Espaçamento interno dos cards: mais apertado na Compacta, mais generoso na Minimalista. */
export function cardPad(style: InterfaceStyle): string {
  if (style === 'compacta') return '!p-3'
  if (style === 'minimalista') return '!p-5'
  return ''
}

/** Espaço entre blocos empilhados. */
export function stackGap(style: InterfaceStyle): string {
  if (style === 'compacta') return 'space-y-1.5'
  if (style === 'minimalista') return 'space-y-5'
  return 'space-y-2.5'
}

/**
 * Painéis de detalhe/análise (gráficos, quebra por categoria, atalhos extras)
 * só aparecem fora da Minimalista — o dado continua existindo e acessível
 * (o usuário troca de estilo quando quiser ver mais), só não ocupa espaço
 * na apresentação minimalista por padrão.
 */
export function showDetails(style: InterfaceStyle): boolean {
  return style !== 'minimalista'
}

export function isAdvanced(style: InterfaceStyle): boolean {
  return style === 'avancada'
}
