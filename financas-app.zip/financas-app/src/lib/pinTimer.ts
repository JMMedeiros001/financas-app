// Guarda, de forma persistida (sobrevive ao processo do app ser encerrado
// pelo Android), o momento em que o app foi para o segundo plano. Assim,
// tanto "voltar do segundo plano" quanto "reabrir depois de ter sido morto"
// usam exatamente a mesma lógica de tempo.

const KEY = 'financas:lastBackgroundedAt'

export function markBackgrounded() {
  try {
    localStorage.setItem(KEY, String(Date.now()))
  } catch {
    /* armazenamento indisponível — a proteção por tempo fica desativada, mas o app continua funcionando */
  }
}

export function clearBackgrounded() {
  try {
    localStorage.removeItem(KEY)
  } catch {
    /* nada a fazer */
  }
}

/**
 * autoLockMinutes: -1 = nunca bloquear, 0 = bloquear imediatamente, N = bloquear após N minutos.
 * Sem nenhum registro de "foi pro segundo plano" (primeira abertura, ou nunca saiu do app
 * nesta instalação), não bloqueia — não há tempo decorrido para comparar.
 */
export function shouldLock(autoLockMinutes: number): boolean {
  if (autoLockMinutes < 0) return false
  let raw: string | null = null
  try {
    raw = localStorage.getItem(KEY)
  } catch {
    return false
  }
  if (!raw) return false
  const elapsedMs = Date.now() - Number(raw)
  return elapsedMs >= autoLockMinutes * 60_000
}
