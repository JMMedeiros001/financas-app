// IA financeira: primeiro tenta a função serverless em /api/ai (IA real, via
// sua própria chave de API guardada só no servidor). Se essa rota não existir
// (ex: rodando só com `npm run dev`) ou falhar por qualquer motivo, cai
// automaticamente no interpretador por regras abaixo — o app nunca trava.

import { AppState } from './storage'
import { EXPENSE_CATEGORIES, INCOME_CATEGORIES } from './categories'
import { sumByType, byCategory, balance, reserved, monthKey, inMonth, formatBRL } from './calc'

export type AiAction =
  | { action: 'register'; type: 'income' | 'expense'; amount: number; category: string; description: string }
  | { action: 'answer'; text: string }
  | { action: 'ask'; text: string }

function monthSummary(state: AppState) {
  const key = monthKey(0)
  const ms = state.tx.filter((t) => inMonth(t, key))
  const income = sumByType(ms, 'income')
  const expense = sumByType(ms, 'expense')
  const cats = byCategory(ms, 'expense')
  const prevExpense = sumByType(state.tx.filter((t) => inMonth(t, monthKey(1))), 'expense')
  return { income, expense, cats, prevExpense, free: balance(state.tx) - reserved(state.goals) }
}

function buildPrompt(state: AppState, question: string) {
  const s = monthSummary(state)
  const cats = s.cats.length ? s.cats.map(([c, v]) => `${c}: ${formatBRL(v)}`).join(', ') : 'nenhum'
  const goals = state.goals.length
    ? state.goals.map((g) => `${g.name}: ${formatBRL(g.currentAmount)}/${formatBRL(g.targetAmount)}`).join('; ')
    : 'nenhuma'

  return `Você é a IA financeira do app FINANÇAS. Responda sempre em português do Brasil, direto, no máximo 4 frases. Nunca invente números: use só os dados abaixo.

DADOS DO MÊS ATUAL
Entradas: ${formatBRL(s.income)}
Saídas: ${formatBRL(s.expense)}
Saldo livre: ${formatBRL(s.free)}
Gastos por categoria: ${cats}
Gastos do mês passado: ${formatBRL(s.prevExpense)}
Metas: ${goals}

O usuário pode pedir para REGISTRAR um lançamento ou fazer uma PERGUNTA/análise.
Responda SOMENTE em JSON, em uma destas formas:
{"action":"register","type":"income"|"expense","amount":number,"category":string,"description":string}
Categorias de gasto: ${EXPENSE_CATEGORIES.join(', ')}. Categorias de receita: ${INCOME_CATEGORIES.join(', ')}.
{"action":"ask","text":string} — se faltar informação para registrar
{"action":"answer","text":string} — para responder ou analisar

Mensagem do usuário: "${question.replace(/"/g, "'")}"`
}

async function askServer(state: AppState, question: string): Promise<AiAction> {
  const res = await fetch('/api/ai', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ prompt: buildPrompt(state, question) })
  })
  if (!res.ok) throw new Error('server_ai_unavailable')
  const data = await res.json()
  if (!data || !data.action) throw new Error('bad_ai_response')
  return data as AiAction
}

// --- Interpretador local por regras (funciona sem servidor, sem chave, offline) ---

const KEYWORDS: Record<string, RegExp> = {
  'Alimentação': /almo|jant|lanch|mercado|comida|pizza|café|padaria|restaurante|ifood/,
  'Transporte': /uber|\b99\b|ônibus|onibus|gasolina|combust|metrô|táxi|taxi/,
  'Moradia': /aluguel|luz|água|agua|condom|internet/,
  'Saúde': /farmácia|farmacia|remédio|remedio|médico|medico|consulta/,
  'Lazer': /cinema|jogo|festa|show|viagem/,
  'Educação': /curso|livro|escola|faculdade/,
  'Assinaturas': /netflix|spotify|assinatura|prime|youtube/
}

function parseAmount(text: string): number | null {
  const m = text.match(/(\d+(?:[.,]\d+)*)\s*(mil\b|k\b)?/i)
  if (!m) return null
  let raw = m[1]
  raw = /,\d{1,2}$/.test(raw) ? raw.replace(/\./g, '').replace(',', '.') : raw.replace(/[.,]/g, '')
  let val = parseFloat(raw)
  if (m[2]) val *= 1000
  return val
}

function guessCategory(text: string, income: boolean): string | null {
  if (income) {
    if (/sal[aá]rio/.test(text)) return 'Salário'
    if (/freela/.test(text)) return 'Freelance'
    if (/venda|vendi/.test(text)) return 'Vendas'
    if (/invest|rendimento/.test(text)) return 'Investimentos'
    return null
  }
  for (const [cat, re] of Object.entries(KEYWORDS)) if (re.test(text)) return cat
  return null
}

function localInterpret(state: AppState, question: string): AiAction {
  const l = question.toLowerCase().trim()
  const s = monthSummary(state)
  const v = parseAmount(l)

  if (/^(gastei|paguei|comprei|recebi|ganhei)/.test(l) && v) {
    const income = /^(recebi|ganhei)/.test(l)
    const desc = l.replace(/^.*?\d[\d.,]*\s*(mil\b|k\b)?\s*(reais|real|r\$)?\s*(de |do |da |no |na |em |com |para |pra )?/, '')
    const description = desc ? desc[0].toUpperCase() + desc.slice(1) : income ? 'Receita' : 'Gasto'
    const category = guessCategory(l, income) || 'Outros'
    return { action: 'register', type: income ? 'income' : 'expense', amount: v, category, description }
  }

  const goalMatch = l.match(/(\d+)\s*mes/)
  if (v && goalMatch) {
    const months = +goalMatch[1]
    const r = reserved(state.goals)
    if (r >= v) return { action: 'answer', text: 'Você já tem reservado o suficiente para esse valor.' }
    return {
      action: 'answer',
      text: r > 0
        ? `Faltam ${formatBRL(v - r)} (você já tem ${formatBRL(r)} reservado): ${formatBRL((v - r) / months)} por mês durante ${months} meses.`
        : `${formatBRL(v)} ÷ ${months} = ${formatBRL(v / months)} por mês.`
    }
  }

  if (/quanto gastei/.test(l))
    return { action: 'answer', text: s.expense ? `Neste mês você gastou ${formatBRL(s.expense)}.` : 'Ainda não há gastos registrados neste mês.' }
  if (/maior despesa/.test(l)) {
    const top = [...state.tx].filter((t) => inMonth(t, monthKey(0)) && t.type === 'expense').sort((a, b) => b.amount - a.amount)[0]
    return { action: 'answer', text: top ? `Sua maior despesa do mês: ${top.description || top.category}, ${formatBRL(top.amount)}.` : 'Sem despesas registradas neste mês.' }
  }
  if (/gastando (mais|demais)/.test(l))
    return { action: 'answer', text: s.cats.length ? `Sua maior categoria é ${s.cats[0][0]}: ${formatBRL(s.cats[0][1])} (${((s.cats[0][1] / s.expense) * 100).toFixed(0)}% dos gastos).` : 'Sem gastos neste mês para analisar.' }
  if (/economizei|economia/.test(l))
    return { action: 'answer', text: s.income ? `Entrou ${formatBRL(s.income)} e saiu ${formatBRL(s.expense)}: economia de ${formatBRL(s.income - s.expense)}.` : 'Sem receitas neste mês para calcular a economia.' }
  if (/compar|m[eê]s passado/.test(l))
    return { action: 'answer', text: s.prevExpense ? `Mês passado: ${formatBRL(s.prevExpense)}. Este mês: ${formatBRL(s.expense)}.` : 'Não há gastos do mês passado para comparar.' }
  if (/saldo/.test(l))
    return { action: 'answer', text: `Saldo livre: ${formatBRL(s.free)}.` }

  return { action: 'answer', text: 'Posso registrar ("gastei 50 no almoço") ou responder sobre gastos, saldo, categorias e metas.' }
}

export async function interpret(state: AppState, question: string): Promise<{ result: AiAction; usedServer: boolean }> {
  try {
    return { result: await askServer(state, question), usedServer: true }
  } catch {
    return { result: localInterpret(state, question), usedServer: false }
  }
}
