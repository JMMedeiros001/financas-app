import { Transaction, Goal } from '@/types'

export const sumByType = (tx: Transaction[], type: 'income' | 'expense') =>
  tx.filter((t) => t.type === type).reduce((s, t) => s + t.amount, 0)

export const balance = (tx: Transaction[]) => sumByType(tx, 'income') - sumByType(tx, 'expense')

export const reserved = (goals: Goal[]) => goals.reduce((s, g) => s + g.currentAmount, 0)

export const freeBalance = (tx: Transaction[], goals: Goal[]) => balance(tx) - reserved(goals)

export const savingsRate = (tx: Transaction[]) => {
  const income = sumByType(tx, 'income')
  if (!income) return 0
  return ((income - sumByType(tx, 'expense')) / income) * 100
}

export const goalProgress = (g: Goal) => (g.targetAmount ? (g.currentAmount / g.targetAmount) * 100 : 0)

export const byCategory = (tx: Transaction[], type: 'income' | 'expense' = 'expense') => {
  const map = new Map<string, number>()
  tx.filter((t) => t.type === type).forEach((t) => map.set(t.category, (map.get(t.category) || 0) + t.amount))
  return [...map.entries()].sort((a, b) => b[1] - a[1])
}

export const monthKey = (offset = 0) => {
  const d = new Date()
  d.setDate(1)
  d.setMonth(d.getMonth() - offset)
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

export const inMonth = (t: Transaction, key: string) => t.date.startsWith(key)

export const formatBRL = (n: number) =>
  n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })

export const todayISO = () => {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
}
