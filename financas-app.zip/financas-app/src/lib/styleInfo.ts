export type InterfaceStyle = 'classica' | 'compacta' | 'minimalista' | 'avancada'

export const STYLE_INFO: Record<InterfaceStyle, { label: string; description: string }> = {
  classica: {
    label: 'Clássica',
    description: 'Simples e direta. Tudo que você precisa, sem complicação.'
  },
  compacta: {
    label: 'Compacta',
    description: 'Mais informações em menos espaço. Ideal para praticidade.'
  },
  minimalista: {
    label: 'Minimalista',
    description: 'Apenas o essencial. Limpa, leve e elegante.'
  },
  avancada: {
    label: 'Avançada',
    description: 'Mais informações, gráficos e análises. Para acompanhar suas finanças em detalhes.'
  }
}

export const STYLE_ORDER: InterfaceStyle[] = ['classica', 'compacta', 'minimalista', 'avancada']
