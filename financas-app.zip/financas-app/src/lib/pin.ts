// A senha nunca é guardada em texto puro — só o hash SHA-256 (via Web Crypto API nativa).
export async function hashPin(pin: string): Promise<string> {
  const data = new TextEncoder().encode('financas$' + pin)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

export async function verifyPin(pin: string, hash: string): Promise<boolean> {
  return (await hashPin(pin)) === hash
}
