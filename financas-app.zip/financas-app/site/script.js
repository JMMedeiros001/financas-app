// Link do APK — configure aqui (ou via variável de ambiente APP_DOWNLOAD_URL no seu processo de build).
const APP_DOWNLOAD_URL = ""; // ex: "https://github.com/seu-usuario/financas/releases/download/v1/financas.apk"

const dlBtn = document.getElementById('dlBtn')
if (APP_DOWNLOAD_URL) {
  dlBtn.href = APP_DOWNLOAD_URL
  dlBtn.textContent = 'BAIXAR APK'
} else {
  dlBtn.removeAttribute('href')
  dlBtn.style.opacity = '.6'
  dlBtn.style.cursor = 'default'
  dlBtn.textContent = 'Download em breve'
}

const burger = document.getElementById('burger')
const nav = document.getElementById('nav')
burger?.addEventListener('click', () => nav.classList.toggle('open'))
nav?.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => nav.classList.remove('open')))
