# FINANÇAS

App de finanças pessoais — site + aplicativo web/PWA/Android, com IA financeira,
senha opcional e estrutura preparada para Firebase.

> ⚠️ **Importante sobre este projeto**: ele foi gerado num ambiente de chat sem
> acesso à internet, então **`npm install` nunca foi executado aqui** e o build
> nunca foi testado de fato. O código foi escrito com cuidado, mas rode
> `npm install && npm run build` na sua máquina e me avise se algum erro aparecer.

---

## 1. O que foi implementado

**App** (`/src`, React + TypeScript + Vite + Tailwind):
- Início: saldo atual, entradas/saídas/reservado/saldo livre, seletor de período
- Finanças: navegação por mês, saldo livre, taxa de economia, gráfico de fluxo do
  mês (Recharts), gastos por categoria (toque para filtrar), lista de lançamentos
  com editar/excluir e filtros
- Registrar gasto/receita: formulário completo (valor, descrição, categoria, data,
  forma de pagamento/origem, observação)
- Metas: criar, adicionar/retirar dinheiro, progresso, exclusão — afeta o saldo livre
- Relatórios: mês/trimestre/ano, gastos por categoria, maiores despesas, gráfico de
  evolução mensal (Recharts)
- IA financeira: comandos naturais ("gastei 50 no almoço", "recebi 2 mil de
  salário"), perguntas sobre saldo/gastos/categorias/metas, cálculo de metas
  ("notebook de R$4.000 em 8 meses"). Tenta primeiro a função serverless
  `/api/ai` (IA real); se não houver ou falhar, cai num interpretador local por
  regras — o app nunca trava por causa da IA
- Senha opcional (PIN 4-6 dígitos, guardado só como hash SHA-256), bloqueio
  automático configurável, tela de bloqueio que oculta os dados
- Backup: exportar/importar JSON, exportar CSV
- Dados de demonstração isolados (marcados e removíveis separadamente)
- Tudo calculado a partir dos dados reais — nenhum valor fixo no código
- PWA: `manifest.json` + service worker (cache do app shell para abrir offline
  depois da primeira visita)
- Estrutura pronta para Capacitor (Android) e para Firebase (ambos opcionais)

**Site** (`/site`, HTML/CSS/JS puro, mobile-first):
header com menu (hambúrguer no mobile), hero, recursos, como funciona, prévia do
app, segurança, seção de download com botão configurável, footer, meta tags de SEO/OG.

## 2. Estrutura do projeto

```
financas-app/
├── api/ai.ts            # função serverless (Vercel) — chama a IA com sua chave
├── public/               # manifest.json, ícones, service worker
├── site/                 # landing page (site oficial, estático)
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   └── assets/logo.png
├── src/
│   ├── main.tsx, App.tsx, index.css
│   ├── types.ts
│   ├── lib/               # storage, calc, categories, ai, pin, firebase
│   ├── hooks/useFinance.ts
│   ├── components/        # peças reutilizáveis (form, cards, nav, lock, onboarding)
│   ├── pages/              # Home, Finance, Goals, Reports, AI, Profile
│   └── assets/logo.png
├── capacitor.config.ts
├── vite.config.ts, tailwind.config.js, tsconfig*.json
└── .env.example
```

## 3. Como executar

```bash
npm install
npm run dev        # abre o app em http://localhost:5173
```

O `site/` é HTML estático — para testar localmente, abra `site/index.html`
direto no navegador ou sirva a pasta com qualquer servidor estático
(`npx serve site`).

A rota `/api/ai` só existe quando publicado na Vercel (ou testado localmente
com `vercel dev`, que exige a Vercel CLI). Rodando só `npm run dev`, essa rota
não existe e a IA cai automaticamente no modo por regras — isso é esperado.

## 4. Como publicar o site

1. Suba este projeto para um repositório Git (GitHub, GitLab, etc.)
2. Importe o repositório na [Vercel](https://vercel.com)
3. Configure a variável de ambiente `AI_API_KEY` em Project Settings → Environment
   Variables (necessária só para a IA real)
4. Deploy — a Vercel builda o app (`npm run build`) e publica `/api/ai`
   automaticamente como função serverless
5. Para publicar a landing page (`/site`) no mesmo domínio ou em outro,
   configure-a como um segundo projeto Vercel apontando para a pasta `site/`
   (ou publique-a em qualquer host de arquivos estáticos)

## 5. Como gerar o APK

Este ambiente de chat não tem Android SDK nem acesso à internet, então o APK
**não foi gerado aqui**. Duas formas reais de gerar:

**A) Sem instalar nada — deixe o GitHub compilar:**
Suba este projeto para um repositório no GitHub (com o arquivo
`.github/workflows/android-build.yml`, que já vem incluso). A cada push na
branch `main`, o GitHub compila o APK automaticamente. Baixe o resultado em:
aba **Actions** → o run mais recente → **Artifacts** → `financas-debug-apk`.
É um APK de debug (sem assinatura de release) — bom para testar no seu
celular, mas para publicar na Play Store você vai precisar assinar um build
de release depois.

**B) Localmente, com Android Studio:**
```bash
npm run build
npx cap add android      # só na primeira vez
npx cap sync android
npx cap open android      # abre no Android Studio
```
No Android Studio: Build → Build Bundle(s)/APK(s) → Build APK(s) (ou AAB para a
Play Store). Requer Android Studio + Android SDK instalados.

## 6. Onde colocar o link do APK

Depois de gerar e hospedar o APK (ex: GitHub Releases), edite:
`site/script.js` → constante `APP_DOWNLOAD_URL`. Enquanto estiver vazia, o
botão mostra "Download em breve" — não invente um link.

## 7. Onde substituir a logo

- `src/assets/logo.png` (usada no app)
- `site/assets/logo.png` (usada no site)
- `public/icons/icon-192.png` e `icon-512.png` (ícone do PWA/instalação)
- `public/favicon.png` (favicon)
- `assets/icon.png` (1024×1024) — fonte do **ícone do app Android** (o que aparece
  na tela inicial, na lista de apps e na tela de instalação do APK). É
  diferente das demais: não existe pasta `android/` neste zip (ela só é
  criada durante o build no GitHub). A etapa "Gerar o ícone do app Android"
  do workflow (`.github/workflows/android-build.yml`) roda
  `scripts/generate-android-icons.py`, que grava o ícone legado E o ícone
  adaptativo (Android 8+) direto nos arquivos que o Android espera — os dois
  precisam ser gerados, porque o adaptativo tem prioridade na tela inicial
  em qualquer Android recente, e é o que uma ferramenta usada numa versão
  anterior deste projeto não estava configurando direito. O próprio workflow
  falha com um erro claro se, por algum motivo, o ícone não for gerado —
  então um build verde na aba Actions já é garantia de que o ícone certo
  está no APK.

Mantenha os mesmos nomes de arquivo para não precisar mexer no código, ou
atualize as referências em `index.html` / `site/index.html`.

## 8. Onde substituir as imagens do aplicativo

A seção "Apresentação do app" do site (`site/index.html`, dentro da `<section>`
sem id logo após "Como funciona") usa `site/assets/logo.png` como espaço
reservado. Troque por `site/assets/app-preview.png` com capturas de tela reais
quando tiver.

## 9. Como configurar a IA

A chave da IA **nunca fica no frontend**. Ela mora só em `api/ai.ts`, lida via
`process.env.AI_API_KEY` no servidor:

1. Crie uma chave em https://console.anthropic.com
2. Na Vercel: Project Settings → Environment Variables → `AI_API_KEY`
3. Redeploy — pronto, a IA real passa a responder em `/api/ai`

Sem essa chave configurada, o app funciona normalmente com o interpretador
local por regras (sem custo, sem internet).

## 10. Como configurar o Firebase (futuramente)

O app funciona 100% local sem Firebase. Para ativar login + sincronização entre
aparelhos, siga os comentários em `src/lib/firebase.ts`: crie um projeto no
Firebase, preencha as variáveis `VITE_FIREBASE_*` no `.env`, descomente o
código do arquivo, e troque a leitura/escrita de `src/lib/storage.ts` (hoje em
`localStorage`) para o Firestore. Lembre de restringir as regras do Firestore
para cada usuário só acessar os próprios dados.

## 11. O que ficou pendente

- **`npm install` e o build nunca foram executados** — este ambiente não tem
  acesso à internet para baixar pacotes. Rode localmente e me avise se algo
  quebrar.
- **APK real**: a estrutura do Capacitor está pronta, mas o APK em si não foi
  gerado (precisa de Android Studio/SDK, que não existem aqui).
- **Deploy real na Vercel**: não foi feito — é um passo seu, com sua conta.
- **Firebase**: só a estrutura/comentários existem; nenhum projeto Firebase foi
  criado ou conectado.
- **IA real**: o código está pronto, mas só funciona depois de você configurar
  sua própria `AI_API_KEY` na Vercel.
- **SQLite/IndexedDB**: o armazenamento local usa `localStorage` (mais simples
  e suficiente para uso pessoal); `src/lib/storage.ts` foi isolado de propósito
  para trocar por IndexedDB/SQLite depois, se quiser, sem mexer nas telas.
- **Capturas de tela reais** do app na seção de apresentação do site — hoje é
  só a logo como espaço reservado.
