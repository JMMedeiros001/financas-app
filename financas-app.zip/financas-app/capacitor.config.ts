import type { CapacitorConfig } from '@capacitor/cli'

const config: CapacitorConfig = {
  appId: 'com.financas.app',
  appName: 'FINANÇAS',
  webDir: 'dist',
  bundledWebRuntime: false
}

export default config
