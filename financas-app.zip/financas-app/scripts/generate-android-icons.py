#!/usr/bin/env python3
"""
Gera o ícone do launcher Android (legado + adaptativo) a partir de
assets/icon.png e grava direto nas pastas mipmap corretas dentro de
android/app/src/main/res/.

Roda depois de `npx cap add android` (que cria a pasta android/ com o
ícone padrão do Capacitor) e antes de `npx cap sync android`.

Por que um script próprio em vez de uma ferramenta de terceiros:
a geração automática usada antes não estava substituindo o ÍCONE
ADAPTATIVO (mipmap-anydpi-v26/ic_launcher.xml) — que é o que Android 8+
usa na tela inicial, com prioridade sobre o mipmap/ic_launcher.png
legado. Resultado: o ícone azul padrão do Capacitor continuava
aparecendo mesmo com o build passando. Este script escreve os dois
conjuntos de arquivos (legado E adaptativo) manualmente, nos caminhos
exatos que o Android espera, sem depender de um comportamento que não
conseguimos inspecionar/testar offline.
"""
import sys
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "assets" / "icon.png"
RES = ROOT / "android" / "app" / "src" / "main" / "res"

# (pasta, tamanho do ícone legado em px, tamanho do foreground adaptativo em px)
DENSITIES = [
    ("mipmap-mdpi", 48, 108),
    ("mipmap-hdpi", 72, 162),
    ("mipmap-xhdpi", 96, 216),
    ("mipmap-xxhdpi", 144, 324),
    ("mipmap-xxxhdpi", 192, 432),
]

BG_COLOR = "#0b0b0c"      # mesma cor de fundo do app (--bg / bg-bg no Tailwind)
SAFE_ZONE_SCALE = 0.72    # zona segura recomendada pelo Android p/ ícone adaptativo


def main() -> None:
    if not SRC.exists():
        print(f"ERRO: não encontrei {SRC}", file=sys.stderr)
        sys.exit(1)
    if not RES.exists():
        print(f"ERRO: {RES} não existe — rode isto depois de 'npx cap add android'", file=sys.stderr)
        sys.exit(1)

    src = Image.open(SRC).convert("RGBA")

    for folder, legacy_size, fg_size in DENSITIES:
        d = RES / folder
        d.mkdir(parents=True, exist_ok=True)

        # Ícone legado (Android < 8 e fallback geral)
        legacy = src.resize((legacy_size, legacy_size), Image.LANCZOS)
        legacy.save(d / "ic_launcher.png")
        legacy.save(d / "ic_launcher_round.png")

        # Camada de primeiro plano do ícone adaptativo (Android 8+),
        # centralizada na "zona segura" pra não ser cortada pela máscara
        # do launcher (círculo, quadrado arredondado, "squircle" etc.)
        canvas = Image.new("RGBA", (fg_size, fg_size), (0, 0, 0, 0))
        inner = int(fg_size * SAFE_ZONE_SCALE)
        icon_scaled = src.resize((inner, inner), Image.LANCZOS)
        offset = (fg_size - inner) // 2
        canvas.paste(icon_scaled, (offset, offset), icon_scaled)
        canvas.save(d / "ic_launcher_foreground.png")

    # Cor de fundo do ícone adaptativo como recurso de cor (não precisa de PNG)
    values_dir = RES / "values"
    values_dir.mkdir(parents=True, exist_ok=True)
    (values_dir / "ic_launcher_background.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        "<resources>\n"
        f'    <color name="ic_launcher_background">{BG_COLOR}</color>\n'
        "</resources>\n"
    )

    # Definição do ícone adaptativo (Android 8 / API 26+) — sobrescreve a
    # do template padrão do Capacitor, que apontava pro logo azul deles.
    anydpi = RES / "mipmap-anydpi-v26"
    anydpi.mkdir(parents=True, exist_ok=True)
    adaptive_xml = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
        '    <background android:drawable="@color/ic_launcher_background"/>\n'
        '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n'
        "</adaptive-icon>\n"
    )
    (anydpi / "ic_launcher.xml").write_text(adaptive_xml)
    (anydpi / "ic_launcher_round.xml").write_text(adaptive_xml)

    print("Ícones do Android gerados a partir de assets/icon.png (legado + adaptativo).")


if __name__ == "__main__":
    main()
