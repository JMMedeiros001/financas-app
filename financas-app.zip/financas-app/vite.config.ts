import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
// PWA: manifest.json e sw.js são escritos à mão em /public (copiados como estão
// para o build) e registrados manualmente em src/main.tsx — de propósito, sem
// plugin de geração automática, para manter o comportamento previsível.
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: { '@': '/src' }
  },
  server: { port: 5173 }
})
