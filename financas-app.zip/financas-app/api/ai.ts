// Função serverless da Vercel (roda em /api/ai). A chave AI_API_KEY só existe
// aqui, no servidor — nunca é enviada para o navegador do usuário.
//
// Configure em: Vercel → seu projeto → Settings → Environment Variables → AI_API_KEY
// (chave da Anthropic, https://console.anthropic.com)

export const config = { runtime: 'edge' }

export default async function handler(req: Request): Promise<Response> {
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ action: 'answer', text: 'Método não suportado.' }), { status: 405 })
  }

  const apiKey = process.env.AI_API_KEY
  if (!apiKey) {
    return new Response(JSON.stringify({ action: 'answer', text: 'IA não configurada no servidor.' }), { status: 500 })
  }

  try {
    const { prompt } = await req.json()

    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-3-5-haiku-latest',
        max_tokens: 300,
        messages: [{ role: 'user', content: prompt }]
      })
    })

    if (!upstream.ok) {
      return new Response(JSON.stringify({ action: 'answer', text: 'A IA não respondeu. Tente de novo.' }), { status: 502 })
    }

    const data = await upstream.json()
    const raw: string = data?.content?.[0]?.text ?? ''
    const clean = raw.replace(/```json|```/g, '').trim()

    let parsed
    try {
      parsed = JSON.parse(clean)
    } catch {
      parsed = { action: 'answer', text: raw || 'Não entendi, pode reformular?' }
    }

    return new Response(JSON.stringify(parsed), { status: 200, headers: { 'content-type': 'application/json' } })
  } catch {
    return new Response(JSON.stringify({ action: 'answer', text: 'Erro ao falar com a IA.' }), { status: 500 })
  }
}
