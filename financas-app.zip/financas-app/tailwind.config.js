/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0b0b0c',
        card: '#17171a',
        line: '#2a2a2f',
        ink: '#f4f4f2',
        mut: '#8b8b93',
        gold: '#d4af37',
        pos: '#3ddc84',
        neg: '#ff5d73'
      },
      borderRadius: { xl2: '1.1rem' }
    }
  },
  plugins: []
}
